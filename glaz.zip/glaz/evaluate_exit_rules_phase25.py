import math
import time
from datetime import timedelta
from typing import Optional, Dict, Any, Tuple, List

import pandas as pd
import yfinance as yf

# ==================================================
# CONFIG
# ==================================================
INPUT_FILE = "trade_evaluation.csv"
OUTPUT_TRADES_FILE = "exit_rule_trade_results.csv"
OUTPUT_SUMMARY_FILE = "exit_rule_summary.csv"

INITIAL_CAPITAL_PER_TRADE = 1000.0
MAX_HOLDING_SESSIONS = 30          # approx. one trading month / 6 weeks calendar
HARD_STOP_PCT = -2.0               # current system stop
SLEEP_SECONDS = 0.25

# Fallback targets if your CSV does not contain t1/t2 columns
FALLBACK_T1_PCT = 5.0
FALLBACK_T2_PCT = 10.0

# Optional: skip symbols with no Yahoo data
VERBOSE = True

# ==================================================
# PHASE 1 SELECTION CONFIG
# ==================================================
# Goal: evaluate which theoretical trades would have been selected if
# market regime + relative strength + top-N selection had been applied.

PHASE1_ENABLED = True
PHASE1_TOP_N_PER_WEEK = 12                # select only top N trades per week
PHASE1_MIN_COMPOSITE_SCORE = 6.8          # minimum composite score 0-10; slightly less aggressive
PHASE1_REJECT_BEAR = False                # start soft; set True to hard-reject BEAR regimes
PHASE1_REJECT_NEGATIVE_RS = False         # optional hard filter; default soft scoring

# Component weights for composite score. Must roughly sum to 1.
# Phase 2 adds breakout quality + basic portfolio exposure controls.
PHASE1_WEIGHT_AI_GRADE = 0.10
PHASE1_WEIGHT_MARKET = 0.08
PHASE1_WEIGHT_REL_STRENGTH = 0.20
PHASE1_WEIGHT_SECTOR = 0.12
PHASE1_WEIGHT_VOLATILITY = 0.06
PHASE1_WEIGHT_EXTENSION = 0.09
PHASE1_WEIGHT_BREAKOUT = 0.13
# Phase 2.5 additions: breadth proxy, multi-timeframe alignment, accumulation/relative volume.
PHASE25_WEIGHT_BREADTH = 0.08
PHASE25_WEIGHT_MTF = 0.08
PHASE25_WEIGHT_ACCUMULATION = 0.06

# Lookback windows for regime / relative strength
REGIME_FAST_SMA = 21
REGIME_SLOW_SMA = 50
REL_STRENGTH_LOOKBACK_DAYS = 21
VOLATILITY_LOOKBACK_DAYS = 14
VIX_SYMBOL = "^VIX"

# Phase 2.5: extended-entry / chasing checks
EXTENSION_EMA_FAST = 10
EXTENSION_EMA_SLOW = 20
EXTENSION_DIST_EMA10_WARN_PCT = 4.0
EXTENSION_DIST_EMA10_BAD_PCT = 6.0
EXTENSION_DIST_EMA20_BAD_PCT = 8.0
EXTENSION_GAP_WARN_PCT = 1.5
EXTENSION_GAP_BAD_PCT = 3.0

# Phase 2: breakout quality scoring
# These are soft scoring inputs, not hard filters.
BREAKOUT_LOOKBACK_DAYS = 20
BREAKOUT_BASE_TIGHT_DAYS = 10
BREAKOUT_VOLUME_LOOKBACK_DAYS = 20
BREAKOUT_ATR_FAST_DAYS = 10
BREAKOUT_ATR_SLOW_DAYS = 30
BREAKOUT_TIGHT_BASE_GOOD_PCT = 6.0
BREAKOUT_TIGHT_BASE_OK_PCT = 10.0
BREAKOUT_EXTREME_RANGE_BAD_PCT = 18.0
BREAKOUT_CLOSE_POSITION_GOOD = 0.75
BREAKOUT_VOLUME_EXPANSION_GOOD = 1.3
BREAKOUT_ATR_COMPRESSION_GOOD = 0.85

# Phase 2.5: breadth / multi-timeframe / accumulation scoring.
BREADTH_EMA_FAST = 50
BREADTH_EMA_SLOW = 200
MTF_DAILY_EMA_FAST = 20
MTF_DAILY_EMA_SLOW = 50
MTF_WEEKLY_EMA = 10
ACCUM_LOOKBACK_DAYS = 20
ACCUM_VOLUME_RATIO_GOOD = 1.2
ACCUM_OBV_LOOKBACK_DAYS = 20

# Phase 2: portfolio exposure controls for weekly selected trades
PHASE2_USE_SECTOR_GROUP_QUOTAS = True
PHASE2_MAX_PER_SECTOR_GROUP_PER_WEEK = 3
PHASE2_USE_MARKET_REGION_QUOTAS = True
PHASE2_MARKET_REGION_QUOTAS = {
    "US_NASDAQ": 5,
    "US_NYSE": 5,
    "GREECE_ATHEX": 2,
    "EUROPE": 4,
    "UK_EUROPE": 3,
    "GLOBAL_DEFAULT": 3,
}

# Optional asset-class quotas so one market does not dominate selected trades.
PHASE1_USE_ASSET_CLASS_QUOTAS = True
PHASE1_ASSET_CLASS_QUOTAS = {
    "US_STOCK": 6,
    "US_ETF": 3,
    "EUROPE_STOCK": 4,
    "EUROPE_ETF": 3,
    "ATHEX": 2,
    "OTHER": 3,
}

OUTPUT_PHASE1_TRADES_FILE = "phase25_trade_selection.csv"
OUTPUT_PHASE1_SUMMARY_FILE = "phase25_exit_rule_summary.csv"
OUTPUT_PHASE1_COMPARISON_FILE = "phase25_all_vs_selected_summary.csv"


# ==================================================
# SYMBOL / DATA HELPERS
# ==================================================
def normalize_symbol(symbol: str) -> str:
    symbol = str(symbol).strip()
    if symbol.startswith("NASDAQ:"):
        return symbol.replace("NASDAQ:", "")
    if symbol.startswith("NYSE:"):
        return symbol.replace("NYSE:", "")
    if symbol.startswith("ATHEX:"):
        return symbol.replace("ATHEX:", "")
    return symbol


def flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df


def get_column_as_series(df: pd.DataFrame, col_name: str) -> pd.Series:
    col = df[col_name]
    if isinstance(col, pd.DataFrame):
        col = col.iloc[:, 0]
    return col.dropna()


def to_float(value) -> Optional[float]:
    if value is None or pd.isna(value):
        return None
    s = str(value).strip()
    if not s:
        return None
    try:
        return float(s.replace(",", "."))
    except Exception:
        return None


def first_valid_price(row: pd.Series, preferred_cols: List[str]) -> Optional[float]:
    # exact and case-insensitive column matching
    col_map = {str(c).strip().lower(): c for c in row.index}
    for wanted in preferred_cols:
        key = wanted.strip().lower()
        if key in col_map:
            val = to_float(row[col_map[key]])
            if val is not None:
                return val
    return None


def download_history(symbol: str, start, end) -> pd.DataFrame:
    hist = yf.download(
        symbol,
        start=start.strftime("%Y-%m-%d"),
        end=end.strftime("%Y-%m-%d"),
        progress=False,
        auto_adjust=False,
        group_by="column",
        threads=False,
    )
    if hist is None or hist.empty:
        return pd.DataFrame()
    hist = flatten_columns(hist)
    hist = hist.dropna(how="all")
    return hist


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    close = get_column_as_series(out, "Close")

    out["EMA5"] = close.ewm(span=5, adjust=False).mean()
    out["EMA10"] = close.ewm(span=10, adjust=False).mean()
    out["SMA5"] = close.rolling(5).mean()
    out["SMA10"] = close.rolling(10).mean()
    out["RET1"] = close.pct_change()

    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(14).mean()
    avg_loss = loss.rolling(14).mean()
    rs = avg_gain / avg_loss.replace(0, math.nan)
    out["RSI14"] = 100 - (100 / (1 + rs))
    out["RSI14_PREV"] = out["RSI14"].shift(1)

    return out


def pct(price: float, entry: float) -> float:
    return (price / entry - 1.0) * 100.0


def get_entry_price_from_row(row: pd.Series) -> Optional[float]:
    return first_valid_price(row, [
        "entry_price", "entry price", "ENTRY PRICE", "entry", "Entry", "ENTRY"
    ])


def get_t1_from_row(row: pd.Series, entry: float) -> Tuple[float, str]:
    explicit = first_valid_price(row, ["t1", "T1", "target1", "target_1", "target price 1"])
    if explicit is not None:
        return explicit, "CSV_T1"
    return entry * (1 + FALLBACK_T1_PCT / 100.0), f"FALLBACK_{FALLBACK_T1_PCT:.0f}PCT"


def get_t2_from_row(row: pd.Series, entry: float) -> Tuple[float, str]:
    explicit = first_valid_price(row, ["t2", "T2", "target2", "target_2", "target price 2"])
    if explicit is not None:
        return explicit, "CSV_T2"
    return entry * (1 + FALLBACK_T2_PCT / 100.0), f"FALLBACK_{FALLBACK_T2_PCT:.0f}PCT"


def get_stop_from_row(row: pd.Series, entry: float) -> Tuple[float, str]:
    explicit = first_valid_price(row, ["stop", "STOP", "stop_price", "stop price"])
    if explicit is not None:
        return explicit, "CSV_STOP"
    return entry * (1 + HARD_STOP_PCT / 100.0), f"FALLBACK_{HARD_STOP_PCT:.1f}PCT"


def prepare_trade_window(hist: pd.DataFrame, entry_date) -> pd.DataFrame:
    entry_date = pd.to_datetime(entry_date)
    window = hist[hist.index >= entry_date].copy()
    return window.iloc[:MAX_HOLDING_SESSIONS]


def infer_entry_price(row: pd.Series, window: pd.DataFrame) -> Tuple[Optional[float], str]:
    explicit = get_entry_price_from_row(row)
    if explicit is not None:
        return explicit, "CSV_ENTRY"

    # Fallback: use the first available close on/after entry_date.
    # This is a proxy, but it allows exit-rule testing from your compact CSV.
    if window.empty or "Close" not in window.columns:
        return None, "NO_ENTRY_AND_NO_PRICE_DATA"

    close = get_column_as_series(window, "Close")
    if close.empty:
        return None, "NO_ENTRY_AND_EMPTY_CLOSE"

    return float(close.iloc[0]), "INFERRED_ENTRY_FROM_ENTRY_DAY_CLOSE"



# ==================================================
# PHASE 1 MARKET / RELATIVE STRENGTH HELPERS
# ==================================================
def get_market_benchmark(symbol: str) -> Tuple[str, str]:
    """Return Yahoo benchmark and market region for a trade symbol."""
    s = str(symbol).strip().upper()
    if s.startswith("NASDAQ:"):
        return "QQQ", "US_NASDAQ"
    if s.startswith("NYSE:"):
        return "SPY", "US_NYSE"
    if s.startswith("ATHEX:"):
        return "GD.AT", "GREECE_ATHEX"
    if s.endswith(".DE"):
        return "VGK", "EUROPE_DE"
    if s.endswith(".PA"):
        return "VGK", "EUROPE_FR"
    if s.endswith(".MI"):
        return "VGK", "EUROPE_IT"
    if s.endswith(".L"):
        return "VGK", "UK"
    # ETFs / unknown symbols: use SPY as conservative default
    return "SPY", "GLOBAL_DEFAULT"




def get_sector_benchmark(symbol: str) -> Tuple[str, str]:
    """Approximate sector/industry ETF for Phase-1.5 sector momentum scoring.

    This is intentionally simple and explainable. Unknown / broad ETFs fall back to
    the same broad benchmark so they are not unfairly penalized.
    """
    s = str(symbol).strip().upper()
    raw = s.split(":")[-1] if ":" in s else s

    # ETFs / broad market
    if raw in {"SPY", "QQQ", "IWM", "DIA", "EQQQ.L", "SXR8.DE", "EXXT.DE", "EIMI.L", "XDEM.DE", "IQQH.DE", "SGLN.L"}:
        return get_market_benchmark(symbol)[0], "BROAD_ETF"

    # Greece / Europe broad fallback: sector ETFs are less reliable through Yahoo.
    if s.startswith("ATHEX:") or raw.endswith(".AT"):
        return "GD.AT", "GREECE_BROAD"
    if raw.endswith((".DE", ".PA", ".MI", ".L")):
        return "VGK", "EUROPE_BROAD"

    # US sector / industry mapping for common symbols in your universe.
    semis = {"NVDA", "AVGO", "LRCX", "TER", "AMD", "ASML", "MU", "KLAC", "AMAT", "SMH", "SOXX"}
    tech = {"AAPL", "MSFT", "ANET", "NET", "IDXX", "EA", "VRSN"}
    financials = {"BAC", "C", "JPM", "SCHW", "FITB", "USB", "CME", "UBS", "BCS", "SMFG", "PFG"}
    industrials = {"ETN", "CAT", "PCAR", "UPS", "LIN", "EMR", "CNI", "RR.L", "WEIR.L"}
    healthcare = {"UNH", "CI", "GSK", "AZN.L", "INCY", "VRTX", "INSM", "IDXX"}
    staples = {"PEP", "CL", "KO", "PG", "COST"}
    energy_materials = {"NEM", "RGLD", "APD"}
    real_estate = {"EQIX"}
    discretionary = {"CASY", "BIDU"}

    if raw in semis:
        return "SMH", "SEMICONDUCTORS"
    if raw in tech:
        return "XLK", "TECH"
    if raw in financials:
        return "XLF", "FINANCIALS"
    if raw in industrials:
        return "XLI", "INDUSTRIALS"
    if raw in healthcare:
        return "XLV", "HEALTHCARE"
    if raw in staples:
        return "XLP", "CONSUMER_STAPLES"
    if raw in energy_materials:
        return "XLB", "MATERIALS"
    if raw in real_estate:
        return "XLRE", "REAL_ESTATE"
    if raw in discretionary:
        return "XLY", "CONSUMER_DISCRETIONARY"

    return get_market_benchmark(symbol)[0], "SECTOR_UNKNOWN_BROAD_FALLBACK"


def classify_asset_class(symbol: str) -> str:
    """Broad bucket used only for Phase-1 weekly selection quotas."""
    s = str(symbol).strip().upper()
    if s.startswith("ATHEX:") or s.endswith(".AT"):
        return "ATHEX"
    if s in {"SPY", "QQQ", "IWM", "DIA", "EQQQ.L", "SXR8.DE", "EXXT.DE", "EIMI.L", "XDEM.DE", "IQQH.DE", "SGLN.L", "ARKK"}:
        if s.endswith((".DE", ".L", ".PA", ".MI")):
            return "EUROPE_ETF"
        return "US_ETF"
    if s.startswith(("NASDAQ:", "NYSE:")) or (":" not in s and "." not in s):
        return "US_STOCK"
    if s.endswith((".DE", ".PA", ".MI", ".L")):
        return "EUROPE_STOCK"
    return "OTHER"


def score_volatility_quality(stock_hist: pd.DataFrame, entry_date) -> Tuple[float, str, Optional[float]]:
    """Score recent volatility. Too little data -> neutral.

    Uses 14-day ATR% approximation. Very high ATR gets penalized because it
    usually turns a 2% stop into noise. Extremely low volatility is also not ideal,
    but it is less dangerous than excessive volatility for this strategy.
    """
    if stock_hist is None or stock_hist.empty or not {"High", "Low", "Close"}.issubset(stock_hist.columns):
        return 5.0, "VOL_UNKNOWN", None
    try:
        entry_date = pd.to_datetime(entry_date)
        h = stock_hist[stock_hist.index <= entry_date + timedelta(days=1)].copy()
        if len(h) < VOLATILITY_LOOKBACK_DAYS + 1:
            return 5.0, "VOL_INSUFFICIENT_DATA", None
        high = get_column_as_series(h, "High")
        low = get_column_as_series(h, "Low")
        close = get_column_as_series(h, "Close")
        prev_close = close.shift(1)
        tr = pd.concat([
            (high - low).abs(),
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ], axis=1).max(axis=1)
        atr = tr.rolling(VOLATILITY_LOOKBACK_DAYS).mean().iloc[-1]
        last_close = close.iloc[-1]
        if pd.isna(atr) or pd.isna(last_close) or float(last_close) <= 0:
            return 5.0, "VOL_UNKNOWN", None
        atr_pct = float(atr / last_close * 100.0)
        if atr_pct <= 1.2:
            return 7.0, "VOL_LOW_STABLE", atr_pct
        if atr_pct <= 2.5:
            return 10.0, "VOL_IDEAL", atr_pct
        if atr_pct <= 4.0:
            return 6.0, "VOL_ELEVATED", atr_pct
        if atr_pct <= 6.0:
            return 3.0, "VOL_HIGH_RISK", atr_pct
        return 1.0, "VOL_EXTREME_RISK", atr_pct
    except Exception:
        return 5.0, "VOL_ERROR", None

def safe_return(close: pd.Series, as_of_date, lookback_sessions: int) -> Optional[float]:
    """Return % change ending on/as-of entry date, using last available trading bar."""
    if close is None or close.empty:
        return None
    as_of_date = pd.to_datetime(as_of_date)
    s = close.sort_index()
    s = s[s.index <= as_of_date + timedelta(days=1)]
    if len(s) < lookback_sessions + 1:
        return None
    end_price = float(s.iloc[-1])
    start_price = float(s.iloc[-lookback_sessions - 1])
    if start_price <= 0:
        return None
    return (end_price / start_price - 1.0) * 100.0


def score_relative_strength(excess_return_pct: Optional[float]) -> Tuple[float, str]:
    """Convert stock-vs-benchmark 21d excess return into 0-10 score."""
    if excess_return_pct is None:
        return 5.0, "RS_UNKNOWN"
    if excess_return_pct >= 5.0:
        return 10.0, "RS_VERY_STRONG"
    if excess_return_pct >= 2.0:
        return 8.0, "RS_STRONG"
    if excess_return_pct >= 0.0:
        return 6.0, "RS_SLIGHTLY_POSITIVE"
    if excess_return_pct >= -2.0:
        return 4.0, "RS_WEAK"
    return 2.0, "RS_VERY_WEAK"


def score_market_regime(regime: str, vix_status: str) -> float:
    """Convert regime + VIX status into 0-10 score."""
    base = {
        "BULL": 9.0,
        "MIXED": 6.0,
        "BEAR": 2.5,
        "UNKNOWN": 5.0,
        "ERROR": 5.0,
    }.get(str(regime).upper(), 5.0)
    if vix_status == "LOW_VOL_SUPPORTIVE":
        base += 0.5
    elif vix_status == "HIGH_VOL_RISK_OFF":
        base -= 1.0
    return max(0.0, min(10.0, base))


def get_ai_grade_from_row(row: pd.Series) -> Tuple[float, str]:
    """Use grade_0_10 if present; otherwise neutral/default score."""
    grade = first_valid_price(row, [
        "grade_0_10", "grade", "score", "ai_grade", "model_grade"
    ])
    if grade is None:
        return 7.0, "DEFAULT_7_NO_GRADE_COLUMN"
    return max(0.0, min(10.0, float(grade))), "CSV_GRADE"


def score_sector_strength(sector_excess_return_pct: Optional[float]) -> Tuple[float, str]:
    """Convert sector-vs-benchmark 21d excess return into 0-10 score."""
    if sector_excess_return_pct is None:
        return 5.0, "SECTOR_RS_UNKNOWN"
    if sector_excess_return_pct >= 4.0:
        return 10.0, "SECTOR_STRONG_LEADER"
    if sector_excess_return_pct >= 1.5:
        return 8.0, "SECTOR_STRONG"
    if sector_excess_return_pct >= 0.0:
        return 6.0, "SECTOR_OK"
    if sector_excess_return_pct >= -2.0:
        return 4.0, "SECTOR_WEAK"
    return 2.0, "SECTOR_VERY_WEAK"


def score_extension_quality(stock_hist: pd.DataFrame, entry_date, entry_price: Optional[float]) -> Tuple[float, str, Dict[str, Any]]:
    """Penalize stretched/chased entries.

    Uses as-of-entry close vs EMA10/EMA20 and previous-close gap. The score is
    intentionally a penalty/quality score, not a hard reject.
    """
    details: Dict[str, Any] = {
        "dist_from_ema10_pct": None,
        "dist_from_ema20_pct": None,
        "gap_1d_pct": None,
        "asof_close": None,
    }
    if stock_hist is None or stock_hist.empty or "Close" not in stock_hist.columns:
        return 5.0, "EXT_UNKNOWN", details
    try:
        entry_date = pd.to_datetime(entry_date)
        h = stock_hist[stock_hist.index <= entry_date + timedelta(days=1)].copy()
        if len(h) < max(EXTENSION_EMA_SLOW, 3):
            return 5.0, "EXT_INSUFFICIENT_DATA", details
        close = get_column_as_series(h, "Close").sort_index()
        if close.empty:
            return 5.0, "EXT_NO_CLOSE", details
        ema10 = close.ewm(span=EXTENSION_EMA_FAST, adjust=False).mean().iloc[-1]
        ema20 = close.ewm(span=EXTENSION_EMA_SLOW, adjust=False).mean().iloc[-1]
        asof_close = float(close.iloc[-1])
        prev_close = float(close.iloc[-2]) if len(close) >= 2 else asof_close

        dist10 = (asof_close / float(ema10) - 1.0) * 100.0 if float(ema10) > 0 else None
        dist20 = (asof_close / float(ema20) - 1.0) * 100.0 if float(ema20) > 0 else None
        gap = (asof_close / prev_close - 1.0) * 100.0 if prev_close > 0 else None

        details.update({
            "dist_from_ema10_pct": round(dist10, 4) if dist10 is not None else None,
            "dist_from_ema20_pct": round(dist20, 4) if dist20 is not None else None,
            "gap_1d_pct": round(gap, 4) if gap is not None else None,
            "asof_close": round(asof_close, 4),
        })

        score = 10.0
        reasons = []
        if dist10 is not None:
            if dist10 > EXTENSION_DIST_EMA10_BAD_PCT:
                score -= 3.0
                reasons.append("FAR_ABOVE_EMA10")
            elif dist10 > EXTENSION_DIST_EMA10_WARN_PCT:
                score -= 1.5
                reasons.append("EXTENDED_ABOVE_EMA10")
            elif dist10 < -3.0:
                score -= 1.0
                reasons.append("BELOW_EMA10_WEAK")
        if dist20 is not None and dist20 > EXTENSION_DIST_EMA20_BAD_PCT:
            score -= 2.0
            reasons.append("FAR_ABOVE_EMA20")
        if gap is not None:
            if gap > EXTENSION_GAP_BAD_PCT:
                score -= 2.0
                reasons.append("LARGE_GAP_UP")
            elif gap > EXTENSION_GAP_WARN_PCT:
                score -= 1.0
                reasons.append("GAP_UP")

        if not reasons:
            return max(0.0, min(10.0, score)), "EXT_GOOD", details
        return max(0.0, min(10.0, score)), "EXT_" + "+".join(reasons), details
    except Exception as e:
        details["extension_error"] = str(e)
        return 5.0, "EXT_ERROR", details



def score_breakout_quality(stock_hist: pd.DataFrame, entry_date, entry_price: Optional[float]) -> Tuple[float, str, Dict[str, Any]]:
    """Score breakout/base quality around the theoretical entry date.

    This tries to capture whether the setup had a reasonably tight base,
    volatility contraction, close near recent highs, and volume confirmation.
    It is deliberately soft-scored to avoid overfitting.
    """
    details: Dict[str, Any] = {
        "breakout_base_range_pct": None,
        "breakout_close_position_20d": None,
        "breakout_volume_ratio": None,
        "breakout_atr_fast_slow_ratio": None,
    }
    required = {"High", "Low", "Close"}
    if stock_hist is None or stock_hist.empty or not required.issubset(set(stock_hist.columns)):
        return 5.0, "BO_UNKNOWN", details
    try:
        entry_date = pd.to_datetime(entry_date)
        h = stock_hist[stock_hist.index <= entry_date + timedelta(days=1)].copy()
        min_needed = max(BREAKOUT_LOOKBACK_DAYS, BREAKOUT_BASE_TIGHT_DAYS, BREAKOUT_ATR_SLOW_DAYS) + 1
        if len(h) < min_needed:
            return 5.0, "BO_INSUFFICIENT_DATA", details

        high = get_column_as_series(h, "High").sort_index()
        low = get_column_as_series(h, "Low").sort_index()
        close = get_column_as_series(h, "Close").sort_index()
        if high.empty or low.empty or close.empty:
            return 5.0, "BO_EMPTY_SERIES", details

        asof_close = float(close.iloc[-1])
        recent_high_10 = float(high.iloc[-BREAKOUT_BASE_TIGHT_DAYS:].max())
        recent_low_10 = float(low.iloc[-BREAKOUT_BASE_TIGHT_DAYS:].min())
        base_range_pct = ((recent_high_10 / recent_low_10) - 1.0) * 100.0 if recent_low_10 > 0 else None

        high_20 = float(high.iloc[-BREAKOUT_LOOKBACK_DAYS:].max())
        low_20 = float(low.iloc[-BREAKOUT_LOOKBACK_DAYS:].min())
        close_position = (asof_close - low_20) / (high_20 - low_20) if high_20 > low_20 else None

        # ATR compression: fast ATR lower than slow ATR indicates volatility contraction / base building.
        prev_close = close.shift(1)
        tr = pd.concat([
            (high - low).abs(),
            (high - prev_close).abs(),
            (low - prev_close).abs(),
        ], axis=1).max(axis=1)
        atr_fast = tr.rolling(BREAKOUT_ATR_FAST_DAYS).mean().iloc[-1]
        atr_slow = tr.rolling(BREAKOUT_ATR_SLOW_DAYS).mean().iloc[-1]
        atr_ratio = float(atr_fast / atr_slow) if pd.notna(atr_fast) and pd.notna(atr_slow) and float(atr_slow) > 0 else None

        volume_ratio = None
        if "Volume" in h.columns:
            vol = get_column_as_series(h, "Volume").sort_index()
            if len(vol) >= BREAKOUT_VOLUME_LOOKBACK_DAYS + 1:
                last_vol = float(vol.iloc[-1])
                avg_vol = float(vol.iloc[-BREAKOUT_VOLUME_LOOKBACK_DAYS-1:-1].mean())
                if avg_vol > 0:
                    volume_ratio = last_vol / avg_vol

        details.update({
            "breakout_base_range_pct": round(base_range_pct, 4) if base_range_pct is not None else None,
            "breakout_close_position_20d": round(close_position, 4) if close_position is not None else None,
            "breakout_volume_ratio": round(volume_ratio, 4) if volume_ratio is not None else None,
            "breakout_atr_fast_slow_ratio": round(atr_ratio, 4) if atr_ratio is not None else None,
        })

        score = 5.0
        reasons = []

        if base_range_pct is not None:
            if base_range_pct <= BREAKOUT_TIGHT_BASE_GOOD_PCT:
                score += 2.0
                reasons.append("TIGHT_BASE")
            elif base_range_pct <= BREAKOUT_TIGHT_BASE_OK_PCT:
                score += 1.0
                reasons.append("OK_BASE")
            elif base_range_pct >= BREAKOUT_EXTREME_RANGE_BAD_PCT:
                score -= 2.0
                reasons.append("WIDE_ERRATIC_BASE")
            else:
                score -= 0.5
                reasons.append("LOOSE_BASE")

        if close_position is not None:
            if close_position >= BREAKOUT_CLOSE_POSITION_GOOD:
                score += 1.5
                reasons.append("CLOSE_NEAR_RANGE_HIGH")
            elif close_position < 0.45:
                score -= 1.5
                reasons.append("CLOSE_WEAK_IN_RANGE")

        if atr_ratio is not None:
            if atr_ratio <= BREAKOUT_ATR_COMPRESSION_GOOD:
                score += 1.0
                reasons.append("ATR_COMPRESSION")
            elif atr_ratio >= 1.25:
                score -= 1.0
                reasons.append("ATR_EXPANSION_NOISY")

        if volume_ratio is not None:
            if volume_ratio >= BREAKOUT_VOLUME_EXPANSION_GOOD:
                score += 1.0
                reasons.append("VOLUME_EXPANSION")
            elif volume_ratio < 0.7:
                score -= 0.5
                reasons.append("LOW_VOLUME")

        score = max(0.0, min(10.0, score))
        label = "BO_" + "+".join(reasons) if reasons else "BO_NEUTRAL"
        return score, label, details
    except Exception as e:
        details["breakout_error"] = str(e)
        return 5.0, "BO_ERROR", details



def score_breadth_regime_proxy(spy_hist: Optional[pd.DataFrame], qqq_hist: Optional[pd.DataFrame], vix_hist: Optional[pd.DataFrame], entry_date) -> Tuple[float, str, Dict[str, Any]]:
    """Market breadth proxy using SPY/QQQ trend plus VIX.

    This is not true constituent breadth (% stocks above MA), but it is robust,
    cheap to compute, and useful for evaluating whether broad risk appetite is
    supportive for long momentum breakouts.
    """
    details: Dict[str, Any] = {
        "spy_close": None, "spy_ema50": None, "spy_ema200": None,
        "qqq_close": None, "qqq_ema50": None, "qqq_ema200": None,
        "breadth_vix": None,
    }
    score = 5.0
    reasons = []
    try:
        entry_date = pd.to_datetime(entry_date)

        def eval_index(df: Optional[pd.DataFrame], prefix: str) -> Optional[str]:
            nonlocal score
            if df is None or df.empty or "Close" not in df.columns:
                return None
            close = get_column_as_series(df, "Close").sort_index()
            close = close[close.index <= entry_date + timedelta(days=1)]
            if len(close) < BREADTH_EMA_FAST + 1:
                return None
            ema50 = close.ewm(span=BREADTH_EMA_FAST, adjust=False).mean().iloc[-1]
            ema200 = close.ewm(span=BREADTH_EMA_SLOW, adjust=False).mean().iloc[-1] if len(close) >= BREADTH_EMA_SLOW + 1 else None
            last = float(close.iloc[-1])
            details[f"{prefix}_close"] = round(last, 4)
            details[f"{prefix}_ema50"] = round(float(ema50), 4) if pd.notna(ema50) else None
            details[f"{prefix}_ema200"] = round(float(ema200), 4) if ema200 is not None and pd.notna(ema200) else None
            if ema200 is not None and pd.notna(ema200):
                if last > ema50 and ema50 > ema200:
                    score += 1.25
                    return f"{prefix.upper()}_STRONG"
                if last < ema50 and ema50 < ema200:
                    score -= 1.25
                    return f"{prefix.upper()}_WEAK"
            if last > ema50:
                score += 0.5
                return f"{prefix.upper()}_ABOVE_EMA50"
            score -= 0.5
            return f"{prefix.upper()}_BELOW_EMA50"

        for label in (eval_index(spy_hist, "spy"), eval_index(qqq_hist, "qqq")):
            if label:
                reasons.append(label)

        if vix_hist is not None and not vix_hist.empty and "Close" in vix_hist.columns:
            v = get_column_as_series(vix_hist, "Close").sort_index()
            v = v[v.index <= entry_date + timedelta(days=1)]
            if not v.empty:
                vix = float(v.iloc[-1])
                details["breadth_vix"] = round(vix, 2)
                if vix < 18:
                    score += 1.0
                    reasons.append("VIX_SUPPORTIVE")
                elif vix > 25:
                    score -= 1.5
                    reasons.append("VIX_RISK_OFF")
                else:
                    reasons.append("VIX_NEUTRAL")

        score = max(0.0, min(10.0, score))
        return score, "+".join(reasons) if reasons else "BREADTH_NEUTRAL", details
    except Exception as e:
        details["breadth_error"] = str(e)
        return 5.0, "BREADTH_ERROR", details


def score_multi_timeframe_alignment(stock_hist: Optional[pd.DataFrame], entry_date) -> Tuple[float, str, Dict[str, Any]]:
    """Score daily + weekly trend alignment at entry."""
    details: Dict[str, Any] = {
        "daily_close": None, "daily_ema20": None, "daily_ema50": None,
        "weekly_close": None, "weekly_ema10": None,
    }
    if stock_hist is None or stock_hist.empty or "Close" not in stock_hist.columns:
        return 5.0, "MTF_UNKNOWN", details
    try:
        entry_date = pd.to_datetime(entry_date)
        close = get_column_as_series(stock_hist, "Close").sort_index()
        close = close[close.index <= entry_date + timedelta(days=1)]
        if len(close) < MTF_DAILY_EMA_SLOW + 1:
            return 5.0, "MTF_INSUFFICIENT_DATA", details
        daily_close = float(close.iloc[-1])
        ema20 = float(close.ewm(span=MTF_DAILY_EMA_FAST, adjust=False).mean().iloc[-1])
        ema50 = float(close.ewm(span=MTF_DAILY_EMA_SLOW, adjust=False).mean().iloc[-1])
        details.update({"daily_close": round(daily_close,4), "daily_ema20": round(ema20,4), "daily_ema50": round(ema50,4)})

        score = 5.0
        reasons = []
        if daily_close > ema20 > ema50:
            score += 2.0
            reasons.append("DAILY_UPTREND")
        elif daily_close > ema20:
            score += 0.75
            reasons.append("DAILY_RECOVERING")
        elif daily_close < ema20 < ema50:
            score -= 2.0
            reasons.append("DAILY_DOWNTREND")
        else:
            reasons.append("DAILY_MIXED")

        # Weekly trend from daily close resampled to Friday weekly close.
        w = close.resample("W-FRI").last().dropna()
        if len(w) >= MTF_WEEKLY_EMA + 1:
            w_close = float(w.iloc[-1])
            w_ema = float(w.ewm(span=MTF_WEEKLY_EMA, adjust=False).mean().iloc[-1])
            details.update({"weekly_close": round(w_close,4), "weekly_ema10": round(w_ema,4)})
            if w_close > w_ema:
                score += 1.5
                reasons.append("WEEKLY_UP")
            else:
                score -= 1.5
                reasons.append("WEEKLY_NOT_UP")
        else:
            reasons.append("WEEKLY_INSUFFICIENT")

        score = max(0.0, min(10.0, score))
        return score, "+".join(reasons), details
    except Exception as e:
        details["mtf_error"] = str(e)
        return 5.0, "MTF_ERROR", details


def score_accumulation_volume(stock_hist: Optional[pd.DataFrame], entry_date) -> Tuple[float, str, Dict[str, Any]]:
    """Relative volume + accumulation/distribution score.

    Rewards volume expansion on/near breakout and positive OBV slope. Penalizes
    many distribution days and weak/low-volume breakouts.
    """
    details: Dict[str, Any] = {
        "rel_volume_ratio": None,
        "accumulation_days": None,
        "distribution_days": None,
        "obv_20d_change_pct": None,
    }
    if stock_hist is None or stock_hist.empty or not {"Close", "Volume"}.issubset(stock_hist.columns):
        return 5.0, "ACCUM_UNKNOWN", details
    try:
        entry_date = pd.to_datetime(entry_date)
        h = stock_hist[stock_hist.index <= entry_date + timedelta(days=1)].copy()
        if len(h) < ACCUM_LOOKBACK_DAYS + 2:
            return 5.0, "ACCUM_INSUFFICIENT_DATA", details
        close = get_column_as_series(h, "Close").sort_index()
        vol = get_column_as_series(h, "Volume").reindex(close.index).dropna()
        close = close.reindex(vol.index).dropna()
        if len(close) < ACCUM_LOOKBACK_DAYS + 2:
            return 5.0, "ACCUM_INSUFFICIENT_DATA", details

        recent_close = close.iloc[-(ACCUM_LOOKBACK_DAYS+1):]
        recent_vol = vol.iloc[-(ACCUM_LOOKBACK_DAYS+1):]
        avg_vol = float(recent_vol.iloc[:-1].mean())
        last_vol = float(recent_vol.iloc[-1])
        rel_vol = last_vol / avg_vol if avg_vol > 0 else None

        pct_changes = recent_close.pct_change() * 100.0
        avg_recent_vol = recent_vol.iloc[:-1].mean()
        accumulation_days = int(((pct_changes > 0) & (recent_vol > avg_recent_vol)).sum())
        distribution_days = int(((pct_changes < -0.5) & (recent_vol > avg_recent_vol)).sum())

        direction = recent_close.diff().fillna(0).apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
        obv = (direction * recent_vol).cumsum()
        obv_change = None
        if len(obv) > 2 and abs(float(obv.iloc[0])) > 0:
            obv_change = (float(obv.iloc[-1]) / abs(float(obv.iloc[0])) - 1.0) * 100.0

        details.update({
            "rel_volume_ratio": round(rel_vol, 4) if rel_vol is not None else None,
            "accumulation_days": accumulation_days,
            "distribution_days": distribution_days,
            "obv_20d_change_pct": round(obv_change, 4) if obv_change is not None else None,
        })

        score = 5.0
        reasons = []
        if rel_vol is not None:
            if rel_vol >= ACCUM_VOLUME_RATIO_GOOD:
                score += 1.5
                reasons.append("REL_VOLUME_EXPANSION")
            elif rel_vol < 0.7:
                score -= 1.0
                reasons.append("LOW_REL_VOLUME")
        if accumulation_days >= distribution_days + 3:
            score += 1.5
            reasons.append("ACCUMULATION_DOMINATES")
        elif distribution_days >= accumulation_days + 3:
            score -= 1.5
            reasons.append("DISTRIBUTION_DOMINATES")
        if obv_change is not None:
            if obv_change > 20:
                score += 1.0
                reasons.append("OBV_UP")
            elif obv_change < -20:
                score -= 1.0
                reasons.append("OBV_DOWN")

        score = max(0.0, min(10.0, score))
        return score, "+".join(reasons) if reasons else "ACCUM_NEUTRAL", details
    except Exception as e:
        details["accum_error"] = str(e)
        return 5.0, "ACCUM_ERROR", details

def calculate_phase1_features(
    row: pd.Series,
    stock_hist: pd.DataFrame,
    benchmark_hist: pd.DataFrame,
    vix_hist: pd.DataFrame,
    entry_date,
    sector_hist: Optional[pd.DataFrame] = None,
    spy_hist: Optional[pd.DataFrame] = None,
    qqq_hist: Optional[pd.DataFrame] = None,
    entry_price: Optional[float] = None,
) -> Dict[str, Any]:
    symbol = row.get("symbol", "")
    benchmark, market_region = get_market_benchmark(symbol)
    entry_date = pd.to_datetime(entry_date)

    result = {
        "market_region": market_region,
        "market_benchmark": benchmark,
        "benchmark_close": None,
        "benchmark_sma21": None,
        "benchmark_sma50": None,
        "market_regime": "UNKNOWN",
        "benchmark_trend": "UNKNOWN",
        "vix_value": None,
        "vix_status": "UNKNOWN",
        "market_score_0_10": 5.0,
        "stock_21d_return_pct": None,
        "benchmark_21d_return_pct": None,
        "relative_strength_21d_pct": None,
        "relative_strength_score_0_10": 5.0,
        "relative_strength_label": "RS_UNKNOWN",
        "sector_benchmark": get_sector_benchmark(symbol)[0],
        "sector_group": get_sector_benchmark(symbol)[1],
        "sector_21d_return_pct": None,
        "sector_vs_market_21d_pct": None,
        "sector_score_0_10": 5.0,
        "sector_label": "SECTOR_RS_UNKNOWN",
        "extension_score_0_10": 5.0,
        "extension_label": "EXT_UNKNOWN",
        "dist_from_ema10_pct": None,
        "dist_from_ema20_pct": None,
        "gap_1d_pct": None,
        "asof_close_for_extension": None,
        "breakout_score_0_10": 5.0,
        "breakout_label": "BO_UNKNOWN",
        "breakout_base_range_pct": None,
        "breakout_close_position_20d": None,
        "breakout_volume_ratio": None,
        "breakout_atr_fast_slow_ratio": None,
        "breadth_score_0_10": 5.0,
        "breadth_label": "BREADTH_UNKNOWN",
        "spy_close": None,
        "spy_ema50": None,
        "spy_ema200": None,
        "qqq_close": None,
        "qqq_ema50": None,
        "qqq_ema200": None,
        "breadth_vix": None,
        "mtf_score_0_10": 5.0,
        "mtf_label": "MTF_UNKNOWN",
        "daily_close": None,
        "daily_ema20": None,
        "daily_ema50": None,
        "weekly_close": None,
        "weekly_ema10": None,
        "accumulation_score_0_10": 5.0,
        "accumulation_label": "ACCUM_UNKNOWN",
        "rel_volume_ratio": None,
        "accumulation_days": None,
        "distribution_days": None,
        "obv_20d_change_pct": None,
        "volatility_atr14_pct": None,
        "volatility_score_0_10": 5.0,
        "volatility_label": "VOL_UNKNOWN",
        "asset_class": classify_asset_class(symbol),
        "ai_grade_0_10": 7.0,
        "ai_grade_source": "DEFAULT_7_NO_GRADE_COLUMN",
        "phase1_composite_score": None,
        "phase1_hard_reject_reason": "",
    }

    try:
        # --- Market regime using benchmark 21/50 SMA + VIX ---
        if benchmark_hist is not None and not benchmark_hist.empty and "Close" in benchmark_hist.columns:
            b_close = get_column_as_series(benchmark_hist, "Close").sort_index()
            b_close_asof = b_close[b_close.index <= entry_date + timedelta(days=1)]
            if not b_close_asof.empty:
                b_df = pd.DataFrame({"Close": b_close_asof})
                b_df["SMA21"] = b_df["Close"].rolling(REGIME_FAST_SMA).mean()
                b_df["SMA50"] = b_df["Close"].rolling(REGIME_SLOW_SMA).mean()
                entry_row = b_df.iloc[-1]
                bench_close = float(entry_row["Close"])
                sma21 = float(entry_row["SMA21"]) if pd.notna(entry_row["SMA21"]) else None
                sma50 = float(entry_row["SMA50"]) if pd.notna(entry_row["SMA50"]) else None

                if sma21 is not None and sma50 is not None:
                    if bench_close > sma21 and sma21 > sma50:
                        regime = "BULL"
                        trend = "BULLISH_CLOSE_GT_SMA21_GT_SMA50"
                    elif bench_close < sma21 and sma21 < sma50:
                        regime = "BEAR"
                        trend = "BEARISH_CLOSE_LT_SMA21_LT_SMA50"
                    else:
                        regime = "MIXED"
                        trend = "MIXED_OR_TRANSITION"
                else:
                    regime = "UNKNOWN"
                    trend = "INSUFFICIENT_SMA_DATA"

                result.update({
                    "benchmark_close": round(bench_close, 4),
                    "benchmark_sma21": round(sma21, 4) if sma21 is not None else None,
                    "benchmark_sma50": round(sma50, 4) if sma50 is not None else None,
                    "market_regime": regime,
                    "benchmark_trend": trend,
                })

                bench_ret = safe_return(b_close, entry_date, REL_STRENGTH_LOOKBACK_DAYS)
                result["benchmark_21d_return_pct"] = round(bench_ret, 4) if bench_ret is not None else None

        # --- VIX status ---
        if vix_hist is not None and not vix_hist.empty and "Close" in vix_hist.columns:
            v_close = get_column_as_series(vix_hist, "Close").sort_index()
            v_close = v_close[v_close.index <= entry_date + timedelta(days=1)]
            if not v_close.empty:
                vix = float(v_close.iloc[-1])
                if vix < 18:
                    vix_status = "LOW_VOL_SUPPORTIVE"
                elif vix <= 25:
                    vix_status = "NORMAL_CAUTION"
                else:
                    vix_status = "HIGH_VOL_RISK_OFF"
                result.update({"vix_value": round(vix, 2), "vix_status": vix_status})

        result["market_score_0_10"] = score_market_regime(result["market_regime"], result["vix_status"])

        # --- Relative strength ---
        if stock_hist is not None and not stock_hist.empty and "Close" in stock_hist.columns:
            s_close = get_column_as_series(stock_hist, "Close").sort_index()
            stock_ret = safe_return(s_close, entry_date, REL_STRENGTH_LOOKBACK_DAYS)
            result["stock_21d_return_pct"] = round(stock_ret, 4) if stock_ret is not None else None
            bench_ret = result.get("benchmark_21d_return_pct")
            if stock_ret is not None and bench_ret is not None:
                excess = stock_ret - float(bench_ret)
                rs_score, rs_label = score_relative_strength(excess)
                result.update({
                    "relative_strength_21d_pct": round(excess, 4),
                    "relative_strength_score_0_10": rs_score,
                    "relative_strength_label": rs_label,
                })

        # --- Sector momentum alignment ---
        if sector_hist is not None and not sector_hist.empty and "Close" in sector_hist.columns:
            sec_close = get_column_as_series(sector_hist, "Close").sort_index()
            sec_ret = safe_return(sec_close, entry_date, REL_STRENGTH_LOOKBACK_DAYS)
            result["sector_21d_return_pct"] = round(sec_ret, 4) if sec_ret is not None else None
            bench_ret = result.get("benchmark_21d_return_pct")
            if sec_ret is not None and bench_ret is not None:
                sector_excess = sec_ret - float(bench_ret)
                sector_score, sector_label = score_sector_strength(sector_excess)
                result.update({
                    "sector_vs_market_21d_pct": round(sector_excess, 4),
                    "sector_score_0_10": sector_score,
                    "sector_label": sector_label,
                })

        # --- Extended-entry / chasing quality ---
        ext_score, ext_label, ext_details = score_extension_quality(stock_hist, entry_date, entry_price)
        result["extension_score_0_10"] = ext_score
        result["extension_label"] = ext_label
        result["dist_from_ema10_pct"] = ext_details.get("dist_from_ema10_pct")
        result["dist_from_ema20_pct"] = ext_details.get("dist_from_ema20_pct")
        result["gap_1d_pct"] = ext_details.get("gap_1d_pct")
        result["asof_close_for_extension"] = ext_details.get("asof_close")

        # --- Breakout/base quality ---
        bo_score, bo_label, bo_details = score_breakout_quality(stock_hist, entry_date, entry_price)
        result["breakout_score_0_10"] = bo_score
        result["breakout_label"] = bo_label
        result["breakout_base_range_pct"] = bo_details.get("breakout_base_range_pct")
        result["breakout_close_position_20d"] = bo_details.get("breakout_close_position_20d")
        result["breakout_volume_ratio"] = bo_details.get("breakout_volume_ratio")
        result["breakout_atr_fast_slow_ratio"] = bo_details.get("breakout_atr_fast_slow_ratio")

        # --- Breadth regime proxy ---
        breadth_score, breadth_label, breadth_details = score_breadth_regime_proxy(spy_hist, qqq_hist, vix_hist, entry_date)
        result["breadth_score_0_10"] = breadth_score
        result["breadth_label"] = breadth_label
        for k, v in breadth_details.items():
            result[k] = v

        # --- Multi-timeframe alignment ---
        mtf_score, mtf_label, mtf_details = score_multi_timeframe_alignment(stock_hist, entry_date)
        result["mtf_score_0_10"] = mtf_score
        result["mtf_label"] = mtf_label
        for k, v in mtf_details.items():
            result[k] = v

        # --- Relative volume / accumulation quality ---
        accum_score, accum_label, accum_details = score_accumulation_volume(stock_hist, entry_date)
        result["accumulation_score_0_10"] = accum_score
        result["accumulation_label"] = accum_label
        for k, v in accum_details.items():
            result[k] = v

        # --- Volatility quality ---
        vol_score, vol_label, atr_pct = score_volatility_quality(stock_hist, entry_date)
        result["volatility_score_0_10"] = vol_score
        result["volatility_label"] = vol_label
        result["volatility_atr14_pct"] = round(atr_pct, 4) if atr_pct is not None else None

        # --- Composite score ---
        ai_grade, ai_grade_source = get_ai_grade_from_row(row)
        result["ai_grade_0_10"] = ai_grade
        result["ai_grade_source"] = ai_grade_source

        composite = (
            PHASE1_WEIGHT_AI_GRADE * ai_grade +
            PHASE1_WEIGHT_MARKET * float(result["market_score_0_10"]) +
            PHASE1_WEIGHT_REL_STRENGTH * float(result["relative_strength_score_0_10"]) +
            PHASE1_WEIGHT_SECTOR * float(result["sector_score_0_10"]) +
            PHASE1_WEIGHT_VOLATILITY * float(result["volatility_score_0_10"]) +
            PHASE1_WEIGHT_EXTENSION * float(result["extension_score_0_10"]) +
            PHASE1_WEIGHT_BREAKOUT * float(result["breakout_score_0_10"]) +
            PHASE25_WEIGHT_BREADTH * float(result["breadth_score_0_10"]) +
            PHASE25_WEIGHT_MTF * float(result["mtf_score_0_10"]) +
            PHASE25_WEIGHT_ACCUMULATION * float(result["accumulation_score_0_10"])
        )
        result["phase1_composite_score"] = round(composite, 4)

        hard_reasons = []
        if PHASE1_REJECT_BEAR and result["market_regime"] == "BEAR":
            hard_reasons.append("REJECT_BEAR_REGIME")
        if PHASE1_REJECT_NEGATIVE_RS:
            rs = result.get("relative_strength_21d_pct")
            if rs is not None and float(rs) < 0:
                hard_reasons.append("REJECT_NEGATIVE_RELATIVE_STRENGTH")
        if hard_reasons:
            result["phase1_hard_reject_reason"] = ";".join(hard_reasons)

        return result

    except Exception as e:
        result["market_regime"] = "ERROR"
        result["phase1_hard_reject_reason"] = f"FEATURE_ERROR:{e}"
        return result


# ==================================================
# EXIT RULES
# Every rule returns dict with pnl_pct, exit_date, exit_reason.
# ==================================================
def result(rule, exit_date, exit_price, exit_reason, pnl_pct, extra=None):
    d = {
        "rule": rule,
        "exit_date_sim": exit_date,
        "exit_price_sim": round(exit_price, 4) if isinstance(exit_price, (float, int)) else exit_price,
        "exit_reason": exit_reason,
        "pnl_pct_sim": round(float(pnl_pct), 4),
        "profit_eur_per_1000": round(INITIAL_CAPITAL_PER_TRADE * float(pnl_pct) / 100.0, 2),
    }
    if extra:
        d.update(extra)
    return d


def actual_input_rule(row: pd.Series):
    p = pd.to_numeric(row.get("pnl_pct", None), errors="coerce")
    if pd.isna(p):
        return None
    return result("ACTUAL_INPUT", row.get("exit_date", ""), None, "INPUT_PNL", float(p))


def hard_stop_or_max_hold(window, entry, stop):
    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        if low <= stop:
            return result("HARD_STOP_OR_MAX_HOLD", dt.date(), stop, "HARD_STOP", pct(stop, entry))
    last_close = float(window.iloc[-1]["Close"])
    return result("HARD_STOP_OR_MAX_HOLD", window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def full_exit_at_target(window, entry, stop, target, name):
    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        if low <= stop:
            return result(name, dt.date(), stop, "HARD_STOP", pct(stop, entry))
        if high >= target:
            return result(name, dt.date(), target, "TARGET_FULL_EXIT", pct(target, entry))
    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def full_exit_at_pct_target(window, entry, stop, target_pct):
    target = entry * (1 + target_pct / 100.0)
    return full_exit_at_target(window, entry, stop, target, f"FULL_EXIT_AT_{target_pct:.0f}PCT")


def ema_exit_after_profit(window, entry, stop, min_profit_pct=3.0, ema_col="EMA5"):
    highest_close = entry
    activated = False
    name = f"{ema_col}_EXIT_AFTER_{min_profit_pct:.0f}PCT"

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        close = float(bar["Close"])
        ema = float(bar[ema_col]) if ema_col in bar and pd.notna(bar[ema_col]) else None

        if low <= stop:
            return result(name, dt.date(), stop, "HARD_STOP", pct(stop, entry))

        highest_close = max(highest_close, close)
        if pct(highest_close, entry) >= min_profit_pct:
            activated = True

        if activated and ema is not None and close < ema:
            return result(name, dt.date(), close, f"CLOSE_BELOW_{ema_col}", pct(close, entry))

    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def trailing_stop_after_profit(window, entry, stop, activation_pct=3.0, trail_pct=2.0):
    name = f"TRAIL_{trail_pct:.1f}PCT_AFTER_{activation_pct:.0f}PCT"
    highest_high = entry
    active_stop = stop
    activated = False

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        close = float(bar["Close"])

        highest_high = max(highest_high, high)

        if pct(highest_high, entry) >= activation_pct:
            activated = True
            active_stop = max(active_stop, highest_high * (1 - trail_pct / 100.0))

        if low <= active_stop:
            reason = "TRAIL_STOP" if activated else "HARD_STOP"
            return result(name, dt.date(), active_stop, reason, pct(active_stop, entry))

    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def time_progress_exit(window, entry, stop):
    name = "TIME_PROGRESS_EXIT"
    for i, (dt, bar) in enumerate(window.iterrows(), start=1):
        low = float(bar["Low"])
        close = float(bar["Close"])
        current_pnl = pct(close, entry)

        if low <= stop:
            return result(name, dt.date(), stop, "HARD_STOP", pct(stop, entry))

        if i >= 10 and current_pnl < 1.5:
            return result(name, dt.date(), close, "DAY10_WEAK_PROGRESS", current_pnl)
        if i >= 15 and current_pnl < 2.5:
            return result(name, dt.date(), close, "DAY15_WEAK_PROGRESS", current_pnl)
        if i >= 20 and current_pnl < 3.0:
            return result(name, dt.date(), close, "DAY20_WEAK_PROGRESS", current_pnl)

    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def exit_score_dynamic(window, entry, stop):
    name = "EXIT_SCORE_DYNAMIC"
    prev_close = None
    red_streak = 0
    highest_close = entry

    for i, (dt, bar) in enumerate(window.iterrows(), start=1):
        low = float(bar["Low"])
        close = float(bar["Close"])
        ema5 = float(bar["EMA5"]) if pd.notna(bar.get("EMA5")) else None
        rsi = float(bar["RSI14"]) if pd.notna(bar.get("RSI14")) else None
        rsi_prev = float(bar["RSI14_PREV"]) if pd.notna(bar.get("RSI14_PREV")) else None

        if low <= stop:
            return result(name, dt.date(), stop, "HARD_STOP", pct(stop, entry), {"exit_score": None})

        highest_close = max(highest_close, close)

        if prev_close is not None and close < prev_close:
            red_streak += 1
        else:
            red_streak = 0
        prev_close = close

        current_pnl = pct(close, entry)
        giveback_from_high = pct(close, highest_close) if highest_close > 0 else 0

        score = 0
        if current_pnl >= 2.0 and ema5 is not None and close < ema5:
            score += 1
        if red_streak >= 2 and current_pnl > 1.0:
            score += 1
        if rsi is not None and rsi_prev is not None and rsi_prev > 65 and rsi < rsi_prev:
            score += 1
        if current_pnl >= 3.0 and giveback_from_high <= -2.0:
            score += 1
        if i >= 20:
            score += 1

        if score >= 3:
            return result(name, dt.date(), close, "EXIT_SCORE_GE_3", current_pnl, {"exit_score": score})

    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry), {"exit_score": None})


def half_t1_half_ema5_runner(window, entry, stop, t1):
    name = "HALF_T1_HALF_EMA5_RUNNER"
    remaining = 1.0
    realized_pct = 0.0
    t1_taken = False
    active_stop = stop

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        close = float(bar["Close"])
        ema5 = float(bar["EMA5"]) if pd.notna(bar.get("EMA5")) else None

        if low <= active_stop:
            realized_pct += remaining * pct(active_stop, entry)
            return result(name, dt.date(), active_stop, "STOP_REMAINDER", realized_pct, {"partial_model": "YES"})

        if not t1_taken and high >= t1:
            realized_pct += 0.5 * pct(t1, entry)
            remaining = 0.5
            t1_taken = True
            active_stop = max(active_stop, entry)  # breakeven for runner

        if t1_taken and ema5 is not None and close < ema5:
            realized_pct += remaining * pct(close, entry)
            return result(name, dt.date(), close, "EMA5_EXIT_AFTER_T1", realized_pct, {"partial_model": "YES"})

    last_close = float(window.iloc[-1]["Close"])
    realized_pct += remaining * pct(last_close, entry)
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", realized_pct, {"partial_model": "YES"})


def run_rules(row, window, entry, stop, t1, t2):
    rules = []

    actual = actual_input_rule(row)
    if actual:
        rules.append(actual)

    rules.extend([
        hard_stop_or_max_hold(window, entry, stop),
        full_exit_at_target(window, entry, stop, t1, "FULL_EXIT_AT_T1"),
        full_exit_at_target(window, entry, stop, t2, "FULL_EXIT_AT_T2"),
        full_exit_at_pct_target(window, entry, stop, 3.0),
        full_exit_at_pct_target(window, entry, stop, 5.0),
        full_exit_at_pct_target(window, entry, stop, 8.0),
        full_exit_at_pct_target(window, entry, stop, 10.0),
        ema_exit_after_profit(window, entry, stop, 3.0, "EMA5"),
        ema_exit_after_profit(window, entry, stop, 5.0, "EMA5"),
        ema_exit_after_profit(window, entry, stop, 3.0, "EMA10"),
        trailing_stop_after_profit(window, entry, stop, 3.0, 2.0),
        trailing_stop_after_profit(window, entry, stop, 5.0, 2.5),
        trailing_stop_after_profit(window, entry, stop, 5.0, 3.0),
        time_progress_exit(window, entry, stop),
        exit_score_dynamic(window, entry, stop),
        half_t1_half_ema5_runner(window, entry, stop, t1),
    ])
    return rules


# ==================================================
# MAIN
# ==================================================
def main():
    df = pd.read_csv(INPUT_FILE)
    df["status"] = df["status"].astype(str).str.upper().str.strip()
    df["symbol"] = df["symbol"].astype(str).str.strip()

    executed = df[~df["status"].isin(["NOT_TRIGGERED", "NO_TRADE", "FUTURE_SETUP"])].copy()

    print(f"Loaded trades: {len(df)}")
    print(f"Executed trades to simulate: {len(executed)}")
    print("Phase 2.5 enabled:", PHASE1_ENABLED)
    print(f"Phase 2.5 params: TOP_N_PER_WEEK={PHASE1_TOP_N_PER_WEEK}, MIN_SCORE={PHASE1_MIN_COMPOSITE_SCORE}, REJECT_BEAR={PHASE1_REJECT_BEAR}, QUOTAS={PHASE1_USE_ASSET_CLASS_QUOTAS}")
    print(f"Weights: AI={PHASE1_WEIGHT_AI_GRADE}, MARKET={PHASE1_WEIGHT_MARKET}, RS={PHASE1_WEIGHT_REL_STRENGTH}, SECTOR={PHASE1_WEIGHT_SECTOR}, VOL={PHASE1_WEIGHT_VOLATILITY}, EXT={PHASE1_WEIGHT_EXTENSION}")

    all_results = []
    skipped = []
    feature_rows = []

    # Cache market data to avoid downloading the same benchmark / VIX repeatedly.
    benchmark_cache: Dict[Tuple[str, str, str], pd.DataFrame] = {}
    sector_cache: Dict[Tuple[str, str, str], pd.DataFrame] = {}
    vix_cache: Dict[Tuple[str, str], pd.DataFrame] = {}
    broad_cache: Dict[Tuple[str, str, str], pd.DataFrame] = {}

    for source_index, row in executed.iterrows():
        symbol = row["symbol"]
        yf_symbol = normalize_symbol(symbol)
        entry_date = pd.to_datetime(row.get("entry_date", None), errors="coerce")

        if pd.isna(entry_date):
            print(f"Skipping {symbol}: missing entry_date")
            skipped.append({"symbol": symbol, "reason": "missing entry_date"})
            continue

        # Fetch enough before entry for Phase 2 features and after entry for exit simulation.
        start = entry_date - timedelta(days=120)
        end = entry_date + timedelta(days=MAX_HOLDING_SESSIONS + 20)

        if VERBOSE:
            print(f"Fetching {symbol} -> {yf_symbol} from {start.date()} to {end.date()}")

        hist = download_history(yf_symbol, start, end)
        if hist.empty or not {"Open", "High", "Low", "Close"}.issubset(set(hist.columns)):
            print(f"Skipping {symbol}: no usable OHLC data")
            skipped.append({"symbol": symbol, "reason": "no usable OHLC data"})
            continue

        hist = add_indicators(hist)
        window = prepare_trade_window(hist, entry_date)

        if window.empty:
            print(f"Skipping {symbol}: no price window after entry_date")
            skipped.append({"symbol": symbol, "reason": "no price window after entry_date"})
            continue

        entry, entry_source = infer_entry_price(row, window)
        if entry is None:
            print(f"Skipping {symbol}: no entry price and cannot infer")
            skipped.append({"symbol": symbol, "reason": "no entry price and cannot infer"})
            continue

        stop, stop_source = get_stop_from_row(row, entry)
        t1, t1_source = get_t1_from_row(row, entry)
        t2, t2_source = get_t2_from_row(row, entry)

        # ---------------- Phase 2 features ----------------
        benchmark, market_region = get_market_benchmark(symbol)
        b_start = entry_date - timedelta(days=120)
        b_end = entry_date + timedelta(days=5)
        b_key = (benchmark, b_start.strftime("%Y-%m-%d"), b_end.strftime("%Y-%m-%d"))
        if b_key not in benchmark_cache:
            if VERBOSE:
                print(f"Fetching benchmark {benchmark} for {symbol}")
            benchmark_cache[b_key] = download_history(benchmark, b_start, b_end)
            time.sleep(SLEEP_SECONDS)
        benchmark_hist = benchmark_cache[b_key]

        v_start = entry_date - timedelta(days=20)
        v_end = entry_date + timedelta(days=5)
        v_key = (v_start.strftime("%Y-%m-%d"), v_end.strftime("%Y-%m-%d"))
        if v_key not in vix_cache:
            vix_cache[v_key] = download_history(VIX_SYMBOL, v_start, v_end)
            time.sleep(SLEEP_SECONDS)
        vix_hist = vix_cache[v_key]

        sector_benchmark, sector_group = get_sector_benchmark(symbol)
        s_key = (sector_benchmark, b_start.strftime("%Y-%m-%d"), b_end.strftime("%Y-%m-%d"))
        if s_key not in sector_cache:
            if VERBOSE:
                print(f"Fetching sector benchmark {sector_benchmark} ({sector_group}) for {symbol}")
            sector_cache[s_key] = download_history(sector_benchmark, b_start, b_end)
            time.sleep(SLEEP_SECONDS)
        sector_hist = sector_cache[s_key]

        # Phase 2.5 breadth proxy uses SPY + QQQ regardless of local benchmark.
        broad_start = entry_date - timedelta(days=300)
        broad_end = entry_date + timedelta(days=5)
        for broad_symbol in ("SPY", "QQQ"):
            broad_key = (broad_symbol, broad_start.strftime("%Y-%m-%d"), broad_end.strftime("%Y-%m-%d"))
            if broad_key not in broad_cache:
                if VERBOSE:
                    print(f"Fetching breadth proxy {broad_symbol} for {symbol}")
                broad_cache[broad_key] = download_history(broad_symbol, broad_start, broad_end)
                time.sleep(SLEEP_SECONDS)
        spy_hist = broad_cache[("SPY", broad_start.strftime("%Y-%m-%d"), broad_end.strftime("%Y-%m-%d"))]
        qqq_hist = broad_cache[("QQQ", broad_start.strftime("%Y-%m-%d"), broad_end.strftime("%Y-%m-%d"))]

        features = calculate_phase1_features(
            row, hist, benchmark_hist, vix_hist, entry_date,
            sector_hist=sector_hist,
            spy_hist=spy_hist,
            qqq_hist=qqq_hist,
            entry_price=entry,
        )

        base_record = {
            "source_index": source_index,
            "week": row.get("week", ""),
            "symbol": symbol,
            "yf_symbol": yf_symbol,
            "status_input": row.get("status", ""),
            "entry_date": entry_date.date(),
            "entry_price_used": round(entry, 4),
            "entry_source": entry_source,
            "stop_used": round(stop, 4),
            "stop_source": stop_source,
            "t1_used": round(t1, 4),
            "t1_source": t1_source,
            "t2_used": round(t2, 4),
            "t2_source": t2_source,
            "input_pnl_pct": row.get("pnl_pct", ""),
            "input_exit_date": row.get("exit_date", ""),
            **features,
        }
        feature_rows.append(base_record.copy())

        rule_results = run_rules(row, window, entry, stop, t1, t2)

        for rr in rule_results:
            all_results.append({
                **base_record,
                **rr,
            })

        time.sleep(SLEEP_SECONDS)

    results = pd.DataFrame(all_results)
    features_df = pd.DataFrame(feature_rows)

    if results.empty:
        print("No simulated results produced.")
        if skipped:
            pd.DataFrame(skipped).to_csv("exit_rule_skipped.csv", index=False, encoding="utf-8-sig")
            print("Saved skipped symbols to exit_rule_skipped.csv")
        return

    # ==================================================
    # Phase 2 selection: rank trades per week by composite score.
    # ==================================================
    if PHASE1_ENABLED and not features_df.empty:
        features_df["phase1_score_rank_in_week"] = (
            features_df.groupby("week")["phase1_composite_score"]
            .rank(method="first", ascending=False)
        )

        # Candidate pool after score threshold and hard rejects. Selection is still
        # Top-N per week, but optionally constrained by broad asset-class quotas.
        features_df["phase1_selected"] = False
        candidate_mask = (
            (features_df["phase1_composite_score"] >= PHASE1_MIN_COMPOSITE_SCORE) &
            (features_df["phase1_hard_reject_reason"].fillna("") == "")
        )

        selected_indices = []
        for week, week_df in features_df[candidate_mask].groupby("week"):
            week_sorted = week_df.sort_values("phase1_composite_score", ascending=False)
            if not PHASE1_USE_ASSET_CLASS_QUOTAS:
                selected_indices.extend(week_sorted.head(PHASE1_TOP_N_PER_WEEK).index.tolist())
                continue

            counts_by_class = {k: 0 for k in PHASE1_ASSET_CLASS_QUOTAS}
            counts_by_sector_group = {}
            counts_by_market_region = {}
            week_selected = []
            # First pass: respect asset-class, sector-group, and market-region exposure caps.
            for idx, r in week_sorted.iterrows():
                asset_class = str(r.get("asset_class", "OTHER"))
                sector_group = str(r.get("sector_group", "SECTOR_UNKNOWN"))
                market_region = str(r.get("market_region", "GLOBAL_DEFAULT"))

                asset_quota = PHASE1_ASSET_CLASS_QUOTAS.get(asset_class, PHASE1_ASSET_CLASS_QUOTAS.get("OTHER", 999))
                if counts_by_class.get(asset_class, 0) >= asset_quota:
                    continue

                if PHASE2_USE_SECTOR_GROUP_QUOTAS:
                    if counts_by_sector_group.get(sector_group, 0) >= PHASE2_MAX_PER_SECTOR_GROUP_PER_WEEK:
                        continue

                if PHASE2_USE_MARKET_REGION_QUOTAS:
                    region_quota = PHASE2_MARKET_REGION_QUOTAS.get(market_region, PHASE2_MARKET_REGION_QUOTAS.get("GLOBAL_DEFAULT", 999))
                    if counts_by_market_region.get(market_region, 0) >= region_quota:
                        continue

                week_selected.append(idx)
                counts_by_class[asset_class] = counts_by_class.get(asset_class, 0) + 1
                counts_by_sector_group[sector_group] = counts_by_sector_group.get(sector_group, 0) + 1
                counts_by_market_region[market_region] = counts_by_market_region.get(market_region, 0) + 1
                if len(week_selected) >= PHASE1_TOP_N_PER_WEEK:
                    break

            # Second pass: if exposure caps left the week under-filled, fill with best remaining candidates.
            # This keeps trade count from collapsing; production bot can choose to keep caps hard.
            if len(week_selected) < PHASE1_TOP_N_PER_WEEK:
                for idx in week_sorted.index:
                    if idx not in week_selected:
                        week_selected.append(idx)
                    if len(week_selected) >= PHASE1_TOP_N_PER_WEEK:
                        break

            selected_indices.extend(week_selected)

        features_df.loc[selected_indices, "phase1_selected"] = True
    else:
        features_df["phase1_score_rank_in_week"] = None
        features_df["phase1_selected"] = True

    # Merge selection back onto simulated results.
    select_cols = ["source_index", "phase1_score_rank_in_week", "phase1_selected"]
    results = results.merge(features_df[select_cols], on="source_index", how="left", suffixes=("", "_sel"))

    # Save detailed outputs.
    results.to_csv(OUTPUT_TRADES_FILE, index=False, encoding="utf-8-sig")
    features_df.to_csv(OUTPUT_PHASE1_TRADES_FILE, index=False, encoding="utf-8-sig")

    # Original all-trades summary by rule.
    summary = (
        results.groupby("rule")
        .agg(
            trades=("symbol", "count"),
            avg_pnl_pct=("pnl_pct_sim", "mean"),
            median_pnl_pct=("pnl_pct_sim", "median"),
            total_profit_eur=("profit_eur_per_1000", "sum"),
            win_rate_pct=("pnl_pct_sim", lambda x: (x > 0).mean() * 100),
            loss_rate_pct=("pnl_pct_sim", lambda x: (x < 0).mean() * 100),
            best_trade_pct=("pnl_pct_sim", "max"),
            worst_trade_pct=("pnl_pct_sim", "min"),
        )
        .reset_index()
        .sort_values("total_profit_eur", ascending=False)
    )

    for col in ["avg_pnl_pct", "median_pnl_pct", "win_rate_pct", "loss_rate_pct", "best_trade_pct", "worst_trade_pct"]:
        summary[col] = summary[col].round(3)
    summary.to_csv(OUTPUT_SUMMARY_FILE, index=False, encoding="utf-8-sig")

    # Phase 2 selected-only summary.
    selected_results = results[results["phase1_selected"] == True].copy()
    if not selected_results.empty:
        phase1_summary = (
            selected_results.groupby("rule")
            .agg(
                selected_trades=("symbol", "count"),
                selected_avg_pnl_pct=("pnl_pct_sim", "mean"),
                selected_median_pnl_pct=("pnl_pct_sim", "median"),
                selected_total_profit_eur=("profit_eur_per_1000", "sum"),
                selected_win_rate_pct=("pnl_pct_sim", lambda x: (x > 0).mean() * 100),
                selected_loss_rate_pct=("pnl_pct_sim", lambda x: (x < 0).mean() * 100),
                selected_best_trade_pct=("pnl_pct_sim", "max"),
                selected_worst_trade_pct=("pnl_pct_sim", "min"),
            )
            .reset_index()
            .sort_values("selected_total_profit_eur", ascending=False)
        )
        for col in ["selected_avg_pnl_pct", "selected_median_pnl_pct", "selected_win_rate_pct", "selected_loss_rate_pct", "selected_best_trade_pct", "selected_worst_trade_pct"]:
            phase1_summary[col] = phase1_summary[col].round(3)
    else:
        phase1_summary = pd.DataFrame()

    phase1_summary.to_csv(OUTPUT_PHASE1_SUMMARY_FILE, index=False, encoding="utf-8-sig")

    # Comparison all vs selected.
    if not phase1_summary.empty:
        comparison = summary.merge(phase1_summary, on="rule", how="left")
        comparison["profit_delta_selected_vs_all_eur"] = (
            comparison["selected_total_profit_eur"] - comparison["total_profit_eur"]
        ).round(2)
        comparison["avg_pnl_delta_selected_vs_all_pct"] = (
            comparison["selected_avg_pnl_pct"] - comparison["avg_pnl_pct"]
        ).round(3)
        comparison.to_csv(OUTPUT_PHASE1_COMPARISON_FILE, index=False, encoding="utf-8-sig")
    else:
        comparison = pd.DataFrame()

    if skipped:
        pd.DataFrame(skipped).to_csv("exit_rule_skipped.csv", index=False, encoding="utf-8-sig")
        print("Saved skipped symbols to exit_rule_skipped.csv")

    print("\nSaved:", OUTPUT_TRADES_FILE)
    print("Saved:", OUTPUT_SUMMARY_FILE)
    print("Saved:", OUTPUT_PHASE1_TRADES_FILE)
    print("Saved:", OUTPUT_PHASE1_SUMMARY_FILE)
    print("Saved:", OUTPUT_PHASE1_COMPARISON_FILE)

    print("\n================ PHASE 1 SELECTION SUMMARY ================")
    if not features_df.empty:
        selected_count = int(features_df["phase1_selected"].sum())
        total_count = len(features_df)
        print(f"Trades evaluated for selection: {total_count}")
        print(f"Trades selected by Phase 2: {selected_count}")
        print(f"Selection rate: {selected_count / total_count * 100:.1f}%")
        print("\nSelected trades by week:")
        print(features_df[features_df["phase1_selected"]].groupby("week")["symbol"].count().to_string())
        print("\nAverage composite score by selected flag:")
        print(features_df.groupby("phase1_selected")["phase1_composite_score"].mean().round(3).to_string())
        print("\nMarket regime distribution for selected trades:")
        print(features_df[features_df["phase1_selected"]].groupby("market_regime")["symbol"].count().to_string())

    print("\n================ EXIT RULE SUMMARY: ALL TRADES ================")
    print(summary.to_string(index=False))

    print("\n================ EXIT RULE SUMMARY: PHASE 1 SELECTED ONLY ================")
    if not phase1_summary.empty:
        print(phase1_summary.to_string(index=False))
    else:
        print("No Phase 2 selected trades. Lower PHASE1_MIN_COMPOSITE_SCORE or increase TOP_N_PER_WEEK.")

    print("\nImportant note:")
    print("- Phase 2 is intentionally a soft scoring + top-N selector, not a large set of hard filters.")
    print("- If your CSV has no grade_0_10, the script uses ai_grade=7.0 for all trades.")
    print("- If your CSV has no entry/t1/t2/stop columns, entry-day close and fallback T1/T2/stop are used.")
    print("- Main files to inspect: phase25_trade_selection.csv and phase25_all_vs_selected_summary.csv")


if __name__ == "__main__":
    main()
