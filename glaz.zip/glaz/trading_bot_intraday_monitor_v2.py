#!/usr/bin/env python3
"""
Intraday trade monitor for Google Sheets watchlists.

What it does
- Reads the current Watchlist sheet
- Reads the previous N weekly Watchlist snapshot sheets (if they exist)
- Reads the Trades sheet and monitors only rows with status OPEN
- Pulls delayed intraday OHLC data from Yahoo Finance
- Triggers alerts when:
    high >= entry
    high >= t1
    high >= t2
    low  <= stop
- Prevents duplicate alerts across runs using dedicated alert timestamp columns
- Updates source sheets and appends to DailySignals
- Sends Telegram alerts in HTML mode if configured, otherwise logs to stdout

Main patch in this version
- Supports previous weekly snapshot sheets like: Y26W11 Watchlist
- Supports a Trades sheet with status=open filtering
- Rounds current price / OHLC values to 2 decimals in Telegram messages
- Highlights the triggered level (ENTRY / STOP / T1 / T2) in bold
- Uses GOOGLE_APPLICATION_CREDENTIALS as a file path via:
    gspread.service_account(filename=GOOGLE_APPLICATION_CREDENTIALS)
"""

import os
import json
import time
import traceback
from datetime import datetime, timedelta
from html import escape
from typing import Any, Dict, List, Optional, Tuple

import requests
import yfinance as yf
import gspread


SHEET_ID = os.getenv("SHEET_ID", "").strip()
WATCHLIST_TAB = os.getenv("WATCHLIST_TAB", "Watchlist").strip()
SIGNALS_TAB = os.getenv("SIGNALS_TAB", "DailySignals").strip()
TRADES_TAB = os.getenv("TRADES_TAB", "Trades").strip()
TRADES_STATUS_COLUMN = os.getenv("TRADES_STATUS_COLUMN", "status").strip().lower()
TRADES_OPEN_STATUS = os.getenv("TRADES_OPEN_STATUS", "open").strip().lower()

GOOGLE_APPLICATION_CREDENTIALS = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "").strip()

MONITOR_INTERVAL = os.getenv("MONITOR_INTERVAL", "15m").strip()
YF_PERIOD = os.getenv("YF_PERIOD", "2d").strip()
ALERTS_REQUIRE_TRADE = os.getenv("ALERTS_REQUIRE_TRADE", "true").strip().lower() in ("1", "true", "yes", "y")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()

SYMBOL_OVERRIDES_JSON = os.getenv("SYMBOL_OVERRIDES_JSON", "").strip()
MONITOR_NAME = os.getenv("MONITOR_NAME", "intraday-monitor").strip()
HISTORY_SHEETS_LOOKBACK_WEEKS = int(os.getenv("HISTORY_SHEETS_LOOKBACK_WEEKS", "4").strip())
SNAPSHOT_SUFFIX = os.getenv("SNAPSHOT_SUFFIX", "Watchlist").strip()

WATCHLIST_HEADERS = [
    "symbol", "decision", "entry", "stop", "t1", "t2",
    "last_run", "last_close", "last_status", "last_signal_ts", "notes",
    "entry_alerted_at", "t1_alerted_at", "t2_alerted_at", "stop_alerted_at",
]

TRADES_HEADERS = [
    "symbol", "status", "entry", "stop", "t1", "t2",
    "last_run", "last_close", "last_status", "last_signal_ts", "notes",
    "entry_alerted_at", "t1_alerted_at", "t2_alerted_at", "stop_alerted_at",
]

SIGNALS_HEADERS = [
    "ts", "week_id", "symbol", "event", "price", "entry", "stop", "t1", "t2",
    "bar_ts", "source", "notes",
]


def now_str_local() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log(msg: str) -> None:
    print(f"[{now_str_local()}] {msg}", flush=True)


def to_float(v: Any) -> Optional[float]:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except Exception:
        return None


def fmt2(v: Any) -> str:
    x = to_float(v)
    return f"{x:.2f}" if x is not None else ""


def parse_symbol_overrides() -> Dict[str, str]:
    if not SYMBOL_OVERRIDES_JSON:
        return {}
    try:
        data = json.loads(SYMBOL_OVERRIDES_JSON)
        if isinstance(data, dict):
            return {str(k).strip(): str(v).strip() for k, v in data.items()}
    except Exception as e:
        log(f"WARNING: invalid SYMBOL_OVERRIDES_JSON -> {e}")
    return {}


SYMBOL_OVERRIDES = parse_symbol_overrides()


def previous_snapshot_titles(lookback_weeks: int, suffix: str) -> List[str]:
    titles: List[str] = []
    now = datetime.now()
    for i in range(1, lookback_weeks + 1):
        d = now - timedelta(weeks=i)
        iso = d.isocalendar()
        yy = iso.year % 100
        ww = iso.week
        titles.append(f"Y{yy:02d}W{ww:02d} {suffix}")
    return titles


def get_optional_worksheet(sh: gspread.Spreadsheet, title: str) -> Optional[gspread.Worksheet]:
    try:
        return sh.worksheet(title)
    except gspread.WorksheetNotFound:
        log(f"Sheet not found, skipping: {title}")
        return None


def tv_to_yahoo_symbol(symbol: str) -> str:
    """
    Converts 'NASDAQ:AAPL' -> 'AAPL'.
    Keeps already-Yahoo-style tickers as-is.
    """
    s = (symbol or "").strip()
    if not s:
        return s
    if s in SYMBOL_OVERRIDES:
        return SYMBOL_OVERRIDES[s]
    if ":" in s:
        return s.split(":")[-1].strip()
    return s


def sheet_col_map(headers: List[str]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for i, h in enumerate(headers, start=1):
        key = (h or "").strip().lower()
        if not key:
            continue
        out[key] = i
        out[key.replace(" ", "_")] = i
        out[key.replace("_", " ")] = i
    return out


def ensure_headers(ws: gspread.Worksheet, required_headers: List[str]) -> Dict[str, int]:
    values = ws.get_all_values()
    header_row = values[0] if values else []
    existing = [str(x).strip() for x in header_row]
    existing_lc = {x.strip().lower(): idx + 1 for idx, x in enumerate(existing) if str(x).strip()}
    next_col = len(existing) + 1
    updates = []
    missing = 0
    for h in required_headers:
        if h.lower() not in existing_lc:
            updates.append({
                "range": gspread.utils.rowcol_to_a1(1, next_col),
                "values": [[h]],
            })
            existing_lc[h.lower()] = next_col
            existing.append(h)
            next_col += 1
            missing += 1

    if missing > 0:
        current_cols = getattr(ws, "col_count", len(header_row) or 1)
        needed_cols = len(existing)
        if needed_cols > current_cols:
            ws.add_cols(needed_cols - current_cols)

    if updates:
        ws.batch_update(updates)
    return sheet_col_map(existing)


def get_cell(row: List[str], col_map: Dict[str, int], key: str) -> str:
    idx = col_map.get(key.lower()) or col_map.get(key.replace("_", " ").lower())
    if not idx:
        return ""
    j = idx - 1
    return row[j] if 0 <= j < len(row) else ""


def batch_update_cells(ws: gspread.Worksheet, row_index: int, updates: List[Tuple[int, Any]]) -> None:
    if not updates:
        return
    payload = []
    for col_idx, val in updates:
        payload.append({
            "range": gspread.utils.rowcol_to_a1(row_index, col_idx),
            "values": [["" if val is None else str(val)]],
        })
    ws.batch_update(payload)


def append_row(ws: gspread.Worksheet, values_by_header: Dict[str, Any], col_map: Dict[str, int]) -> None:
    max_col = max(col_map.values()) if col_map else 1
    row = [""] * max_col
    for k, v in values_by_header.items():
        col_idx = col_map.get(k.lower()) or col_map.get(k.replace("_", " ").lower())
        if col_idx:
            row[col_idx - 1] = "" if v is None else str(v)
    ws.append_row(row, value_input_option="USER_ENTERED")


def iso_week_id(dt_val: Optional[datetime] = None) -> str:
    dt_val = dt_val or datetime.now()
    y, w, _ = dt_val.isocalendar()
    return f"{y}-W{w:02d}"


def send_telegram_message(text: str) -> None:
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        log("Telegram not configured; message below:")
        print(text, flush=True)
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "disable_web_page_preview": True,
        "parse_mode": "HTML",
    }
    r = requests.post(url, json=payload, timeout=20)
    r.raise_for_status()


def append_note(existing: str, new_note: str) -> str:
    existing = (existing or "").strip()
    new_note = (new_note or "").strip()
    if not new_note:
        return existing
    if not existing:
        return new_note
    if new_note in existing:
        return existing
    return existing + "\n" + new_note


def fetch_latest_bar(yahoo_symbol: str, interval: str, period: str) -> Optional[Dict[str, Any]]:
    try:
        df = yf.download(
            tickers=yahoo_symbol,
            interval=interval,
            period=period,
            progress=False,
            auto_adjust=False,
            threads=False,
            prepost=False,
            group_by="column",
        )
    except Exception as e:
        log(f"{yahoo_symbol}: yfinance error -> {e}")
        return None

    if df is None or df.empty:
        return None

    try:
        if hasattr(df.columns, "nlevels") and df.columns.nlevels > 1:
            df = df.copy()
            df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]

        last = df.iloc[-1]
        idx = df.index[-1]

        return {
            "bar_ts": str(idx),
            "open": to_float(last["Open"]) if "Open" in last.index else None,
            "high": to_float(last["High"]) if "High" in last.index else None,
            "low": to_float(last["Low"]) if "Low" in last.index else None,
            "close": to_float(last["Close"]) if "Close" in last.index else None,
            "volume": to_float(last["Volume"]) if "Volume" in last.index else None,
        }
    except Exception as e:
        log(f"{yahoo_symbol}: could not parse latest bar -> {e}")
        return None


def connect_sheets() -> Tuple[gspread.Spreadsheet, gspread.Worksheet, gspread.Worksheet, Optional[gspread.Worksheet]]:
    if not SHEET_ID:
        raise RuntimeError("SHEET_ID is required")
    if not GOOGLE_APPLICATION_CREDENTIALS:
        raise RuntimeError("GOOGLE_APPLICATION_CREDENTIALS is required")

    gc = gspread.service_account(filename=GOOGLE_APPLICATION_CREDENTIALS)
    sh = gc.open_by_key(SHEET_ID)

    ws_watch = sh.worksheet(WATCHLIST_TAB)
    try:
        ws_signals = sh.worksheet(SIGNALS_TAB)
    except gspread.WorksheetNotFound:
        ws_signals = sh.add_worksheet(title=SIGNALS_TAB, rows=1000, cols=20)

    ws_trades = get_optional_worksheet(sh, TRADES_TAB)

    ensure_headers(ws_watch, WATCHLIST_HEADERS)
    ensure_headers(ws_signals, SIGNALS_HEADERS)
    if ws_trades is not None:
        ensure_headers(ws_trades, TRADES_HEADERS)

    return sh, ws_watch, ws_signals, ws_trades


def is_open_trade_row(row: List[str], col_map: Dict[str, int]) -> bool:
    status = (get_cell(row, col_map, TRADES_STATUS_COLUMN) or "").strip().lower()
    return status == TRADES_OPEN_STATUS


def is_trade_watchlist_row(row: List[str], col_map: Dict[str, int]) -> bool:
    decision = (get_cell(row, col_map, "decision") or "").strip().upper()
    if ALERTS_REQUIRE_TRADE:
        return decision == "TRADE"
    return True


def evaluate_events(row: List[str], col_map: Dict[str, int], bar: Dict[str, Any]) -> List[Dict[str, Any]]:
    entry = to_float(get_cell(row, col_map, "entry"))
    stop = to_float(get_cell(row, col_map, "stop"))
    t1 = to_float(get_cell(row, col_map, "t1"))
    t2 = to_float(get_cell(row, col_map, "t2"))

    high_v = to_float(bar.get("high"))
    low_v = to_float(bar.get("low"))
    close_v = to_float(bar.get("close"))

    events: List[Dict[str, Any]] = []

    if entry is not None and high_v is not None and not get_cell(row, col_map, "entry_alerted_at") and high_v >= entry:
        events.append({"event": "ENTRY", "trigger_price": close_v, "level": entry})

    if t1 is not None and high_v is not None and not get_cell(row, col_map, "t1_alerted_at") and high_v >= t1:
        events.append({"event": "T1", "trigger_price": close_v, "level": t1})

    if t2 is not None and high_v is not None and not get_cell(row, col_map, "t2_alerted_at") and high_v >= t2:
        events.append({"event": "T2", "trigger_price": close_v, "level": t2})

    if stop is not None and low_v is not None and not get_cell(row, col_map, "stop_alerted_at") and low_v <= stop:
        events.append({"event": "STOP", "trigger_price": close_v, "level": stop})

    return events


def build_alert_message(
    symbol: str,
    source_sheet: str,
    bar: Dict[str, Any],
    event: str,
    row: List[str],
    col_map: Dict[str, int],
) -> str:
    entry = get_cell(row, col_map, "entry")
    stop = get_cell(row, col_map, "stop")
    t1 = get_cell(row, col_map, "t1")
    t2 = get_cell(row, col_map, "t2")
    notes = get_cell(row, col_map, "notes")

    def level_line(name: str, value: str) -> str:
        rendered_value = fmt2(value) or value
        text = f"{name}: {rendered_value}"
        return f"<b>{escape(text)}</b>" if event.upper() == name.upper() else escape(text)

    return (
        f"{escape(MONITOR_NAME)}\n"
        f"Source: {escape(source_sheet)}\n"
        f"Symbol: {escape(symbol)}\n"
        f"Event: <b>{escape(event.upper())}</b>\n"
        f"Bar time: {escape(str(bar.get('bar_ts') or ''))}\n"
        f"Current price: {fmt2(bar.get('close'))}\n"
        f"High: {fmt2(bar.get('high'))}\n"
        f"Low: {fmt2(bar.get('low'))}\n"
        f"{level_line('ENTRY', entry)}\n"
        f"{level_line('STOP', stop)}\n"
        f"{level_line('T1', t1)}\n"
        f"{level_line('T2', t2)}\n\n"
        f"Notes:\n{escape(notes or '')}"
    )


def status_for_event(event: str) -> str:
    event = event.upper().strip()
    return event if event in ("ENTRY", "T1", "T2", "STOP") else "SIGNAL"


def process_source_sheet(
    ws: gspread.Worksheet,
    ws_signals: gspread.Worksheet,
    required_headers: List[str],
    row_filter_fn,
    source_name: str,
    bar_cache: Dict[str, Optional[Dict[str, Any]]],
) -> Tuple[int, int, int]:
    ensure_headers(ws, required_headers)
    values = ws.get_all_values()
    if not values or len(values) < 2:
        log(f"{source_name}: empty sheet")
        return 0, 0, 0

    col_map = sheet_col_map(values[0])
    signals_col_map = ensure_headers(ws_signals, SIGNALS_HEADERS)

    total_rows = 0
    monitored_rows = 0
    alerts_sent = 0

    for row_index, row in enumerate(values[1:], start=2):
        total_rows += 1

        symbol = (get_cell(row, col_map, "symbol") or "").strip()
        if not symbol:
            continue

        if not row_filter_fn(row, col_map):
            continue

        monitored_rows += 1
        yahoo_symbol = tv_to_yahoo_symbol(symbol)

        if yahoo_symbol in bar_cache:
            bar = bar_cache[yahoo_symbol]
        else:
            bar = fetch_latest_bar(yahoo_symbol, MONITOR_INTERVAL, YF_PERIOD)
            bar_cache[yahoo_symbol] = bar

        updates: List[Tuple[int, Any]] = []
        if "last_run" in col_map:
            updates.append((col_map["last_run"], now_str_local()))

        if not bar:
            log(f"{source_name} | {symbol} ({yahoo_symbol}): no intraday data")
            batch_update_cells(ws, row_index, updates)
            continue

        if "last_close" in col_map:
            updates.append((col_map["last_close"], bar.get("close")))

        events = evaluate_events(row, col_map, bar)

        if not events:
            batch_update_cells(ws, row_index, updates)
            log(f"{source_name} | {symbol} ({yahoo_symbol}): no new events | close={fmt2(bar.get('close'))}")
            continue

        week_id = iso_week_id()
        existing_notes = get_cell(row, col_map, "notes")

        for ev in events:
            event = ev["event"].upper().strip()
            ts_now = now_str_local()

            if event == "ENTRY" and "entry_alerted_at" in col_map:
                updates.append((col_map["entry_alerted_at"], ts_now))
            elif event == "T1" and "t1_alerted_at" in col_map:
                updates.append((col_map["t1_alerted_at"], ts_now))
            elif event == "T2" and "t2_alerted_at" in col_map:
                updates.append((col_map["t2_alerted_at"], ts_now))
            elif event == "STOP" and "stop_alerted_at" in col_map:
                updates.append((col_map["stop_alerted_at"], ts_now))

            if "last_status" in col_map:
                updates.append((col_map["last_status"], status_for_event(event)))
            if "last_signal_ts" in col_map:
                updates.append((col_map["last_signal_ts"], ts_now))

            note = (
                f"[INTRADAY_{event}] {ts_now} | source={source_name} | "
                f"bar={bar.get('bar_ts')} | close={fmt2(bar.get('close'))} | "
                f"high={fmt2(bar.get('high'))} | low={fmt2(bar.get('low'))}"
            )
            existing_notes = append_note(existing_notes, note)

            msg = build_alert_message(symbol, source_name, bar, event, row, col_map)
            try:
                send_telegram_message(msg)
                alerts_sent += 1
            except Exception as e:
                log(f"{source_name} | {symbol}: failed to send alert -> {e}")

            append_row(ws_signals, {
                "ts": ts_now,
                "week_id": week_id,
                "symbol": symbol,
                "event": event,
                "price": fmt2(bar.get("close")),
                "entry": get_cell(row, col_map, "entry"),
                "stop": get_cell(row, col_map, "stop"),
                "t1": get_cell(row, col_map, "t1"),
                "t2": get_cell(row, col_map, "t2"),
                "bar_ts": bar.get("bar_ts"),
                "source": f"{source_name}|YAHOO_{MONITOR_INTERVAL}",
                "notes": note,
            }, signals_col_map)

            log(
                f"{source_name} | {symbol}: {event} triggered | "
                f"close={fmt2(bar.get('close'))} high={fmt2(bar.get('high'))} low={fmt2(bar.get('low'))}"
            )

        if "notes" in col_map:
            updates.append((col_map["notes"], existing_notes))

        batch_update_cells(ws, row_index, updates)
        time.sleep(0.5)

    return total_rows, monitored_rows, alerts_sent


def main() -> int:
    sh, ws_watch, ws_signals, ws_trades = connect_sheets()

    total_rows = 0
    monitored_rows = 0
    alerts_sent = 0
    bar_cache: Dict[str, Optional[Dict[str, Any]]] = {}

    t, m, a = process_source_sheet(
        ws=ws_watch,
        ws_signals=ws_signals,
        required_headers=WATCHLIST_HEADERS,
        row_filter_fn=is_trade_watchlist_row,
        source_name=WATCHLIST_TAB,
        bar_cache=bar_cache,
    )
    total_rows += t
    monitored_rows += m
    alerts_sent += a

    for title in previous_snapshot_titles(HISTORY_SHEETS_LOOKBACK_WEEKS, SNAPSHOT_SUFFIX):
        ws_prev = get_optional_worksheet(sh, title)
        if ws_prev is None:
            continue

        t, m, a = process_source_sheet(
            ws=ws_prev,
            ws_signals=ws_signals,
            required_headers=WATCHLIST_HEADERS,
            row_filter_fn=is_trade_watchlist_row,
            source_name=title,
            bar_cache=bar_cache,
        )
        total_rows += t
        monitored_rows += m
        alerts_sent += a

    if ws_trades is not None:
        t, m, a = process_source_sheet(
            ws=ws_trades,
            ws_signals=ws_signals,
            required_headers=TRADES_HEADERS,
            row_filter_fn=is_open_trade_row,
            source_name=TRADES_TAB,
            bar_cache=bar_cache,
        )
        total_rows += t
        monitored_rows += m
        alerts_sent += a

    log(f"Done. total_rows={total_rows} monitored_rows={monitored_rows} alerts_sent={alerts_sent}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as e:
        log(f"FATAL: {type(e).__name__}: {e}")
        traceback.print_exc()
        raise
