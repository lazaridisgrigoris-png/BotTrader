$headers = @{
  "x-api-key" = "0nG77A6Hc6ajztBP6lfXN7HJpwQJUsIHaArnOMnW"
  "Content-Type" = "application/json"
}
$body = '{"symbol":"NASDAQ:AAPL","interval":"1D","range":"YTD","theme":"dark","width":800,"height":600}'

Invoke-WebRequest -Uri "https://api.chart-img.com/v1/tradingview/advanced-chart" -Method Post -Headers $headers -Body $body -OutFile "test.png"
