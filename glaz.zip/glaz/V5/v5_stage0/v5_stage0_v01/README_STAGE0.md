# AutoTrader V5 — Stage 0
## Universe / Security Metadata / Sector Benchmark foundation

Stage 0 is deterministic and contains no AI calls.

It establishes three separate responsibilities:

1. Security Universe — what V5 is allowed to consider.
2. Security Metadata — what each security is.
3. Sector Benchmarks — how a security's local sector should be evaluated.

Existing `Security Metadata` remains authoritative. Stage 0 does not overwrite a non-blank metadata value by default.

Sheets used:
- `Security Universe`
- existing `Security Metadata`
- `Sector Benchmarks`
- `Stage0 Audit`

Market coverage initially includes US, Greece, UK, Germany, France, Italy, Spain, Netherlands, Switzerland, Japan, India, Hong Kong, Canada, and Australia. Non-equity opportunity sleeves are retained for Gold, Silver, Energy, Industrial Metals, and Agriculture.

This v0.1 builds the architecture, migrates the existing Security Metadata into the new universe, optionally merges a seed CSV, validates Yahoo history, creates the sector benchmark matrix, and writes an audit record.

It intentionally does not scrape arbitrary web pages to manufacture stock lists. Automatic market-universe discovery should be implemented as provider adapters in the next Stage-0 increment so each constituent source is explicit, repeatable, and auditable.

Environment:
- `SHEET_ID`
- `SERVICE_ACCOUNT_JSON`
- optional `SECURITY_METADATA_TAB` (default `Security Metadata`)
- optional `SECURITY_UNIVERSE_TAB` (default `Security Universe`)
- optional `SECTOR_BENCHMARKS_TAB` (default `Sector Benchmarks`)
- optional `STAGE0_AUDIT_TAB` (default `Stage0 Audit`)
- optional `YAHOO_VALIDATE` (default `true`)

Run:

```bash
python3 run_stage0.py build
python3 run_stage0.py validate
python3 run_stage0.py build --sync-metadata
```

For first use, run `build` without metadata sync, inspect the new sheets, then enable sync only after review.
