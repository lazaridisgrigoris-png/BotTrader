# V5 Stage 0 Design Decisions

## Security Metadata is kept
Existing Security Metadata remains the security-classification authority.

V5 adds:
- Security Universe: membership and operational state.
- Sector Benchmarks: benchmark mapping.

## Identity model
V5 distinguishes domicile country, listing country, listing market, and primary economic market. This is required for dual-listed / cross-border cases such as ACAG.

## Metadata precedence
Existing non-blank Security Metadata wins by default. Automated sources may fill blanks. Overwriting existing authoritative metadata requires an explicit force option.

## Sector benchmark hierarchy
Official local -> synthetic local -> official regional -> synthetic regional -> global proxy -> neutral.

Provider symbols for official local sector indices must be verified before being marked VERIFIED.

## Automation contract
Every component must run non-interactively, be idempotent, log a version/timestamp, write audit counts, and fail before downstream paid AI if data quality fails.

## Next Stage-0 increment
Add source adapters for automatic universe discovery/refresh per market. Each adapter must output canonical fields and provenance. Discovery answers what is available; later V5 screening answers what is interesting now.
