from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
from pathlib import Path
from typing import Dict, List, Any, Tuple

import pandas as pd
import yfinance as yf
import gspread
from google.oauth2.service_account import Credentials

from stage0_schemas import SECURITY_UNIVERSE_COLUMNS, SECURITY_METADATA_V5_COLUMNS, SECTOR_BENCHMARK_COLUMNS, AUDIT_COLUMNS

VERSION = "5.0-stage0-v0.1"
BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = Path(os.getenv("V5_MARKETS_CONFIG", str(BASE_DIR / "config" / "markets.json")))
SEED_PATH = Path(os.getenv("V5_UNIVERSE_SEED", str(BASE_DIR / "config" / "universe_seed.csv")))
SHEET_ID = os.getenv("SHEET_ID", "").strip()
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "").strip()
SECURITY_METADATA_TAB = os.getenv("SECURITY_METADATA_TAB", "Security Metadata")
SECURITY_UNIVERSE_TAB = os.getenv("SECURITY_UNIVERSE_TAB", "Security Universe")
SECTOR_BENCHMARKS_TAB = os.getenv("SECTOR_BENCHMARKS_TAB", "Sector Benchmarks")
STAGE0_AUDIT_TAB = os.getenv("STAGE0_AUDIT_TAB", "Stage0 Audit")
YAHOO_VALIDATE = os.getenv("YAHOO_VALIDATE", "true").lower() in {"1","true","yes","y"}
YAHOO_HISTORY_PERIOD = os.getenv("YAHOO_HISTORY_PERIOD", "6mo")
MIN_HISTORY_DAYS = int(os.getenv("STAGE0_MIN_HISTORY_DAYS", "40"))
MAX_YAHOO_FAIL_RATIO = float(os.getenv("STAGE0_MAX_YAHOO_FAIL_RATIO", "0.10"))

COUNTRY_ALIASES = {"USA":"UNITED STATES","US":"UNITED STATES","UNITED STATES OF AMERICA":"UNITED STATES","UK":"UNITED KINGDOM","GREAT BRITAIN":"UNITED KINGDOM","HONG KONG SAR":"HONG KONG"}
SECTOR_NORMALIZE = {"COMMUNICATION SERVICES":"COMMUNICATION_SERVICES","CONSUMER CYCLICAL":"CONSUMER_DISCRETIONARY","CONSUMER DISCRETIONARY":"CONSUMER_DISCRETIONARY","CONSUMER DEFENSIVE":"CONSUMER_STAPLES","CONSUMER STAPLES":"CONSUMER_STAPLES","ENERGY":"ENERGY","FINANCIAL SERVICES":"FINANCIALS","FINANCIAL":"FINANCIALS","FINANCIALS":"FINANCIALS","HEALTHCARE":"HEALTHCARE","HEALTH CARE":"HEALTHCARE","INDUSTRIALS":"INDUSTRIALS","BASIC MATERIALS":"MATERIALS","MATERIALS":"MATERIALS","REAL ESTATE":"REAL_ESTATE","TECHNOLOGY":"TECHNOLOGY","UTILITIES":"UTILITIES"}

def now_iso(): return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
def clean(v):
    if v is None: return ""
    s = str(v).strip()
    return "" if s.lower() in {"nan","none","null"} else s

def norm_key(v): return re.sub(r"[^A-Z0-9]+", "", clean(v).upper())
def norm_country(v):
    c = clean(v).upper()
    return COUNTRY_ALIASES.get(c, c)

def norm_sector_group(sector_group, sector):
    sg = clean(sector_group).upper().replace("-","_").replace(" ","_")
    return sg or SECTOR_NORMALIZE.get(clean(sector).upper(), "")

def truthy(v, default=False):
    s = clean(v).lower()
    if not s: return default
    return s in {"1","true","yes","y","on","enabled"}

def choose(*vals):
    for v in vals:
        s = clean(v)
        if s: return s
    return ""

def load_config(): return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))

def gs_client():
    if not SHEET_ID: raise RuntimeError("SHEET_ID is required")
    if not SERVICE_ACCOUNT_JSON: raise RuntimeError("SERVICE_ACCOUNT_JSON is required")
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON, scopes=["https://www.googleapis.com/auth/spreadsheets","https://www.googleapis.com/auth/drive"])
    return gspread.authorize(creds)

def get_or_create_ws(book, title, cols=40):
    try: return book.worksheet(title)
    except gspread.WorksheetNotFound: return book.add_worksheet(title=title, rows=2500, cols=cols)

def ws_to_df(ws):
    vals = ws.get_all_values()
    if not vals: return pd.DataFrame()
    headers = [clean(x) for x in vals[0]]
    width = len(headers)
    rows = [(r + [""] * max(0, width-len(r)))[:width] for r in vals[1:]]
    df = pd.DataFrame(rows, columns=headers)
    if len(df): df = df.loc[~df.apply(lambda r: all(not clean(x) for x in r), axis=1)].copy()
    return df

def ensure_columns(df, cols):
    out = df.copy()
    for c in cols:
        if c not in out.columns: out[c] = ""
    extras = [c for c in out.columns if c not in cols]
    return out[cols + extras]

def write_df(ws, df):
    df = df.fillna("").astype(str)
    ws.clear()
    ws.update(values=[list(df.columns)] + df.values.tolist(), range_name="A1")

def append_row(ws, cols, record):
    if not ws.get_all_values(): ws.update(values=[cols], range_name="A1")
    ws.append_row([clean(record.get(c,"")) for c in cols], value_input_option="RAW")

def market_lookup(config):
    out = {}
    for m in config["equity_markets"]:
        out[norm_country(m["country"])] = m
        out[norm_key(m["market"])] = m
    return out

def infer_market_row(row, config):
    lookup = market_lookup(config)
    for c in [row.get("primary_economic_market"),row.get("listing_country"),row.get("domicile_country"),row.get("country")]:
        if norm_country(c) in lookup: return lookup[norm_country(c)]
        if norm_key(c) in lookup: return lookup[norm_key(c)]
    return {}

def metadata_to_universe(meta, config):
    if meta.empty: return pd.DataFrame(columns=SECURITY_UNIVERSE_COLUMNS)
    rows=[]
    for _,r in meta.iterrows():
        d=r.to_dict(); m=infer_market_row(d,config)
        symbol=choose(d.get("symbol"),d.get("yahoo_symbol")); ys=choose(d.get("yahoo_symbol"),symbol.split(":")[-1] if symbol else "")
        listing_country=choose(d.get("listing_country"),d.get("country")); domicile=choose(d.get("domicile_country"),d.get("country")); econ=choose(d.get("primary_economic_market"),listing_country,domicile)
        rows.append({"universe_id":norm_key(ys or symbol),"symbol":symbol,"yahoo_symbol":ys,"asset_type":choose(d.get("asset_type"),"Stock"),"enabled":"TRUE" if clean(d.get("status")).upper() not in {"DISABLED","INACTIVE","EXCLUDED"} else "FALSE","domicile_country":domicile,"listing_country":listing_country,"listing_market":choose(d.get("listing_market"),d.get("exchange")),"primary_economic_market":econ,"region":choose(d.get("region"),m.get("region")),"sector":clean(d.get("sector")),"industry":clean(d.get("industry")),"sector_group":norm_sector_group(d.get("sector_group"),d.get("sector")),"local_benchmark":choose(d.get("local_benchmark"),m.get("local_benchmark")),"regional_benchmark":choose(d.get("regional_benchmark"),m.get("regional_benchmark")),"global_benchmark":"ACWI","broker_route":choose(d.get("broker_route"),m.get("broker_route")),"tradable":"UNKNOWN","source":choose(d.get("source"),"Security Metadata"),"source_priority":"100","metadata_status":"FOUND","status":"ACTIVE","notes":clean(d.get("notes"))})
    return ensure_columns(pd.DataFrame(rows),SECURITY_UNIVERSE_COLUMNS)

def load_seed(config):
    if not SEED_PATH.exists(): return pd.DataFrame(columns=SECURITY_UNIVERSE_COLUMNS)
    seed=pd.read_csv(SEED_PATH,dtype=str).fillna(""); rows=[]
    for _,r in seed.iterrows():
        d=r.to_dict(); m=infer_market_row(d,config); symbol=choose(d.get("symbol"),d.get("yahoo_symbol")); ys=choose(d.get("yahoo_symbol"),symbol.split(":")[-1] if symbol else "")
        x={**d,"universe_id":norm_key(ys or symbol),"symbol":symbol,"yahoo_symbol":ys,"enabled":"TRUE" if truthy(d.get("enabled"),True) else "FALSE","region":choose(d.get("region"),m.get("region")),"sector_group":norm_sector_group(d.get("sector_group"),d.get("sector")),"local_benchmark":choose(d.get("local_benchmark"),m.get("local_benchmark")),"regional_benchmark":choose(d.get("regional_benchmark"),m.get("regional_benchmark")),"global_benchmark":choose(d.get("global_benchmark"),"ACWI"),"broker_route":choose(d.get("broker_route"),m.get("broker_route")),"source":choose(d.get("source"),"UNIVERSE_SEED"),"source_priority":choose(d.get("source_priority"),"80"),"tradable":choose(d.get("tradable"),"UNKNOWN"),"status":choose(d.get("status"),"ACTIVE")}
        rows.append(x)
    return ensure_columns(pd.DataFrame(rows),SECURITY_UNIVERSE_COLUMNS)

def merge_universe(existing, meta_u, seed):
    sources=[]
    for df,priority in [(existing,120),(meta_u,100),(seed,80)]:
        if df is None or df.empty: continue
        x=ensure_columns(df,SECURITY_UNIVERSE_COLUMNS).copy(); x["_priority"]=priority; sources.append(x)
    if not sources: return pd.DataFrame(columns=SECURITY_UNIVERSE_COLUMNS)
    all_df=pd.concat(sources,ignore_index=True)
    all_df["universe_id"]=all_df.apply(lambda r: choose(r.get("universe_id"),norm_key(choose(r.get("yahoo_symbol"),r.get("symbol")))),axis=1)
    all_df=all_df[all_df["universe_id"].astype(str).str.len()>0]
    merged=[]
    for uid,grp in all_df.groupby("universe_id",sort=False):
        grp=grp.sort_values("_priority",ascending=False); out={"universe_id":uid}
        for c in SECURITY_UNIVERSE_COLUMNS:
            if c!="universe_id": out[c]=choose(*grp[c].tolist())
        merged.append(out)
    return ensure_columns(pd.DataFrame(merged),SECURITY_UNIVERSE_COLUMNS)

def yahoo_validate_row(row):
    ys=clean(row.get("yahoo_symbol"))
    if not ys: return {"yahoo_ok":"NO","data_quality_status":"NO_YAHOO_SYMBOL","history_days":"0","last_verified":now_iso()}
    try:
        hist=yf.download(ys,period=YAHOO_HISTORY_PERIOD,interval="1d",auto_adjust=False,progress=False,threads=False)
        if hist is None or hist.empty: return {"yahoo_ok":"NO","data_quality_status":"NO_PRICE_HISTORY","history_days":"0","last_verified":now_iso()}
        c=hist["Close"].iloc[:,0] if isinstance(hist["Close"],pd.DataFrame) else hist["Close"]; v=hist["Volume"].iloc[:,0] if isinstance(hist["Volume"],pd.DataFrame) else hist["Volume"]
        close=pd.to_numeric(c,errors="coerce").dropna(); vol=pd.to_numeric(v,errors="coerce").dropna(); temp=pd.DataFrame({"c":close,"v":vol}).dropna()
        days=len(close); ok=days>=MIN_HISTORY_DAYS
        return {"last_price":f"{float(close.iloc[-1]):.6f}" if len(close) else "","avg_volume_20d":f"{float(vol.tail(20).mean()):.2f}" if len(vol) else "","median_dollar_volume_20d":f"{float((temp['c']*temp['v']).tail(20).median()):.2f}" if len(temp) else "","history_days":str(days),"yahoo_ok":"YES" if ok else "NO","data_quality_status":"OK" if ok else "INSUFFICIENT_HISTORY","last_verified":now_iso()}
    except Exception as e:
        return {"yahoo_ok":"NO","data_quality_status":f"YAHOO_ERROR:{type(e).__name__}","history_days":"0","last_verified":now_iso()}

def validate_yahoo(df):
    if not YAHOO_VALIDATE or df.empty: return df
    out=df.copy()
    for idx,row in out.iterrows():
        if not truthy(row.get("enabled"),True): continue
        vals=yahoo_validate_row(row.to_dict())
        for k,v in vals.items(): out.at[idx,k]=v
        print(f"[YAHOO] {row.get('yahoo_symbol')} -> {vals.get('data_quality_status')}")
    return out

def build_sector_benchmarks(config,existing):
    existing_map={}
    if existing is not None and not existing.empty:
        existing=ensure_columns(existing,SECTOR_BENCHMARK_COLUMNS)
        for _,r in existing.iterrows(): existing_map[(norm_key(r["market"]),norm_key(r["sector_group"]))]=r.to_dict()
    sg_proxy={x["sector_group"]:x["global_proxy"] for x in config["sector_groups"]}; rows=[]
    for m in config["equity_markets"]:
        for sg,proxy in sg_proxy.items():
            prev=existing_map.get((norm_key(m["market"]),norm_key(sg)),{})
            rows.append({"market":m["market"],"country":m["country"],"region":m["region"],"sector_group":sg,"local_benchmark":m["local_benchmark"],"official_local_sector_name":clean(prev.get("official_local_sector_name")),"official_local_sector_exchange_ticker":clean(prev.get("official_local_sector_exchange_ticker")),"official_local_sector_provider_symbol":clean(prev.get("official_local_sector_provider_symbol")),"official_local_status":choose(prev.get("official_local_status"),"UNVERIFIED"),"official_regional_sector_name":clean(prev.get("official_regional_sector_name")),"official_regional_sector_provider_symbol":clean(prev.get("official_regional_sector_provider_symbol")),"global_sector_benchmark":choose(prev.get("global_sector_benchmark"),proxy),"benchmark_priority":"OFFICIAL_LOCAL>SYNTHETIC_LOCAL>OFFICIAL_REGIONAL>SYNTHETIC_REGIONAL>GLOBAL_PROXY>NEUTRAL","source":choose(prev.get("source"),"V5_STAGE0_SEED"),"last_verified":clean(prev.get("last_verified")),"status":choose(prev.get("status"),"ACTIVE"),"notes":clean(prev.get("notes"))})
    return pd.DataFrame(rows,columns=SECTOR_BENCHMARK_COLUMNS)

def validate_universe(df):
    errors=[]
    if df.empty: return "FAIL",["Security Universe is empty"]
    enabled=df[df["enabled"].astype(str).str.upper().isin(["TRUE","1","YES","Y"])]
    if enabled.empty: errors.append("No enabled securities")
    if df["universe_id"].duplicated().any(): errors.append(f"Duplicate universe_id count={int(df['universe_id'].duplicated().sum())}")
    miss=enabled[enabled["yahoo_symbol"].astype(str).str.strip().eq("")]
    if len(miss): errors.append(f"Enabled rows missing yahoo_symbol={len(miss)}")
    if YAHOO_VALIDATE and len(enabled):
        fails=enabled[enabled["yahoo_ok"].astype(str).str.upper().ne("YES")]; ratio=len(fails)/len(enabled)
        if ratio>MAX_YAHOO_FAIL_RATIO: errors.append(f"Yahoo failure ratio {ratio:.1%} > {MAX_YAHOO_FAIL_RATIO:.1%}")
    return ("PASS" if not errors else "FAIL"),errors

def sync_metadata(meta,universe,force=False):
    meta=ensure_columns(meta,SECURITY_METADATA_V5_COLUMNS); index={}
    for i,r in meta.iterrows():
        for k in [r.get("symbol",""),r.get("yahoo_symbol","")]:
            if norm_key(k): index[norm_key(k)]=i
    for _,u in universe.iterrows():
        if not truthy(u.get("enabled"),True): continue
        keys=[norm_key(u.get("symbol")),norm_key(u.get("yahoo_symbol"))]; idx=next((index[k] for k in keys if k and k in index),None)
        mapped={"symbol":clean(u.get("symbol")),"yahoo_symbol":clean(u.get("yahoo_symbol")),"asset_type":clean(u.get("asset_type")),"exchange":clean(u.get("listing_market")),"country":choose(u.get("listing_country"),u.get("domicile_country")),"region":clean(u.get("region")),"sector":clean(u.get("sector")),"industry":clean(u.get("industry")),"local_benchmark":clean(u.get("local_benchmark")),"regional_benchmark":clean(u.get("regional_benchmark")),"sector_group":clean(u.get("sector_group")),"last_updated":now_iso(),"source":choose(u.get("source"),"V5 Stage0"),"status":clean(u.get("status")),"notes":clean(u.get("notes")),"domicile_country":clean(u.get("domicile_country")),"listing_country":clean(u.get("listing_country")),"listing_market":clean(u.get("listing_market")),"primary_economic_market":clean(u.get("primary_economic_market")),"broker_route":clean(u.get("broker_route"))}
        if idx is None:
            new={c:"" for c in meta.columns}; new.update(mapped); meta=pd.concat([meta,pd.DataFrame([new])],ignore_index=True); idx=len(meta)-1
            for k in keys:
                if k:index[k]=idx
        else:
            for c,v in mapped.items():
                if force or not clean(meta.at[idx,c]):
                    if clean(v): meta.at[idx,c]=v
    return meta

def run(mode,do_sync_metadata=False,force_metadata_overwrite=False):
    config=load_config(); gc=gs_client(); book=gc.open_by_key(SHEET_ID)
    ws_meta=get_or_create_ws(book,SECURITY_METADATA_TAB,50); ws_univ=get_or_create_ws(book,SECURITY_UNIVERSE_TAB,50); ws_sector=get_or_create_ws(book,SECTOR_BENCHMARKS_TAB,30); ws_audit=get_or_create_ws(book,STAGE0_AUDIT_TAB,30)
    meta=ws_to_df(ws_meta); existing_univ=ws_to_df(ws_univ); existing_sector=ws_to_df(ws_sector); seed=load_seed(config)
    universe=merge_universe(existing_univ,metadata_to_universe(meta,config),seed)
    if mode=="build": universe=validate_yahoo(universe)
    status,errors=validate_universe(universe); sectors=build_sector_benchmarks(config,existing_sector)
    if mode=="build":
        write_df(ws_univ,ensure_columns(universe,SECURITY_UNIVERSE_COLUMNS)); write_df(ws_sector,sectors)
        if do_sync_metadata: write_df(ws_meta,sync_metadata(meta,universe,force_metadata_overwrite))
    enabled=universe[universe["enabled"].astype(str).str.upper().isin(["TRUE","1","YES","Y"])] if len(universe) else universe
    audit={"run_ts":now_iso(),"version":VERSION,"mode":mode,"metadata_rows":len(meta),"existing_universe_rows":len(existing_univ),"seed_rows":len(seed),"merged_universe_rows":len(universe),"enabled_rows":len(enabled),"yahoo_ok_rows":int((enabled["yahoo_ok"].astype(str).str.upper()=="YES").sum()) if len(enabled) else 0,"yahoo_fail_rows":int((enabled["yahoo_ok"].astype(str).str.upper()!="YES").sum()) if len(enabled) else 0,"metadata_missing_rows":int((universe["metadata_status"].astype(str).str.upper()!="FOUND").sum()) if len(universe) else 0,"sector_benchmark_rows":len(sectors),"validation_status":status,"errors":" | ".join(errors)}
    append_row(ws_audit,AUDIT_COLUMNS,audit); print(json.dumps(audit,indent=2))
    if status!="PASS": raise SystemExit(2)

def main():
    p=argparse.ArgumentParser(); p.add_argument("mode",choices=["build","validate"]); p.add_argument("--sync-metadata",action="store_true"); p.add_argument("--force-metadata-overwrite",action="store_true"); args=p.parse_args()
    if args.force_metadata_overwrite and not args.sync_metadata: p.error("--force-metadata-overwrite requires --sync-metadata")
    run(args.mode,args.sync_metadata,args.force_metadata_overwrite)

if __name__=="__main__": main()
