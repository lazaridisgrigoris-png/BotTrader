# AutoTrader V5 — Stage 0.2.2

## Purpose
Stage 0.2.2 makes **Sector Benchmarks the authoritative persisted benchmark-resolution table** for V5.

The previous build calculated local/synthetic benchmark resolution in memory, but the worksheet did not expose enough of the actual synthetic definition to audit or consume it safely downstream. v0.2.2 fixes that.

## What is persisted for every market × sector row
The `Sector Benchmarks` worksheet now contains canonical fields:

- `market_benchmark` — broad local market index (e.g. `GD.AT`). This is **not** the sector benchmark.
- official local benchmark fields
- local sector proxy fields
- `synthetic_local_id`
- `synthetic_local_members` — semicolon-separated validated Yahoo/provider symbols
- `synthetic_regional_id`
- `synthetic_regional_members`
- `global_sector_benchmark`
- `resolved_benchmark_type`
- `resolved_benchmark`
- `resolved_benchmark_label`
- `resolved_member_count`
- `resolved_status`
- `resolution_reason`

`effective_benchmark_*` is retained only as a backward-compatible alias.

## Resolution hierarchy

`OFFICIAL_LOCAL > LOCAL_SECTOR_PROXY > SYNTHETIC_LOCAL > SYNTHETIC_REGIONAL > GLOBAL_PROXY > NEUTRAL`

If `resolved_benchmark_type=SYNTHETIC_LOCAL`, then `resolved_benchmark` is the logical basket ID (for example `SYNTH:GREECE:FINANCIALS`) and the exact validated constituents are persisted in `synthetic_local_members`.

If `resolved_benchmark_type=SYNTHETIC_REGIONAL`, the exact constituents are persisted in `synthetic_regional_members`.

## Recommended first run
Because your current `Security Universe` has already been expanded and validated by v0.2.1, you do **not** need to rediscover all securities.

```powershell
python run_stage0.py benchmarks
```

This will rebuild and overwrite:

- `Sector Benchmarks`
- `Sector Benchmark Members`
- append `Stage0 Audit`

It does not modify `Security Metadata`.

## Validation
The final JSON now includes `benchmark_sheet_consistency`.

Expected:

```text
sector_benchmark_rows = 154
benchmark_sheet_consistency = PASS
```

The counts in the final JSON are derived from the same canonical `resolved_benchmark_type` column that is written to `Sector Benchmarks`.

Example consistency check: if JSON says `synthetic_local_rows = 112`, there must be exactly 112 worksheet rows with `resolved_benchmark_type = SYNTHETIC_LOCAL`.

## Full rebuild
Only use this if you want to rerun discovery and Yahoo validation:

```powershell
python run_stage0.py build
```
