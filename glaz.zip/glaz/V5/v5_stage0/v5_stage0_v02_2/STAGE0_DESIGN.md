# Stage 0.2.2 Design — Authoritative Sector Benchmarks

Stage 0.2.2 freezes one important contract for V5:

> Downstream components must consume the persisted `resolved_*` fields in `Sector Benchmarks`; they must not independently re-resolve a different benchmark hierarchy in memory.

For synthetic benchmarks, the worksheet contains both a stable logical ID and the exact validated constituent list used to define the basket on that run.

The broad `market_benchmark` is kept separate from the sector benchmark so `GD.AT`, `SPY`, `^FTSE`, etc. cannot be mistaken for sector references.

`Sector Benchmark Members` remains the normalized/auditable child table. The semicolon-separated member fields in `Sector Benchmarks` are intentionally duplicated for operational transparency and easy downstream loading.
