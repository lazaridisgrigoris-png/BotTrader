# AutoTrader V5 Stage 0.2

Stage 0.2 keeps the Stage 0.1 Security Universe foundation and makes the local-sector benchmark layer operational.

## What is new in 0.2

- Preserves the 14 markets × 11 sector-group matrix (154 rows).
- Validates configured official local sector symbols with Yahoo/yfinance.
- Builds a synthetic local sector basket from the existing `Security Universe` whenever no usable official local sector series exists.
- Writes a new `Sector Benchmark Members` worksheet so every synthetic basket is auditable.
- Resolves each market/sector through:
  `OFFICIAL_LOCAL > SYNTHETIC_LOCAL > OFFICIAL_REGIONAL > SYNTHETIC_REGIONAL > GLOBAL_PROXY > NEUTRAL`.
- Adds `effective_benchmark_type`, `effective_benchmark_symbol`, resolution status/reason, constituent counts and coverage diagnostics to `Sector Benchmarks`.
- Adds fail-fast startup errors for missing credentials/config files.
- Adds `benchmarks` mode so sector work can be rerun without downloading Yahoo data for the whole stock universe.

## First run from Stage 0.1

Keep your existing environment variables (`SHEET_ID`, `SERVICE_ACCOUNT_JSON`). Then run:

```powershell
python run_stage0.py benchmarks
```

This reuses the already validated `Security Universe` and updates only:

- `Sector Benchmarks`
- `Sector Benchmark Members`
- `Stage0 Audit`

It does **not** modify `Security Metadata` unless `--sync-metadata` is explicitly supplied.

## Full rebuild

```powershell
python run_stage0.py build
```

This also revalidates all enabled universe Yahoo symbols before rebuilding the sector layer.

## Do not sync metadata yet

For the first 0.2 run, do not use `--sync-metadata`. Inspect the sector resolution first.

## Greece / Financials seed

The included seed contains:

- Official index name: `FTSE/ATHEX Banks`
- ATHEX exchange ticker: `DTR`
- Yahoo provider symbol candidate: `DTR.AT`

The code still validates `DTR.AT` at runtime. A configured seed is not accepted as verified merely because it exists in the CSV.

## Synthetic local sector

When an official local provider symbol is unavailable or does not validate, Stage 0.2 groups enabled securities by **market + sector_group** and uses Yahoo-valid members as an equal-weight synthetic local sector basket.

`SYNTH:<MARKET>:<SECTOR_GROUP>` is a logical V5 benchmark identifier, not a Yahoo ticker. Its exact constituents are stored in `Sector Benchmark Members`.

The default minimum of two valid securities is an operational definition of a basket, not a trading threshold. It can be changed with `STAGE0_MIN_SYNTHETIC_MEMBERS`.
