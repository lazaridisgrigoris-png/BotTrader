# V5 Stage 0.2 Design

## Purpose

Stage 0.2 fixes the benchmark-layer gap discovered after Stage 0.1: `local_benchmark` identifies the broad local market (for example `GD.AT`), but that is not a local **sector** benchmark.

Stage 0.2 therefore resolves a separate sector reference for every market/sector pair.

## Resolution hierarchy

1. `OFFICIAL_LOCAL`
2. `SYNTHETIC_LOCAL`
3. `OFFICIAL_REGIONAL`
4. `SYNTHETIC_REGIONAL` (schema-reserved; not yet generated in 0.2)
5. `GLOBAL_PROXY`
6. `NEUTRAL`

The first validated/usable layer wins.

## Official local validation

An official-local mapping can be supplied through `config/sector_benchmark_seed.csv` or edited in the Google Sheet. A provider symbol is not marked verified until yfinance returns at least the configured minimum history.

## Synthetic local construction

Synthetic local sectors are built only from the existing Security Universe. A stock must:

- be enabled;
- map to one of the configured V5 markets;
- have a sector group;
- have `yahoo_ok=YES` to count as a valid basket member.

The member list is written to `Sector Benchmark Members`. Stage 0.2 does not yet calculate a permanent stored synthetic index time series; downstream opportunity/scoring modules will calculate the equal-weight sector return from these auditable members as of the analysis date.

This avoids look-ahead caused by storing a single current synthetic series as if its historical constituent membership had always been identical. Historical constituent handling can be added when the historical validation engine requires it.

## Data ownership

- `Security Universe`: potential investable securities and operational data quality.
- `Security Metadata`: identity/classification data.
- `Sector Benchmarks`: benchmark-resolution policy and current effective source.
- `Sector Benchmark Members`: auditable membership for synthetic local sector baskets.

## No trading logic

Stage 0.2 does not score trades, rank stocks, allocate capital, or call AI.
