from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
from pathlib import Path
from typing import Dict, Any, Tuple

import pandas as pd
import yfinance as yf
import gspread
from google.oauth2.service_account import Credentials

from stage0_schemas import (
    SECURITY_UNIVERSE_COLUMNS,
    SECURITY_METADATA_V5_COLUMNS,
    SECTOR_BENCHMARK_COLUMNS,
    SECTOR_MEMBER_COLUMNS,
    AUDIT_COLUMNS,
)

VERSION = "5.0-stage0-v0.2"
BASE_DIR = Path(__file__).resolve().parent
CONFIG_PATH = Path(os.getenv("V5_MARKETS_CONFIG", str(BASE_DIR / "config" / "markets.json")))
SEED_PATH = Path(os.getenv("V5_UNIVERSE_SEED", str(BASE_DIR / "config" / "universe_seed.csv")))
SECTOR_SEED_PATH = Path(os.getenv("V5_SECTOR_BENCHMARK_SEED", str(BASE_DIR / "config" / "sector_benchmark_seed.csv")))

SHEET_ID = os.getenv("SHEET_ID", "").strip()
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "").strip()
SECURITY_METADATA_TAB = os.getenv("SECURITY_METADATA_TAB", "Security Metadata")
SECURITY_UNIVERSE_TAB = os.getenv("SECURITY_UNIVERSE_TAB", "Security Universe")
SECTOR_BENCHMARKS_TAB = os.getenv("SECTOR_BENCHMARKS_TAB", "Sector Benchmarks")
SECTOR_MEMBERS_TAB = os.getenv("SECTOR_MEMBERS_TAB", "Sector Benchmark Members")
STAGE0_AUDIT_TAB = os.getenv("STAGE0_AUDIT_TAB", "Stage0 Audit")

YAHOO_VALIDATE = os.getenv("YAHOO_VALIDATE", "true").lower() in {"1", "true", "yes", "y"}
YAHOO_HISTORY_PERIOD = os.getenv("YAHOO_HISTORY_PERIOD", "6mo")
MIN_HISTORY_DAYS = int(os.getenv("STAGE0_MIN_HISTORY_DAYS", "40"))
MAX_YAHOO_FAIL_RATIO = float(os.getenv("STAGE0_MAX_YAHOO_FAIL_RATIO", "0.10"))
# This is an operational definition, not a trading threshold: a synthetic "sector"
# must have at least two independently listed members to be a sector basket.
MIN_SYNTHETIC_MEMBERS = int(os.getenv("STAGE0_MIN_SYNTHETIC_MEMBERS", "2"))

COUNTRY_ALIASES = {
    "USA": "UNITED STATES",
    "US": "UNITED STATES",
    "UNITED STATES OF AMERICA": "UNITED STATES",
    "UK": "UNITED KINGDOM",
    "GREAT BRITAIN": "UNITED KINGDOM",
    "HONG KONG SAR": "HONG KONG",
}
SECTOR_NORMALIZE = {
    "COMMUNICATION SERVICES": "COMMUNICATION_SERVICES",
    "CONSUMER CYCLICAL": "CONSUMER_DISCRETIONARY",
    "CONSUMER DISCRETIONARY": "CONSUMER_DISCRETIONARY",
    "CONSUMER DEFENSIVE": "CONSUMER_STAPLES",
    "CONSUMER STAPLES": "CONSUMER_STAPLES",
    "ENERGY": "ENERGY",
    "FINANCIAL SERVICES": "FINANCIALS",
    "FINANCIAL": "FINANCIALS",
    "FINANCIALS": "FINANCIALS",
    "HEALTHCARE": "HEALTHCARE",
    "HEALTH CARE": "HEALTHCARE",
    "INDUSTRIALS": "INDUSTRIALS",
    "BASIC MATERIALS": "MATERIALS",
    "MATERIALS": "MATERIALS",
    "REAL ESTATE": "REAL_ESTATE",
    "TECHNOLOGY": "TECHNOLOGY",
    "UTILITIES": "UTILITIES",
}


def now_iso() -> str:
    return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()


def clean(v: Any) -> str:
    if v is None:
        return ""
    s = str(v).strip()
    return "" if s.lower() in {"nan", "none", "null"} else s


def norm_key(v: Any) -> str:
    return re.sub(r"[^A-Z0-9]+", "", clean(v).upper())


def norm_country(v: Any) -> str:
    c = clean(v).upper()
    return COUNTRY_ALIASES.get(c, c)


def norm_sector_group(sector_group: Any, sector: Any) -> str:
    sg = clean(sector_group).upper().replace("-", "_").replace(" ", "_")
    return sg or SECTOR_NORMALIZE.get(clean(sector).upper(), "")


def truthy(v: Any, default: bool = False) -> bool:
    s = clean(v).lower()
    if not s:
        return default
    return s in {"1", "true", "yes", "y", "on", "enabled"}


def choose(*vals: Any) -> str:
    for v in vals:
        s = clean(v)
        if s:
            return s
    return ""


def load_config() -> Dict[str, Any]:
    return json.loads(CONFIG_PATH.read_text(encoding="utf-8"))


def validate_startup_files() -> None:
    if not SHEET_ID:
        raise RuntimeError("STAGE0 CONFIG ERROR: SHEET_ID is required")
    if not SERVICE_ACCOUNT_JSON:
        raise RuntimeError("STAGE0 CONFIG ERROR: SERVICE_ACCOUNT_JSON is required")
    p = Path(SERVICE_ACCOUNT_JSON)
    if not p.exists():
        raise RuntimeError(f"STAGE0 CONFIG ERROR: Service-account file not found: {p}")
    if not CONFIG_PATH.exists():
        raise RuntimeError(f"STAGE0 CONFIG ERROR: Markets config not found: {CONFIG_PATH}")


def gs_client():
    validate_startup_files()
    creds = Credentials.from_service_account_file(
        SERVICE_ACCOUNT_JSON,
        scopes=[
            "https://www.googleapis.com/auth/spreadsheets",
            "https://www.googleapis.com/auth/drive",
        ],
    )
    return gspread.authorize(creds)


def get_or_create_ws(book, title: str, cols: int = 40):
    try:
        return book.worksheet(title)
    except gspread.WorksheetNotFound:
        return book.add_worksheet(title=title, rows=3000, cols=cols)


def ws_to_df(ws) -> pd.DataFrame:
    vals = ws.get_all_values()
    if not vals:
        return pd.DataFrame()
    headers = [clean(x) for x in vals[0]]
    width = len(headers)
    rows = [(r + [""] * max(0, width - len(r)))[:width] for r in vals[1:]]
    df = pd.DataFrame(rows, columns=headers)
    if len(df):
        df = df.loc[~df.apply(lambda r: all(not clean(x) for x in r), axis=1)].copy()
    return df


def ensure_columns(df: pd.DataFrame, cols) -> pd.DataFrame:
    out = df.copy()
    for c in cols:
        if c not in out.columns:
            out[c] = ""
    extras = [c for c in out.columns if c not in cols]
    return out[cols + extras]


def write_df(ws, df: pd.DataFrame) -> None:
    df = df.fillna("").astype(str)
    ws.clear()
    ws.update(values=[list(df.columns)] + df.values.tolist(), range_name="A1")


def append_row(ws, cols, record: Dict[str, Any]) -> None:
    if not ws.get_all_values():
        ws.update(values=[cols], range_name="A1")
    ws.append_row([clean(record.get(c, "")) for c in cols], value_input_option="RAW")


def market_lookup(config: Dict[str, Any]) -> Dict[str, Dict[str, Any]]:
    out = {}
    for m in config["equity_markets"]:
        out[norm_country(m["country"])] = m
        out[norm_key(m["market"])] = m
    return out


def infer_market_row(row: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    lookup = market_lookup(config)
    for c in [
        row.get("primary_economic_market"),
        row.get("listing_country"),
        row.get("domicile_country"),
        row.get("country"),
    ]:
        if norm_country(c) in lookup:
            return lookup[norm_country(c)]
        if norm_key(c) in lookup:
            return lookup[norm_key(c)]
    return {}


def metadata_to_universe(meta: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    if meta.empty:
        return pd.DataFrame(columns=SECURITY_UNIVERSE_COLUMNS)
    rows = []
    for _, r in meta.iterrows():
        d = r.to_dict()
        m = infer_market_row(d, config)
        symbol = choose(d.get("symbol"), d.get("yahoo_symbol"))
        ys = choose(d.get("yahoo_symbol"), symbol.split(":")[-1] if symbol else "")
        listing_country = choose(d.get("listing_country"), d.get("country"))
        domicile = choose(d.get("domicile_country"), d.get("country"))
        econ = choose(d.get("primary_economic_market"), listing_country, domicile)
        rows.append(
            {
                "universe_id": norm_key(ys or symbol),
                "symbol": symbol,
                "yahoo_symbol": ys,
                "asset_type": choose(d.get("asset_type"), "Stock"),
                "enabled": "TRUE"
                if clean(d.get("status")).upper() not in {"DISABLED", "INACTIVE", "EXCLUDED"}
                else "FALSE",
                "domicile_country": domicile,
                "listing_country": listing_country,
                "listing_market": choose(d.get("listing_market"), d.get("exchange")),
                "primary_economic_market": econ,
                "region": choose(d.get("region"), m.get("region")),
                "sector": clean(d.get("sector")),
                "industry": clean(d.get("industry")),
                "sector_group": norm_sector_group(d.get("sector_group"), d.get("sector")),
                "local_benchmark": choose(d.get("local_benchmark"), m.get("local_benchmark")),
                "regional_benchmark": choose(d.get("regional_benchmark"), m.get("regional_benchmark")),
                "global_benchmark": "ACWI",
                "broker_route": choose(d.get("broker_route"), m.get("broker_route")),
                "tradable": "UNKNOWN",
                "source": choose(d.get("source"), "Security Metadata"),
                "source_priority": "100",
                "metadata_status": "FOUND",
                "status": "ACTIVE",
                "notes": clean(d.get("notes")),
            }
        )
    return ensure_columns(pd.DataFrame(rows), SECURITY_UNIVERSE_COLUMNS)


def load_seed(config: Dict[str, Any]) -> pd.DataFrame:
    if not SEED_PATH.exists():
        return pd.DataFrame(columns=SECURITY_UNIVERSE_COLUMNS)
    seed = pd.read_csv(SEED_PATH, dtype=str).fillna("")
    rows = []
    for _, r in seed.iterrows():
        d = r.to_dict()
        m = infer_market_row(d, config)
        symbol = choose(d.get("symbol"), d.get("yahoo_symbol"))
        ys = choose(d.get("yahoo_symbol"), symbol.split(":")[-1] if symbol else "")
        x = {
            **d,
            "universe_id": norm_key(ys or symbol),
            "symbol": symbol,
            "yahoo_symbol": ys,
            "enabled": "TRUE" if truthy(d.get("enabled"), True) else "FALSE",
            "region": choose(d.get("region"), m.get("region")),
            "sector_group": norm_sector_group(d.get("sector_group"), d.get("sector")),
            "local_benchmark": choose(d.get("local_benchmark"), m.get("local_benchmark")),
            "regional_benchmark": choose(d.get("regional_benchmark"), m.get("regional_benchmark")),
            "global_benchmark": choose(d.get("global_benchmark"), "ACWI"),
            "broker_route": choose(d.get("broker_route"), m.get("broker_route")),
            "source": choose(d.get("source"), "UNIVERSE_SEED"),
            "source_priority": choose(d.get("source_priority"), "80"),
            "tradable": choose(d.get("tradable"), "UNKNOWN"),
            "status": choose(d.get("status"), "ACTIVE"),
        }
        rows.append(x)
    return ensure_columns(pd.DataFrame(rows), SECURITY_UNIVERSE_COLUMNS)


def merge_universe(existing: pd.DataFrame, meta_u: pd.DataFrame, seed: pd.DataFrame) -> pd.DataFrame:
    sources = []
    for df, priority in [(existing, 120), (meta_u, 100), (seed, 80)]:
        if df is None or df.empty:
            continue
        x = ensure_columns(df, SECURITY_UNIVERSE_COLUMNS).copy()
        x["_priority"] = priority
        sources.append(x)
    if not sources:
        return pd.DataFrame(columns=SECURITY_UNIVERSE_COLUMNS)
    all_df = pd.concat(sources, ignore_index=True)
    all_df["universe_id"] = all_df.apply(
        lambda r: choose(r.get("universe_id"), norm_key(choose(r.get("yahoo_symbol"), r.get("symbol")))),
        axis=1,
    )
    all_df = all_df[all_df["universe_id"].astype(str).str.len() > 0]
    merged = []
    for uid, grp in all_df.groupby("universe_id", sort=False):
        grp = grp.sort_values("_priority", ascending=False)
        out = {"universe_id": uid}
        for c in SECURITY_UNIVERSE_COLUMNS:
            if c != "universe_id":
                out[c] = choose(*grp[c].tolist())
        merged.append(out)
    return ensure_columns(pd.DataFrame(merged), SECURITY_UNIVERSE_COLUMNS)


def yahoo_history_status(symbol: str, cache: Dict[str, Tuple[bool, str, int]]) -> Tuple[bool, str, int]:
    symbol = clean(symbol)
    if not symbol:
        return False, "NO_SYMBOL", 0
    if symbol in cache:
        return cache[symbol]
    try:
        hist = yf.download(
            symbol,
            period=YAHOO_HISTORY_PERIOD,
            interval="1d",
            auto_adjust=False,
            progress=False,
            threads=False,
        )
        if hist is None or hist.empty:
            out = (False, "NO_PRICE_HISTORY", 0)
        else:
            c = hist["Close"].iloc[:, 0] if isinstance(hist["Close"], pd.DataFrame) else hist["Close"]
            close = pd.to_numeric(c, errors="coerce").dropna()
            days = len(close)
            out = (days >= MIN_HISTORY_DAYS, "OK" if days >= MIN_HISTORY_DAYS else "INSUFFICIENT_HISTORY", days)
    except Exception as e:
        out = (False, f"YAHOO_ERROR:{type(e).__name__}", 0)
    cache[symbol] = out
    return out


def yahoo_validate_row(row: Dict[str, Any]) -> Dict[str, str]:
    ys = clean(row.get("yahoo_symbol"))
    if not ys:
        return {
            "yahoo_ok": "NO",
            "data_quality_status": "NO_YAHOO_SYMBOL",
            "history_days": "0",
            "last_verified": now_iso(),
        }
    try:
        hist = yf.download(
            ys,
            period=YAHOO_HISTORY_PERIOD,
            interval="1d",
            auto_adjust=False,
            progress=False,
            threads=False,
        )
        if hist is None or hist.empty:
            return {
                "yahoo_ok": "NO",
                "data_quality_status": "NO_PRICE_HISTORY",
                "history_days": "0",
                "last_verified": now_iso(),
            }
        c = hist["Close"].iloc[:, 0] if isinstance(hist["Close"], pd.DataFrame) else hist["Close"]
        v = hist["Volume"].iloc[:, 0] if isinstance(hist["Volume"], pd.DataFrame) else hist["Volume"]
        close = pd.to_numeric(c, errors="coerce").dropna()
        vol = pd.to_numeric(v, errors="coerce").dropna()
        temp = pd.DataFrame({"c": close, "v": vol}).dropna()
        days = len(close)
        ok = days >= MIN_HISTORY_DAYS
        return {
            "last_price": f"{float(close.iloc[-1]):.6f}" if len(close) else "",
            "avg_volume_20d": f"{float(vol.tail(20).mean()):.2f}" if len(vol) else "",
            "median_dollar_volume_20d": f"{float((temp['c'] * temp['v']).tail(20).median()):.2f}" if len(temp) else "",
            "history_days": str(days),
            "yahoo_ok": "YES" if ok else "NO",
            "data_quality_status": "OK" if ok else "INSUFFICIENT_HISTORY",
            "last_verified": now_iso(),
        }
    except Exception as e:
        return {
            "yahoo_ok": "NO",
            "data_quality_status": f"YAHOO_ERROR:{type(e).__name__}",
            "history_days": "0",
            "last_verified": now_iso(),
        }


def validate_yahoo(df: pd.DataFrame) -> pd.DataFrame:
    if not YAHOO_VALIDATE or df.empty:
        return df
    out = df.copy()
    for idx, row in out.iterrows():
        if not truthy(row.get("enabled"), True):
            continue
        vals = yahoo_validate_row(row.to_dict())
        for k, v in vals.items():
            out.at[idx, k] = v
        print(f"[YAHOO] {row.get('yahoo_symbol')} -> {vals.get('data_quality_status')}")
    return out


def load_sector_seed() -> pd.DataFrame:
    if not SECTOR_SEED_PATH.exists():
        return pd.DataFrame()
    return pd.read_csv(SECTOR_SEED_PATH, dtype=str).fillna("")


def sector_seed_map(seed: pd.DataFrame) -> Dict[Tuple[str, str], Dict[str, str]]:
    out: Dict[Tuple[str, str], Dict[str, str]] = {}
    if seed is None or seed.empty:
        return out
    for _, r in seed.iterrows():
        out[(norm_key(r.get("market")), norm_key(r.get("sector_group")))] = r.to_dict()
    return out


def build_sector_members(universe: pd.DataFrame, config: Dict[str, Any]) -> pd.DataFrame:
    rows = []
    if universe.empty:
        return pd.DataFrame(columns=SECTOR_MEMBER_COLUMNS)
    for _, r in universe.iterrows():
        if not truthy(r.get("enabled"), True):
            continue
        sg = norm_sector_group(r.get("sector_group"), r.get("sector"))
        if not sg:
            continue
        m = infer_market_row(r.to_dict(), config)
        if not m:
            continue
        yahoo_ok = clean(r.get("yahoo_ok")).upper()
        member_status = "VALID" if yahoo_ok == "YES" else "INVALID_DATA"
        rows.append(
            {
                "market": m["market"],
                "country": m["country"],
                "region": m["region"],
                "sector_group": sg,
                "universe_id": clean(r.get("universe_id")),
                "symbol": clean(r.get("symbol")),
                "yahoo_symbol": clean(r.get("yahoo_symbol")),
                "enabled": clean(r.get("enabled")),
                "yahoo_ok": clean(r.get("yahoo_ok")),
                "data_quality_status": clean(r.get("data_quality_status")),
                "member_status": member_status,
                "weighting_method": "EQUAL_WEIGHT",
                "source": "Security Universe",
            }
        )
    return pd.DataFrame(rows, columns=SECTOR_MEMBER_COLUMNS)


def build_sector_benchmarks(
    config: Dict[str, Any],
    existing: pd.DataFrame,
    universe: pd.DataFrame,
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    existing_map = {}
    if existing is not None and not existing.empty:
        existing = ensure_columns(existing, SECTOR_BENCHMARK_COLUMNS)
        for _, r in existing.iterrows():
            existing_map[(norm_key(r["market"]), norm_key(r["sector_group"]))] = r.to_dict()

    seed = load_sector_seed()
    seed_map = sector_seed_map(seed)
    sg_proxy = {x["sector_group"]: x["global_proxy"] for x in config["sector_groups"]}
    members = build_sector_members(universe, config)
    yahoo_cache: Dict[str, Tuple[bool, str, int]] = {}
    rows = []

    for m in config["equity_markets"]:
        for sg, proxy in sg_proxy.items():
            key = (norm_key(m["market"]), norm_key(sg))
            prev = existing_map.get(key, {})
            seeded = seed_map.get(key, {})

            # Seed values take precedence over blank/unverified generated rows, while user-edited
            # nonblank values in the sheet remain authoritative.
            local_name = choose(prev.get("official_local_sector_name"), seeded.get("official_local_sector_name"))
            local_ticker = choose(prev.get("official_local_sector_exchange_ticker"), seeded.get("official_local_sector_exchange_ticker"))
            local_symbol = choose(prev.get("official_local_sector_provider_symbol"), seeded.get("official_local_sector_provider_symbol"))
            local_status = choose(prev.get("official_local_status"), seeded.get("official_local_status"), "UNVERIFIED")
            regional_name = choose(prev.get("official_regional_sector_name"), seeded.get("official_regional_sector_name"))
            regional_symbol = choose(prev.get("official_regional_sector_provider_symbol"), seeded.get("official_regional_sector_provider_symbol"))
            regional_status = choose(prev.get("official_regional_status"), seeded.get("official_regional_status"), "UNVERIFIED")
            global_symbol = choose(prev.get("global_sector_benchmark"), proxy)

            local_ok, local_validation, local_days = yahoo_history_status(local_symbol, yahoo_cache) if local_symbol else (False, "NOT_CONFIGURED", 0)
            regional_ok, regional_validation, _ = yahoo_history_status(regional_symbol, yahoo_cache) if regional_symbol else (False, "NOT_CONFIGURED", 0)
            global_ok, global_validation, _ = yahoo_history_status(global_symbol, yahoo_cache) if global_symbol else (False, "NOT_CONFIGURED", 0)

            mm = members[(members["market"] == m["market"]) & (members["sector_group"] == sg)] if len(members) else members
            member_count = len(mm)
            valid_count = int((mm["member_status"] == "VALID").sum()) if len(mm) else 0
            coverage = (valid_count / member_count) if member_count else 0.0
            synthetic_ok = valid_count >= MIN_SYNTHETIC_MEMBERS
            synthetic_status = "USABLE" if synthetic_ok else ("INSUFFICIENT_MEMBERS" if member_count else "NO_MEMBERS")

            if local_ok:
                effective_type = "OFFICIAL_LOCAL"
                effective_symbol = local_symbol
                effective_label = local_name or local_symbol
                resolution_status = "RESOLVED_LOCAL"
                reason = f"Official local provider symbol validated with {local_days} history days"
            elif synthetic_ok:
                effective_type = "SYNTHETIC_LOCAL"
                effective_symbol = f"SYNTH:{m['market']}:{sg}"
                effective_label = f"Synthetic {m['market']} {sg} basket"
                resolution_status = "RESOLVED_LOCAL"
                reason = f"Official local unavailable; {valid_count}/{member_count} local members usable"
            elif regional_ok:
                effective_type = "OFFICIAL_REGIONAL"
                effective_symbol = regional_symbol
                effective_label = regional_name or regional_symbol
                resolution_status = "RESOLVED_REGIONAL"
                reason = "No usable local benchmark; official regional provider symbol validated"
            elif global_ok:
                effective_type = "GLOBAL_PROXY"
                effective_symbol = global_symbol
                effective_label = global_symbol
                resolution_status = "RESOLVED_GLOBAL_FALLBACK"
                reason = "No usable local/regional benchmark; global proxy validated"
            else:
                effective_type = "NEUTRAL"
                effective_symbol = ""
                effective_label = "NEUTRAL"
                resolution_status = "UNRESOLVED"
                reason = "No validated official/synthetic/regional/global benchmark available"

            source = choose(prev.get("source"), seeded.get("source"), "V5_STAGE0_V02")
            notes = choose(prev.get("notes"), seeded.get("notes"))
            rows.append(
                {
                    "market": m["market"],
                    "country": m["country"],
                    "region": m["region"],
                    "sector_group": sg,
                    "local_benchmark": m["local_benchmark"],
                    "official_local_sector_name": local_name,
                    "official_local_sector_exchange_ticker": local_ticker,
                    "official_local_sector_provider_symbol": local_symbol,
                    "official_local_status": "VERIFIED" if local_ok else local_status,
                    "official_local_validation_status": local_validation,
                    "official_local_history_days": str(local_days),
                    "synthetic_local_member_count": str(member_count),
                    "synthetic_local_valid_member_count": str(valid_count),
                    "synthetic_local_coverage_ratio": f"{coverage:.4f}",
                    "synthetic_local_status": synthetic_status,
                    "official_regional_sector_name": regional_name,
                    "official_regional_sector_provider_symbol": regional_symbol,
                    "official_regional_status": "VERIFIED" if regional_ok else regional_status,
                    "official_regional_validation_status": regional_validation,
                    "global_sector_benchmark": global_symbol,
                    "global_proxy_validation_status": global_validation,
                    "effective_benchmark_type": effective_type,
                    "effective_benchmark_symbol": effective_symbol,
                    "effective_benchmark_label": effective_label,
                    "resolution_status": resolution_status,
                    "resolution_reason": reason,
                    "benchmark_priority": "OFFICIAL_LOCAL>SYNTHETIC_LOCAL>OFFICIAL_REGIONAL>SYNTHETIC_REGIONAL>GLOBAL_PROXY>NEUTRAL",
                    "source": source,
                    "last_verified": now_iso(),
                    "status": choose(prev.get("status"), "ACTIVE"),
                    "notes": notes,
                }
            )

    return pd.DataFrame(rows, columns=SECTOR_BENCHMARK_COLUMNS), members


def validate_universe(df: pd.DataFrame) -> Tuple[str, list[str]]:
    errors = []
    if df.empty:
        return "FAIL", ["Security Universe is empty"]
    enabled = df[df["enabled"].astype(str).str.upper().isin(["TRUE", "1", "YES", "Y"])]
    if enabled.empty:
        errors.append("No enabled securities")
    if df["universe_id"].duplicated().any():
        errors.append(f"Duplicate universe_id count={int(df['universe_id'].duplicated().sum())}")
    miss = enabled[enabled["yahoo_symbol"].astype(str).str.strip().eq("")]
    if len(miss):
        errors.append(f"Enabled rows missing yahoo_symbol={len(miss)}")
    if YAHOO_VALIDATE and len(enabled):
        fails = enabled[enabled["yahoo_ok"].astype(str).str.upper().ne("YES")]
        ratio = len(fails) / len(enabled)
        if ratio > MAX_YAHOO_FAIL_RATIO:
            errors.append(f"Yahoo failure ratio {ratio:.1%} > {MAX_YAHOO_FAIL_RATIO:.1%}")
    return ("PASS" if not errors else "FAIL"), errors


def validate_sector_resolution(sectors: pd.DataFrame) -> list[str]:
    errors = []
    if sectors.empty:
        return ["Sector Benchmarks is empty"]
    unresolved = sectors[sectors["resolution_status"] == "UNRESOLVED"]
    # Unresolved sectors are reported, not treated as a Stage0 hard failure. Some markets can
    # legitimately lack a local/regional/global sector series. Downstream must use NEUTRAL.
    if len(unresolved):
        print(f"[SECTOR] WARNING: unresolved sector rows={len(unresolved)} (neutral fallback)")
    return errors


def sync_metadata(meta: pd.DataFrame, universe: pd.DataFrame, sectors: pd.DataFrame, force: bool = False) -> pd.DataFrame:
    meta = ensure_columns(meta, SECURITY_METADATA_V5_COLUMNS)
    index = {}
    for i, r in meta.iterrows():
        for k in [r.get("symbol", ""), r.get("yahoo_symbol", "")]:
            if norm_key(k):
                index[norm_key(k)] = i

    sector_effective = {}
    for _, s in sectors.iterrows():
        sector_effective[(norm_key(s.get("market")), norm_key(s.get("sector_group")))] = s.to_dict()

    config = load_config()
    for _, u in universe.iterrows():
        if not truthy(u.get("enabled"), True):
            continue
        keys = [norm_key(u.get("symbol")), norm_key(u.get("yahoo_symbol"))]
        idx = next((index[k] for k in keys if k and k in index), None)
        market = infer_market_row(u.to_dict(), config)
        sec = sector_effective.get((norm_key(market.get("market")), norm_key(u.get("sector_group"))), {}) if market else {}
        mapped = {
            "symbol": clean(u.get("symbol")),
            "yahoo_symbol": clean(u.get("yahoo_symbol")),
            "asset_type": clean(u.get("asset_type")),
            "exchange": clean(u.get("listing_market")),
            "country": choose(u.get("listing_country"), u.get("domicile_country")),
            "region": clean(u.get("region")),
            "sector": clean(u.get("sector")),
            "industry": clean(u.get("industry")),
            "local_benchmark": clean(u.get("local_benchmark")),
            "regional_benchmark": clean(u.get("regional_benchmark")),
            "sector_benchmark": clean(sec.get("effective_benchmark_symbol")),
            "sector_group": clean(u.get("sector_group")),
            "last_updated": now_iso(),
            "source": choose(u.get("source"), "V5 Stage0"),
            "status": clean(u.get("status")),
            "notes": clean(u.get("notes")),
            "domicile_country": clean(u.get("domicile_country")),
            "listing_country": clean(u.get("listing_country")),
            "listing_market": clean(u.get("listing_market")),
            "primary_economic_market": clean(u.get("primary_economic_market")),
            "local_sector_benchmark": clean(sec.get("effective_benchmark_symbol")) if clean(sec.get("effective_benchmark_type")) in {"OFFICIAL_LOCAL", "SYNTHETIC_LOCAL"} else "",
            "regional_sector_benchmark": clean(sec.get("effective_benchmark_symbol")) if clean(sec.get("effective_benchmark_type")) in {"OFFICIAL_REGIONAL", "SYNTHETIC_REGIONAL"} else "",
            "global_sector_benchmark": clean(sec.get("global_sector_benchmark")),
            "broker_route": clean(u.get("broker_route")),
        }
        if idx is None:
            new = {c: "" for c in meta.columns}
            new.update(mapped)
            meta = pd.concat([meta, pd.DataFrame([new])], ignore_index=True)
            idx = len(meta) - 1
            for k in keys:
                if k:
                    index[k] = idx
        else:
            for c, v in mapped.items():
                if force or not clean(meta.at[idx, c]):
                    if clean(v):
                        meta.at[idx, c] = v
    return meta


def sector_audit_counts(sectors: pd.DataFrame) -> Dict[str, int]:
    if sectors.empty:
        return {
            "official_local_configured_rows": 0,
            "official_local_valid_rows": 0,
            "synthetic_local_usable_rows": 0,
            "resolved_local_rows": 0,
            "global_fallback_rows": 0,
            "unresolved_sector_rows": 0,
        }
    return {
        "official_local_configured_rows": int(sectors["official_local_sector_provider_symbol"].astype(str).str.strip().ne("").sum()),
        "official_local_valid_rows": int((sectors["official_local_validation_status"] == "OK").sum()),
        "synthetic_local_usable_rows": int((sectors["synthetic_local_status"] == "USABLE").sum()),
        "resolved_local_rows": int((sectors["resolution_status"] == "RESOLVED_LOCAL").sum()),
        "global_fallback_rows": int((sectors["resolution_status"] == "RESOLVED_GLOBAL_FALLBACK").sum()),
        "unresolved_sector_rows": int((sectors["resolution_status"] == "UNRESOLVED").sum()),
    }


def run(mode: str, do_sync_metadata: bool = False, force_metadata_overwrite: bool = False) -> None:
    config = load_config()
    gc = gs_client()
    book = gc.open_by_key(SHEET_ID)

    ws_meta = get_or_create_ws(book, SECURITY_METADATA_TAB, 50)
    ws_univ = get_or_create_ws(book, SECURITY_UNIVERSE_TAB, 50)
    ws_sector = get_or_create_ws(book, SECTOR_BENCHMARKS_TAB, 40)
    ws_members = get_or_create_ws(book, SECTOR_MEMBERS_TAB, 20)
    ws_audit = get_or_create_ws(book, STAGE0_AUDIT_TAB, 35)

    meta = ws_to_df(ws_meta)
    existing_univ = ws_to_df(ws_univ)
    existing_sector = ws_to_df(ws_sector)
    seed = load_seed(config)

    if mode == "benchmarks":
        # Benchmark-only mode intentionally reuses the validated Security Universe already in the sheet.
        universe = ensure_columns(existing_univ, SECURITY_UNIVERSE_COLUMNS)
        if universe.empty:
            raise RuntimeError("STAGE0 BENCHMARK ERROR: Security Universe is empty. Run 'build' first.")
    else:
        universe = merge_universe(existing_univ, metadata_to_universe(meta, config), seed)
        if mode == "build":
            universe = validate_yahoo(universe)

    status, errors = validate_universe(universe)
    sectors, members = build_sector_benchmarks(config, existing_sector, universe)
    errors.extend(validate_sector_resolution(sectors))
    if errors:
        status = "FAIL"

    if mode in {"build", "benchmarks"}:
        if mode == "build":
            write_df(ws_univ, ensure_columns(universe, SECURITY_UNIVERSE_COLUMNS))
        write_df(ws_sector, sectors)
        write_df(ws_members, members)
        if do_sync_metadata:
            write_df(ws_meta, sync_metadata(meta, universe, sectors, force_metadata_overwrite))

    enabled = universe[universe["enabled"].astype(str).str.upper().isin(["TRUE", "1", "YES", "Y"])] if len(universe) else universe
    counts = sector_audit_counts(sectors)
    audit = {
        "run_ts": now_iso(),
        "version": VERSION,
        "mode": mode,
        "metadata_rows": len(meta),
        "existing_universe_rows": len(existing_univ),
        "seed_rows": len(seed),
        "merged_universe_rows": len(universe),
        "enabled_rows": len(enabled),
        "yahoo_ok_rows": int((enabled["yahoo_ok"].astype(str).str.upper() == "YES").sum()) if len(enabled) else 0,
        "yahoo_fail_rows": int((enabled["yahoo_ok"].astype(str).str.upper() != "YES").sum()) if len(enabled) else 0,
        "metadata_missing_rows": int((universe["metadata_status"].astype(str).str.upper() != "FOUND").sum()) if len(universe) else 0,
        "sector_benchmark_rows": len(sectors),
        "sector_member_rows": len(members),
        **counts,
        "validation_status": status,
        "errors": " | ".join(errors),
    }
    append_row(ws_audit, AUDIT_COLUMNS, audit)
    print(json.dumps(audit, indent=2))
    if status != "PASS":
        raise SystemExit(2)


def main() -> None:
    p = argparse.ArgumentParser(
        description="AutoTrader V5 Stage0 v0.2 - universe + local sector benchmark resolution"
    )
    p.add_argument("mode", choices=["build", "validate", "benchmarks"])
    p.add_argument("--sync-metadata", action="store_true")
    p.add_argument("--force-metadata-overwrite", action="store_true")
    args = p.parse_args()
    if args.force_metadata_overwrite and not args.sync_metadata:
        p.error("--force-metadata-overwrite requires --sync-metadata")
    run(args.mode, args.sync_metadata, args.force_metadata_overwrite)


if __name__ == "__main__":
    main()
