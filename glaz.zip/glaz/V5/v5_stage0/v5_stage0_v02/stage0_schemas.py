SECURITY_UNIVERSE_COLUMNS = [
    "universe_id","symbol","yahoo_symbol","asset_type","enabled",
    "domicile_country","listing_country","listing_market","primary_economic_market",
    "region","sector","industry","sector_group","local_benchmark","regional_benchmark",
    "global_benchmark","broker_route","tradable","source","source_priority",
    "avg_volume_20d","median_dollar_volume_20d","last_price","history_days","yahoo_ok",
    "data_quality_status","metadata_status","status","last_verified","notes"
]

SECURITY_METADATA_V5_COLUMNS = [
    "symbol","yahoo_symbol","asset_type","exchange","country","region","sector","industry",
    "local_benchmark","regional_benchmark","sector_benchmark","sector_group","last_updated",
    "source","status","notes","domicile_country","listing_country","listing_market",
    "primary_economic_market","local_sector_benchmark","regional_sector_benchmark",
    "global_sector_benchmark","broker_route"
]

SECTOR_BENCHMARK_COLUMNS = [
    "market","country","region","sector_group","local_benchmark",
    "official_local_sector_name","official_local_sector_exchange_ticker",
    "official_local_sector_provider_symbol","official_local_status",
    "official_local_validation_status","official_local_history_days",
    "synthetic_local_member_count","synthetic_local_valid_member_count",
    "synthetic_local_coverage_ratio","synthetic_local_status",
    "official_regional_sector_name","official_regional_sector_provider_symbol",
    "official_regional_status","official_regional_validation_status",
    "global_sector_benchmark","global_proxy_validation_status",
    "effective_benchmark_type","effective_benchmark_symbol","effective_benchmark_label",
    "resolution_status","resolution_reason",
    "benchmark_priority","source","last_verified","status","notes"
]

SECTOR_MEMBER_COLUMNS = [
    "market","country","region","sector_group","universe_id","symbol","yahoo_symbol",
    "enabled","yahoo_ok","data_quality_status","member_status","weighting_method","source"
]

AUDIT_COLUMNS = [
    "run_ts","version","mode","metadata_rows","existing_universe_rows","seed_rows",
    "merged_universe_rows","enabled_rows","yahoo_ok_rows","yahoo_fail_rows",
    "metadata_missing_rows","sector_benchmark_rows","sector_member_rows",
    "official_local_configured_rows","official_local_valid_rows",
    "synthetic_local_usable_rows","resolved_local_rows","global_fallback_rows",
    "unresolved_sector_rows","validation_status","errors"
]
