# Stage 0.2 design

Stage 0 is an identity/data-quality layer, not an alpha engine.

Pipeline:

`Security Metadata + existing Security Universe -> Yahoo market discovery -> metadata enrichment -> Yahoo OHLCV validation -> merged Security Universe -> local sector members -> regional sector members -> benchmark resolver -> audit`

The universe builder deliberately avoids technical indicators and setup scores. Market-cap/liquidity are used only as discovery ranking dimensions to keep a broad, investable candidate pool.

A synthetic sector requires at least two validated securities because a single security is not a sector basket. This is a structural data-definition rule, not a trading threshold.

No benchmark provider symbol is invented. Exchange-only identifiers may be stored while provider symbols remain blank until runtime-verifiable history exists.
