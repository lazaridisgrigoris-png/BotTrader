SECURITY_UNIVERSE_COLUMNS = [
    "universe_id","symbol","yahoo_symbol","asset_type","enabled",
    "domicile_country","listing_country","listing_market","primary_economic_market",
    "region","sector","industry","sector_group","local_benchmark","regional_benchmark",
    "global_benchmark","broker_route","tradable","source","source_priority",
    "market_cap","avg_volume_3m","avg_volume_20d","median_dollar_volume_20d","last_price",
    "history_days","yahoo_ok","data_quality_status","metadata_status","status",
    "last_verified","notes"
]

SECTOR_BENCHMARK_COLUMNS = [
    "market","country","region","sector_group","local_benchmark",
    "official_local_sector_name","official_local_sector_exchange_ticker",
    "official_local_sector_provider_symbol","official_local_status",
    "local_sector_proxy_name","local_sector_proxy_provider_symbol","local_sector_proxy_status",
    "synthetic_local_member_count","synthetic_local_valid_member_count","synthetic_local_status",
    "synthetic_regional_member_count","synthetic_regional_valid_member_count","synthetic_regional_status",
    "global_sector_benchmark","global_proxy_status",
    "effective_benchmark_type","effective_benchmark_symbol","effective_benchmark_label",
    "resolution_status","resolution_reason","benchmark_priority","source","last_verified","status","notes"
]

SECTOR_MEMBER_COLUMNS = [
    "scope","scope_key","market","region","sector_group","symbol","yahoo_symbol",
    "member_valid","member_status","source","last_verified"
]

DISCOVERY_AUDIT_COLUMNS = [
    "run_ts","version","market","region_code","target_count","existing_count","discovered_count",
    "new_count","post_merge_count","sector_known_count","yahoo_ok_count","source_status","notes"
]

AUDIT_COLUMNS = [
    "run_ts","version","mode","metadata_rows","existing_universe_rows","discovered_rows",
    "merged_universe_rows","enabled_rows","yahoo_ok_rows","yahoo_fail_rows","sector_known_rows",
    "sector_benchmark_rows","local_proxy_rows","synthetic_local_rows","synthetic_regional_rows",
    "global_fallback_rows","unresolved_sector_rows","validation_status","errors"
]
