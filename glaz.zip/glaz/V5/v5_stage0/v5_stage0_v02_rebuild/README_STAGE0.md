# AutoTrader V5 — Stage 0.2 REBUILT

This replaces the earlier Stage 0.2 experiment. It joins the two pieces that must be solved together:

1. **Automatic Security Universe discovery** for all 14 equity markets.
2. **Local/regional sector benchmark resolution** from the expanded universe.

No OpenAI/LLM calls are used.

## Why this rebuild exists
The earlier v0.2 could resolve synthetic sectors only from the inherited V4 universe. That made Spain/Japan/India/Hong Kong/Australia too sparse and forced many rows to US global proxies. This build first expands the market universe, enriches sector metadata, validates Yahoo history, and *then* resolves sector benchmarks.

## Discovery source
Uses `yfinance.EquityQuery` + `yfinance.screen` with Yahoo region/exchange filters. The target counts are **coverage targets**, not trading thresholds. Candidate ranking is the union/balance of market-cap and 3-month-volume ranks; no technical signal is used.

Default coverage targets reflect the previously agreed V5 scope: US 350, Greece 100, UK 75, Germany/France 60, Italy 50, Spain 40, Netherlands 35, Switzerland 40, Japan 75, India/Hong Kong/Canada/Australia 60 each.

## Sector benchmark priority
`OFFICIAL_LOCAL > LOCAL_SECTOR_PROXY > SYNTHETIC_LOCAL > SYNTHETIC_REGIONAL > GLOBAL_PROXY > NEUTRAL`

- US sector SPDRs are treated as **local-market sector proxies**, not mislabeled as official indices.
- Greece Financials retains the verified ATHEX exchange identity `FTSE/ATHEX Banks / DTR`, but no Yahoo/provider symbol is invented. Until a provider symbol with sufficient history is verified, the effective benchmark is the synthetic Greek Financials basket.
- Synthetic local/regional baskets are auditable in `Sector Benchmark Members`.

## First run
Keep the same environment variables as Stage 0.1:

```powershell
$env:SHEET_ID="..."
$env:SERVICE_ACCOUNT_JSON="C:\path\service-account.json"
python run_stage0.py build
```

Do **not** run any metadata sync flag; this build does not overwrite `Security Metadata`.

## Sheets written
- `Security Universe`
- `Universe Discovery Audit`
- `Sector Benchmarks`
- `Sector Benchmark Members`
- `Stage0 Audit`

Your existing `Security Metadata` is read-only in this stage.

## Other modes
```powershell
python run_stage0.py discover    # discovery + validation + benchmark resolution
python run_stage0.py benchmarks  # reuse current Security Universe; rebuild benchmark layer
python run_stage0.py validate    # revalidate current universe and benchmarks
```

## Important operational note
Yahoo screener/profile endpoints can throttle. If a market comes back `PARTIAL` or `FAIL` in `Universe Discovery Audit`, do not treat Stage 0 as complete. Rerun later; the existing universe remains merged rather than being destroyed.
