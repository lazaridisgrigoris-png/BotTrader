from __future__ import annotations
from typing import Any, Dict, List, Tuple
import pandas as pd
import yfinance as yf


def clean(v: Any) -> str:
    if v is None:return ""
    s=str(v).strip(); return "" if s.lower() in {"nan","none","null"} else s

def validate_symbol(symbol: str, min_days: int=40) -> Tuple[bool,str,int]:
    s=clean(symbol)
    if not s:return False,'NOT_CONFIGURED',0
    try:
        h=yf.download(s,period='6mo',interval='1d',progress=False,auto_adjust=False,threads=False)
        n=len(h.dropna(how='all')) if h is not None else 0
        if n>=min_days:return True,'OK',n
        return False,'INSUFFICIENT_HISTORY',n
    except Exception as e:
        return False,f'ERROR:{type(e).__name__}',0

def _valid_members(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:return df
    x=df.copy()
    if 'enabled' in x: x=x[x['enabled'].astype(str).str.upper().isin(['TRUE','1','YES','Y'])]
    if 'yahoo_ok' in x: x=x[x['yahoo_ok'].astype(str).str.upper().isin(['TRUE','1','YES','Y'])]
    return x

def resolve(config: Dict[str,Any], universe: pd.DataFrame, seed: pd.DataFrame, min_days: int=40):
    seed_map={}
    if seed is not None and not seed.empty:
        for _,r in seed.iterrows(): seed_map[(clean(r.get('market')).upper(),clean(r.get('sector_group')).upper())]=r.to_dict()
    rows=[]; members=[]; cache={}
    def val(sym):
        if sym not in cache: cache[sym]=validate_symbol(sym,min_days)
        return cache[sym]
    sectors=config['sector_groups']
    for m in config['equity_markets']:
        if not m.get('enabled',True):continue
        market=m['market']; region=m['region']; country=m['country']
        for s in sectors:
            sg=s['sector_group']; global_proxy=s['global_proxy']; z=seed_map.get((market,sg),{})
            offsym=clean(z.get('official_local_sector_provider_symbol'))
            proxysym=clean(z.get('local_sector_proxy_provider_symbol'))
            offok,offstat,_=val(offsym) if offsym else (False,'NOT_CONFIGURED',0)
            proxyok,proxystat,_=val(proxysym) if proxysym else (False,'NOT_CONFIGURED',0)
            gpok,gpstat,_=val(global_proxy)
            local=universe[(universe['primary_economic_market'].astype(str).str.upper()==country.upper()) & (universe['sector_group'].astype(str).str.upper()==sg)] if not universe.empty else pd.DataFrame()
            localv=_valid_members(local)
            regional=universe[(universe['region'].astype(str).str.upper()==region.upper()) & (universe['sector_group'].astype(str).str.upper()==sg)] if not universe.empty else pd.DataFrame()
            regionalv=_valid_members(regional)
            for scope,key,src in [('LOCAL',market,localv),('REGIONAL',region,regionalv)]:
                for _,r in src.iterrows():
                    members.append({'scope':scope,'scope_key':key,'market':market if scope=='LOCAL' else '', 'region':region,
                                    'sector_group':sg,'symbol':clean(r.get('symbol')),'yahoo_symbol':clean(r.get('yahoo_symbol')),
                                    'member_valid':'TRUE','member_status':'OK','source':'Security Universe','last_verified':''})
            # Minimum two constituents is structural, not alpha: one security cannot represent a sector basket.
            local_usable=len(localv)>=2; regional_usable=len(regionalv)>=2
            if offok:
                etype,esym,elabel,rstatus,reason='OFFICIAL_LOCAL',offsym,clean(z.get('official_local_sector_name')) or offsym,'RESOLVED_LOCAL','Verified official local provider symbol'
            elif proxyok:
                etype,esym,elabel,rstatus,reason='LOCAL_SECTOR_PROXY',proxysym,clean(z.get('local_sector_proxy_name')) or proxysym,'RESOLVED_LOCAL','Verified local-market sector proxy'
            elif local_usable:
                etype,esym,elabel,rstatus,reason='SYNTHETIC_LOCAL',f'SYNTH:{market}:{sg}',f'Synthetic {market} {sg} basket','RESOLVED_LOCAL',f'{len(localv)} validated local members'
            elif regional_usable:
                etype,esym,elabel,rstatus,reason='SYNTHETIC_REGIONAL',f'SYNTH:{region}:{sg}',f'Synthetic {region} {sg} basket','RESOLVED_REGIONAL',f'Local unavailable; {len(regionalv)} validated regional members'
            elif gpok:
                etype,esym,elabel,rstatus,reason='GLOBAL_PROXY',global_proxy,global_proxy,'RESOLVED_GLOBAL_FALLBACK','No usable local/regional benchmark; global proxy validated'
            else:
                etype,esym,elabel,rstatus,reason='NEUTRAL','','Neutral','UNRESOLVED','No validated benchmark available'
            rows.append({
                'market':market,'country':country,'region':region,'sector_group':sg,'local_benchmark':m['local_benchmark'],
                'official_local_sector_name':clean(z.get('official_local_sector_name')),
                'official_local_sector_exchange_ticker':clean(z.get('official_local_sector_exchange_ticker')),
                'official_local_sector_provider_symbol':offsym,
                'official_local_status':offstat if offsym else clean(z.get('official_local_status')) or 'UNCONFIGURED',
                'local_sector_proxy_name':clean(z.get('local_sector_proxy_name')),'local_sector_proxy_provider_symbol':proxysym,
                'local_sector_proxy_status':proxystat if proxysym else clean(z.get('local_sector_proxy_status')) or 'UNCONFIGURED',
                'synthetic_local_member_count':len(local),'synthetic_local_valid_member_count':len(localv),
                'synthetic_local_status':'USABLE' if local_usable else ('ONE_MEMBER' if len(localv)==1 else 'NO_MEMBERS'),
                'synthetic_regional_member_count':len(regional),'synthetic_regional_valid_member_count':len(regionalv),
                'synthetic_regional_status':'USABLE' if regional_usable else ('ONE_MEMBER' if len(regionalv)==1 else 'NO_MEMBERS'),
                'global_sector_benchmark':global_proxy,'global_proxy_status':gpstat,
                'effective_benchmark_type':etype,'effective_benchmark_symbol':esym,'effective_benchmark_label':elabel,
                'resolution_status':rstatus,'resolution_reason':reason,
                'benchmark_priority':'OFFICIAL_LOCAL>LOCAL_SECTOR_PROXY>SYNTHETIC_LOCAL>SYNTHETIC_REGIONAL>GLOBAL_PROXY>NEUTRAL',
                'source':clean(z.get('source')) or 'V5_STAGE0_AUTOMATED','last_verified':'','status':'ACTIVE','notes':clean(z.get('notes'))
            })
    return pd.DataFrame(rows),pd.DataFrame(members)
