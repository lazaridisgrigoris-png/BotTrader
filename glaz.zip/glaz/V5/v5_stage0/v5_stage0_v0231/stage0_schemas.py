SECURITY_UNIVERSE_COLUMNS = [
    "universe_id","symbol","yahoo_symbol","asset_type","enabled",
    "domicile_country","listing_country","listing_market","primary_economic_market",
    "economic_market_status","canonical_company_id","canonical_company_name",
    "canonical_security_symbol","canonical_status","quote_type","breadth_market","breadth_membership_status","basket_eligible","basket_exclusion_reason",
    "region","sector","industry","sector_group","local_benchmark","regional_benchmark",
    "global_benchmark","broker_route","tradable","source","source_priority",
    "market_cap","avg_volume_3m","avg_volume_20d","median_dollar_volume_20d","last_price",
    "history_days","yahoo_ok","data_quality_status","metadata_status","identity_status",
    "last_identity_verified","status","last_verified","notes"
]

SECTOR_BENCHMARK_COLUMNS = [
    "market","country","region","sector_group","market_benchmark",
    "official_local_sector_name","official_local_sector_exchange_ticker",
    "official_local_sector_provider_symbol","official_local_status",
    "local_sector_proxy_name","local_sector_proxy_provider_symbol","local_sector_proxy_status",
    "synthetic_local_id","synthetic_local_member_count","synthetic_local_valid_member_count",
    "synthetic_local_status","synthetic_local_members",
    "synthetic_regional_id","synthetic_regional_member_count","synthetic_regional_valid_member_count",
    "synthetic_regional_status","synthetic_regional_members",
    "global_sector_benchmark","global_proxy_status",
    "resolved_benchmark_type","resolved_benchmark","resolved_benchmark_label",
    "resolved_member_count","resolved_status","resolution_reason",
    "effective_benchmark_type","effective_benchmark_symbol","effective_benchmark_label",
    "resolution_status","benchmark_priority","source","last_verified","status","notes"
]

SECTOR_MEMBER_COLUMNS = [
    "scope","scope_key","market","region","sector_group","symbol","yahoo_symbol",
    "canonical_company_id","canonical_company_name","primary_economic_market","listing_country",
    "member_valid","member_status","source","last_verified"
]

DISCOVERY_AUDIT_COLUMNS = [
    "run_ts","version","market","region_code","target_count","existing_count","discovered_count",
    "new_count","post_merge_count","sector_known_count","yahoo_ok_count","source_status","notes"
]

IDENTITY_AUDIT_COLUMNS = [
    "run_ts","version","total_rows","identity_candidates","identity_ok","identity_failed",
    "economic_market_verified_rows","basket_eligible_rows","cross_listing_excluded_rows",
    "duplicate_company_excluded_rows","non_equity_excluded_rows","unverified_identity_excluded_rows","local_listing_override_rows","provider_retry_rows","notes"
]

AUDIT_COLUMNS = [
    "run_ts","version","mode","metadata_rows","existing_universe_rows","discovered_rows",
    "merged_universe_rows","enabled_rows","yahoo_ok_rows","yahoo_fail_rows","sector_known_rows",
    "economic_market_verified_rows","basket_eligible_rows","cross_listing_excluded_rows",
    "duplicate_company_excluded_rows","local_listing_override_rows","provider_retry_rows","sector_benchmark_rows","official_local_rows","local_proxy_rows",
    "synthetic_local_rows","synthetic_regional_rows","global_fallback_rows","unresolved_sector_rows",
    "benchmark_sheet_consistency","validation_status","errors"
]
