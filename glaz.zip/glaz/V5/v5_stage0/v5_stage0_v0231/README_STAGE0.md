# AutoTrader V5 Stage 0.2.3 — Economic Market & Canonical Company Cleanup

This version keeps the v0.2.2 authoritative Sector Benchmarks design and fixes the remaining conceptual defect: a security listed in a country is not automatically part of that country's economic sector.

## New identity layer
`Security Universe` now persists:
- `primary_economic_market`
- `economic_market_status`
- `canonical_company_id`
- `canonical_company_name`
- `canonical_security_symbol`
- `canonical_status`
- `quote_type`
- `basket_eligible`
- `basket_exclusion_reason`
- `identity_status`
- `last_identity_verified`

Yahoo company profile data is used to identify domicile/economic market. Existing Security Metadata remains a trusted fallback source when Yahoo identity is unavailable.

## Synthetic sector basket rules
A security may enter a synthetic local/regional sector basket only when it is:
1. enabled,
2. Yahoo-price valid,
3. an equity/stock,
4. economic-market identified,
5. listed in the same country as its economic market,
6. sector classified,
7. the single canonical representative of that company.

This removes cross-listings/ADRs/certificates such as an Italian listing of a US company from the Italian sector basket, and prevents the same company from appearing twice through multiple listings.

The structural minimum remains two canonical companies for a synthetic sector basket. This is not an alpha/trading threshold; one company cannot represent a sector.

## Recommended upgrade run from v0.2.2
Your 1,448-row universe already exists, so do **not** rediscover first.

```powershell
python run_stage0.py identity
```

This performs the identity cleanup, writes the updated Security Universe and Identity Audit, then rebuilds Sector Benchmarks and Sector Benchmark Members.

Profile calls can take time and Yahoo can throttle. The results are cached in Security Universe for 30 days by default. If some identity calls fail, those unverified securities are conservatively excluded from synthetic baskets rather than contaminating them.

Then, if required:

```powershell
python run_stage0.py benchmarks
```

## Environment controls
- `STAGE0_IDENTITY_WORKERS` default `4`
- `STAGE0_IDENTITY_MAX_AGE_DAYS` default `30`
- existing Stage0 environment variables from v0.2.2 remain unchanged.

## New worksheet
`Identity Audit` records identity success/failure, verified economic markets, basket-eligible securities, cross-listing exclusions and duplicate-company exclusions.

## v0.2.3.1 minor corrections

1. **Breadth market is separate from corporate domicile/economic market.** Explicit ATHEX securities already present in Security Metadata remain members of Greek market/sector breadth even when Yahoo reports a foreign corporate domicile (examples: EEE.AT, CENER.AT, BOCHGR.AT, ACAG.AT). Foreign secondary listings discovered on other venues remain excluded from local synthetic baskets.
2. **Successful identity is persistent.** Normal `identity` runs query only unresolved identities. Set `STAGE0_IDENTITY_REFRESH_EXISTING=true` only for an explicit refresh.
3. **Provider failures are retryable.** Yahoo auth/rate-limit failures are recorded as `PROVIDER_RETRY_REQUIRED` and never overwrite a previously verified identity.
4. Added `breadth_market` and `breadth_membership_status` to Security Universe plus provider/override counts to audits.

Recommended upgrade from v0.2.3:

```powershell
python run_stage0.py identity
```

Because the successful v0.2.3 identities are persisted, this run should retry mainly the previously unresolved/provider-failed rows instead of re-querying the full universe.
