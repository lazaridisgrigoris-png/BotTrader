# Stage 0.2.3 Design

Pipeline:

`Security Metadata + Security Universe`
→ `Yahoo identity enrichment`
→ `economic market / listing market separation`
→ `canonical company grouping`
→ `one local primary/canonical security per company`
→ `price/data validation`
→ `local sector members`
→ `regional sector members`
→ `authoritative benchmark resolution`
→ `audit`

Benchmark hierarchy remains:

`OFFICIAL_LOCAL > LOCAL_SECTOR_PROXY > SYNTHETIC_LOCAL > SYNTHETIC_REGIONAL > GLOBAL_PROXY > NEUTRAL`

Key invariant: **listing venue does not define economic-market membership.**

Key invariant: **one company contributes at most once to a synthetic basket.**

### v0.2.3.1 breadth membership rule
Corporate domicile/economic market is descriptive identity. Synthetic local sector breadth is based on validated local market membership. For ATHEX, explicit Security Metadata ATHEX listings are retained in Greek breadth even when corporate domicile is foreign. This is intentionally narrower than a universal primary-listing inference; other cross-market exceptions require evidence before adding rules.
