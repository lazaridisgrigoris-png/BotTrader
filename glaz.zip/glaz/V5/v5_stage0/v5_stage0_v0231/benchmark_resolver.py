from __future__ import annotations
from typing import Any, Dict, Tuple
import pandas as pd
import yfinance as yf


def clean(v: Any) -> str:
    if v is None:
        return ""
    s = str(v).strip()
    return "" if s.lower() in {"nan", "none", "null"} else s


def validate_symbol(symbol: str, min_days: int = 40) -> Tuple[bool, str, int]:
    s = clean(symbol)
    if not s:
        return False, "NOT_CONFIGURED", 0
    try:
        h = yf.download(s, period="6mo", interval="1d", progress=False, auto_adjust=False, threads=False)
        n = len(h.dropna(how="all")) if h is not None else 0
        if n >= min_days:
            return True, "OK", n
        return False, "INSUFFICIENT_HISTORY", n
    except Exception as e:
        return False, f"ERROR:{type(e).__name__}", 0


def _valid_members(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty:
        return df
    x = df.copy()
    if "enabled" in x:
        x = x[x["enabled"].astype(str).str.upper().isin(["TRUE", "1", "YES", "Y"])]
    if "yahoo_ok" in x:
        x = x[x["yahoo_ok"].astype(str).str.upper().isin(["TRUE", "1", "YES", "Y"])]
    # v0.2.3: canonical economic-market membership is authoritative for synthetic baskets.
    if "basket_eligible" in x and x["basket_eligible"].astype(str).str.strip().ne('').any():
        x = x[x["basket_eligible"].astype(str).str.upper().isin(["TRUE", "1", "YES", "Y"])]
    return x


def _member_symbols(df: pd.DataFrame) -> list[str]:
    if df is None or df.empty:
        return []
    vals = []
    for _, r in df.iterrows():
        s = clean(r.get("yahoo_symbol") or r.get("symbol"))
        if s:
            vals.append(s)
    # Stable deterministic order and no duplicates.
    return sorted(set(vals), key=lambda x: x.upper())


def resolve(config: Dict[str, Any], universe: pd.DataFrame, seed: pd.DataFrame, min_days: int = 40):
    seed_map = {}
    if seed is not None and not seed.empty:
        for _, r in seed.iterrows():
            seed_map[(clean(r.get("market")).upper(), clean(r.get("sector_group")).upper())] = r.to_dict()

    rows = []
    members = []
    cache = {}

    def val(sym):
        if sym not in cache:
            cache[sym] = validate_symbol(sym, min_days)
        return cache[sym]

    sectors = config["sector_groups"]
    for m in config["equity_markets"]:
        if not m.get("enabled", True):
            continue
        market = m["market"]
        region = m["region"]
        country = m["country"]

        for s in sectors:
            sg = s["sector_group"]
            global_proxy = s["global_proxy"]
            z = seed_map.get((market, sg), {})

            offsym = clean(z.get("official_local_sector_provider_symbol"))
            proxysym = clean(z.get("local_sector_proxy_provider_symbol"))
            offok, offstat, _ = val(offsym) if offsym else (False, "NOT_CONFIGURED", 0)
            proxyok, proxystat, _ = val(proxysym) if proxysym else (False, "NOT_CONFIGURED", 0)
            gpok, gpstat, _ = val(global_proxy)

            if universe.empty:
                local = pd.DataFrame()
                regional = pd.DataFrame()
            else:
                local = universe[
                    (universe["breadth_market"].astype(str).str.upper() == country.upper())
                    & (universe["sector_group"].astype(str).str.upper() == sg)
                ]
                regional = universe[
                    (universe["region"].astype(str).str.upper() == region.upper())
                    & (universe["sector_group"].astype(str).str.upper() == sg)
                ]

            localv = _valid_members(local)
            regionalv = _valid_members(regional)
            local_symbols = _member_symbols(localv)
            regional_symbols = _member_symbols(regionalv)
            local_id = f"SYNTH:{market}:{sg}"
            regional_id = f"SYNTH:{region}:{sg}"

            for scope, key, src in [("LOCAL", market, localv), ("REGIONAL", region, regionalv)]:
                for _, r in src.iterrows():
                    members.append({
                        "scope": scope,
                        "scope_key": key,
                        "market": market if scope == "LOCAL" else "",
                        "region": region,
                        "sector_group": sg,
                        "symbol": clean(r.get("symbol")),
                        "yahoo_symbol": clean(r.get("yahoo_symbol")),
                        "canonical_company_id": clean(r.get("canonical_company_id")),
                        "canonical_company_name": clean(r.get("canonical_company_name")),
                        "primary_economic_market": clean(r.get("primary_economic_market")),
                        "listing_country": clean(r.get("listing_country")),
                        "member_valid": "TRUE",
                        "member_status": "CANONICAL_LOCAL_BREADTH_MEMBER",
                        "source": "Security Universe",
                        "last_verified": "",
                    })

            # Structural representation rule: one security is not a sector basket.
            local_usable = len(localv) >= 2
            regional_usable = len(regionalv) >= 2

            if offok:
                rtype = "OFFICIAL_LOCAL"
                rbench = offsym
                rlabel = clean(z.get("official_local_sector_name")) or offsym
                rmember_count = 0
                rstatus = "VALID"
                legacy_status = "RESOLVED_LOCAL"
                reason = "Verified official local provider symbol"
            elif proxyok:
                rtype = "LOCAL_SECTOR_PROXY"
                rbench = proxysym
                rlabel = clean(z.get("local_sector_proxy_name")) or proxysym
                rmember_count = 0
                rstatus = "VALID"
                legacy_status = "RESOLVED_LOCAL"
                reason = "Verified local-market sector proxy"
            elif local_usable:
                rtype = "SYNTHETIC_LOCAL"
                rbench = local_id
                rlabel = f"Synthetic {market} {sg} basket"
                rmember_count = len(local_symbols)
                rstatus = "VALID"
                legacy_status = "RESOLVED_LOCAL"
                reason = f"{len(local_symbols)} validated local members persisted in synthetic_local_members"
            elif regional_usable:
                rtype = "SYNTHETIC_REGIONAL"
                rbench = regional_id
                rlabel = f"Synthetic {region} {sg} basket"
                rmember_count = len(regional_symbols)
                rstatus = "VALID"
                legacy_status = "RESOLVED_REGIONAL"
                reason = f"Local unavailable; {len(regional_symbols)} validated regional members persisted in synthetic_regional_members"
            elif gpok:
                rtype = "GLOBAL_PROXY"
                rbench = global_proxy
                rlabel = global_proxy
                rmember_count = 0
                rstatus = "VALID"
                legacy_status = "RESOLVED_GLOBAL_FALLBACK"
                reason = "No usable local/regional benchmark; global proxy validated"
            else:
                rtype = "NEUTRAL"
                rbench = ""
                rlabel = "Neutral"
                rmember_count = 0
                rstatus = "UNRESOLVED"
                legacy_status = "UNRESOLVED"
                reason = "No validated benchmark available"

            rows.append({
                "market": market,
                "country": country,
                "region": region,
                "sector_group": sg,
                "market_benchmark": m["local_benchmark"],
                "official_local_sector_name": clean(z.get("official_local_sector_name")),
                "official_local_sector_exchange_ticker": clean(z.get("official_local_sector_exchange_ticker")),
                "official_local_sector_provider_symbol": offsym,
                "official_local_status": offstat if offsym else clean(z.get("official_local_status")) or "UNCONFIGURED",
                "local_sector_proxy_name": clean(z.get("local_sector_proxy_name")),
                "local_sector_proxy_provider_symbol": proxysym,
                "local_sector_proxy_status": proxystat if proxysym else clean(z.get("local_sector_proxy_status")) or "UNCONFIGURED",
                "synthetic_local_id": local_id,
                "synthetic_local_member_count": len(local),
                "synthetic_local_valid_member_count": len(local_symbols),
                "synthetic_local_status": "USABLE" if local_usable else ("ONE_MEMBER" if len(local_symbols) == 1 else "NO_MEMBERS"),
                "synthetic_local_members": ";".join(local_symbols),
                "synthetic_regional_id": regional_id,
                "synthetic_regional_member_count": len(regional),
                "synthetic_regional_valid_member_count": len(regional_symbols),
                "synthetic_regional_status": "USABLE" if regional_usable else ("ONE_MEMBER" if len(regional_symbols) == 1 else "NO_MEMBERS"),
                "synthetic_regional_members": ";".join(regional_symbols),
                "global_sector_benchmark": global_proxy,
                "global_proxy_status": gpstat,
                # Canonical V5 persisted resolution fields.
                "resolved_benchmark_type": rtype,
                "resolved_benchmark": rbench,
                "resolved_benchmark_label": rlabel,
                "resolved_member_count": rmember_count,
                "resolved_status": rstatus,
                "resolution_reason": reason,
                # Backward-compatible aliases for v0.2.1 readers.
                "effective_benchmark_type": rtype,
                "effective_benchmark_symbol": rbench,
                "effective_benchmark_label": rlabel,
                "resolution_status": legacy_status,
                "benchmark_priority": "OFFICIAL_LOCAL>LOCAL_SECTOR_PROXY>SYNTHETIC_LOCAL>SYNTHETIC_REGIONAL>GLOBAL_PROXY>NEUTRAL",
                "source": clean(z.get("source")) or "V5_STAGE0_AUTOMATED",
                "last_verified": "",
                "status": "ACTIVE",
                "notes": clean(z.get("notes")),
            })

    return pd.DataFrame(rows), pd.DataFrame(members)
