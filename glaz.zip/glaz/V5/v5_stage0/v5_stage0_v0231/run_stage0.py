from __future__ import annotations
import argparse, datetime as dt, json, os, re
from pathlib import Path
from typing import Any, Dict
import pandas as pd
import yfinance as yf
import gspread
from google.oauth2.service_account import Credentials
from stage0_schemas import *
from universe_discovery import discover_market, enrich_missing_metadata
from identity_resolver import enrich_identity
from benchmark_resolver import resolve

VERSION='5.0-stage0-v0.2.3.1-breadth-membership-provider-resilience'
BASE=Path(__file__).resolve().parent
CONFIG_PATH=Path(os.getenv('V5_MARKETS_CONFIG',BASE/'config'/'markets.json'))
SEED_PATH=Path(os.getenv('V5_UNIVERSE_SEED',BASE/'config'/'universe_seed.csv'))
BENCH_SEED_PATH=Path(os.getenv('V5_BENCHMARK_SEED',BASE/'config'/'benchmark_seed.csv'))
SHEET_ID=os.getenv('SHEET_ID','').strip(); SERVICE_ACCOUNT_JSON=os.getenv('SERVICE_ACCOUNT_JSON','').strip()
META_TAB=os.getenv('SECURITY_METADATA_TAB','Security Metadata'); UNIV_TAB=os.getenv('SECURITY_UNIVERSE_TAB','Security Universe')
BENCH_TAB=os.getenv('SECTOR_BENCHMARKS_TAB','Sector Benchmarks'); MEMBER_TAB=os.getenv('SECTOR_MEMBERS_TAB','Sector Benchmark Members')
DISC_AUDIT_TAB=os.getenv('UNIVERSE_DISCOVERY_AUDIT_TAB','Universe Discovery Audit'); IDENTITY_AUDIT_TAB=os.getenv('IDENTITY_AUDIT_TAB','Identity Audit'); AUDIT_TAB=os.getenv('STAGE0_AUDIT_TAB','Stage0 Audit')
MIN_HISTORY=int(os.getenv('STAGE0_MIN_HISTORY_DAYS','40'))


def now(): return dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
def clean(v):
    if v is None:return ''
    s=str(v).strip(); return '' if s.lower() in {'nan','none','null'} else s
def uid(v):return re.sub(r'[^A-Z0-9]+','',clean(v).upper())
def ensure(df,cols):
    x=df.copy()
    for c in cols:
        if c not in x:x[c]=''
    return x[cols+[c for c in x.columns if c not in cols]]
def read_ws(ws):
    vals=ws.get_all_values()
    if not vals:return pd.DataFrame()
    hdr=[clean(x) for x in vals[0]]; rows=[]
    # Google Sheets can contain duplicate/blank headers after schema changes.
    # Make them unique so pandas operations (especially concat) are safe.
    seen={}
    unique=[]
    for i,h in enumerate(hdr):
        base=h or f'unnamed_{i+1}'
        n=seen.get(base,0)+1; seen[base]=n
        unique.append(base if n==1 else f'{base}__dup{n}')
    hdr=unique
    for r in vals[1:]:
        rr=(r+['']*len(hdr))[:len(hdr)]
        if any(clean(x) for x in rr):rows.append(rr)
    return pd.DataFrame(rows,columns=hdr)
def write_ws(ws,df):
    x=df.fillna('').astype(str); ws.clear(); ws.update(values=[list(x.columns)]+x.values.tolist(),range_name='A1')
def ws(book,title,cols=50):
    try:return book.worksheet(title)
    except gspread.WorksheetNotFound:return book.add_worksheet(title=title,rows=5000,cols=cols)
def load_config():return json.loads(CONFIG_PATH.read_text(encoding='utf-8'))
def client():
    if not SHEET_ID:raise RuntimeError('STAGE0 CONFIG ERROR: SHEET_ID is required')
    if not SERVICE_ACCOUNT_JSON:raise RuntimeError('STAGE0 CONFIG ERROR: SERVICE_ACCOUNT_JSON is required')
    p=Path(SERVICE_ACCOUNT_JSON)
    if not p.exists():raise RuntimeError(f'STAGE0 CONFIG ERROR: service account JSON not found: {p}')
    c=Credentials.from_service_account_file(str(p),scopes=['https://www.googleapis.com/auth/spreadsheets','https://www.googleapis.com/auth/drive'])
    return gspread.authorize(c)

def metadata_to_universe(meta,config):
    if meta.empty:return pd.DataFrame(columns=SECURITY_UNIVERSE_COLUMNS)
    markets={clean(m['country']).upper():m for m in config['equity_markets']}
    rows=[]
    for _,r in meta.iterrows():
        d=r.to_dict(); country=clean(d.get('primary_economic_market') or d.get('listing_country') or d.get('country') or d.get('domicile_country'))
        m=markets.get(country.upper(),{}); sym=clean(d.get('yahoo_symbol') or d.get('symbol')).split(':')[-1]
        rows.append({'universe_id':uid(sym),'symbol':clean(d.get('symbol') or sym),'yahoo_symbol':sym,'asset_type':clean(d.get('asset_type') or 'Stock'),
        'enabled':'FALSE' if clean(d.get('status')).upper() in {'DISABLED','INACTIVE','EXCLUDED'} else 'TRUE',
        'domicile_country':clean(d.get('domicile_country') or d.get('country')),'listing_country':clean(d.get('listing_country') or d.get('country')),
        'listing_market':clean(d.get('listing_market') or d.get('exchange')),'primary_economic_market':country,
        'economic_market_status':'SOURCE_METADATA' if country else 'UNVERIFIED',
        'canonical_company_id':clean(d.get('canonical_company_id')),'canonical_company_name':clean(d.get('canonical_company_name')),
        'canonical_security_symbol':clean(d.get('canonical_security_symbol')),'canonical_status':clean(d.get('canonical_status')),
        'quote_type':clean(d.get('quote_type')),'breadth_market':clean(d.get('breadth_market')),'breadth_membership_status':clean(d.get('breadth_membership_status')),'basket_eligible':clean(d.get('basket_eligible')),'basket_exclusion_reason':clean(d.get('basket_exclusion_reason')),
        'region':clean(d.get('region') or m.get('region')),'sector':clean(d.get('sector')),'industry':clean(d.get('industry')),
        'sector_group':clean(d.get('sector_group')).upper().replace(' ','_'),'local_benchmark':clean(d.get('local_benchmark') or m.get('local_benchmark')),
        'regional_benchmark':clean(d.get('regional_benchmark') or m.get('regional_benchmark')),'global_benchmark':'ACWI','broker_route':clean(d.get('broker_route') or m.get('broker_route')),
        'tradable':'UNKNOWN','source':clean(d.get('source') or 'Security Metadata'),'source_priority':'100','metadata_status':'FOUND',
        'identity_status':clean(d.get('identity_status')),'last_identity_verified':clean(d.get('last_identity_verified')),
        'status':'ACTIVE','notes':clean(d.get('notes'))})
    return ensure(pd.DataFrame(rows),SECURITY_UNIVERSE_COLUMNS)

def merge(*dfs):
    chunks=[]
    for prio,df in enumerate(dfs):
        if df is None or df.empty:continue
        x=ensure(df,SECURITY_UNIVERSE_COLUMNS).copy(); x['_p']=1000-prio; chunks.append(x)
    if not chunks:return pd.DataFrame(columns=SECURITY_UNIVERSE_COLUMNS)
    a=pd.concat(chunks,ignore_index=True); a['universe_id']=a.apply(lambda r:clean(r.get('universe_id')) or uid(clean(r.get('yahoo_symbol') or r.get('symbol'))),axis=1)
    out=[]
    for k,g in a[a['universe_id']!=''].groupby('universe_id',sort=False):
        g=g.sort_values('_p',ascending=False); row={'universe_id':k}
        for c in SECURITY_UNIVERSE_COLUMNS:
            if c=='universe_id':continue
            vals=[clean(v) for v in g[c].tolist() if clean(v)]; row[c]=vals[0] if vals else ''
        out.append(row)
    return ensure(pd.DataFrame(out),SECURITY_UNIVERSE_COLUMNS)

def validate_prices(df):
    x=ensure(df,SECURITY_UNIVERSE_COLUMNS).copy()
    syms=[s for s in x['yahoo_symbol'].astype(str).str.strip().unique() if s]
    for i in range(0,len(syms),80):
        batch=syms[i:i+80]
        try:data=yf.download(batch,period='6mo',interval='1d',progress=False,auto_adjust=False,group_by='ticker',threads=True)
        except Exception:data=None
        for s in batch:
            try:
                h=data[s] if data is not None and len(batch)>1 and s in data.columns.get_level_values(0) else data
                h=h.dropna(how='all') if h is not None else pd.DataFrame(); n=len(h)
                close=pd.to_numeric(h['Close'],errors='coerce').dropna() if n and 'Close' in h else pd.Series(dtype=float)
                vol=pd.to_numeric(h['Volume'],errors='coerce').dropna() if n and 'Volume' in h else pd.Series(dtype=float)
                last=float(close.iloc[-1]) if len(close) else None; avgv=float(vol.tail(20).mean()) if len(vol) else None
                mdv=float((pd.to_numeric(h['Close'],errors='coerce')*pd.to_numeric(h['Volume'],errors='coerce')).tail(20).median()) if n else None
                ok=n>=MIN_HISTORY and last is not None
            except Exception:n=0;last=avgv=mdv=None;ok=False
            m=x['yahoo_symbol'].astype(str).str.strip()==s
            x.loc[m,'history_days']=str(n); x.loc[m,'last_price']='' if last is None else f'{last:.6g}'
            x.loc[m,'avg_volume_20d']='' if avgv is None else f'{avgv:.6g}'; x.loc[m,'median_dollar_volume_20d']='' if mdv is None else f'{mdv:.6g}'
            x.loc[m,'yahoo_ok']='TRUE' if ok else 'FALSE'; x.loc[m,'data_quality_status']='OK' if ok else 'INSUFFICIENT_OR_NO_HISTORY'; x.loc[m,'last_verified']=now()
    return x

def run(mode):
    config=load_config(); book=client().open_by_key(SHEET_ID)
    meta=read_ws(ws(book,META_TAB)); existing=read_ws(ws(book,UNIV_TAB)); base=merge(existing,metadata_to_universe(meta,config))
    discovered=[]; da=[]
    if mode in {'discover','build'}:
        for m in config['equity_markets']:
            d,status=discover_market(m); discovered.append(d)
            existing_count=int((base['primary_economic_market'].astype(str).str.upper()==m['country'].upper()).sum()) if not base.empty else 0
            da.append({'run_ts':now(),'version':VERSION,'market':m['market'],'region_code':m['yahoo_region'],'target_count':m['target_count'],'existing_count':existing_count,
            'discovered_count':len(d),'new_count':sum(uid(s) not in set(base['universe_id']) for s in d.get('yahoo_symbol',[])) if len(d) else 0,
            'post_merge_count':'','sector_known_count':sum(d.get('sector_group',pd.Series(dtype=str)).astype(str).str.len()>0) if len(d) else 0,
            'yahoo_ok_count':'','source_status':status,'notes':'Rank-based discovery; target_count is coverage control, not a trading threshold'})
        disc=pd.concat([d for d in discovered if d is not None and not d.empty],ignore_index=True) if any(d is not None and not d.empty for d in discovered) else pd.DataFrame()
        base=merge(base,disc)
        base=enrich_missing_metadata(base,max_workers=int(os.getenv('STAGE0_METADATA_WORKERS','6')))
        base=validate_prices(base)
        for rec in da:
            m=next(x for x in config['equity_markets'] if x['market']==rec['market']); sub=base[base['primary_economic_market'].astype(str).str.upper()==m['country'].upper()]
            rec['post_merge_count']=len(sub); rec['sector_known_count']=sum(sub['sector_group'].astype(str).str.len()>0); rec['yahoo_ok_count']=sum(sub['yahoo_ok'].astype(str).str.upper()=='TRUE')
        write_ws(ws(book,UNIV_TAB),ensure(base,SECURITY_UNIVERSE_COLUMNS)); write_ws(ws(book,DISC_AUDIT_TAB),ensure(pd.DataFrame(da),DISCOVERY_AUDIT_COLUMNS))
    elif mode in {'benchmarks','validate','identity'}:
        if base.empty:raise RuntimeError('Security Universe is empty. Run build first.')
        if mode=='validate': base=validate_prices(base); write_ws(ws(book,UNIV_TAB),ensure(base,SECURITY_UNIVERSE_COLUMNS))

    identity_stats={}
    if mode in {'identity','build'}:
        base,identity_stats=enrich_identity(base,max_workers=int(os.getenv('STAGE0_IDENTITY_WORKERS','4')),max_age_days=int(os.getenv('STAGE0_IDENTITY_MAX_AGE_DAYS','30')),refresh_existing=os.getenv('STAGE0_IDENTITY_REFRESH_EXISTING','false').strip().lower() in {'1','true','yes','y'})
        write_ws(ws(book,UNIV_TAB),ensure(base,SECURITY_UNIVERSE_COLUMNS))
        ia={'run_ts':now(),'version':VERSION,'total_rows':len(base),**identity_stats,
            'notes':'Synthetic sector baskets use economic-market verified, same-market, canonical-company securities only.'}
        write_ws(ws(book,IDENTITY_AUDIT_TAB),ensure(pd.DataFrame([ia]),IDENTITY_AUDIT_COLUMNS))
    elif 'basket_eligible' not in base.columns or base['basket_eligible'].astype(str).str.strip().eq('').all():
        print('WARNING: identity/canonical cleanup has not been run. Run: python run_stage0.py identity')

    bench_seed=pd.read_csv(BENCH_SEED_PATH,dtype=str).fillna('') if BENCH_SEED_PATH.exists() else pd.DataFrame()
    benches,members=resolve(config,base,bench_seed,MIN_HISTORY)
    ts=now(); benches['last_verified']=ts
    if not members.empty:members['last_verified']=ts
    write_ws(ws(book,BENCH_TAB),ensure(benches,SECTOR_BENCHMARK_COLUMNS)); write_ws(ws(book,MEMBER_TAB),ensure(members,SECTOR_MEMBER_COLUMNS))
    counts=benches['resolved_benchmark_type'].value_counts().to_dict() if not benches.empty else {}
    # Persisted-sheet consistency: the counts printed in Stage0 Audit must come from
    # the same canonical rows/columns written to Sector Benchmarks.
    sheet_consistency = (len(benches) == len(config['equity_markets']) * len(config['sector_groups'])) and (int(sum(counts.values())) == len(benches))
    aud={'run_ts':ts,'version':VERSION,'mode':mode,'metadata_rows':len(meta),'existing_universe_rows':len(existing),'discovered_rows':sum(len(d) for d in discovered if d is not None) if discovered else 0,
         'merged_universe_rows':len(base),'enabled_rows':sum(base['enabled'].astype(str).str.upper()=='TRUE'),'yahoo_ok_rows':sum(base['yahoo_ok'].astype(str).str.upper()=='TRUE'),
         'yahoo_fail_rows':sum(base['yahoo_ok'].astype(str).str.upper()=='FALSE'),'sector_known_rows':sum(base['sector_group'].astype(str).str.len()>0),
         'economic_market_verified_rows':sum(base['economic_market_status'].astype(str).str.upper().isin(['YAHOO_VERIFIED','SOURCE_METADATA'])),
         'basket_eligible_rows':sum(base['basket_eligible'].astype(str).str.upper()=='TRUE'),
         'cross_listing_excluded_rows':sum(base['basket_exclusion_reason'].astype(str)=='CROSS_LISTING'),
         'duplicate_company_excluded_rows':sum(base['basket_exclusion_reason'].astype(str)=='DUPLICATE_COMPANY_LISTING'),
         'local_listing_override_rows':sum(base['breadth_membership_status'].astype(str)=='LOCAL_LISTING_OVERRIDE_ATHEX'),
         'provider_retry_rows':sum(base['economic_market_status'].astype(str)=='PROVIDER_RETRY_REQUIRED'),
         'sector_benchmark_rows':len(benches),
         'official_local_rows':counts.get('OFFICIAL_LOCAL',0),'local_proxy_rows':counts.get('LOCAL_SECTOR_PROXY',0),'synthetic_local_rows':counts.get('SYNTHETIC_LOCAL',0),'synthetic_regional_rows':counts.get('SYNTHETIC_REGIONAL',0),
         'global_fallback_rows':counts.get('GLOBAL_PROXY',0),'unresolved_sector_rows':counts.get('NEUTRAL',0),
         'benchmark_sheet_consistency':'PASS' if sheet_consistency else 'FAIL',
         'validation_status':'PASS' if counts.get('NEUTRAL',0)==0 and sheet_consistency else ('WARN' if sheet_consistency else 'FAIL'),'errors':''}
    aws=ws(book,AUDIT_TAB); old=read_ws(aws)
    # Audit schema evolved from v0.1. Keep only canonical audit columns before append;
    # this also drops any duplicate-header aliases from older sheet versions.
    old=ensure(old,AUDIT_COLUMNS)[AUDIT_COLUMNS] if not old.empty else pd.DataFrame(columns=AUDIT_COLUMNS)
    new=pd.concat([old,pd.DataFrame([aud],columns=AUDIT_COLUMNS)],ignore_index=True)
    write_ws(aws,new)
    print(json.dumps(aud,indent=2))

def main():
    p=argparse.ArgumentParser(description='AutoTrader V5 Stage 0.2.3.1: local breadth membership + provider resilience')
    p.add_argument('mode',choices=['build','discover','identity','benchmarks','validate'])
    a=p.parse_args(); run(a.mode)
if __name__=='__main__':main()
