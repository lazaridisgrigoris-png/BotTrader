from __future__ import annotations
import concurrent.futures as cf
import math
import re
from typing import Any, Dict, Iterable, List, Tuple
import pandas as pd
import yfinance as yf

SECTOR_MAP = {
    "communication services":"COMMUNICATION_SERVICES",
    "consumer cyclical":"CONSUMER_DISCRETIONARY",
    "consumer discretionary":"CONSUMER_DISCRETIONARY",
    "consumer defensive":"CONSUMER_STAPLES",
    "consumer staples":"CONSUMER_STAPLES",
    "energy":"ENERGY",
    "financial services":"FINANCIALS",
    "financial":"FINANCIALS",
    "financials":"FINANCIALS",
    "healthcare":"HEALTHCARE",
    "health care":"HEALTHCARE",
    "industrials":"INDUSTRIALS",
    "basic materials":"MATERIALS",
    "materials":"MATERIALS",
    "real estate":"REAL_ESTATE",
    "technology":"TECHNOLOGY",
    "utilities":"UTILITIES",
}

def clean(v: Any) -> str:
    if v is None: return ""
    s=str(v).strip()
    return "" if s.lower() in {"nan","none","null"} else s

def norm_sector(v: Any) -> str:
    s=clean(v).lower().replace("_"," ")
    return SECTOR_MAP.get(s, clean(v).upper().replace(" ","_"))

def uid(symbol: str) -> str:
    return re.sub(r"[^A-Z0-9]+","",clean(symbol).upper())

def _quotes(resp: Dict[str, Any]) -> List[Dict[str, Any]]:
    if not isinstance(resp, dict): return []
    q=resp.get("quotes")
    return q if isinstance(q,list) else []

def _screen(market: Dict[str,Any], sort_field: str, size: int) -> List[Dict[str,Any]]:
    from yfinance import EquityQuery
    clauses=[EquityQuery('eq',['region',market['yahoo_region']])]
    ex=market.get('exchanges') or []
    if ex:
        clauses.append(EquityQuery('is-in',['exchange',*ex]))
    q=EquityQuery('and',clauses) if len(clauses)>1 else clauses[0]
    resp=yf.screen(q,size=min(250,max(25,size)),sortField=sort_field,sortAsc=False)
    return _quotes(resp)

def discover_market(market: Dict[str,Any]) -> Tuple[pd.DataFrame,str]:
    target=int(market.get('target_count',60))
    # Discovery is rank-based, not a trading filter: union largest and most-liquid names.
    raw=[]
    errors=[]
    for sortf in ("intradaymarketcap","avgdailyvol3m"):
        try: raw.extend(_screen(market,sortf,min(250,max(target*2,80))))
        except Exception as e: errors.append(f"{sortf}:{type(e).__name__}:{e}")
    by={}
    for q in raw:
        sym=clean(q.get('symbol'))
        if not sym: continue
        by[sym]=q
    rows=[]
    for sym,q in by.items():
        rows.append({
            'universe_id':uid(sym),'symbol':sym,'yahoo_symbol':sym,'asset_type':'Stock','enabled':'TRUE',
            'domicile_country':'','listing_country':market['country'],
            'listing_market':clean(q.get('exchange')),'primary_economic_market':'','economic_market_status':'UNVERIFIED',
            'region':market['region'],'sector':clean(q.get('sector')),'industry':clean(q.get('industry')),
            'sector_group':norm_sector(q.get('sector')),'local_benchmark':market['local_benchmark'],
            'regional_benchmark':market['regional_benchmark'],'global_benchmark':'ACWI',
            'broker_route':market['broker_route'],'tradable':'UNKNOWN','source':'YAHOO_SCREENER',
            'source_priority':'70','market_cap':clean(q.get('marketCap') or q.get('intradaymarketcap')),
            'avg_volume_3m':clean(q.get('averageDailyVolume3Month') or q.get('avgdailyvol3m')),
            'metadata_status':'DISCOVERED','status':'ACTIVE','notes':'Ranked discovery by market cap and 3m volume'
        })
    df=pd.DataFrame(rows)
    if df.empty: return df, ("FAIL:"+" | ".join(errors) if errors else "NO_RESULTS")
    for c in ['market_cap','avg_volume_3m']:
        if c not in df: df[c]=''
        df[c+'_n']=pd.to_numeric(df[c],errors='coerce').fillna(0)
    # balanced discovery rank = best of cap rank and volume rank; avoids an arbitrary liquidity cutoff.
    df['cap_rank']=df['market_cap_n'].rank(method='min',ascending=False)
    df['vol_rank']=df['avg_volume_3m_n'].rank(method='min',ascending=False)
    df['discovery_rank']=df[['cap_rank','vol_rank']].min(axis=1)
    df=df.sort_values(['discovery_rank','market_cap_n'],ascending=[True,False]).head(target).copy()
    return df.drop(columns=['market_cap_n','avg_volume_3m_n','cap_rank','vol_rank','discovery_rank']), ("OK" if not errors else "PARTIAL:"+" | ".join(errors))

def enrich_one(symbol: str) -> Dict[str,Any]:
    try:
        info=yf.Ticker(symbol).get_info() or {}
        return {
            'yahoo_symbol':symbol,
            'sector':clean(info.get('sector')),
            'industry':clean(info.get('industry')),
            'sector_group':norm_sector(info.get('sector')),
            'domicile_country':clean(info.get('country')),
            'listing_market':clean(info.get('exchange')),
            'market_cap':clean(info.get('marketCap')),
            'avg_volume_3m':clean(info.get('averageVolume')),
            'metadata_enrich_status':'OK'
        }
    except Exception as e:
        return {'yahoo_symbol':symbol,'metadata_enrich_status':f'ERROR:{type(e).__name__}'}

def enrich_missing_metadata(df: pd.DataFrame, max_workers: int=6) -> pd.DataFrame:
    if df.empty: return df
    out=df.copy()
    mask=(out.get('sector_group','').astype(str).str.strip()=='') | (out.get('industry','').astype(str).str.strip()=='')
    syms=sorted(set(out.loc[mask,'yahoo_symbol'].astype(str).str.strip())-{""})
    if not syms: return out
    results={}
    with cf.ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs={ex.submit(enrich_one,s):s for s in syms}
        for f in cf.as_completed(futs):
            r=f.result(); results[r['yahoo_symbol']]=r
    for i,row in out.iterrows():
        r=results.get(clean(row.get('yahoo_symbol')))
        if not r: continue
        for c in ['sector','industry','sector_group','domicile_country','listing_market','market_cap','avg_volume_3m']:
            if not clean(row.get(c)) and clean(r.get(c)): out.at[i,c]=r[c]
        if clean(r.get('metadata_enrich_status'))!='OK':
            out.at[i,'notes']=(clean(out.at[i,'notes'])+'; '+r['metadata_enrich_status']).strip('; ')
    return out
