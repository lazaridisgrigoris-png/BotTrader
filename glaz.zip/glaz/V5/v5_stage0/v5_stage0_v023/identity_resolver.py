from __future__ import annotations
import concurrent.futures as cf
import datetime as dt
import re
from typing import Any, Dict
import pandas as pd
import yfinance as yf

COUNTRY_ALIASES = {
    'UNITED STATES OF AMERICA':'United States','USA':'United States','US':'United States','UNITED STATES':'United States',
    'UK':'United Kingdom','GREAT BRITAIN':'United Kingdom','UNITED KINGDOM':'United Kingdom',
    'GREECE':'Greece','GERMANY':'Germany','FRANCE':'France','ITALY':'Italy','SPAIN':'Spain',
    'NETHERLANDS':'Netherlands','SWITZERLAND':'Switzerland','JAPAN':'Japan','INDIA':'India',
    'HONG KONG':'Hong Kong','HONG KONG SAR':'Hong Kong','CANADA':'Canada','AUSTRALIA':'Australia',
}

EXCHANGE_COUNTRY = {
    'NMS':'United States','NAS':'United States','NYQ':'United States','NYE':'United States','ASE':'United States','PCX':'United States','BTS':'United States',
    'ATH':'Greece','LSE':'United Kingdom','GER':'Germany','FRA':'Germany','PAR':'France','MIL':'Italy',
    'MCE':'Spain','MAD':'Spain','AMS':'Netherlands','EBS':'Switzerland','JPX':'Japan','TYO':'Japan',
    'NSI':'India','BSE':'India','HKG':'Hong Kong','TOR':'Canada','NEO':'Canada','ASX':'Australia',
}

SUFFIX_COUNTRY = [
    ('.AT','Greece'),('.L','United Kingdom'),('.DE','Germany'),('.F','Germany'),('.PA','France'),('.MI','Italy'),
    ('.MC','Spain'),('.AS','Netherlands'),('.SW','Switzerland'),('.T','Japan'),('.NS','India'),('.BO','India'),
    ('.HK','Hong Kong'),('.TO','Canada'),('.NE','Canada'),('.AX','Australia')
]

TRUE = {'TRUE','1','YES','Y'}

def clean(v: Any) -> str:
    if v is None: return ''
    s=str(v).strip()
    return '' if s.lower() in {'nan','none','null'} else s

def norm_country(v: Any) -> str:
    s=clean(v)
    return COUNTRY_ALIASES.get(s.upper(), s)

def norm_name(v: Any) -> str:
    s=clean(v).upper()
    # Remove punctuation and common legal suffixes so dual listings collapse to one company.
    s=re.sub(r'[^A-Z0-9 ]+',' ',s)
    toks=[t for t in s.split() if t not in {'PLC','INC','CORP','CORPORATION','LTD','LIMITED','SA','S A','AG','NV','N V','SE','SPA','S P A','CO','COMPANY','HOLDINGS','HOLDING'}]
    return ' '.join(toks).strip()

def listing_country(symbol: str, exchange: str, fallback: str='') -> str:
    ex=clean(exchange).upper()
    if ex in EXCHANGE_COUNTRY: return EXCHANGE_COUNTRY[ex]
    s=clean(symbol).upper()
    for suffix,country in SUFFIX_COUNTRY:
        if s.endswith(suffix): return country
    return norm_country(fallback)

def _fetch(symbol: str) -> Dict[str,Any]:
    try:
        info=yf.Ticker(symbol).get_info() or {}
        name=clean(info.get('longName') or info.get('shortName'))
        country=norm_country(info.get('country'))
        exchange=clean(info.get('exchange'))
        quote_type=clean(info.get('quoteType')).upper()
        return {
            'yahoo_symbol':symbol,'identity_status':'OK','canonical_company_name':name,
            'domicile_country':country,'primary_economic_market':country,'economic_market_status':'YAHOO_VERIFIED' if country else 'YAHOO_NO_COUNTRY',
            'listing_market':exchange,'listing_country':listing_country(symbol,exchange,''),'quote_type':quote_type,
            'sector':clean(info.get('sector')),'industry':clean(info.get('industry')),
        }
    except Exception as e:
        return {'yahoo_symbol':symbol,'identity_status':f'ERROR:{type(e).__name__}','economic_market_status':'FETCH_ERROR'}

def _fresh(v: str, max_age_days: int) -> bool:
    s=clean(v)
    if not s: return False
    try:
        t=dt.datetime.fromisoformat(s.replace('Z','+00:00'))
        now=dt.datetime.now(dt.timezone.utc)
        if t.tzinfo is None: t=t.replace(tzinfo=dt.timezone.utc)
        return (now-t).days <= max_age_days
    except Exception:
        return False

def enrich_identity(df: pd.DataFrame, max_workers: int=4, max_age_days: int=30) -> tuple[pd.DataFrame, Dict[str,int]]:
    if df.empty: return df, {}
    x=df.copy()
    for c in ['economic_market_status','canonical_company_id','canonical_company_name','canonical_security_symbol','canonical_status','quote_type','basket_eligible','basket_exclusion_reason','identity_status','last_identity_verified']:
        if c not in x: x[c]=''

    candidate_mask=(x['enabled'].astype(str).str.upper().isin(TRUE)) & (x['yahoo_ok'].astype(str).str.upper().isin(TRUE))
    candidates=x[candidate_mask].copy()
    need=[]
    for _,r in candidates.iterrows():
        if clean(r.get('identity_status'))=='OK' and _fresh(r.get('last_identity_verified'),max_age_days):
            continue
        s=clean(r.get('yahoo_symbol') or r.get('symbol'))
        if s: need.append(s)
    need=sorted(set(need))
    results={}
    with cf.ThreadPoolExecutor(max_workers=max_workers) as ex:
        futs={ex.submit(_fetch,s):s for s in need}
        for f in cf.as_completed(futs):
            r=f.result(); results[r['yahoo_symbol']]=r

    ts=dt.datetime.now(dt.timezone.utc).replace(microsecond=0).isoformat()
    for i,r in x.iterrows():
        sym=clean(r.get('yahoo_symbol') or r.get('symbol'))
        got=results.get(sym)
        if got:
            for c in ['identity_status','canonical_company_name','domicile_country','primary_economic_market','economic_market_status','listing_market','listing_country','quote_type']:
                if clean(got.get(c)): x.at[i,c]=got[c]
            # Sector/industry from Yahoo identity call may correct stale classification, but only fill blanks.
            for c in ['sector','industry']:
                if not clean(r.get(c)) and clean(got.get(c)): x.at[i,c]=got[c]
            x.at[i,'last_identity_verified']=ts
        else:
            # Trusted pre-existing metadata remains usable when Yahoo identity was not required/refreshed.
            src=clean(r.get('source')).upper(); ms=clean(r.get('metadata_status')).upper()
            if not clean(r.get('economic_market_status')) and (ms=='FOUND' or 'METADATA' in src):
                x.at[i,'economic_market_status']='SOURCE_METADATA'
            if not clean(r.get('listing_country')):
                x.at[i,'listing_country']=listing_country(sym,clean(r.get('listing_market')),clean(r.get('listing_country')))

        name=clean(x.at[i,'canonical_company_name'])
        econ=norm_country(x.at[i,'primary_economic_market'])
        if econ: x.at[i,'primary_economic_market']=econ
        if name and econ:
            x.at[i,'canonical_company_id']=re.sub(r'[^A-Z0-9]+','_',f'{econ}_{norm_name(name)}').strip('_')
            x.at[i,'canonical_status']='NAMED'
        elif econ and sym:
            x.at[i,'canonical_company_id']=re.sub(r'[^A-Z0-9]+','_',f'{econ}_{sym.upper()}').strip('_')
            x.at[i,'canonical_status']='SYMBOL_FALLBACK'

    # Eligibility before canonical dedupe.
    x['basket_eligible']='FALSE'; x['basket_exclusion_reason']=''
    prelim=[]
    for i,r in x.iterrows():
        reason=''
        if str(r.get('enabled','')).upper() not in TRUE: reason='DISABLED'
        elif str(r.get('yahoo_ok','')).upper() not in TRUE: reason='YAHOO_INVALID'
        elif clean(r.get('asset_type')).upper() not in {'STOCK','EQUITY',''}: reason='NON_EQUITY_ASSET_TYPE'
        elif clean(r.get('quote_type')).upper() not in {'','EQUITY'}: reason='NON_EQUITY_QUOTE_TYPE'
        elif clean(r.get('economic_market_status')).upper() in {'','FETCH_ERROR','YAHOO_NO_COUNTRY','UNVERIFIED'}: reason='UNVERIFIED_ECONOMIC_MARKET'
        elif not clean(r.get('primary_economic_market')): reason='MISSING_ECONOMIC_MARKET'
        elif norm_country(r.get('listing_country')).upper()!=norm_country(r.get('primary_economic_market')).upper(): reason='CROSS_LISTING'
        elif not clean(r.get('sector_group')): reason='MISSING_SECTOR'
        else: prelim.append(i)
        if reason: x.at[i,'basket_exclusion_reason']=reason

    # One company = one contribution. Prefer the most liquid same-market listing.
    if prelim:
        p=x.loc[prelim].copy()
        p['_liq']=pd.to_numeric(p.get('median_dollar_volume_20d',''),errors='coerce').fillna(0)
        p['_cap']=pd.to_numeric(p.get('market_cap',''),errors='coerce').fillna(0)
        p['_cid']=p['canonical_company_id'].astype(str)
        # If no reliable company identity, keep security-specific fallback to avoid accidental merges.
        empty=p['_cid'].str.strip()==''
        p.loc[empty,'_cid']='SECURITY_'+p.loc[empty,'yahoo_symbol'].astype(str).str.upper()
        p=p.sort_values(['_cid','_liq','_cap'],ascending=[True,False,False])
        winners=set(p.groupby('_cid',sort=False).head(1).index)
        for i in prelim:
            if i in winners:
                x.at[i,'basket_eligible']='TRUE'; x.at[i,'basket_exclusion_reason']=''
                x.at[i,'canonical_security_symbol']=clean(x.at[i,'yahoo_symbol'] or x.at[i,'symbol'])
                x.at[i,'canonical_status']='CANONICAL'
            else:
                x.at[i,'basket_eligible']='FALSE'; x.at[i,'basket_exclusion_reason']='DUPLICATE_COMPANY_LISTING'; x.at[i,'canonical_status']='DUPLICATE'
        # Copy canonical symbol to duplicates for audit clarity.
        winner_by_cid={row['_cid']:clean(x.at[idx,'yahoo_symbol'] or x.at[idx,'symbol']) for idx,row in p.loc[list(winners)].iterrows()}
        for idx,row in p.iterrows():
            if not clean(x.at[idx,'canonical_security_symbol']): x.at[idx,'canonical_security_symbol']=winner_by_cid.get(row['_cid'],'')

    stats={
        'identity_candidates':len(need),
        'identity_ok':sum(1 for r in results.values() if r.get('identity_status')=='OK'),
        'identity_failed':sum(1 for r in results.values() if r.get('identity_status')!='OK'),
        'economic_market_verified_rows':int(x['economic_market_status'].astype(str).str.upper().isin(['YAHOO_VERIFIED','SOURCE_METADATA']).sum()),
        'basket_eligible_rows':int((x['basket_eligible'].astype(str).str.upper()=='TRUE').sum()),
        'cross_listing_excluded_rows':int((x['basket_exclusion_reason'].astype(str)=='CROSS_LISTING').sum()),
        'duplicate_company_excluded_rows':int((x['basket_exclusion_reason'].astype(str)=='DUPLICATE_COMPANY_LISTING').sum()),
        'non_equity_excluded_rows':int(x['basket_exclusion_reason'].astype(str).str.startswith('NON_EQUITY').sum()),
        'unverified_identity_excluded_rows':int((x['basket_exclusion_reason'].astype(str)=='UNVERIFIED_ECONOMIC_MARKET').sum()),
    }
    return x,stats
