# Stage 0.2.3 Design

Pipeline:

`Security Metadata + Security Universe`
→ `Yahoo identity enrichment`
→ `economic market / listing market separation`
→ `canonical company grouping`
→ `one local primary/canonical security per company`
→ `price/data validation`
→ `local sector members`
→ `regional sector members`
→ `authoritative benchmark resolution`
→ `audit`

Benchmark hierarchy remains:

`OFFICIAL_LOCAL > LOCAL_SECTOR_PROXY > SYNTHETIC_LOCAL > SYNTHETIC_REGIONAL > GLOBAL_PROXY > NEUTRAL`

Key invariant: **listing venue does not define economic-market membership.**

Key invariant: **one company contributes at most once to a synthetic basket.**
