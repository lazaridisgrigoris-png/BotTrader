VERSION = "5.0-stage1-v1.0-global-opportunity"

WEEKLY_COLUMNS = [
    "run_ts","version","asof_date","iso_week","weekly_rank","market","kind","country","region",
    "benchmark","execution","constituent_count_configured","constituent_count_with_data",
    "trend_score","rs_score","acceleration_score","breadth_score","risk_score","opportunity_score",
    "status","status_usage","score_method","breadth_method","breadth_n",
    "pct_gt_ema13","pct_gt_ema34","pct_gt_ema50","pct_positive_21d","pct_near_20d_high",
    "ret_5d_pct","ret_21d_pct","ret_63d_pct","price_vs_ema13_pct","ema13_vs_ema34_pct","dist_63d_high_pct",
    "excess_5d_pct","excess_21d_pct","excess_63d_pct","accel_raw","ema13_slope_delta",
    "atr14_pct","atr_expansion_ratio","drawdown_63d_pct","vix","data_status","notes"
]

LATEST_COLUMNS = WEEKLY_COLUMNS

AUDIT_COLUMNS = [
    "run_ts","version","mode","requested_asof","snapshot_count","universe_rows","eligible_breadth_rows",
    "equity_markets_configured","asset_sleeves_configured","market_rows_output","no_data_market_rows",
    "price_symbols_requested","price_symbols_ok","price_symbols_failed","global_reference_ok","vix_ok",
    "stage0_latest_status","stage0_source_status","breadth_membership_field_present","validation_status","errors"
]
