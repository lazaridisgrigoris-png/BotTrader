# AutoTrader V5 — Stage 1 v1.0

## Purpose
Production first version of the **Global Opportunity Engine**. It answers the weekly question:

> Where should V5 look hardest for long opportunities right now?

It uses **market data only**. It does **not** read Trades and makes **no AI calls**.

## Inputs
- `Security Universe` from frozen Stage 0.2.3.1+
- latest `Stage0 Audit` (validation status check)
- Yahoo Finance OHLCV
- `config/markets.json`
- `config/stage1_config.json`

## Equity market breadth
Stage 1 deliberately uses Stage 0's `breadth_market` plus canonical `basket_eligible` securities. Therefore:
- legitimate ATHEX local members such as EEE.AT/CENER.AT may participate in Greece breadth even when corporate domicile differs;
- obvious foreign secondary listings remain excluded;
- duplicate company listings do not double-count breadth.

## Five dimensions
Historical Phase-1 weights are preserved as the starting hypothesis:
- Trend 25%
- Relative Strength vs ACWI 25%
- Acceleration 15%
- Breadth 20%
- Risk 15%

The labels `PRIORITY / ACTIVE / SELECTIVE / AVOID` are **allocation/research signals, not trade gates**.

## Important production correction vs the old experiment
The old research script used benchmark trend as a proxy for asset-sleeve breadth (Gold, Silver, etc.), which double-counted similar information. V1.0 does **not** do that. For asset sleeves with no real constituent breadth, breadth is omitted and the remaining dimensions are transparently reweighted (`DYNAMIC_REWEIGHT_MISSING_BREADTH`).

## Output tabs
- `V5 Global Opportunity Weekly`
- `V5 Global Opportunity Latest`
- `V5 Stage1 Audit`

## Environment
```powershell
$env:SHEET_ID="..."
$env:SERVICE_ACCOUNT_JSON="C:\path\service-account.json"
```
Existing Stage-0 environment variables can be reused.

## First run
From this folder:
```powershell
python run_stage1.py selftest
python run_stage1.py validate
python run_stage1.py current
```

To reconstruct recent history using the production Stage-1 logic:
```powershell
python run_stage1.py backfill
```

Optional explicit as-of date:
```powershell
python run_stage1.py current --asof 2026-09-11
```

## Idempotence
`current` replaces any existing Weekly rows for the same `asof_date`; it does not keep adding duplicates. `backfill` rebuilds the Stage-1 Weekly output.

## What v1.0 intentionally does NOT do
- no sector opportunity scoring (Stage 2)
- no stock prescreen (Stage 3)
- no Trades/strategy-health feedback yet
- no news
- no AI
- no hard rejection of a market based on `status`
