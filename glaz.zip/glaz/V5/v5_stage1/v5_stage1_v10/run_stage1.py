#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import os
import sys
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np
import pandas as pd

from global_opportunity import (
    canonical_market_constituents, evaluate_one, friday_snapshots, last_completed_friday,
    normalize_symbol, norm_bool,
)
from stage1_schemas import VERSION, WEEKLY_COLUMNS, LATEST_COLUMNS, AUDIT_COLUMNS

BASE = Path(__file__).resolve().parent

SHEET_ID = os.getenv("SHEET_ID", "").strip()
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "").strip()
SECURITY_UNIVERSE_TAB = os.getenv("SECURITY_UNIVERSE_TAB", "Security Universe")
STAGE0_AUDIT_TAB = os.getenv("STAGE0_AUDIT_TAB", "Stage0 Audit")
OUTPUT_WEEKLY_TAB = os.getenv("STAGE1_WEEKLY_TAB", "V5 Global Opportunity Weekly")
OUTPUT_LATEST_TAB = os.getenv("STAGE1_LATEST_TAB", "V5 Global Opportunity Latest")
STAGE1_AUDIT_TAB = os.getenv("STAGE1_AUDIT_TAB", "V5 Stage1 Audit")
YAHOO_BATCH_SIZE = int(os.getenv("STAGE1_YAHOO_BATCH_SIZE", "80"))
YAHOO_BATCH_PAUSE = float(os.getenv("STAGE1_YAHOO_BATCH_PAUSE", "0.20"))


def load_json(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def make_unique_headers(headers: Sequence[str]) -> List[str]:
    out, seen = [], {}
    for i, raw in enumerate(headers):
        h = str(raw or "").strip() or f"__blank_{i}"
        n = seen.get(h, 0)
        out.append(h if n == 0 else f"{h}__dup{n}")
        seen[h] = n + 1
    return out


def connect_workbook():
    import gspread
    from google.oauth2.service_account import Credentials
    if not SHEET_ID:
        raise RuntimeError("SHEET_ID environment variable is required.")
    if not SERVICE_ACCOUNT_JSON:
        raise RuntimeError("SERVICE_ACCOUNT_JSON environment variable is required.")
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON, scopes=scopes)
    return gspread.authorize(creds).open_by_key(SHEET_ID)


def read_ws(sh, tab: str) -> pd.DataFrame:
    ws = sh.worksheet(tab)
    values = ws.get_all_values()
    if not values:
        return pd.DataFrame()
    headers = make_unique_headers(values[0])
    rows = values[1:]
    width = len(headers)
    rows = [(r + [""] * width)[:width] for r in rows]
    return pd.DataFrame(rows, columns=headers)


def ensure_columns(df: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    out = df.copy()
    for c in columns:
        if c not in out.columns:
            out[c] = ""
    return out[list(columns)]


def write_df(sh, tab: str, df: pd.DataFrame):
    import gspread
    data = df.replace([np.inf, -np.inf], np.nan).where(pd.notnull(df), "")
    values = [list(data.columns)] + data.astype(object).values.tolist()
    try:
        ws = sh.worksheet(tab)
        ws.clear()
        ws.resize(rows=max(100, len(values) + 20), cols=max(20, len(data.columns) + 2))
    except gspread.WorksheetNotFound:
        ws = sh.add_worksheet(title=tab, rows=max(100, len(values) + 20), cols=max(20, len(data.columns) + 2))
    ws.update(values, value_input_option="RAW")


def append_row(sh, tab: str, row: dict, columns: Sequence[str]):
    import gspread
    try:
        old = read_ws(sh, tab)
    except gspread.WorksheetNotFound:
        old = pd.DataFrame(columns=columns)
    old = ensure_columns(old, columns)
    new = pd.DataFrame([{c: row.get(c, "") for c in columns}])
    write_df(sh, tab, pd.concat([old, new], ignore_index=True))


def normalize_download(df: pd.DataFrame) -> Optional[pd.DataFrame]:
    if df is None or df.empty:
        return None
    x = df.copy()
    if isinstance(x.columns, pd.MultiIndex):
        # This helper is only for extracted single-symbol frames.
        if x.columns.nlevels > 1:
            x.columns = x.columns.get_level_values(0)
    need = {"Open","High","Low","Close"}
    if not need.issubset(set(x.columns)):
        return None
    x.index = pd.to_datetime(x.index).tz_localize(None)
    return x[~x.index.duplicated(keep="last")].sort_index()


def download_batch(symbols: Sequence[str], start: date, end: date) -> Dict[str, Optional[pd.DataFrame]]:
    import yfinance as yf
    cache = {s: None for s in symbols}
    syms = list(dict.fromkeys(s for s in symbols if s))
    for pos in range(0, len(syms), YAHOO_BATCH_SIZE):
        batch = syms[pos:pos + YAHOO_BATCH_SIZE]
        print(f"[YAHOO] batch {pos+1}-{min(pos+len(batch), len(syms))}/{len(syms)}")
        try:
            raw = yf.download(
                tickers=batch, start=str(start), end=str(end + timedelta(days=1)), interval="1d",
                auto_adjust=True, progress=False, threads=True, group_by="ticker"
            )
        except Exception as e:
            print(f"[WARN] batch failed: {type(e).__name__}: {e}")
            raw = None

        if raw is not None and not raw.empty:
            if len(batch) == 1:
                cache[batch[0]] = normalize_download(raw)
            elif isinstance(raw.columns, pd.MultiIndex):
                lvl0 = set(map(str, raw.columns.get_level_values(0)))
                lvl1 = set(map(str, raw.columns.get_level_values(1)))
                for sym in batch:
                    try:
                        if sym in lvl0:
                            sub = raw[sym].copy()
                        elif sym in lvl1:
                            sub = raw.xs(sym, axis=1, level=1).copy()
                        else:
                            continue
                        cache[sym] = normalize_download(sub)
                    except Exception:
                        pass
        time.sleep(YAHOO_BATCH_PAUSE)
    return cache


def latest_stage0_status(stage0_audit: pd.DataFrame) -> str:
    if stage0_audit.empty or "validation_status" not in stage0_audit.columns:
        return "UNKNOWN"
    vals = stage0_audit["validation_status"].astype(str).str.strip()
    vals = vals[vals != ""]
    return vals.iloc[-1] if len(vals) else "UNKNOWN"


def equity_market_defs(markets_cfg: dict) -> List[dict]:
    return [m for m in markets_cfg.get("equity_markets", []) if m.get("enabled", True)]


def asset_defs(stage1_cfg: dict) -> List[dict]:
    return [m for m in stage1_cfg.get("asset_sleeves", []) if m.get("enabled", True)]


def build_constituents(universe: pd.DataFrame, markets: Sequence[dict]) -> Dict[str, List[str]]:
    out = {}
    for m in markets:
        out[m["market"]] = canonical_market_constituents(universe, m["country"])
    return out


def validate_inputs(universe: pd.DataFrame, stage0_status: str, markets: Sequence[dict]) -> List[str]:
    errors = []
    required = {"enabled","yahoo_symbol","yahoo_ok","basket_eligible","breadth_market","breadth_membership_status"}
    missing = sorted(required - set(universe.columns))
    if missing:
        errors.append("Security Universe missing columns: " + ",".join(missing))
    if stage0_status not in {"PASS", "UNKNOWN"}:
        errors.append(f"Latest Stage0 Audit validation_status={stage0_status}")
    if universe.empty:
        errors.append("Security Universe is empty")
    for m in markets:
        if not m.get("local_benchmark"):
            errors.append(f"Market {m.get('market')} has no local_benchmark")
    return errors


def run_engine(mode: str, asof: Optional[str] = None):
    stage1_cfg = load_json(BASE / "config" / "stage1_config.json")
    markets_cfg = load_json(BASE / "config" / "markets.json")
    sh = connect_workbook()
    universe = read_ws(sh, SECURITY_UNIVERSE_TAB)
    try:
        stage0_audit = read_ws(sh, STAGE0_AUDIT_TAB)
    except Exception:
        stage0_audit = pd.DataFrame()
    s0_status = latest_stage0_status(stage0_audit)
    markets = equity_market_defs(markets_cfg)
    assets = asset_defs(stage1_cfg)
    errs = validate_inputs(universe, s0_status, markets)
    if errs:
        raise RuntimeError("; ".join(errs))

    constituents = build_constituents(universe, markets)
    eligible_breadth_rows = sum(len(v) for v in constituents.values())

    today = date.today()
    if asof:
        requested = datetime.strptime(asof, "%Y-%m-%d").date()
    else:
        requested = last_completed_friday(today)

    if mode == "backfill":
        lookback = int(stage1_cfg.get("backfill_lookback_days", 100))
        snapshots = friday_snapshots(requested - timedelta(days=lookback), requested)
    else:
        snapshots = [requested]

    if not snapshots:
        raise RuntimeError("No weekly snapshots resolved.")

    global_ref = stage1_cfg["global_reference"]
    vix_symbol = stage1_cfg["vix_symbol"]
    symbols = [global_ref, vix_symbol]
    symbols += [m["local_benchmark"] for m in markets]
    symbols += [a["benchmark"] for a in assets]
    for xs in constituents.values():
        symbols.extend(xs)
    symbols = list(dict.fromkeys(normalize_symbol(s) for s in symbols if s))

    history_days = int(stage1_cfg.get("history_days", 420))
    start = min(snapshots) - timedelta(days=history_days)
    end = max(snapshots)
    cache = download_batch(symbols, start, end)

    run_ts = datetime.now(timezone.utc).isoformat(timespec="seconds")
    rows = []
    for snap in snapshots:
        for m in markets:
            rows.append(evaluate_one(
                run_ts=run_ts, version=VERSION, asof_date=snap, market=m["market"], kind="COUNTRY",
                country=m["country"], region=m["region"], benchmark=m["local_benchmark"], execution=m["broker_route"],
                constituents=constituents[m["market"]], cache=cache,
                global_reference=global_ref, vix_symbol=vix_symbol,
                weights=stage1_cfg["weights"], thresholds=stage1_cfg["status_thresholds"],
                min_breadth_stocks=int(stage1_cfg.get("min_breadth_stocks", 8)),
                status_usage=stage1_cfg["status_usage"],
            ))
        for a in assets:
            rows.append(evaluate_one(
                run_ts=run_ts, version=VERSION, asof_date=snap, market=a["market"], kind="ASSET",
                country="", region="GLOBAL", benchmark=a["benchmark"], execution=a["execution"], constituents=[], cache=cache,
                global_reference=global_ref, vix_symbol=vix_symbol,
                weights=stage1_cfg["weights"], thresholds=stage1_cfg["status_thresholds"],
                min_breadth_stocks=int(stage1_cfg.get("min_breadth_stocks", 8)),
                status_usage=stage1_cfg["status_usage"],
            ))

    result = pd.DataFrame(rows)
    for snap in sorted(result["asof_date"].unique()):
        mask = result["asof_date"] == snap
        scores = pd.to_numeric(result.loc[mask, "opportunity_score"], errors="coerce")
        ranks = scores.rank(method="min", ascending=False, na_option="bottom")
        result.loc[mask, "weekly_rank"] = ranks.astype("Int64").astype(str).replace("<NA>", "")
    result = ensure_columns(result, WEEKLY_COLUMNS)

    latest_date = result["asof_date"].max()
    latest = result[result["asof_date"] == latest_date].copy()
    latest["__score"] = pd.to_numeric(latest["opportunity_score"], errors="coerce")
    latest = latest.sort_values(["__score","market"], ascending=[False,True]).drop(columns=["__score"])
    latest = ensure_columns(latest, LATEST_COLUMNS)

    if mode == "backfill":
        write_df(sh, OUTPUT_WEEKLY_TAB, result)
    else:
        try:
            prior = read_ws(sh, OUTPUT_WEEKLY_TAB)
        except Exception:
            prior = pd.DataFrame(columns=WEEKLY_COLUMNS)
        prior = ensure_columns(prior, WEEKLY_COLUMNS)
        # Idempotent current run: replace same asof_date rows rather than duplicate them.
        prior = prior[prior["asof_date"].astype(str) != str(latest_date)]
        combined = pd.concat([prior, result], ignore_index=True)
        write_df(sh, OUTPUT_WEEKLY_TAB, combined)
    write_df(sh, OUTPUT_LATEST_TAB, latest)

    ok_count = sum(1 for s in symbols if cache.get(s) is not None and not cache[s].empty)
    failed_count = len(symbols) - ok_count
    no_data = int((result["status"].astype(str) == "NO_DATA").sum())
    audit = {
        "run_ts": run_ts, "version": VERSION, "mode": mode, "requested_asof": str(requested),
        "snapshot_count": len(snapshots), "universe_rows": len(universe), "eligible_breadth_rows": eligible_breadth_rows,
        "equity_markets_configured": len(markets), "asset_sleeves_configured": len(assets), "market_rows_output": len(result),
        "no_data_market_rows": no_data, "price_symbols_requested": len(symbols), "price_symbols_ok": ok_count,
        "price_symbols_failed": failed_count,
        "global_reference_ok": bool(cache.get(global_ref) is not None and not cache[global_ref].empty),
        "vix_ok": bool(cache.get(vix_symbol) is not None and not cache[vix_symbol].empty),
        "stage0_latest_status": s0_status, "stage0_source_status": "FOUND" if not stage0_audit.empty else "NOT_FOUND",
        "breadth_membership_field_present": "breadth_market" in universe.columns,
        "validation_status": "PASS" if no_data == 0 and cache.get(global_ref) is not None else "WARN",
        "errors": "" if no_data == 0 else f"NO_DATA rows={no_data}",
    }
    append_row(sh, STAGE1_AUDIT_TAB, audit, AUDIT_COLUMNS)
    print(json.dumps(audit, indent=2, default=str))
    print("\nTop opportunities:")
    print(latest[["weekly_rank","market","kind","status","opportunity_score","breadth_method","breadth_n"]].head(10).to_string(index=False))


def validate_only():
    stage1_cfg = load_json(BASE / "config" / "stage1_config.json")
    markets_cfg = load_json(BASE / "config" / "markets.json")
    sh = connect_workbook()
    universe = read_ws(sh, SECURITY_UNIVERSE_TAB)
    try:
        s0 = read_ws(sh, STAGE0_AUDIT_TAB)
    except Exception:
        s0 = pd.DataFrame()
    markets = equity_market_defs(markets_cfg)
    status = latest_stage0_status(s0)
    errors = validate_inputs(universe, status, markets)
    constituents = build_constituents(universe, markets) if not errors else {}
    summary = {
        "version": VERSION, "validation_status": "PASS" if not errors else "FAIL",
        "stage0_latest_status": status, "universe_rows": len(universe),
        "markets": {m["market"]: len(constituents.get(m["market"], [])) for m in markets},
        "errors": errors,
    }
    print(json.dumps(summary, indent=2))
    if errors:
        raise SystemExit(2)


def selftest():
    from global_opportunity import trend_score, rs_score, acceleration_score, breadth_score, risk_score, weighted_opportunity
    idx = pd.bdate_range("2026-01-01", periods=120)
    base = np.linspace(100, 125, len(idx)) + np.sin(np.arange(len(idx))/5)
    def frame(mult=1.0):
        c = pd.Series(base*mult, index=idx)
        return pd.DataFrame({"Open":c*0.998,"High":c*1.01,"Low":c*0.99,"Close":c,"Volume":1_000_000}, index=idx)
    bm, glob = frame(1.0), frame(0.95)
    t,_ = trend_score(bm); r,_ = rs_score(bm,glob); a,_ = acceleration_score(bm); k,_ = risk_score(bm,None)
    cache = {f"S{i}": frame(0.9+i/100) for i in range(12)}
    b,bd = breadth_score(list(cache), cache, idx[-1].date(), 8)
    score,method = weighted_opportunity({"trend":t,"rs":r,"acceleration":a,"breadth":b,"risk":k},
                                        {"trend":.25,"rs":.25,"acceleration":.15,"breadth":.20,"risk":.15})
    assert all(np.isfinite(x) for x in (t,r,a,b,k,score))
    assert bd["breadth_n"] == 12
    assert method == "FULL_5_DIMENSION"
    print(json.dumps({"selftest":"PASS","trend":round(t,3),"rs":round(r,3),"acceleration":round(a,3),
                      "breadth":round(b,3),"risk":round(k,3),"opportunity":round(score,3)}, indent=2))


def main():
    p = argparse.ArgumentParser(description="AutoTrader V5 Stage 1 - Global Opportunity Engine")
    sub = p.add_subparsers(dest="mode", required=True)
    for name in ("current","backfill"):
        sp = sub.add_parser(name)
        sp.add_argument("--asof", help="YYYY-MM-DD. Defaults to latest completed Friday.")
    sub.add_parser("validate")
    sub.add_parser("selftest")
    args = p.parse_args()
    if args.mode == "validate":
        validate_only()
    elif args.mode == "selftest":
        selftest()
    else:
        run_engine(args.mode, args.asof)


if __name__ == "__main__":
    main()
