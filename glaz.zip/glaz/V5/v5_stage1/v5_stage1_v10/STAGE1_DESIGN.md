# Stage 1 design contract

**Component:** Global Opportunity Engine  
**Version:** 5.0-stage1-v1.0-global-opportunity

## Contract
1. Stage 0 owns universe identity, local breadth membership and canonical deduplication.
2. Stage 1 owns weekly cross-market opportunity measurement.
3. Stage 1 never mutates Security Universe or Sector Benchmarks.
4. Stage 1 never reads Trades in v1.0, preserving non-circular market-data-only scoring.
5. Stage 1 never invokes AI.
6. Market status is contextual/allocation information, not permission to reject all stocks from that market.
7. Stage 2 will evaluate sectors inside these markets; a strong sector can still matter in a weak market.

## Equity market set
Inherited from Stage 0: US, Greece, UK, Germany, France, Italy, Spain, Netherlands, Switzerland, Japan, India, Hong Kong, Canada, Australia.

## Asset sleeves
Frozen from the historical experiment for continuity: Gold, Silver, Energy, Industrial Metals, Agriculture.

## Scoring
Trend 25 / RS 25 / Acceleration 15 / Breadth 20 / Risk 15.
Missing components are explicitly omitted and weights renormalized; the output records `score_method`.

## Breadth
Only Stage-0 canonical local breadth members are counted. This is the main production improvement over the old experimental metadata-country constituent logic.

## Next validation
After a successful live run, compare:
- market constituent counts by country;
- breadth method/count;
- weekly rankings/status;
- differences versus frozen historical Phase-1 results.
Do not adjust weights/thresholds merely because one weekly result looks surprising.
