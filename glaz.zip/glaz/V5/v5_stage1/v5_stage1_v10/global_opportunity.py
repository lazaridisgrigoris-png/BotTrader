from __future__ import annotations

import math
from dataclasses import dataclass
from datetime import date, datetime, timedelta
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

import numpy as np
import pandas as pd


def clamp(x: float, lo: float = 0.0, hi: float = 10.0) -> float:
    return max(lo, min(hi, float(x)))


def finite(x) -> bool:
    try:
        return bool(np.isfinite(float(x)))
    except Exception:
        return False


def norm_bool(x) -> bool:
    return str(x or "").strip().lower() in {"true", "1", "yes", "y"}


def normalize_symbol(x: str) -> str:
    s = str(x or "").strip()
    if ":" in s:
        s = s.split(":", 1)[1]
    return s


def asof_df(df: Optional[pd.DataFrame], asof_date: date) -> Optional[pd.DataFrame]:
    if df is None or df.empty:
        return None
    x = df.loc[df.index <= pd.Timestamp(asof_date)]
    return x if len(x) else None


def pct_return(close: pd.Series, days: int) -> float:
    c = close.dropna()
    if len(c) <= days:
        return np.nan
    return float((c.iloc[-1] / c.iloc[-1-days] - 1.0) * 100.0)


def atr_pct(df: pd.DataFrame, n: int = 14) -> float:
    if df is None or len(df) < n + 2:
        return np.nan
    prev = df["Close"].shift(1)
    tr = pd.concat([
        df["High"] - df["Low"],
        (df["High"] - prev).abs(),
        (df["Low"] - prev).abs(),
    ], axis=1).max(axis=1)
    atr = tr.rolling(n).mean().iloc[-1]
    close = df["Close"].iloc[-1]
    return float(100.0 * atr / close) if close and finite(atr) else np.nan


def trend_score(df: pd.DataFrame) -> Tuple[float, dict]:
    if df is None or len(df) < 70:
        return np.nan, {}
    c = df["Close"].dropna()
    if len(c) < 70:
        return np.nan, {}
    e13 = c.ewm(span=13, adjust=False).mean()
    e34 = c.ewm(span=34, adjust=False).mean()
    e50 = c.ewm(span=50, adjust=False).mean()

    score = 0.0
    score += 2.0 if c.iloc[-1] > e13.iloc[-1] else 0.0
    score += 2.0 if e13.iloc[-1] > e34.iloc[-1] else 0.0
    score += 1.5 if e34.iloc[-1] > e50.iloc[-1] else 0.0
    score += 1.5 if e13.iloc[-1] > e13.iloc[-6] else 0.0
    score += 1.0 if e34.iloc[-1] > e34.iloc[-6] else 0.0

    r21 = pct_return(c, 21)
    if finite(r21):
        score += clamp((r21 + 4.0) / 8.0, 0, 1.0)

    hi63 = c.tail(63).max()
    dist_high = 100.0 * (c.iloc[-1] / hi63 - 1.0) if hi63 else np.nan
    if finite(dist_high):
        score += clamp((dist_high + 12.0) / 12.0, 0, 1.0)

    return clamp(score), {
        "ret_21d_pct": r21,
        "ret_63d_pct": pct_return(c, 63),
        "price_vs_ema13_pct": 100.0 * (c.iloc[-1] / e13.iloc[-1] - 1.0),
        "ema13_vs_ema34_pct": 100.0 * (e13.iloc[-1] / e34.iloc[-1] - 1.0),
        "dist_63d_high_pct": dist_high,
    }


def rs_score(df: pd.DataFrame, global_df: pd.DataFrame) -> Tuple[float, dict]:
    if df is None or global_df is None:
        return np.nan, {}
    a = df["Close"].dropna()
    g = global_df["Close"].dropna()
    horizons = [(5, 0.25), (21, 0.40), (63, 0.35)]
    weighted, used = 0.0, 0.0
    details = {}
    for days, weight in horizons:
        ra, rg = pct_return(a, days), pct_return(g, days)
        if finite(ra) and finite(rg):
            ex = ra - rg
            details[f"excess_{days}d_pct"] = ex
            weighted += weight * clamp(5.0 + ex * 0.5)
            used += weight
    return (weighted / used if used else np.nan), details


def acceleration_score(df: pd.DataFrame) -> Tuple[float, dict]:
    if df is None or len(df) < 70:
        return np.nan, {}
    c = df["Close"].dropna()
    if len(c) < 70:
        return np.nan, {}
    r5, r21, r63 = pct_return(c, 5), pct_return(c, 21), pct_return(c, 63)
    e13 = c.ewm(span=13, adjust=False).mean()
    slope_now = 100.0 * (e13.iloc[-1] / e13.iloc[-6] - 1.0)
    slope_prev = 100.0 * (e13.iloc[-6] / e13.iloc[-11] - 1.0)
    slope_delta = slope_now - slope_prev
    m5 = r5 / 5.0 if finite(r5) else 0.0
    m21 = r21 / 21.0 if finite(r21) else 0.0
    m63 = r63 / 63.0 if finite(r63) else 0.0
    accel = 0.60 * (m5 - m21) + 0.40 * (m21 - m63) + 0.25 * slope_delta
    return clamp(5.0 + accel * 12.0), {
        "ret_5d_pct": r5,
        "accel_raw": accel,
        "ema13_slope_delta": slope_delta,
    }


def breadth_score(
    constituents: Sequence[str],
    cache: Mapping[str, Optional[pd.DataFrame]],
    asof_date: date,
    min_stocks: int,
) -> Tuple[float, dict]:
    vals = []
    for sym in constituents:
        d = asof_df(cache.get(sym), asof_date)
        if d is None or len(d) < 55:
            continue
        c = d["Close"].dropna()
        if len(c) < 55:
            continue
        e13 = c.ewm(span=13, adjust=False).mean().iloc[-1]
        e34 = c.ewm(span=34, adjust=False).mean().iloc[-1]
        e50 = c.ewm(span=50, adjust=False).mean().iloc[-1]
        r21 = pct_return(c, 21)
        hi20 = c.tail(20).max()
        vals.append({
            "gt13": c.iloc[-1] > e13,
            "gt34": c.iloc[-1] > e34,
            "gt50": c.iloc[-1] > e50,
            "pos21": finite(r21) and r21 > 0,
            "near20high": c.iloc[-1] >= 0.98 * hi20,
        })
    n = len(vals)
    if n < min_stocks:
        return np.nan, {"breadth_n": n, "breadth_method": "INSUFFICIENT_CANONICAL_LOCAL_MEMBERS"}

    def p(key: str) -> float:
        return 100.0 * sum(bool(v[key]) for v in vals) / n

    p13, p34, p50, p21, ph = [p(k) for k in ("gt13", "gt34", "gt50", "pos21", "near20high")]
    participation = 0.20*p13 + 0.25*p34 + 0.25*p50 + 0.20*p21 + 0.10*ph
    return clamp(participation / 10.0), {
        "breadth_n": n,
        "pct_gt_ema13": p13,
        "pct_gt_ema34": p34,
        "pct_gt_ema50": p50,
        "pct_positive_21d": p21,
        "pct_near_20d_high": ph,
        "breadth_method": "CANONICAL_LOCAL_BREADTH_MEMBERS",
    }


def risk_score(df: pd.DataFrame, vix_df: Optional[pd.DataFrame] = None) -> Tuple[float, dict]:
    if df is None or len(df) < 70:
        return np.nan, {}
    c = df["Close"].dropna()
    atr_now = atr_pct(df, 14)
    old = df.iloc[:-10] if len(df) > 30 else df
    atr_old = atr_pct(old, 14)
    atr_ratio = atr_now / atr_old if finite(atr_now) and finite(atr_old) and atr_old > 0 else 1.0
    high63 = c.tail(63).max()
    dd63 = 100.0 * (c.iloc[-1] / high63 - 1.0) if high63 else np.nan

    score = 8.5
    if finite(dd63):
        score -= clamp(max(0.0, -dd63 - 3.0) * 0.25, 0, 2.5)
    score -= clamp(max(0.0, atr_ratio - 1.0) * 3.0, 0, 2.0)
    if finite(atr_now):
        score -= clamp(max(0.0, atr_now - 3.0) * 0.35, 0, 1.5)

    vix = np.nan
    if vix_df is not None and len(vix_df):
        vix = float(vix_df["Close"].iloc[-1])
        if vix >= 35:
            score -= 2.0
        elif vix >= 28:
            score -= 1.2
        elif vix >= 22:
            score -= 0.6

    return clamp(score), {
        "atr14_pct": atr_now,
        "atr_expansion_ratio": atr_ratio,
        "drawdown_63d_pct": dd63,
        "vix": vix,
    }


def weighted_opportunity(parts: Mapping[str, float], weights: Mapping[str, float]) -> Tuple[float, str]:
    total, used = 0.0, 0.0
    missing = []
    for key, weight in weights.items():
        value = parts.get(key, np.nan)
        if finite(value):
            total += float(weight) * float(value)
            used += float(weight)
        else:
            missing.append(key)
    if used <= 0:
        return np.nan, "NO_SCORE_COMPONENTS"
    method = "FULL_5_DIMENSION" if not missing else "DYNAMIC_REWEIGHT_MISSING_" + "_".join(missing).upper()
    return total / used, method


def status_from_score(score: float, thresholds: Mapping[str, float]) -> str:
    if not finite(score):
        return "NO_DATA"
    if score >= float(thresholds["PRIORITY"]):
        return "PRIORITY"
    if score >= float(thresholds["ACTIVE"]):
        return "ACTIVE"
    if score >= float(thresholds["SELECTIVE"]):
        return "SELECTIVE"
    return "AVOID"


def canonical_market_constituents(universe: pd.DataFrame, country: str) -> List[str]:
    """
    Stage-1 market breadth is driven by Stage-0 local breadth membership, not
    corporate domicile/economic country. We require Stage-0 basket eligibility
    to avoid foreign secondary listings and duplicate company listings.
    """
    if universe.empty:
        return []
    u = universe.copy()
    for col in ("enabled","yahoo_ok","basket_eligible"):
        if col not in u.columns:
            u[col] = False
    if "breadth_market" not in u.columns:
        raise RuntimeError("Security Universe lacks breadth_market. Run Stage 0.2.3.1+ first.")
    if "yahoo_symbol" not in u.columns:
        u["yahoo_symbol"] = u.get("symbol", "")

    mask = (
        u["enabled"].map(norm_bool)
        & u["yahoo_ok"].map(norm_bool)
        & u["basket_eligible"].map(norm_bool)
        & (u["breadth_market"].astype(str).str.strip().str.lower() == str(country).strip().lower())
    )
    syms = [normalize_symbol(x) for x in u.loc[mask, "yahoo_symbol"].tolist()]
    return list(dict.fromkeys(s for s in syms if s))


def friday_snapshots(start_date: date, end_date: date) -> List[date]:
    if start_date > end_date:
        return []
    return [d.date() for d in pd.date_range(start=start_date, end=end_date, freq="W-FRI")]


def last_completed_friday(on_date: date) -> date:
    # Monday=0 ... Friday=4. On Friday itself, use that date; weekend uses prior Friday.
    delta = (on_date.weekday() - 4) % 7
    return on_date - timedelta(days=delta)


def evaluate_one(
    *, run_ts: str, version: str, asof_date: date, market: str, kind: str,
    country: str, region: str, benchmark: str, execution: str,
    constituents: Sequence[str], cache: Mapping[str, Optional[pd.DataFrame]],
    global_reference: str, vix_symbol: str, weights: Mapping[str, float],
    thresholds: Mapping[str, float], min_breadth_stocks: int, status_usage: str,
) -> dict:
    df = asof_df(cache.get(benchmark), asof_date)
    gdf = asof_df(cache.get(global_reference), asof_date)
    vdf = asof_df(cache.get(vix_symbol), asof_date)

    base = {
        "run_ts": run_ts, "version": version, "asof_date": str(asof_date),
        "iso_week": f"{asof_date.isocalendar().year}-W{asof_date.isocalendar().week:02d}",
        "weekly_rank": "", "market": market, "kind": kind, "country": country, "region": region,
        "benchmark": benchmark, "execution": execution,
        "constituent_count_configured": len(constituents), "constituent_count_with_data": 0,
        "status_usage": status_usage,
    }
    if df is None or len(df) < 70 or gdf is None or len(gdf) < 70:
        return {**base, "status": "NO_DATA", "data_status": "BENCHMARK_OR_GLOBAL_REFERENCE_INSUFFICIENT",
                "notes": "STAGE1_MARKET_DATA_ONLY_NO_TRADES_NO_AI"}

    trend, td = trend_score(df)
    rs, rd = rs_score(df, gdf)
    accel, ad = acceleration_score(df)
    risk, riskd = risk_score(df, vdf)

    if kind == "COUNTRY":
        breadth, bd = breadth_score(constituents, cache, asof_date, min_breadth_stocks)
    else:
        # Known defect in the old experiment: using benchmark trend as asset breadth
        # double-counted the same information. Production v1.0 omits unavailable
        # asset breadth and renormalizes the other dimensions transparently.
        breadth, bd = np.nan, {"breadth_n": 0, "breadth_method": "ASSET_BREADTH_NOT_DEFINED_OMITTED"}

    parts = {"trend":trend, "rs":rs, "acceleration":accel, "breadth":breadth, "risk":risk}
    opp, score_method = weighted_opportunity(parts, weights)
    n_with_data = int(bd.get("breadth_n", 0))

    row = {
        **base,
        "constituent_count_with_data": n_with_data,
        "trend_score": round(trend, 3) if finite(trend) else "",
        "rs_score": round(rs, 3) if finite(rs) else "",
        "acceleration_score": round(accel, 3) if finite(accel) else "",
        "breadth_score": round(breadth, 3) if finite(breadth) else "",
        "risk_score": round(risk, 3) if finite(risk) else "",
        "opportunity_score": round(opp, 3) if finite(opp) else "",
        "status": status_from_score(opp, thresholds),
        "score_method": score_method,
        "breadth_method": bd.get("breadth_method", ""),
        "breadth_n": n_with_data,
        "pct_gt_ema13": bd.get("pct_gt_ema13", ""),
        "pct_gt_ema34": bd.get("pct_gt_ema34", ""),
        "pct_gt_ema50": bd.get("pct_gt_ema50", ""),
        "pct_positive_21d": bd.get("pct_positive_21d", ""),
        "pct_near_20d_high": bd.get("pct_near_20d_high", ""),
        "ret_5d_pct": ad.get("ret_5d_pct", ""),
        "ret_21d_pct": td.get("ret_21d_pct", ""),
        "ret_63d_pct": td.get("ret_63d_pct", ""),
        "price_vs_ema13_pct": td.get("price_vs_ema13_pct", ""),
        "ema13_vs_ema34_pct": td.get("ema13_vs_ema34_pct", ""),
        "dist_63d_high_pct": td.get("dist_63d_high_pct", ""),
        "excess_5d_pct": rd.get("excess_5d_pct", ""),
        "excess_21d_pct": rd.get("excess_21d_pct", ""),
        "excess_63d_pct": rd.get("excess_63d_pct", ""),
        "accel_raw": ad.get("accel_raw", ""),
        "ema13_slope_delta": ad.get("ema13_slope_delta", ""),
        "atr14_pct": riskd.get("atr14_pct", ""),
        "atr_expansion_ratio": riskd.get("atr_expansion_ratio", ""),
        "drawdown_63d_pct": riskd.get("drawdown_63d_pct", ""),
        "vix": riskd.get("vix", ""),
        "data_status": "OK" if finite(opp) else "PARTIAL_OR_NO_SCORE",
        "notes": "STAGE1_MARKET_DATA_ONLY_NO_TRADES_NO_AI",
    }
    return row
