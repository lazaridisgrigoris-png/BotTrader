import yfinance as yf
import mplfinance as mpf
import pandas as pd
from datetime import date

symbol = "AAPL"

df = yf.download(
    tickers=symbol,
    period="1y",      # ← full rolling year
    interval="1d",
    auto_adjust=False,
    group_by="column",
    progress=True
)


if df is None or df.empty:
    raise RuntimeError(f"No data returned for {symbol}")

# --- 1) If MultiIndex columns exist, flatten them ---
# Example MultiIndex: ('Open','AAPL') or ('AAPL','Open')
if isinstance(df.columns, pd.MultiIndex):
    # Keep only the first level if it contains OHLCV names,
    # otherwise keep the last level.
    levels0 = set(map(str, df.columns.get_level_values(0)))
    levels1 = set(map(str, df.columns.get_level_values(-1)))

    ohlcv = {"Open", "High", "Low", "Close", "Volume", "Adj Close"}

    if len(levels0 & ohlcv) >= 3:
        df.columns = df.columns.get_level_values(0)
    elif len(levels1 & ohlcv) >= 3:
        df.columns = df.columns.get_level_values(-1)
    else:
        # Fallback: join levels with underscore
        df.columns = ["_".join(map(str, c)) for c in df.columns.to_list()]

# --- 2) Normalize column names and keep only OHLCV ---
# Sometimes yfinance returns 'Adj Close' too; mplfinance doesn't need it.
rename_map = {c: str(c).strip() for c in df.columns}
df = df.rename(columns=rename_map)

required = ["Open", "High", "Low", "Close", "Volume"]
missing = [c for c in required if c not in df.columns]
if missing:
    # Print helpful debugging info
    raise RuntimeError(f"Missing columns {missing}. Columns returned: {list(df.columns)}")

df = df[required].copy()

# --- 3) Force numeric types safely ---
for col in required:
    s = df[col]
    # If somehow still not a Series, squeeze to Series
    if not isinstance(s, pd.Series):
        s = s.squeeze()
    df[col] = pd.to_numeric(s, errors="coerce")

df = df.dropna()

# --- 4) Ensure DateTimeIndex for mplfinance ---
df.index = pd.to_datetime(df.index)

# --- 5) Plot ---
out = f"{symbol}_YTD.png"
mpf.plot(
    df,
    type="candle",
    style="yahoo",
    volume=True,
    figsize=(8, 6),
    savefig=out
)

print(f"Saved chart: {out}")


