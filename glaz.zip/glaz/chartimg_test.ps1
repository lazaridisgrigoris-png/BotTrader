$key = "0nG77A6Hc6ajztBP6lfXN7HJpwQJUsIHaArnOMnW"

# NOTE: v1 docs show key can be passed in the query string. :contentReference[oaicite:3]{index=3}
$url = "https://api.chart-img.com/v1/tradingview/advanced-chart" +
       "?key=$key&symbol=NASDAQ:AAPL&interval=1D&theme=dark&width=800&height=600"

Invoke-WebRequest -Uri $url -OutFile "test.png"



