#!/usr/bin/env python3
"""
full_watchlist_parsing.py (Yahoo Finance + mplfinance version)

Replaces Chart-IMG with:
- yfinance: download 1y daily OHLCV
- mplfinance: render candlestick+volume chart to PNG bytes
Then sends PNG to OpenAI Vision exactly like before.

Dependencies:
  python -m pip install openai gspread google-auth yfinance mplfinance pandas matplotlib httpx

Env vars (recommended):
  OPENAI_API_KEY=...
  SHEET_ID=...
Optional:
  SERVICE_ACCOUNT_JSON=...
  OPENAI_MODEL=...
  RUN_MODE=daily|weekly
"""

from __future__ import annotations

import base64
import datetime as dt
import io
import json
import os
import re
import time
import random
import httpx
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import gspread
import gspread.utils
import pandas as pd
import yfinance as yf
import mplfinance as mpf
from google.oauth2.service_account import Credentials
from openai import OpenAI, APIConnectionError, APITimeoutError, RateLimitError, APIError

# Gemini (optional)

def strip_json_fence(text: str) -> str:
    """Remove common markdown code fences around JSON and return the raw JSON string."""
    if text is None:
        return ""
    s = str(text).strip()
    # Remove ```json ... ``` or ``` ... ``` fences
    if s.startswith("```"):
        # Drop the opening fence line
        s = re.sub(r"^```(?:json)?\s*\n", "", s, flags=re.IGNORECASE)
        # Drop the trailing fence
        s = re.sub(r"\n```\s*$", "", s)
    # Some models wrap in single backticks
    if s.startswith("`") and s.endswith("`") and len(s) >= 2:
        s = s[1:-1].strip()
    return s

try:
    from google import genai as google_genai
    from google.genai import types as genai_types
except ImportError:  # pragma: no cover
    google_genai = None
    genai_types = None

import socket
import requests
# =========================
# CONFIG
# =========================

# ---- Google Sheets
SHEET_ID = os.getenv("SHEET_ID", "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg")
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "auto-trading-481921-980bcad6baf5.json")
WATCHLIST_TAB = "Watchlist"
HISTORY_TAB = "DailySignals"
GEM_OUTPUT_TAB = "Output_Gem"

# ---- Chart rendering (local)
LOOKBACK_PERIOD = os.getenv("LOOKBACK_PERIOD", "1y")  # e.g. 6mo, 1y, 2y
INTERVAL = "1d"

# mplfinance render settings (affect readability + OpenAI image tokens)
FIGSIZE = (8, 6)   # inches
DPI = 150          # 120–180 is a good range

# ---- OpenAI
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
OPENAI_TIMEOUT_SEC = 180


# ---- Provider selection
# openai | gemini | both
ANALYSIS_PROVIDER = os.getenv("ANALYSIS_PROVIDER", "openai").strip().lower()
if ANALYSIS_PROVIDER not in ("openai", "gemini", "both"):
    ANALYSIS_PROVIDER = "openai"

# ---- Gemini
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash-lite")
GEMINI_TIMEOUT_SEC = int(os.getenv("GEMINI_TIMEOUT_SEC", "180"))

# ---- Runtime
OUTPUT_DIR = Path("output")
SAVE_CHARTS = True
SLEEP_BETWEEN_SYMBOLS_SEC = 0.5

# ---- Strategy constraints (hard filters)
MAX_STOP_PCT = 0.02     # 2%
MIN_TARGET1_PCT = 0.05  # 5%
MAX_HOLD_DAYS = 20      # ~1 month trading days

# Entry must be close to current price to be actionable in DAILY scans
ENTRY_MAX_GAP_PCT = float(os.getenv("ENTRY_MAX_GAP_PCT", "0.02"))  # 2% default
STOP_MAX_PCT = float(os.getenv("STOP_MAX_PCT", "0.02"))        # 2% max stop
MIN_TARGET2_PCT = float(os.getenv("MIN_TARGET2_PCT", "0.10")) # 10% target2
# If TRADE, entry_price should align with the detected breakout_level (prevents "loose" entries)
ENTRY_BREAKOUT_ALIGN_PCT = float(os.getenv("ENTRY_BREAKOUT_ALIGN_PCT", "0.005"))  # 0.5% default


# ---- Phase 2.5 selector / ranking engine
# AI proposes setup. Python computes objective context and selects Top-N trades.
PHASE25_ENABLED = os.getenv("PHASE25_ENABLED", "true").strip().lower() in ("1", "true", "yes", "y")
PHASE25_TOP_N_PER_WEEK = int(os.getenv("PHASE25_TOP_N_PER_WEEK", "12"))
PHASE25_MIN_FINAL_SCORE = float(os.getenv("PHASE25_MIN_FINAL_SCORE", "6.8"))
PHASE25_REJECT_BEAR = os.getenv("PHASE25_REJECT_BEAR", "false").strip().lower() in ("1", "true", "yes", "y")
PHASE25_REJECT_NEGATIVE_RS = os.getenv("PHASE25_REJECT_NEGATIVE_RS", "false").strip().lower() in ("1", "true", "yes", "y")
PHASE25_APPLY_DECISION_OVERRIDE = os.getenv("PHASE25_APPLY_DECISION_OVERRIDE", "true").strip().lower() in ("1", "true", "yes", "y")

# Component weights. Keep explainable and aligned with evaluation script Phase-2.5.
PHASE25_WEIGHT_AI_GRADE = float(os.getenv("PHASE25_WEIGHT_AI_GRADE", "0.10"))
PHASE25_WEIGHT_MARKET = float(os.getenv("PHASE25_WEIGHT_MARKET", "0.08"))
PHASE25_WEIGHT_REL_STRENGTH = float(os.getenv("PHASE25_WEIGHT_REL_STRENGTH", "0.20"))
PHASE25_WEIGHT_SECTOR = float(os.getenv("PHASE25_WEIGHT_SECTOR", "0.12"))
PHASE25_WEIGHT_VOLATILITY = float(os.getenv("PHASE25_WEIGHT_VOLATILITY", "0.06"))
PHASE25_WEIGHT_EXTENSION = float(os.getenv("PHASE25_WEIGHT_EXTENSION", "0.09"))
PHASE25_WEIGHT_BREAKOUT = float(os.getenv("PHASE25_WEIGHT_BREAKOUT", "0.13"))
PHASE25_WEIGHT_BREADTH = float(os.getenv("PHASE25_WEIGHT_BREADTH", "0.08"))
PHASE25_WEIGHT_MTF = float(os.getenv("PHASE25_WEIGHT_MTF", "0.08"))
PHASE25_WEIGHT_ACCUMULATION = float(os.getenv("PHASE25_WEIGHT_ACCUMULATION", "0.06"))

REGIME_FAST_SMA = int(os.getenv("REGIME_FAST_SMA", "21"))
REGIME_SLOW_SMA = int(os.getenv("REGIME_SLOW_SMA", "50"))
REL_STRENGTH_LOOKBACK_DAYS = int(os.getenv("REL_STRENGTH_LOOKBACK_DAYS", "21"))
VOLATILITY_LOOKBACK_DAYS = int(os.getenv("VOLATILITY_LOOKBACK_DAYS", "14"))
VIX_SYMBOL = os.getenv("VIX_SYMBOL", "^VIX")

EXTENSION_EMA_FAST = int(os.getenv("EXTENSION_EMA_FAST", "10"))
EXTENSION_EMA_SLOW = int(os.getenv("EXTENSION_EMA_SLOW", "20"))
EXTENSION_DIST_EMA10_WARN_PCT = float(os.getenv("EXTENSION_DIST_EMA10_WARN_PCT", "4.0"))
EXTENSION_DIST_EMA10_BAD_PCT = float(os.getenv("EXTENSION_DIST_EMA10_BAD_PCT", "6.0"))
EXTENSION_DIST_EMA20_BAD_PCT = float(os.getenv("EXTENSION_DIST_EMA20_BAD_PCT", "8.0"))
EXTENSION_GAP_WARN_PCT = float(os.getenv("EXTENSION_GAP_WARN_PCT", "1.5"))
EXTENSION_GAP_BAD_PCT = float(os.getenv("EXTENSION_GAP_BAD_PCT", "3.0"))

BREAKOUT_LOOKBACK_DAYS = int(os.getenv("BREAKOUT_LOOKBACK_DAYS", "20"))
BREAKOUT_BASE_TIGHT_DAYS = int(os.getenv("BREAKOUT_BASE_TIGHT_DAYS", "10"))
BREAKOUT_VOLUME_LOOKBACK_DAYS = int(os.getenv("BREAKOUT_VOLUME_LOOKBACK_DAYS", "20"))
BREAKOUT_ATR_FAST_DAYS = int(os.getenv("BREAKOUT_ATR_FAST_DAYS", "10"))
BREAKOUT_ATR_SLOW_DAYS = int(os.getenv("BREAKOUT_ATR_SLOW_DAYS", "30"))
BREAKOUT_TIGHT_BASE_GOOD_PCT = float(os.getenv("BREAKOUT_TIGHT_BASE_GOOD_PCT", "6.0"))
BREAKOUT_TIGHT_BASE_OK_PCT = float(os.getenv("BREAKOUT_TIGHT_BASE_OK_PCT", "10.0"))
BREAKOUT_EXTREME_RANGE_BAD_PCT = float(os.getenv("BREAKOUT_EXTREME_RANGE_BAD_PCT", "18.0"))
BREAKOUT_CLOSE_POSITION_GOOD = float(os.getenv("BREAKOUT_CLOSE_POSITION_GOOD", "0.75"))
BREAKOUT_VOLUME_EXPANSION_GOOD = float(os.getenv("BREAKOUT_VOLUME_EXPANSION_GOOD", "1.3"))
BREAKOUT_ATR_COMPRESSION_GOOD = float(os.getenv("BREAKOUT_ATR_COMPRESSION_GOOD", "0.85"))

BREADTH_EMA_FAST = int(os.getenv("BREADTH_EMA_FAST", "50"))
BREADTH_EMA_SLOW = int(os.getenv("BREADTH_EMA_SLOW", "200"))
MTF_DAILY_EMA_FAST = int(os.getenv("MTF_DAILY_EMA_FAST", "20"))
MTF_DAILY_EMA_SLOW = int(os.getenv("MTF_DAILY_EMA_SLOW", "50"))
MTF_WEEKLY_EMA = int(os.getenv("MTF_WEEKLY_EMA", "10"))
ACCUM_LOOKBACK_DAYS = int(os.getenv("ACCUM_LOOKBACK_DAYS", "20"))
ACCUM_VOLUME_RATIO_GOOD = float(os.getenv("ACCUM_VOLUME_RATIO_GOOD", "1.2"))
ACCUM_OBV_LOOKBACK_DAYS = int(os.getenv("ACCUM_OBV_LOOKBACK_DAYS", "20"))

PHASE25_MAX_PER_SECTOR_GROUP_PER_WEEK = int(os.getenv("PHASE25_MAX_PER_SECTOR_GROUP_PER_WEEK", "3"))
PHASE25_ASSET_CLASS_QUOTAS = {
    "US_STOCK": int(os.getenv("PHASE25_QUOTA_US_STOCK", "6")),
    "US_ETF": int(os.getenv("PHASE25_QUOTA_US_ETF", "3")),
    "EUROPE_STOCK": int(os.getenv("PHASE25_QUOTA_EUROPE_STOCK", "4")),
    "EUROPE_ETF": int(os.getenv("PHASE25_QUOTA_EUROPE_ETF", "3")),
    "ATHEX": int(os.getenv("PHASE25_QUOTA_ATHEX", "2")),
    "OTHER": int(os.getenv("PHASE25_QUOTA_OTHER", "3")),
}
PHASE25_MARKET_REGION_QUOTAS = {
    "US_NASDAQ": int(os.getenv("PHASE25_REGION_US_NASDAQ", "5")),
    "US_NYSE": int(os.getenv("PHASE25_REGION_US_NYSE", "5")),
    "GREECE_ATHEX": int(os.getenv("PHASE25_REGION_GREECE_ATHEX", "2")),
    "EUROPE_DE": int(os.getenv("PHASE25_REGION_EUROPE_DE", "4")),
    "EUROPE_FR": int(os.getenv("PHASE25_REGION_EUROPE_FR", "4")),
    "EUROPE_IT": int(os.getenv("PHASE25_REGION_EUROPE_IT", "4")),
    "UK": int(os.getenv("PHASE25_REGION_UK", "3")),
    "GLOBAL_DEFAULT": int(os.getenv("PHASE25_REGION_GLOBAL_DEFAULT", "3")),
}

# ---- Run mode
# weekly: full analysis (OpenAI/Gemini) + writebacks
# daily : monitoring run (no AI calls; just refresh prices + last_run)
RUN_MODE = os.getenv("RUN_MODE", "weekly").strip().lower()
if RUN_MODE not in ("daily", "weekly"):
    RUN_MODE = "weekly"

# ---- Watchlist headers (auto-added if missing)
WATCHLIST_HEADERS = [
    # input controls
    "symbol",
    "enabled",
    "min_grade",
    "only_alert_if_trade",
    "update_only_on_change",

    # primary outputs
    "last_run",
    "last_close",
    "decision",
    "grade_0_10",
    "pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",

    # status tracking
    "last_status",
    "last_grade",
    "last_pattern",
    "last_signal_ts",
    "last_change_ts",

    # Phase-2.5 selector outputs
    "ai_grade",
    "market_regime",
    "market_score",
    "relative_strength_score",
    "relative_strength_21d_pct",
    "sector_group",
    "sector_score",
    "volatility_score",
    "extension_score",
    "breakout_score",
    "breadth_score",
    "mtf_score",
    "accumulation_score",
    "final_score",
    "weekly_rank",
    "selected",
    "reject_reason",
    "selector_notes",
]

HISTORY_HEADERS = [
    "run_ts",
    "mode",
    "symbol",
    "decision",
    "grade_0_10",
    "best_pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",
    "final_score",
    "weekly_rank",
    "selected",
    "reject_reason",
    "selector_notes",
]

# Output_Gem: symbol + primary outputs (to compare Gemini results with Watchlist/OpenAI)
GEM_OUTPUT_HEADERS = [
    "symbol",
    "last_run",
    "last_close",
    "decision",
    "grade_0_10",
    "pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",
    "final_score",
    "selected",
    "weekly_rank",
    "selector_notes",
]


WEEKLY_RESET_KEEP_HEADERS = ["symbol", "enabled", "min_grade", "only_alert_if_trade"]


def weekly_snapshot_title(suffix: str, when: Optional[dt.datetime] = None) -> str:
    when = when or dt.datetime.now()
    iso = when.isocalendar()
    yy = iso.year % 100
    ww = iso.week
    return f"Y{yy:02d}W{ww:02d} {suffix}"


def create_sheet_snapshot(sh: gspread.Spreadsheet, src_ws: gspread.Worksheet, new_title: str) -> gspread.Worksheet:
    """Create a value snapshot of a worksheet under a new title."""
    try:
        existing = sh.worksheet(new_title)
        sh.del_worksheet(existing)
    except gspread.WorksheetNotFound:
        pass

    values = src_ws.get_all_values()
    rows = max(len(values), 1000)
    cols = max(max((len(r) for r in values), default=0), 20)
    new_ws = sh.add_worksheet(title=new_title, rows=rows, cols=cols)
    if values:
        end_a1 = gspread.utils.rowcol_to_a1(len(values), max(len(r) for r in values))
        new_ws.update(f"A1:{end_a1}", values)
    return new_ws


def clear_sheet_except_headers(ws: gspread.Worksheet, keep_headers: List[str]) -> None:
    """Keep header row and preserve only selected columns for all data rows; clear everything else."""
    values = ws.get_all_values()
    if len(values) < 2:
        return

    header = [str(x).strip() for x in values[0]]
    max_cols = max(max((len(r) for r in values), default=0), len(header))
    keep = {str(h).strip().lower() for h in keep_headers}

    cleaned_rows: List[List[str]] = []
    for row in values[1:]:
        row = list(row) + [""] * (max_cols - len(row))
        new_row: List[str] = []
        for i in range(max_cols):
            h = header[i].strip().lower() if i < len(header) else ""
            new_row.append(row[i] if h in keep else "")
        cleaned_rows.append(new_row)

    if cleaned_rows:
        end_a1 = gspread.utils.rowcol_to_a1(len(cleaned_rows) + 1, max_cols)
        ws.update(f"A2:{end_a1}", cleaned_rows)


def prepare_weekly_sheets(ws_watch: gspread.Worksheet, ws_gem: gspread.Worksheet) -> None:
    """Before weekly processing: snapshot both sheets, then clear all non-input columns."""
    sh = ws_watch.spreadsheet
    create_sheet_snapshot(sh, ws_watch, weekly_snapshot_title("Watchlist"))
    create_sheet_snapshot(sh, ws_gem, weekly_snapshot_title("Output_gem"))
    clear_sheet_except_headers(ws_watch, WEEKLY_RESET_KEEP_HEADERS)
    clear_sheet_except_headers(ws_gem, WEEKLY_RESET_KEEP_HEADERS)

# =========================
# PROMPTS
# =========================

BASE_PROMPT = f"""
You evaluate daily stock charts using Bulkowski-style chart patterns with highest probability of success.
LONG trades only.

Constraints:
- Timeframe: Daily
- Lookback: last {LOOKBACK_PERIOD} (as shown in the chart image)
- Max holding time: 1 month (about {MAX_HOLD_DAYS} trading days)
- Target: +5% to +10%
- Stop loss: -1% to -2% (flag NO_TRADE if unrealistic given volatility/structure)

Return STRICT JSON only with exactly this schema:
{{
  "symbol": "EXCHANGE:TICKER",
  "pattern_candidates": [
    {{"name": "string", "confidence_0_100": 0, "breakout_level": 0.0, "invalidation_level": 0.0}}
  ],
  "entry_plan": {{
    "decision": "TRADE" or "NO_TRADE",
    "trigger": "string",
    "entry_price": 0.0,
    "stop_price": 0.0,
    "target_price_1": 0.0,
    "target_price_2": 0.0,
    "time_stop_days": {MAX_HOLD_DAYS}
  }},
  "risk_notes": ["string"],
  "grade_0_10": 0,
  "no_trade_if": ["string"]
}}
""".strip()

DAILY_INSTRUCTIONS = """
Mode: DAILY EXECUTION SCAN
- Be strict: Only set decision=TRADE if breakout/trigger is actionable now or next 1–2 sessions.
- Require stop to be structurally valid and within 1–2% (otherwise NO_TRADE).
- Prefer patterns that can plausibly deliver +5% within 1 month before major resistance.

- IMPORTANT: DAILY scan rule: Only set decision=TRADE if entry_price is within ~2% of the latest close (current price proxy).
- If entry_price is farther away (waiting for breakout/pullback), set decision=NO_TRADE and note it as FUTURE_SETUP.
""".strip()

WEEKLY_INSTRUCTIONS = """
Mode: WEEKLY SETUP SCAN
- Identify if a high-quality Bulkowski-style setup is forming or close to a valid trigger.
- It's OK if entry isn't today, but only mark TRADE if trigger is very close (near breakout level).
- Still respect the stop realism: if 1–2% stop is not realistic, prefer NO_TRADE and explain.
""".strip()

PROMPT_BY_MODE = {
    "daily": BASE_PROMPT + "\n\n" + DAILY_INSTRUCTIONS,
    "weekly": BASE_PROMPT + "\n\n" + WEEKLY_INSTRUCTIONS,
}


# =========================
# HELPERS
# =========================

def now_str_local() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def today_iso() -> str:
    return dt.date.today().isoformat()

def safe_filename(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
    return s.strip("_") or "item"

def png_bytes_to_data_url(png_bytes: bytes) -> str:
    b64 = base64.b64encode(png_bytes).decode("ascii")
    return f"data:image/png;base64,{b64}"

def to_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        if isinstance(x, (int, float)):
            return float(x)
        s = str(x).strip()
        if s == "":
            return None
        return float(s)
    except Exception:
        return None

def truthy(x: Any, default: bool = False) -> bool:
    if x is None:
        return default
    s = str(x).strip().upper()
    if s == "":
        return default
    return s in ("TRUE", "YES", "1", "Y")

def to_int(x: Any, default: int) -> int:
    try:
        if x is None:
            return default
        s = str(x).strip()
        if s == "":
            return default
        return int(float(s))
    except Exception:
        return default


# =========================
# GOOGLE SHEETS
# =========================

def connect_sheets() -> Tuple[gspread.Worksheet, gspread.Worksheet, gspread.Worksheet]:
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON, scopes=scopes)
    gc = gspread.authorize(creds)
    sh = gc.open_by_key(SHEET_ID)

    ws_watch = sh.worksheet(WATCHLIST_TAB)

    try:
        ws_hist = sh.worksheet(HISTORY_TAB)
    except gspread.WorksheetNotFound:
        ws_hist = sh.add_worksheet(title=HISTORY_TAB, rows=2000, cols=30)
        ws_hist.append_row(HISTORY_HEADERS)

    try:
        ws_gem = sh.worksheet(GEM_OUTPUT_TAB)
    except gspread.WorksheetNotFound:
        ws_gem = sh.add_worksheet(title=GEM_OUTPUT_TAB, rows=2000, cols=30)
        ws_gem.append_row(GEM_OUTPUT_HEADERS)

    return ws_watch, ws_hist, ws_gem

def ensure_headers(ws: gspread.Worksheet, required_headers: List[str]) -> Dict[str, int]:
    values = ws.get_all_values()
    if not values:
        ws.append_row(required_headers)
        header_row = required_headers
    else:
        header_row = values[0]

    col_map = {}
    for i, h in enumerate(header_row, start=1):
        key = h.strip().lower()
        if not key:
            continue
        col_map[key] = i
        col_map[key.replace(" ", "_")] = i
    missing = [h for h in required_headers if h.lower() not in col_map]
    if missing:
        new_headers = header_row + missing
        ws.update("1:1", [new_headers])
        col_map = {}
        for i, h in enumerate(new_headers, start=1):
            key = h.strip().lower()
            if not key:
                continue
            col_map[key] = i
            col_map[key.replace(" ", "_")] = i
    return col_map


def build_symbol_row_map(ws: gspread.Worksheet, symbol_col_name: str = "symbol") -> Dict[str, int]:
    """Return mapping from symbol -> row index for a sheet with headers on row 1."""
    values = ws.get_all_values()
    if not values or len(values) < 2:
        return {}
    header = [h.strip().lower() for h in values[0]]
    try:
        sym_idx = header.index(symbol_col_name.lower())
    except ValueError:
        return {}
    out: Dict[str, int] = {}
    for i in range(2, len(values) + 1):
        row = values[i - 1]
        if sym_idx < len(row):
            s = row[sym_idx].strip()
            if s:
                out[s] = i
    return out


def upsert_row_by_symbol(
    ws: gspread.Worksheet,
    col_map: Dict[str, int],
    symbol_to_row: Dict[str, int],
    symbol: str,
    values_by_col: Dict[str, Any],
) -> None:
    """Upsert a row by symbol (update if exists, append otherwise)."""
    s = (symbol or "").strip()
    if not s:
        return

    if s not in symbol_to_row:
        # Append a full-width row matching existing header width.
        max_col = max(col_map.values()) if col_map else 1
        row_vals = [""] * max_col
        if "symbol" in col_map:
            row_vals[col_map["symbol"] - 1] = s
        for k, v in values_by_col.items():
            ck = str(k).strip().lower()
            if ck in col_map:
                row_vals[col_map[ck] - 1] = "" if v is None else str(v)
        ws.append_row(row_vals, value_input_option="RAW")
        # Refresh map for appended row
        symbol_to_row[s] = len(ws.get_all_values())
        return

    row_index = symbol_to_row[s]
    updates: List[Tuple[int, Any]] = []
    for k, v in values_by_col.items():
        ck = str(k).strip().lower()
        if ck in col_map:
            updates.append((col_map[ck], v))
    batch_update_cells(ws, row_index, updates)


def get_cell(row: List[str], col_map: Dict[str, int], name: str) -> str:
    c = col_map[name.lower()]
    return row[c - 1].strip() if c - 1 < len(row) else ""

def set_cell(ws: gspread.Worksheet, row_index: int, col: int, val: Any) -> None:
    """Single-cell write (kept for rare cases). Prefer batch_update_cells()."""
    ws.update_cell(row_index, col, "" if val is None else str(val))

def batch_update_cells(ws: gspread.Worksheet, row_index: int, updates: List[Tuple[int, Any]]) -> None:
    """Batch update many cells in ONE Sheets API write request."""
    if not updates:
        return
    payload = []
    for col, val in updates:
        a1 = gspread.utils.rowcol_to_a1(row_index, col)
        payload.append({"range": a1, "values": [["" if val is None else str(val)]]})
    ws.batch_update(payload)


def merge_notes(existing: str, new: str) -> str:
    """Append new notes while keeping existing notes for reference."""
    existing = (existing or "").strip()
    new = (new or "").strip()
    if not existing:
        return new
    if not new:
        return existing
    if new in existing:
        return existing
    return existing + "\n\n---\n\n" + new


# =========================
# YFINANCE + MPLFINANCE (replaces Chart-IMG)
# =========================

def symbol_to_yf_ticker(symbol: str) -> str:
    """
    Converts 'NASDAQ:AAPL' -> 'AAPL'
    Keeps already-Yahoo-style tickers as-is.
    """
    s = symbol.strip()
    if ":" in s:
        return s.split(":")[-1].strip()
    return s

def yf_download_ohlcv(yf_ticker: str) -> pd.DataFrame:
    df = yf.download(
        tickers=yf_ticker,
        period=LOOKBACK_PERIOD,
        interval=INTERVAL,
        auto_adjust=False,
        group_by="column",
        progress=False,
        threads=False,
    )
    if df is None or df.empty:
        raise RuntimeError(f"No Yahoo Finance data returned for ticker={yf_ticker}")

    # If MultiIndex columns exist, flatten them (robust handling)
    if isinstance(df.columns, pd.MultiIndex):
        levels0 = set(map(str, df.columns.get_level_values(0)))
        levels1 = set(map(str, df.columns.get_level_values(-1)))
        ohlcv = {"Open", "High", "Low", "Close", "Volume", "Adj Close"}

        if len(levels0 & ohlcv) >= 3:
            df.columns = df.columns.get_level_values(0)
        elif len(levels1 & ohlcv) >= 3:
            df.columns = df.columns.get_level_values(-1)
        else:
            df.columns = ["_".join(map(str, c)) for c in df.columns.to_list()]

    df = df.rename(columns={c: str(c).strip() for c in df.columns})

    required = ["Open", "High", "Low", "Close", "Volume"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"Missing OHLCV columns {missing}. Got columns: {list(df.columns)}")

    df = df[required].copy()

    # Force numeric
    for col in required:
        s = df[col]
        if not isinstance(s, pd.Series):
            s = s.squeeze()
        df[col] = pd.to_numeric(s, errors="coerce")

    df = df.dropna()
    df.index = pd.to_datetime(df.index)
    return df

def render_chart_png_bytes(ohlcv: pd.DataFrame, title: str = "") -> bytes:
    # Return matplotlib figure so we can save into bytes.
    fig, _axes = mpf.plot(
        ohlcv,
        type="candle",
        style="yahoo",
        volume=True,
        figsize=FIGSIZE,
        title=title or None,
        returnfig=True,
    )

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=DPI, bbox_inches="tight")
    # Avoid memory leak when looping many tickers
    try:
        import matplotlib.pyplot as plt
        plt.close(fig)
    except Exception:
        pass

    return buf.getvalue()

def fetch_chart_png(symbol: str) -> bytes:
    yf_ticker = symbol_to_yf_ticker(symbol)
    df = yf_download_ohlcv(yf_ticker)
    return render_chart_png_bytes(df, title=symbol)



def ohlcv_to_compact_json(df: pd.DataFrame, max_rows: int = 260) -> str:
    """Serialize the last max_rows OHLCV bars into compact JSON to keep payload small."""
    d = df.tail(max_rows).copy()
    # Round prices to reduce token size while keeping precision for pattern logic
    for col in ["Open", "High", "Low", "Close"]:
        d[col] = d[col].round(2)
    # Ensure int volume
    d["Volume"] = d["Volume"].astype("int64")

    rows = []
    for idx, r in d.iterrows():
        rows.append({
            "date": idx.strftime("%Y-%m-%d"),
            "o": float(r["Open"]),
            "h": float(r["High"]),
            "l": float(r["Low"]),
            "c": float(r["Close"]),
            "v": int(r["Volume"]),
        })
    return json.dumps(rows, separators=(",", ":"))


# =========================
# OPENAI
# =========================

import os
import platform
import httpx
from openai import OpenAI

def openai_client() -> OpenAI:
    """Working OpenAI client for both Windows local and Cloud Run Linux."""
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    
    # These were the critical missing pieces!
    org_id = os.getenv("OPENAI_ORG_ID", "org-9EwgB06MNEoPblcvOM37AaQU")
    project_id = os.getenv("OPENAI_PROJECT_ID", "proj_tarlZtrcFzsRr4BsFvw640H7")

    client_args = {
        "api_key": api_key,
        "organization": org_id,
        "project": project_id,
        "max_retries": 3,
    }

    # Apply Cloud Run specific networking logic
    if platform.system() == "Linux":
        cert_path = "/etc/ssl/certs/ca-certificates.crt"
        # Force HTTP/1.1 and explicit SSL verification for GCP stability
        client_args["http_client"] = httpx.Client(
            http2=False, 
            verify=cert_path if os.path.exists(cert_path) else True,
            timeout=httpx.Timeout(180.0, connect=30.0),
            headers={"Connection": "close"}
        )
        print(f"DEBUG: Linux detected. Client configured with Org: {org_id[:8]}...")
    else:
        print(f"DEBUG: {platform.system()} detected. Using default local stack.")

    return OpenAI(**client_args)


def gemini_client():
    """Create a Gemini client (Developer API key flow)."""
    if google_genai is None:
        raise RuntimeError("Gemini SDK not installed. Add 'google-genai' to requirements.txt.")
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not set.")
    return google_genai.Client(api_key=api_key)


def analyze_ohlcv_gemini(symbol: str, ohlcv_df: pd.DataFrame, client) -> Dict[str, Any]:
    """Text-only analysis (no image): send compact OHLCV JSON to Gemini and parse strict JSON."""
    if genai_types is None:
        raise RuntimeError("Gemini SDK not available (google-genai).")
    
    
    prompt = PROMPT_BY_MODE[RUN_MODE]
    ohlcv_json = ohlcv_to_compact_json(ohlcv_df, max_rows=260)

    latest_close = float(ohlcv_df["Close"].iloc[-1]) if not ohlcv_df.empty else 0.0

    data_prompt = (
        f"Symbol: {symbol}\n\n"
        f"You are given DAILY OHLCV bars as a JSON array of objects with keys: date,o,h,l,c,v.\n"
        f"Use ONLY this OHLCV (no images) to detect Bulkowski-style chart patterns and propose a LONG trade plan.\n\n"
        f"Latest close: {latest_close}\n\n"
        f"OHLCV_JSON:\n{ohlcv_json}\n\n"
        f"{prompt}\n\n"
        f"Return STRICT JSON only. No markdown. No prose outside JSON."
    )

    max_attempts = 2
    base_sleep = 1.5
    for attempt in range(1, max_attempts + 1):
        try:
            resp = client.models.generate_content(
                model=GEMINI_MODEL,
                contents=data_prompt,
                config=genai_types.GenerateContentConfig(
                    temperature=0.2,
                    max_output_tokens=8192,
                    response_mime_type="application/json",
                ),
            )
            text = (resp.text or "").strip()
            if not text:
                raise RuntimeError("Gemini returned empty response text.")
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                m = re.search(r"\{.*\}", text, flags=re.DOTALL)
                if not m:
                    raise RuntimeError(f"Gemini output not JSON: {text[:1200]}")
                return json.loads(m.group(0))
            if text.startswith("```"):
                text = text.strip("`")
                text = text.replace("json", "", 1).strip()
            # --- output_gem writeback (Gemini text/vision result) ---
            try:
                gem_decision = normalize_decision(gem_result) if gem_result else "NO_TRADE"
                gem_g = grade_val(gem_result) if gem_result else None
                gem_pat = best_pattern(gem_result) if gem_result else None

                # The update_only_on_change flag lives on watchlist; apply the same rule to output_gem.
                update_only_on_change = False
                wrow = watch_row_by_symbol.get(symbol, [])
                if wrow and "update_only_on_change" in col_map:
                    u_idx = col_map["update_only_on_change"] - 1
                    if 0 <= u_idx < len(wrow):
                        update_only_on_change = parse_bool(wrow[u_idx])

                old_gem_row = gem_row_by_symbol.get(symbol, [])
                old_gem_status = ""
                if old_gem_row:
                    st_col = col_map_gem.get("last_status") or col_map_gem.get("decision")
                    if st_col:
                        s_idx = st_col - 1
                        if 0 <= s_idx < len(old_gem_row):
                            old_gem_status = (old_gem_row[s_idx] or "").strip()

                gem_changed = status_changed(old_gem_status, gem_decision)
                do_update_gem = (not update_only_on_change) or gem_changed

                # Ensure row exists in output_gem
                if symbol not in symbol_to_row_gem:
                    upsert_row_by_symbol(ws_gem, col_map_gem, symbol_to_row_gem, symbol, {"symbol": symbol}, logger=log, cache_row_by_symbol=gem_row_by_symbol)
                    # Refresh maps for this symbol
                    _gem_rows_refresh = ws_gem.get_all_values()
                    gem_row_by_symbol.clear()
                    for _r in _gem_rows_refresh[1:]:
                        if _r and len(_r) > 0:
                            _sym = (_r[0] or "").strip()
                            if _sym:
                                gem_row_by_symbol[_sym] = _r
                    symbol_to_row_gem = build_symbol_row_map(ws_gem)

                grow_idx = symbol_to_row_gem.get(symbol)
                if grow_idx:
                    gem_wb = build_watchlist_writeback(gem_result) if gem_result else {}
                    # Merge notes to keep existing notes for reference
                    old_gem_notes = ""
                    if old_gem_row and "notes" in col_map_gem:
                        n_idx = col_map_gem["notes"] - 1
                        if 0 <= n_idx < len(old_gem_row):
                            old_gem_notes = old_gem_row[n_idx]
                    if isinstance(gem_wb, dict) and "notes" in gem_wb:
                        gem_wb["notes"] = (gem_wb.get("notes") or "")  # WEEKLY: overwrite notes (clear old before writing)

                    gem_status_fields: Dict[str, Any] = {
                        "last_status": gem_decision,
                        "last_grade": gem_g,
                        "last_pattern": gem_pat,
                    }
                    if gem_changed:
                        gem_status_fields["last_change_ts"] = now_str_local()
                    if gem_decision == "TRADE":
                        gem_status_fields["last_signal_ts"] = now_str_local()

                    update_watchlist_row(ws_gem, col_map_gem, grow_idx, gem_wb, gem_status_fields, do_update_gem)

                    # Always refresh last_run on output_gem to mirror watchlist behavior
                    lr_col = col_map_gem.get("last_run")
                    if lr_col:
                        last_run_payload_gem.append({
                            "range": gspread.utils.rowcol_to_a1(grow_idx, lr_col),
                            "values": [[now_str_local()]],
                        })
            except Exception as _gem_wb_e:
                log(f"{symbol}: output_gem writeback error -> {_gem_wb_e}")

            # If vision ran, re-write watchlist with FINAL decision/notes (respecting update_only_on_change)
            if vision:
                try:
                    final_decision = normalize_decision(result)
                    final_g = grade_val(result)
                    final_pat = best_pattern(result)
                    old_row = watch_row_by_symbol.get(symbol, [])
                    old_status = ""
                    if old_row:
                        st_col = col_map.get("last_status") or col_map.get("decision")
                        if st_col:
                            s_idx = st_col - 1
                            if 0 <= s_idx < len(old_row):
                                old_status = (old_row[s_idx] or "").strip()
                    changed2 = status_changed(old_status, final_decision)
                    update_only_on_change = False
                    if old_row and "update_only_on_change" in col_map:
                        u_idx = col_map["update_only_on_change"] - 1
                        if 0 <= u_idx < len(old_row):
                            update_only_on_change = parse_bool(old_row[u_idx])
                    do_update2 = (not update_only_on_change) or changed2

                    final_wb = build_watchlist_writeback(result)
                    old_notes = ""
                    if old_row and "notes" in col_map:
                        n_idx = col_map["notes"] - 1
                        if 0 <= n_idx < len(old_row):
                            old_notes = old_row[n_idx]
                    if isinstance(final_wb, dict) and "notes" in final_wb:
                        final_wb["notes"] = (final_wb.get("notes") or "")  # WEEKLY: overwrite notes (clear old before writing)

                    status_fields2: Dict[str, Any] = {
                        "last_status": final_decision,
                        "last_grade": final_g,
                        "last_pattern": final_pat,
                    }
                    if changed2:
                        status_fields2["last_change_ts"] = now_str_local()
                    if final_decision == "TRADE":
                        status_fields2["last_signal_ts"] = now_str_local()

                    update_watchlist_row(ws_watch, col_map, row_index, final_wb, status_fields2, do_update2)
                except Exception as _vision_wb_e:
                    log(f"{symbol}: watchlist vision writeback error -> {_vision_wb_e}")

        except Exception as e:
            if attempt == max_attempts:
                raise
            sleep_s = base_sleep * (2 ** (attempt - 1)) + random.uniform(0, 0.5)
            print(f"[{now_str_local()}] {symbol}: Gemini error ({type(e).__name__}); retry {attempt}/{max_attempts} in {sleep_s:.1f}s")
            time.sleep(sleep_s)




def analyze_trade_confirmation_gemini_image(
    symbol: str,
    chart_png_bytes: bytes,
    last_close: float,
    openai_result: dict | None,
    gemini_text_result: dict | None,
    gemini_client: "google_genai.Client",
    logger: logging.Logger,
) -> dict:
    # Defensive: callers may accidentally pass the gemini_client() factory instead of an instantiated Client.
    if callable(gemini_client):
        gemini_client = gemini_client()

    """Second-pass confirmation using Gemini with the rendered chart image.

    Only run this when *either* OpenAI or Gemini-text suggested TRADE.
    Returns a small JSON payload with a TRADE/NO_TRADE decision and a short rationale.
    """
    vision_model = os.getenv("GEMINI_VISION_MODEL", os.getenv("GEMINI_MODEL", "gemini-2.0-flash"))
    temperature = float(os.getenv("GEMINI_VISION_TEMPERATURE", os.getenv("GEMINI_TEMPERATURE", "0.2")))

    constraints = {
        "entry_max_gap_pct": ENTRY_MAX_GAP_PCT,
        "stop_max_pct": STOP_MAX_PCT,
        "min_target1_pct": MIN_TARGET1_PCT,
        "min_target2_pct": MIN_TARGET2_PCT,
        "mode": os.getenv("MODE", "daily"),
    }

    def _compact_plan(r: dict | None) -> dict | None:
        if not isinstance(r, dict):
            return None
        ep = r.get("entry_plan")
        if not isinstance(ep, dict):
            ep = {}
        return {
            "decision": ep.get("decision"),
            "entry_price": ep.get("entry_price"),
            "stop_price": ep.get("stop_price"),
            "target_price_1": ep.get("target_price_1"),
            "target_price_2": ep.get("target_price_2"),
            "trigger": ep.get("trigger"),
        }

    payload = {
        "symbol": symbol,
        "last_close": last_close,
        "constraints": constraints,
        "openai_plan": _compact_plan(openai_result),
        "gemini_text_plan": _compact_plan(gemini_text_result),
    }

    prompt = (
        "You are a strict technical-analysis validator. You will be given a candlestick chart image rendered from OHLCV. "
        "Your job: CONFIRM or REJECT a previously-proposed LONG trade setup based ONLY on what you see in the chart.\n\n"
        "Rules (must follow):\n"
        "- Only LONG trades.\n"
        "- If a trade is not actionable near the current price, return NO_TRADE.\n"
        f"- Entry must be within {ENTRY_MAX_GAP_PCT:.4f} (ENTRY_MAX_GAP_PCT) of last_close.\n"
        f"- Stop distance (entry->stop) must be <= {STOP_MAX_PCT:.4f} (STOP_MAX_PCT).\n"
        f"- Target1 must be >= {MIN_TARGET1_PCT:.4f} and Target2 >= {MIN_TARGET2_PCT:.4f} above entry.\n"
        "If the chart does not clearly support the setup/pattern, return NO_TRADE.\n\n"
        "Return STRICT JSON ONLY in this schema:\n"
        "{\n"
        "  \"symbol\": string,\n"
        "  \"decision\": \"TRADE\" | \"NO_TRADE\",\n"
        "  \"confidence_0_100\": number,\n"
        "  \"reason\": string,\n"
        "  \"suggested_entry_plan\": {\n"
        "     \"entry_price\": number|null,\n"
        "     \"stop_price\": number|null,\n"
        "     \"target_price_1\": number|null,\n"
        "     \"target_price_2\": number|null\n"
        "  }\n"
        "}\n\n"
        "Context (JSON):\n"
        + json.dumps(payload, ensure_ascii=False)
    )

    # Build multimodal content for the google-genai SDK (works across versions by using dict fallback).
    raw_text = None
    try:
        content = [
            genai_types.Content(
                role="user",
                parts=[
                    genai_types.Part.from_bytes(data=chart_png_bytes, mime_type="image/png"),
                    genai_types.Part.from_text(text=prompt),
                ],
            )
        ]
        resp = gemini_client.models.generate_content(
            model=vision_model,
            contents=content,
            config=genai_types.GenerateContentConfig(temperature=temperature),
        )
        raw_text = getattr(resp, "text", None)
    except Exception:
        content = [
            {
                "role": "user",
                "parts": [
                    {
                        "inline_data": {
                            "mime_type": "image/png",
                            "data": base64.b64encode(chart_png_bytes).decode("utf-8"),
                        }
                    },
                    {"text": prompt},
                ],
            }
        ]
        resp = gemini_client.models.generate_content(
            model=vision_model,
            contents=content,
            config={"temperature": temperature},
        )
        raw_text = getattr(resp, "text", None)

    raw_text = (raw_text or "").strip()
    if not raw_text:
        raise ValueError("Gemini vision returned empty response")

    raw_text = strip_json_fence(raw_text)
    out = json.loads(raw_text)

    out.setdefault("symbol", symbol)
    out.setdefault("decision", "NO_TRADE")
    out.setdefault("confidence_0_100", 50)
    out.setdefault("reason", "")
    out.setdefault("suggested_entry_plan", {"entry_price": None, "stop_price": None, "target_price_1": None, "target_price_2": None})
    return out

def analyze_ohlcv(symbol: str, ohlcv_df: pd.DataFrame, client: OpenAI) -> Dict[str, Any]:
    """Text-only analysis (no image): send compact OHLCV JSON to the model."""
    prompt = PROMPT_BY_MODE[RUN_MODE]
    ohlcv_json = ohlcv_to_compact_json(ohlcv_df, max_rows=260)

    # Current price proxy (latest close)
    latest_close = float(ohlcv_df["Close"].iloc[-1]) if not ohlcv_df.empty else 0.0

    data_prompt = (
        f"Symbol: {symbol}\n\n"
        f"You are given DAILY OHLCV bars as a JSON array of objects with keys: "
        f"date,o,h,l,c,v (open/high/low/close/volume).\n"
        f"Use this OHLCV data (not an image) to detect Bulkowski-style chart patterns "
        f"and propose a LONG trade plan that follows the constraints.\n\n"
        f"OHLCV_JSON:\n{ohlcv_json}"
    )

    max_attempts = 5
    base_sleep = 1.5

    for attempt in range(1, max_attempts + 1):
        try:
            resp = client.responses.create(
                model=OPENAI_MODEL,
                input=[{
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": data_prompt + "\n\n" + prompt},
                    ],
                }],
                timeout=OPENAI_TIMEOUT_SEC,
            )

            text = (resp.output_text or "").strip()
            if not text:
                raise RuntimeError("OpenAI returned empty output_text.")

            try:
                return json.loads(text)
            except json.JSONDecodeError:
                m = re.search(r"\{.*\}", text, flags=re.DOTALL)
                if not m:
                    raise RuntimeError(f"OpenAI output not JSON:\n{text[:1200]}")
                return json.loads(m.group(0))

        except (APIConnectionError, APITimeoutError, RateLimitError, APIError) as e:
            if attempt == max_attempts:
                raise
            sleep_s = base_sleep * (2 ** (attempt - 1)) + random.uniform(0, 0.5)
            print(
                f"[{now_str_local()}] {symbol}: OpenAI transient error ({type(e).__name__}). "
                f"Retry {attempt}/{max_attempts} in {sleep_s:.1f}s"
            )
            time.sleep(sleep_s)



# =========================
# PHASE-2.5 SELECTOR HELPERS
# =========================

def get_column_as_series(df: pd.DataFrame, col_name: str) -> pd.Series:
    col = df[col_name]
    if isinstance(col, pd.DataFrame):
        col = col.iloc[:, 0]
    return pd.to_numeric(col, errors="coerce").dropna()


def safe_return(close: pd.Series, lookback_sessions: int) -> Optional[float]:
    if close is None or close.empty or len(close) < lookback_sessions + 1:
        return None
    s = close.sort_index().dropna()
    if len(s) < lookback_sessions + 1:
        return None
    end_price = float(s.iloc[-1])
    start_price = float(s.iloc[-lookback_sessions - 1])
    if start_price <= 0:
        return None
    return (end_price / start_price - 1.0) * 100.0


def get_market_benchmark(symbol: str) -> Tuple[str, str]:
    s = str(symbol).strip().upper()
    if s.startswith("NASDAQ:"):
        return "QQQ", "US_NASDAQ"
    if s.startswith("NYSE:"):
        return "SPY", "US_NYSE"
    if s.startswith("ATHEX:") or s.endswith(".AT"):
        return "GD.AT", "GREECE_ATHEX"
    if s.endswith(".DE"):
        return "VGK", "EUROPE_DE"
    if s.endswith(".PA"):
        return "VGK", "EUROPE_FR"
    if s.endswith(".MI"):
        return "VGK", "EUROPE_IT"
    if s.endswith(".L"):
        return "VGK", "UK"
    return "SPY", "GLOBAL_DEFAULT"


def get_sector_benchmark(symbol: str) -> Tuple[str, str]:
    s = str(symbol).strip().upper()
    raw = s.split(":")[-1] if ":" in s else s
    if raw in {"SPY", "QQQ", "IWM", "DIA", "EQQQ.L", "SXR8.DE", "EXXT.DE", "EIMI.L", "XDEM.DE", "IQQH.DE", "SGLN.L", "ARKK"}:
        return get_market_benchmark(symbol)[0], "BROAD_ETF"
    if s.startswith("ATHEX:") or raw.endswith(".AT"):
        return "GD.AT", "GREECE_BROAD"
    if raw.endswith((".DE", ".PA", ".MI", ".L")):
        return "VGK", "EUROPE_BROAD"
    semis = {"NVDA", "AVGO", "LRCX", "TER", "AMD", "ASML", "MU", "KLAC", "AMAT", "SMH", "SOXX"}
    tech = {"AAPL", "MSFT", "ANET", "NET", "IDXX", "EA", "VRSN"}
    financials = {"BAC", "C", "JPM", "SCHW", "FITB", "USB", "CME", "UBS", "BCS", "SMFG", "PFG"}
    industrials = {"ETN", "CAT", "PCAR", "UPS", "LIN", "EMR", "CNI", "RR.L", "WEIR.L"}
    healthcare = {"UNH", "CI", "GSK", "AZN.L", "INCY", "VRTX", "INSM", "IDXX"}
    staples = {"PEP", "CL", "KO", "PG", "COST"}
    materials = {"NEM", "RGLD", "APD"}
    real_estate = {"EQIX"}
    discretionary = {"CASY", "BIDU"}
    if raw in semis: return "SMH", "SEMICONDUCTORS"
    if raw in tech: return "XLK", "TECH"
    if raw in financials: return "XLF", "FINANCIALS"
    if raw in industrials: return "XLI", "INDUSTRIALS"
    if raw in healthcare: return "XLV", "HEALTHCARE"
    if raw in staples: return "XLP", "CONSUMER_STAPLES"
    if raw in materials: return "XLB", "MATERIALS"
    if raw in real_estate: return "XLRE", "REAL_ESTATE"
    if raw in discretionary: return "XLY", "CONSUMER_DISCRETIONARY"
    return get_market_benchmark(symbol)[0], "SECTOR_UNKNOWN_BROAD_FALLBACK"


def classify_asset_class(symbol: str) -> str:
    s = str(symbol).strip().upper()
    if s.startswith("ATHEX:") or s.endswith(".AT"):
        return "ATHEX"
    if s in {"SPY", "QQQ", "IWM", "DIA", "EQQQ.L", "SXR8.DE", "EXXT.DE", "EIMI.L", "XDEM.DE", "IQQH.DE", "SGLN.L", "ARKK"}:
        return "EUROPE_ETF" if s.endswith((".DE", ".L", ".PA", ".MI")) else "US_ETF"
    if s.startswith(("NASDAQ:", "NYSE:")) or (":" not in s and "." not in s):
        return "US_STOCK"
    if s.endswith((".DE", ".PA", ".MI", ".L")):
        return "EUROPE_STOCK"
    return "OTHER"


def score_relative_strength(excess_return_pct: Optional[float]) -> Tuple[float, str]:
    if excess_return_pct is None: return 5.0, "RS_UNKNOWN"
    if excess_return_pct >= 5.0: return 10.0, "RS_VERY_STRONG"
    if excess_return_pct >= 2.0: return 8.0, "RS_STRONG"
    if excess_return_pct >= 0.0: return 6.0, "RS_SLIGHTLY_POSITIVE"
    if excess_return_pct >= -2.0: return 4.0, "RS_WEAK"
    return 2.0, "RS_VERY_WEAK"


def score_sector_strength(sector_excess_return_pct: Optional[float]) -> Tuple[float, str]:
    if sector_excess_return_pct is None: return 5.0, "SECTOR_RS_UNKNOWN"
    if sector_excess_return_pct >= 4.0: return 10.0, "SECTOR_STRONG_LEADER"
    if sector_excess_return_pct >= 1.5: return 8.0, "SECTOR_STRONG"
    if sector_excess_return_pct >= 0.0: return 6.0, "SECTOR_OK"
    if sector_excess_return_pct >= -2.0: return 4.0, "SECTOR_WEAK"
    return 2.0, "SECTOR_VERY_WEAK"


def score_market_regime(regime: str, vix_status: str) -> float:
    base = {"BULL": 9.0, "MIXED": 6.0, "BEAR": 2.5, "UNKNOWN": 5.0, "ERROR": 5.0}.get(str(regime).upper(), 5.0)
    if vix_status == "LOW_VOL_SUPPORTIVE": base += 0.5
    elif vix_status == "HIGH_VOL_RISK_OFF": base -= 1.0
    return max(0.0, min(10.0, base))


def score_volatility_quality(stock_hist: pd.DataFrame) -> Tuple[float, str, Optional[float]]:
    if stock_hist is None or stock_hist.empty or not {"High", "Low", "Close"}.issubset(stock_hist.columns):
        return 5.0, "VOL_UNKNOWN", None
    try:
        h = stock_hist.copy()
        if len(h) < VOLATILITY_LOOKBACK_DAYS + 1:
            return 5.0, "VOL_INSUFFICIENT_DATA", None
        high = get_column_as_series(h, "High")
        low = get_column_as_series(h, "Low")
        close = get_column_as_series(h, "Close")
        prev_close = close.shift(1)
        tr = pd.concat([(high - low).abs(), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
        atr = tr.rolling(VOLATILITY_LOOKBACK_DAYS).mean().iloc[-1]
        last_close = close.iloc[-1]
        if pd.isna(atr) or pd.isna(last_close) or float(last_close) <= 0:
            return 5.0, "VOL_UNKNOWN", None
        atr_pct = float(atr / last_close * 100.0)
        if atr_pct <= 1.2: return 7.0, "VOL_LOW_STABLE", atr_pct
        if atr_pct <= 2.5: return 10.0, "VOL_IDEAL", atr_pct
        if atr_pct <= 4.0: return 6.0, "VOL_ELEVATED", atr_pct
        if atr_pct <= 6.0: return 3.0, "VOL_HIGH_RISK", atr_pct
        return 1.0, "VOL_EXTREME_RISK", atr_pct
    except Exception:
        return 5.0, "VOL_ERROR", None


def score_extension_quality(stock_hist: pd.DataFrame) -> Tuple[float, str, Dict[str, Any]]:
    details = {"dist_from_ema10_pct": None, "dist_from_ema20_pct": None, "gap_1d_pct": None, "asof_close": None}
    if stock_hist is None or stock_hist.empty or "Close" not in stock_hist.columns:
        return 5.0, "EXT_UNKNOWN", details
    try:
        if len(stock_hist) < max(EXTENSION_EMA_SLOW, 3):
            return 5.0, "EXT_INSUFFICIENT_DATA", details
        close = get_column_as_series(stock_hist, "Close").sort_index()
        ema10 = close.ewm(span=EXTENSION_EMA_FAST, adjust=False).mean().iloc[-1]
        ema20 = close.ewm(span=EXTENSION_EMA_SLOW, adjust=False).mean().iloc[-1]
        asof_close = float(close.iloc[-1])
        prev_close = float(close.iloc[-2]) if len(close) >= 2 else asof_close
        dist10 = (asof_close / float(ema10) - 1.0) * 100.0 if float(ema10) > 0 else None
        dist20 = (asof_close / float(ema20) - 1.0) * 100.0 if float(ema20) > 0 else None
        gap = (asof_close / prev_close - 1.0) * 100.0 if prev_close > 0 else None
        details.update({"dist_from_ema10_pct": round(dist10, 4) if dist10 is not None else None, "dist_from_ema20_pct": round(dist20, 4) if dist20 is not None else None, "gap_1d_pct": round(gap, 4) if gap is not None else None, "asof_close": round(asof_close, 4)})
        score = 10.0; reasons = []
        if dist10 is not None:
            if dist10 > EXTENSION_DIST_EMA10_BAD_PCT: score -= 3.0; reasons.append("FAR_ABOVE_EMA10")
            elif dist10 > EXTENSION_DIST_EMA10_WARN_PCT: score -= 1.5; reasons.append("EXTENDED_ABOVE_EMA10")
            elif dist10 < -3.0: score -= 1.0; reasons.append("BELOW_EMA10_WEAK")
        if dist20 is not None and dist20 > EXTENSION_DIST_EMA20_BAD_PCT:
            score -= 2.0; reasons.append("FAR_ABOVE_EMA20")
        if gap is not None:
            if gap > EXTENSION_GAP_BAD_PCT: score -= 2.0; reasons.append("LARGE_GAP_UP")
            elif gap > EXTENSION_GAP_WARN_PCT: score -= 1.0; reasons.append("GAP_UP")
        return max(0.0, min(10.0, score)), ("EXT_GOOD" if not reasons else "EXT_" + "+".join(reasons)), details
    except Exception as e:
        details["extension_error"] = str(e)
        return 5.0, "EXT_ERROR", details


def score_breakout_quality(stock_hist: pd.DataFrame) -> Tuple[float, str, Dict[str, Any]]:
    details = {"breakout_base_range_pct": None, "breakout_close_position_20d": None, "breakout_volume_ratio": None, "breakout_atr_fast_slow_ratio": None}
    required = {"High", "Low", "Close"}
    if stock_hist is None or stock_hist.empty or not required.issubset(set(stock_hist.columns)):
        return 5.0, "BO_UNKNOWN", details
    try:
        h = stock_hist.copy()
        min_needed = max(BREAKOUT_LOOKBACK_DAYS, BREAKOUT_BASE_TIGHT_DAYS, BREAKOUT_ATR_SLOW_DAYS) + 1
        if len(h) < min_needed:
            return 5.0, "BO_INSUFFICIENT_DATA", details
        high = get_column_as_series(h, "High").sort_index(); low = get_column_as_series(h, "Low").sort_index(); close = get_column_as_series(h, "Close").sort_index()
        asof_close = float(close.iloc[-1])
        recent_high_10 = float(high.iloc[-BREAKOUT_BASE_TIGHT_DAYS:].max())
        recent_low_10 = float(low.iloc[-BREAKOUT_BASE_TIGHT_DAYS:].min())
        base_range_pct = ((recent_high_10 / recent_low_10) - 1.0) * 100.0 if recent_low_10 > 0 else None
        high_20 = float(high.iloc[-BREAKOUT_LOOKBACK_DAYS:].max()); low_20 = float(low.iloc[-BREAKOUT_LOOKBACK_DAYS:].min())
        close_position = (asof_close - low_20) / (high_20 - low_20) if high_20 > low_20 else None
        prev_close = close.shift(1)
        tr = pd.concat([(high - low).abs(), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
        atr_fast = tr.rolling(BREAKOUT_ATR_FAST_DAYS).mean().iloc[-1]
        atr_slow = tr.rolling(BREAKOUT_ATR_SLOW_DAYS).mean().iloc[-1]
        atr_ratio = float(atr_fast / atr_slow) if pd.notna(atr_fast) and pd.notna(atr_slow) and float(atr_slow) > 0 else None
        volume_ratio = None
        if "Volume" in h.columns:
            vol = get_column_as_series(h, "Volume").sort_index()
            if len(vol) >= BREAKOUT_VOLUME_LOOKBACK_DAYS + 1:
                last_vol = float(vol.iloc[-1]); avg_vol = float(vol.iloc[-BREAKOUT_VOLUME_LOOKBACK_DAYS-1:-1].mean())
                if avg_vol > 0: volume_ratio = last_vol / avg_vol
        details.update({"breakout_base_range_pct": round(base_range_pct, 4) if base_range_pct is not None else None, "breakout_close_position_20d": round(close_position, 4) if close_position is not None else None, "breakout_volume_ratio": round(volume_ratio, 4) if volume_ratio is not None else None, "breakout_atr_fast_slow_ratio": round(atr_ratio, 4) if atr_ratio is not None else None})
        score = 5.0; reasons = []
        if base_range_pct is not None:
            if base_range_pct <= BREAKOUT_TIGHT_BASE_GOOD_PCT: score += 2.0; reasons.append("TIGHT_BASE")
            elif base_range_pct <= BREAKOUT_TIGHT_BASE_OK_PCT: score += 1.0; reasons.append("OK_BASE")
            elif base_range_pct >= BREAKOUT_EXTREME_RANGE_BAD_PCT: score -= 2.0; reasons.append("WIDE_ERRATIC_BASE")
            else: score -= 0.5; reasons.append("LOOSE_BASE")
        if close_position is not None:
            if close_position >= BREAKOUT_CLOSE_POSITION_GOOD: score += 1.5; reasons.append("CLOSE_NEAR_RANGE_HIGH")
            elif close_position < 0.45: score -= 1.5; reasons.append("CLOSE_WEAK_IN_RANGE")
        if atr_ratio is not None:
            if atr_ratio <= BREAKOUT_ATR_COMPRESSION_GOOD: score += 1.0; reasons.append("ATR_COMPRESSION")
            elif atr_ratio >= 1.25: score -= 1.0; reasons.append("ATR_EXPANSION_NOISY")
        if volume_ratio is not None:
            if volume_ratio >= BREAKOUT_VOLUME_EXPANSION_GOOD: score += 1.0; reasons.append("VOLUME_EXPANSION")
            elif volume_ratio < 0.7: score -= 0.5; reasons.append("LOW_VOLUME")
        return max(0.0, min(10.0, score)), ("BO_" + "+".join(reasons) if reasons else "BO_NEUTRAL"), details
    except Exception as e:
        details["breakout_error"] = str(e)
        return 5.0, "BO_ERROR", details


def score_breadth_regime_proxy(spy_hist: Optional[pd.DataFrame], qqq_hist: Optional[pd.DataFrame], vix_hist: Optional[pd.DataFrame]) -> Tuple[float, str, Dict[str, Any]]:
    details = {"spy_close": None, "spy_ema50": None, "spy_ema200": None, "qqq_close": None, "qqq_ema50": None, "qqq_ema200": None, "breadth_vix": None}
    score = 5.0; reasons = []
    try:
        def eval_index(df: Optional[pd.DataFrame], prefix: str) -> Optional[str]:
            nonlocal score
            if df is None or df.empty or "Close" not in df.columns: return None
            close = get_column_as_series(df, "Close").sort_index()
            if len(close) < BREADTH_EMA_FAST + 1: return None
            ema50 = close.ewm(span=BREADTH_EMA_FAST, adjust=False).mean().iloc[-1]
            ema200 = close.ewm(span=BREADTH_EMA_SLOW, adjust=False).mean().iloc[-1] if len(close) >= BREADTH_EMA_SLOW + 1 else None
            last = float(close.iloc[-1])
            details[f"{prefix}_close"] = round(last, 4); details[f"{prefix}_ema50"] = round(float(ema50), 4)
            details[f"{prefix}_ema200"] = round(float(ema200), 4) if ema200 is not None and pd.notna(ema200) else None
            if ema200 is not None and pd.notna(ema200):
                if last > ema50 and ema50 > ema200: score += 1.25; return f"{prefix.upper()}_STRONG"
                if last < ema50 and ema50 < ema200: score -= 1.25; return f"{prefix.upper()}_WEAK"
            if last > ema50: score += 0.5; return f"{prefix.upper()}_ABOVE_EMA50"
            score -= 0.5; return f"{prefix.upper()}_BELOW_EMA50"
        for label in (eval_index(spy_hist, "spy"), eval_index(qqq_hist, "qqq")):
            if label: reasons.append(label)
        if vix_hist is not None and not vix_hist.empty and "Close" in vix_hist.columns:
            v = get_column_as_series(vix_hist, "Close").sort_index()
            if not v.empty:
                vix = float(v.iloc[-1]); details["breadth_vix"] = round(vix, 2)
                if vix < 18: score += 1.0; reasons.append("VIX_SUPPORTIVE")
                elif vix > 25: score -= 1.5; reasons.append("VIX_RISK_OFF")
                else: reasons.append("VIX_NEUTRAL")
        return max(0.0, min(10.0, score)), ("+".join(reasons) if reasons else "BREADTH_NEUTRAL"), details
    except Exception as e:
        details["breadth_error"] = str(e)
        return 5.0, "BREADTH_ERROR", details


def score_multi_timeframe_alignment(stock_hist: Optional[pd.DataFrame]) -> Tuple[float, str, Dict[str, Any]]:
    details = {"daily_close": None, "daily_ema20": None, "daily_ema50": None, "weekly_close": None, "weekly_ema10": None}
    if stock_hist is None or stock_hist.empty or "Close" not in stock_hist.columns:
        return 5.0, "MTF_UNKNOWN", details
    try:
        close = get_column_as_series(stock_hist, "Close").sort_index()
        if len(close) < MTF_DAILY_EMA_SLOW + 1:
            return 5.0, "MTF_INSUFFICIENT_DATA", details
        daily_close = float(close.iloc[-1]); ema20 = float(close.ewm(span=MTF_DAILY_EMA_FAST, adjust=False).mean().iloc[-1]); ema50 = float(close.ewm(span=MTF_DAILY_EMA_SLOW, adjust=False).mean().iloc[-1])
        details.update({"daily_close": round(daily_close,4), "daily_ema20": round(ema20,4), "daily_ema50": round(ema50,4)})
        score = 5.0; reasons = []
        if daily_close > ema20 > ema50: score += 2.0; reasons.append("DAILY_UPTREND")
        elif daily_close > ema20: score += 0.75; reasons.append("DAILY_RECOVERING")
        elif daily_close < ema20 < ema50: score -= 2.0; reasons.append("DAILY_DOWNTREND")
        else: reasons.append("DAILY_MIXED")
        w = close.resample("W-FRI").last().dropna()
        if len(w) >= MTF_WEEKLY_EMA + 1:
            w_close = float(w.iloc[-1]); w_ema = float(w.ewm(span=MTF_WEEKLY_EMA, adjust=False).mean().iloc[-1])
            details.update({"weekly_close": round(w_close,4), "weekly_ema10": round(w_ema,4)})
            if w_close > w_ema: score += 1.5; reasons.append("WEEKLY_UP")
            else: score -= 1.5; reasons.append("WEEKLY_NOT_UP")
        else:
            reasons.append("WEEKLY_INSUFFICIENT")
        return max(0.0, min(10.0, score)), "+".join(reasons), details
    except Exception as e:
        details["mtf_error"] = str(e)
        return 5.0, "MTF_ERROR", details


def score_accumulation_volume(stock_hist: Optional[pd.DataFrame]) -> Tuple[float, str, Dict[str, Any]]:
    details = {"rel_volume_ratio": None, "accumulation_days": None, "distribution_days": None, "obv_20d_change_pct": None}
    if stock_hist is None or stock_hist.empty or not {"Close", "Volume"}.issubset(stock_hist.columns):
        return 5.0, "ACCUM_UNKNOWN", details
    try:
        if len(stock_hist) < ACCUM_LOOKBACK_DAYS + 2:
            return 5.0, "ACCUM_INSUFFICIENT_DATA", details
        close = get_column_as_series(stock_hist, "Close").sort_index()
        vol = get_column_as_series(stock_hist, "Volume").reindex(close.index).dropna()
        close = close.reindex(vol.index).dropna()
        recent_close = close.iloc[-(ACCUM_LOOKBACK_DAYS+1):]
        recent_vol = vol.iloc[-(ACCUM_LOOKBACK_DAYS+1):]
        avg_vol = float(recent_vol.iloc[:-1].mean()); last_vol = float(recent_vol.iloc[-1])
        rel_vol = last_vol / avg_vol if avg_vol > 0 else None
        pct_changes = recent_close.pct_change() * 100.0
        avg_recent_vol = recent_vol.iloc[:-1].mean()
        accumulation_days = int(((pct_changes > 0) & (recent_vol > avg_recent_vol)).sum())
        distribution_days = int(((pct_changes < -0.5) & (recent_vol > avg_recent_vol)).sum())
        direction = recent_close.diff().fillna(0).apply(lambda x: 1 if x > 0 else (-1 if x < 0 else 0))
        obv = (direction * recent_vol).cumsum()
        obv_change = None
        if len(obv) > 2 and abs(float(obv.iloc[0])) > 0:
            obv_change = (float(obv.iloc[-1]) / abs(float(obv.iloc[0])) - 1.0) * 100.0
        details.update({"rel_volume_ratio": round(rel_vol, 4) if rel_vol is not None else None, "accumulation_days": accumulation_days, "distribution_days": distribution_days, "obv_20d_change_pct": round(obv_change, 4) if obv_change is not None else None})
        score = 5.0; reasons = []
        if rel_vol is not None:
            if rel_vol >= ACCUM_VOLUME_RATIO_GOOD: score += 1.5; reasons.append("REL_VOLUME_EXPANSION")
            elif rel_vol < 0.7: score -= 1.0; reasons.append("LOW_REL_VOLUME")
        if accumulation_days >= distribution_days + 3: score += 1.5; reasons.append("ACCUMULATION_DOMINATES")
        elif distribution_days >= accumulation_days + 3: score -= 1.5; reasons.append("DISTRIBUTION_DOMINATES")
        if obv_change is not None:
            if obv_change > 20: score += 1.0; reasons.append("OBV_UP")
            elif obv_change < -20: score -= 1.0; reasons.append("OBV_DOWN")
        return max(0.0, min(10.0, score)), ("+".join(reasons) if reasons else "ACCUM_NEUTRAL"), details
    except Exception as e:
        details["accum_error"] = str(e)
        return 5.0, "ACCUM_ERROR", details


def download_selector_history(yf_ticker: str, cache: Dict[str, Optional[pd.DataFrame]]) -> Optional[pd.DataFrame]:
    if yf_ticker in cache:
        return cache[yf_ticker]
    try:
        df = yf_download_ohlcv(yf_ticker)
        cache[yf_ticker] = df
        return df
    except Exception:
        cache[yf_ticker] = None
        return None


def compute_phase25_selector(symbol: str, stock_hist: pd.DataFrame, result: Dict[str, Any], market_cache: Dict[str, Optional[pd.DataFrame]]) -> Dict[str, Any]:
    benchmark, market_region = get_market_benchmark(symbol)
    sector_benchmark, sector_group = get_sector_benchmark(symbol)
    asset_class = classify_asset_class(symbol)
    out: Dict[str, Any] = {
        "asset_class": asset_class,
        "market_region": market_region,
        "market_benchmark": benchmark,
        "sector_benchmark": sector_benchmark,
        "sector_group": sector_group,
        "market_regime": "UNKNOWN",
        "market_score": 5.0,
        "relative_strength_score": 5.0,
        "relative_strength_21d_pct": None,
        "sector_score": 5.0,
        "volatility_score": 5.0,
        "extension_score": 5.0,
        "breakout_score": 5.0,
        "breadth_score": 5.0,
        "mtf_score": 5.0,
        "accumulation_score": 5.0,
        "final_score": None,
        "selector_notes": "",
        "reject_reason": "",
    }
    try:
        bench_hist = download_selector_history(benchmark, market_cache)
        sector_hist = download_selector_history(sector_benchmark, market_cache)
        spy_hist = download_selector_history("SPY", market_cache)
        qqq_hist = download_selector_history("QQQ", market_cache)
        vix_hist = download_selector_history(VIX_SYMBOL, market_cache)

        # Market regime on symbol-specific benchmark.
        vix_status = "UNKNOWN"
        if bench_hist is not None and not bench_hist.empty and "Close" in bench_hist.columns:
            bc = get_column_as_series(bench_hist, "Close").sort_index()
            if len(bc) >= REGIME_SLOW_SMA + 1:
                sma21 = bc.rolling(REGIME_FAST_SMA).mean().iloc[-1]
                sma50 = bc.rolling(REGIME_SLOW_SMA).mean().iloc[-1]
                last = float(bc.iloc[-1])
                if last > sma21 > sma50:
                    out["market_regime"] = "BULL"
                elif last < sma21 and sma21 < sma50:
                    out["market_regime"] = "BEAR"
                else:
                    out["market_regime"] = "MIXED"
        if vix_hist is not None and not vix_hist.empty and "Close" in vix_hist.columns:
            vc = get_column_as_series(vix_hist, "Close")
            if not vc.empty:
                vix = float(vc.iloc[-1])
                if vix < 18: vix_status = "LOW_VOL_SUPPORTIVE"
                elif vix <= 25: vix_status = "NORMAL_CAUTION"
                else: vix_status = "HIGH_VOL_RISK_OFF"
        out["market_score"] = score_market_regime(out["market_regime"], vix_status)

        stock_ret = safe_return(get_column_as_series(stock_hist, "Close"), REL_STRENGTH_LOOKBACK_DAYS) if stock_hist is not None and "Close" in stock_hist.columns else None
        bench_ret = safe_return(get_column_as_series(bench_hist, "Close"), REL_STRENGTH_LOOKBACK_DAYS) if bench_hist is not None and "Close" in bench_hist.columns else None
        if stock_ret is not None and bench_ret is not None:
            rs_excess = stock_ret - bench_ret
            out["relative_strength_21d_pct"] = round(rs_excess, 4)
            out["relative_strength_score"], rs_label = score_relative_strength(rs_excess)
        else:
            rs_label = "RS_UNKNOWN"

        if sector_hist is not None and bench_ret is not None and "Close" in sector_hist.columns:
            sector_ret = safe_return(get_column_as_series(sector_hist, "Close"), REL_STRENGTH_LOOKBACK_DAYS)
            if sector_ret is not None:
                out["sector_score"], sector_label = score_sector_strength(sector_ret - bench_ret)
            else:
                sector_label = "SECTOR_RS_UNKNOWN"
        else:
            sector_label = "SECTOR_RS_UNKNOWN"

        vol_score, vol_label, atr_pct = score_volatility_quality(stock_hist)
        out["volatility_score"] = vol_score
        ext_score, ext_label, ext_details = score_extension_quality(stock_hist)
        out["extension_score"] = ext_score
        bo_score, bo_label, bo_details = score_breakout_quality(stock_hist)
        out["breakout_score"] = bo_score
        breadth_score, breadth_label, _breadth_details = score_breadth_regime_proxy(spy_hist, qqq_hist, vix_hist)
        out["breadth_score"] = breadth_score
        mtf_score, mtf_label, _mtf_details = score_multi_timeframe_alignment(stock_hist)
        out["mtf_score"] = mtf_score
        acc_score, acc_label, acc_details = score_accumulation_volume(stock_hist)
        out["accumulation_score"] = acc_score

        ai_grade = float(grade_val(result) or 0)
        out["ai_grade"] = ai_grade
        composite = (
            PHASE25_WEIGHT_AI_GRADE * ai_grade +
            PHASE25_WEIGHT_MARKET * float(out["market_score"]) +
            PHASE25_WEIGHT_REL_STRENGTH * float(out["relative_strength_score"]) +
            PHASE25_WEIGHT_SECTOR * float(out["sector_score"]) +
            PHASE25_WEIGHT_VOLATILITY * float(out["volatility_score"]) +
            PHASE25_WEIGHT_EXTENSION * float(out["extension_score"]) +
            PHASE25_WEIGHT_BREAKOUT * float(out["breakout_score"]) +
            PHASE25_WEIGHT_BREADTH * float(out["breadth_score"]) +
            PHASE25_WEIGHT_MTF * float(out["mtf_score"]) +
            PHASE25_WEIGHT_ACCUMULATION * float(out["accumulation_score"])
        )
        out["final_score"] = round(composite, 4)
        hard = []
        if PHASE25_REJECT_BEAR and out["market_regime"] == "BEAR": hard.append("REJECT_BEAR_REGIME")
        if PHASE25_REJECT_NEGATIVE_RS and out.get("relative_strength_21d_pct") is not None and float(out["relative_strength_21d_pct"]) < 0:
            hard.append("REJECT_NEGATIVE_RELATIVE_STRENGTH")
        out["reject_reason"] = ";".join(hard)
        out["selector_notes"] = (
            f"[SELECTOR] AI={ai_grade:.1f}; Regime={out['market_regime']}({out['market_score']:.1f}); "
            f"RS={out['relative_strength_score']:.1f} {rs_label} ({out.get('relative_strength_21d_pct')}); "
            f"Sector={sector_group}/{sector_label}({out['sector_score']:.1f}); "
            f"Vol={vol_label}({out['volatility_score']:.1f}); Ext={ext_label}({out['extension_score']:.1f}); "
            f"Breakout={bo_label}({out['breakout_score']:.1f}); Breadth={breadth_label}({out['breadth_score']:.1f}); "
            f"MTF={mtf_label}({out['mtf_score']:.1f}); Accum={acc_label}({out['accumulation_score']:.1f}); "
            f"Final={out['final_score']:.2f}"
        )
        return out
    except Exception as e:
        out["reject_reason"] = f"SELECTOR_ERROR:{e}"
        out["selector_notes"] = f"[SELECTOR_ERROR] {e}"
        out["final_score"] = 0.0
        return out


def selector_writeback_fields(features: Dict[str, Any], selected: bool, rank: Any = "", reject_reason: str = "") -> Dict[str, Any]:
    return {
        "ai_grade": features.get("ai_grade", ""),
        "market_regime": features.get("market_regime", ""),
        "market_score": features.get("market_score", ""),
        "relative_strength_score": features.get("relative_strength_score", ""),
        "relative_strength_21d_pct": features.get("relative_strength_21d_pct", ""),
        "sector_group": features.get("sector_group", ""),
        "sector_score": features.get("sector_score", ""),
        "volatility_score": features.get("volatility_score", ""),
        "extension_score": features.get("extension_score", ""),
        "breakout_score": features.get("breakout_score", ""),
        "breadth_score": features.get("breadth_score", ""),
        "mtf_score": features.get("mtf_score", ""),
        "accumulation_score": features.get("accumulation_score", ""),
        "final_score": features.get("final_score", ""),
        "weekly_rank": rank,
        "selected": "YES" if selected else "NO",
        "reject_reason": reject_reason,
        "selector_notes": features.get("selector_notes", ""),
    }


def apply_phase25_weekly_selection(
    ws_watch: gspread.Worksheet,
    col_map: Dict[str, int],
    candidates: List[Dict[str, Any]],
    log_fn,
) -> List[Dict[str, Any]]:
    if not PHASE25_ENABLED or not candidates:
        return []

    eligible = []
    for c in candidates:
        features = c.get("features", {})
        decision = normalize_decision(c.get("result", {}))
        hard_reject = features.get("reject_reason") or ""
        score = to_float(features.get("final_score")) or 0.0
        if decision == "TRADE" and score >= PHASE25_MIN_FINAL_SCORE and not hard_reject:
            eligible.append(c)

    eligible.sort(key=lambda x: float(x.get("features", {}).get("final_score") or 0), reverse=True)
    selected_ids = set()
    counts_asset = {k: 0 for k in PHASE25_ASSET_CLASS_QUOTAS}
    counts_sector: Dict[str, int] = {}
    counts_region: Dict[str, int] = {}

    for c in eligible:
        f = c.get("features", {})
        asset = str(f.get("asset_class", "OTHER"))
        sector = str(f.get("sector_group", "SECTOR_UNKNOWN"))
        region = str(f.get("market_region", "GLOBAL_DEFAULT"))
        asset_quota = PHASE25_ASSET_CLASS_QUOTAS.get(asset, PHASE25_ASSET_CLASS_QUOTAS.get("OTHER", 999))
        region_quota = PHASE25_MARKET_REGION_QUOTAS.get(region, PHASE25_MARKET_REGION_QUOTAS.get("GLOBAL_DEFAULT", 999))
        if counts_asset.get(asset, 0) >= asset_quota:
            continue
        if counts_sector.get(sector, 0) >= PHASE25_MAX_PER_SECTOR_GROUP_PER_WEEK:
            continue
        if counts_region.get(region, 0) >= region_quota:
            continue
        selected_ids.add(id(c))
        counts_asset[asset] = counts_asset.get(asset, 0) + 1
        counts_sector[sector] = counts_sector.get(sector, 0) + 1
        counts_region[region] = counts_region.get(region, 0) + 1
        if len(selected_ids) >= PHASE25_TOP_N_PER_WEEK:
            break

    ranked_selected = [c for c in eligible if id(c) in selected_ids]
    ranked_selected.sort(key=lambda x: float(x.get("features", {}).get("final_score") or 0), reverse=True)
    ranks = {id(c): i + 1 for i, c in enumerate(ranked_selected)}

    output = []
    for c in candidates:
        row_index = c["row_index"]
        result = c["result"]
        features = c["features"]
        was_trade = normalize_decision(result) == "TRADE"
        selected = id(c) in selected_ids
        reject_reason = features.get("reject_reason") or ""
        if was_trade and not selected:
            score = to_float(features.get("final_score")) or 0.0
            if not reject_reason:
                if score < PHASE25_MIN_FINAL_SCORE:
                    reject_reason = f"PHASE25_SCORE_BELOW_MIN:{score:.2f}<{PHASE25_MIN_FINAL_SCORE:.2f}"
                else:
                    reject_reason = "PHASE25_NOT_IN_TOP_N_OR_QUOTA"

        # Final decision override: only selected candidates remain actionable TRADE.
        if PHASE25_APPLY_DECISION_OVERRIDE and was_trade and not selected:
            ep = result.get("entry_plan") or {}
            ep["decision"] = "NO_TRADE"
            result["entry_plan"] = ep
            rn = result.get("risk_notes") if isinstance(result.get("risk_notes"), list) else []
            rn.append(f"[PHASE25_SELECTOR] Not selected: {reject_reason}")
            result["risk_notes"] = rn
            nt = result.get("no_trade_if") if isinstance(result.get("no_trade_if"), list) else []
            nt.append(f"[PHASE25_SELECTOR] {reject_reason}")
            result["no_trade_if"] = nt
        elif selected:
            rn = result.get("risk_notes") if isinstance(result.get("risk_notes"), list) else []
            rn.append(f"[PHASE25_SELECTOR] SELECTED rank={ranks.get(id(c),'')} score={features.get('final_score')}")
            result["risk_notes"] = rn

        selector_note = features.get("selector_notes", "") + f"; Selected={'YES' if selected else 'NO'}; Rank={ranks.get(id(c),'')}; Reject={reject_reason}"
        features = dict(features)
        features["selector_notes"] = selector_note
        rank = ranks.get(id(c), "")
        status_fields = {
            "last_status": normalize_decision(result),
            "last_grade": grade_val(result),
            "last_pattern": best_pattern(result),
        }
        if normalize_decision(result) == "TRADE":
            status_fields["last_signal_ts"] = now_str_local()
        wb = build_watchlist_writeback(result)
        wb["notes"] = merge_notes(wb.get("notes", ""), selector_note)
        wb.update(selector_writeback_fields(features, selected, rank, reject_reason))
        update_watchlist_row(ws_watch, col_map, row_index, wb, status_fields, do_update=True)
        output.append({"symbol": c.get("symbol"), "selected": selected, "rank": rank, "final_score": features.get("final_score"), "reject_reason": reject_reason})

    log_fn(f"Phase-2.5 selector: candidates={len(candidates)} eligible={len(eligible)} selected={len(selected_ids)} top_n={PHASE25_TOP_N_PER_WEEK}")
    return output

# =========================
# POST-FILTERS (enforce your plan)
# =========================

def enforce_plan_filters(result: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    notes: List[str] = []
    entry_plan = result.get("entry_plan") or {}
    decision = str(entry_plan.get("decision", "")).upper().strip()

    entry = to_float(entry_plan.get("entry_price"))
    stop = to_float(entry_plan.get("stop_price"))
    t1 = to_float(entry_plan.get("target_price_1"))
    t2 = to_float(entry_plan.get("target_price_2"))

    if decision == "TRADE":
        if entry is None or stop is None or t1 is None or t2 is None:
            notes.append("Missing prices in entry_plan; forcing NO_TRADE.")
            decision = "NO_TRADE"

    if decision == "TRADE" and entry and stop:
        stop_pct = (entry - stop) / entry
        if stop_pct <= 0:
            notes.append("Stop is not below entry for LONG; forcing NO_TRADE.")
            decision = "NO_TRADE"
        elif stop_pct > MAX_STOP_PCT:
            notes.append(f"Stop distance {stop_pct*100:.2f}% > {MAX_STOP_PCT*100:.2f}% max; forcing NO_TRADE.")
            decision = "NO_TRADE"

    if decision == "TRADE" and entry and t1:
        t1_pct = (t1 - entry) / entry
        if t1_pct < MIN_TARGET1_PCT:
            notes.append(f"Target1 gain {t1_pct*100:.2f}% < {MIN_TARGET1_PCT*100:.2f}% min; forcing NO_TRADE.")
            decision = "NO_TRADE"

    entry_plan["decision"] = "TRADE" if decision == "TRADE" else "NO_TRADE"
    result["entry_plan"] = entry_plan

    if notes:
        rn = list(result.get("risk_notes") or [])
        rn += [f"[PLAN_FILTER] {n}" for n in notes]
        result["risk_notes"] = rn

        nt = list(result.get("no_trade_if") or [])
        nt += [f"[PLAN_FILTER] {n}" for n in notes]
        result["no_trade_if"] = nt

    return result, notes



def enforce_entry_proximity(result: Dict[str, Any], last_close: float) -> Tuple[Dict[str, Any], List[str]]:
    """If decision=TRADE but entry is far from current price, downgrade to FUTURE_SETUP (valid setup, not actionable now)."""
    notes: List[str] = []
    ep = result.get("entry_plan") or {}
    decision = str(ep.get("decision", "")).upper().strip()

    entry = to_float(ep.get("entry_price"))

    if decision == "TRADE" and entry is not None and last_close and last_close > 0:
        gap = abs(entry - last_close) / last_close
        if gap > ENTRY_MAX_GAP_PCT:
            notes.append(
                f"Entry {entry:.2f} is {gap*100:.2f}% away from last close {last_close:.2f}. "
                f"Treat as FUTURE_SETUP; not actionable for this run."
            )
            ep["decision"] = "FUTURE_SETUP"
            result["entry_plan"] = ep

    if notes:
        rn = list(result.get("risk_notes") or [])
        rn += [f"[FUTURE_SETUP] {n}" for n in notes]
        result["risk_notes"] = rn

        nt = list(result.get("no_trade_if") or [])
        nt += [f"[FUTURE_SETUP] {n}" for n in notes]
        result["no_trade_if"] = nt

    return result, notes


# =========================
# EXTRA POLICY: alert threshold + status change logic
# =========================

def best_pattern(result: Dict[str, Any]) -> str:
    pats = result.get("pattern_candidates") or []
    if not pats:
        return ""
    return str((pats[0] or {}).get("name", "")).strip()

def entry_fields(result: Dict[str, Any]) -> Tuple[Any, Any, Any, Any]:
    ep = result.get("entry_plan") or {}
    return ep.get("entry_price", ""), ep.get("stop_price", ""), ep.get("target_price_1", ""), ep.get("target_price_2", "")

def normalize_decision(result: Dict[str, Any]) -> str:
    ep = result.get("entry_plan") or {}
    d = str(ep.get("decision", "")).upper().strip()
    if d in ("TRADE", "NO_TRADE", "FUTURE_SETUP", "ERROR"):
        return d
    return "NO_TRADE"

def grade_val(result: Dict[str, Any]) -> int:
    g = result.get("grade_0_10", 0)
    try:
        return int(float(g))
    except Exception:
        return 0

def passes_user_thresholds(result: Dict[str, Any], min_grade: int, only_alert_if_trade: bool) -> bool:
    d = normalize_decision(result)
    g = grade_val(result)
    if g < min_grade:
        return False
    if only_alert_if_trade and d != "TRADE":
        return False
    return True

def status_changed(old_status: str, new_status: str) -> bool:
    return (old_status or "").strip().upper() != (new_status or "").strip().upper()


# =========================
# WATCHLIST WRITEBACK + HISTORY
# =========================

def build_watchlist_writeback(result: Dict[str, Any]) -> Dict[str, Any]:
    decision = normalize_decision(result)
    grade = result.get("grade_0_10", "")
    entry, stop, t1, t2 = entry_fields(result)

    rn = result.get("risk_notes") or []
    nt = result.get("no_trade_if") or []
    notes_parts: List[str] = []
    if isinstance(rn, list) and rn:
        notes_parts.append("Risk: " + " | ".join(map(str, rn[:6])))
    if decision == "NO_TRADE" and isinstance(nt, list) and nt:
        notes_parts.append("NoTradeIf: " + " | ".join(map(str, nt[:6])))

    return {
        "last_run": now_str_local(),
        "last_close": (round(to_float(result.get("last_close")) or 0.0, 4) if to_float(result.get("last_close")) is not None else ""),
        "decision": decision,
        "grade_0_10": grade,
        "pattern": best_pattern(result),
        "entry": entry,
        "stop": stop,
        "t1": t1,
        "t2": t2,
        "notes": " || ".join(notes_parts),
        "raw_json": json.dumps(result, ensure_ascii=False),
    }

def update_watchlist_row(
    ws_watch: gspread.Worksheet,
    col_map: Dict[str, int],
    row_index: int,
    wb: Dict[str, Any],
    status_fields: Dict[str, Any],
    do_update: bool
) -> None:
    if not do_update:
        return

    updates: List[Tuple[int, Any]] = []
    for k, v in {**wb, **status_fields}.items():
        ck = k.lower()
        if ck in col_map:
            updates.append((col_map[ck], v))
    batch_update_cells(ws_watch, row_index, updates)

def build_history_row(result: Dict[str, Any]) -> List[Any]:
    """Build one history row to later append in a single batch."""
    decision = normalize_decision(result)
    grade = result.get("grade_0_10", "")
    pat = best_pattern(result)
    entry, stop, t1, t2 = entry_fields(result)

    rn = result.get("risk_notes") or []
    nt = result.get("no_trade_if") or []
    notes_parts: List[str] = []
    if isinstance(rn, list) and rn:
        notes_parts.append("Risk: " + " | ".join(map(str, rn[:6])))
    if decision == "NO_TRADE" and isinstance(nt, list) and nt:
        notes_parts.append("NoTradeIf: " + " | ".join(map(str, nt[:6])))

    return [
        now_str_local(),
        RUN_MODE,
        result.get("symbol", ""),
        decision,
        grade,
        pat,
        entry,
        stop,
        t1,
        t2,
        " || ".join(notes_parts),
        json.dumps(result, ensure_ascii=False),
        result.get("phase25", {}).get("final_score", ""),
        result.get("phase25", {}).get("weekly_rank", ""),
        result.get("phase25", {}).get("selected", ""),
        result.get("phase25", {}).get("reject_reason", ""),
        result.get("phase25", {}).get("selector_notes", ""),
    ]


# =========================
# NETWORK PROBE
# =========================



def network_probe():
    print("--- STARTING NETWORK PROBE ---")
    # Test 1: DNS Lookup
    try:
        ip = socket.gethostbyname("api.openai.com")
        print(f"DNS Check: api.openai.com resolved to {ip}")
    except Exception as e:
        print(f"DNS Check FAILED: Could not resolve OpenAI domain. {e}")

    # Test 2: Basic HTTP Reachability
    try:
        r = requests.get("https://api.openai.com/v1/models", timeout=5)
        print(f"HTTP Check: OpenAI reached. Status: {r.status_code}")
    except Exception as e:
        print(f"HTTP Check FAILED: {e}")
    print("--- END NETWORK PROBE ---")

def enforce_entry_breakout_alignment(result: Dict[str, Any], tol_pct: float = ENTRY_BREAKOUT_ALIGN_PCT) -> Tuple[Dict[str, Any], List[str]]:
    """Ensure entry_price is close to the chosen breakout_level (apples-to-apples between providers).

    If the model proposes a TRADE but the entry is far from the breakout level, we force NO_TRADE.
    This prevents 'loose' Gemini plans where entry is materially away from the technical trigger.
    """
    notes: List[str] = []
    if not isinstance(result, dict):
        return result, notes

    entry_plan = result.get("entry_plan") or {}
    if not isinstance(entry_plan, dict):
        return result, notes

    decision = (entry_plan.get("decision") or "").upper()
    if decision != "TRADE":
        return result, notes

    entry = entry_plan.get("entry_price")
    if not isinstance(entry, (int, float)) or entry <= 0:
        return result, notes

    breakout_level = None
    pcs = result.get("pattern_candidates") or []
    if isinstance(pcs, list) and pcs:
        first = pcs[0]
        if isinstance(first, dict):
            breakout_level = first.get("breakout_level")

    if not isinstance(breakout_level, (int, float)) or breakout_level <= 0:
        return result, notes

    gap = abs(float(entry) - float(breakout_level)) / float(breakout_level)
    if gap > float(tol_pct):
        note = f"[ALIGN_FILTER] entry_price ({entry}) is {gap*100:.2f}% away from breakout_level ({breakout_level}); forcing NO_TRADE."
        notes.append(note)

        entry_plan["decision"] = "NO_TRADE"
        entry_plan["trigger"] = (entry_plan.get("trigger") or "") + " | Forced NO_TRADE by ALIGN_FILTER."
        result["entry_plan"] = entry_plan

        rn = result.get("risk_notes")
        if not isinstance(rn, list):
            rn = []
        rn.append(note)
        result["risk_notes"] = rn

        nti = result.get("no_trade_if")
        if not isinstance(nti, list):
            nti = []
        nti.append(note)
        result["no_trade_if"] = nti

    return result, notes


def compute_daily_signal(
    prev_close: Optional[float],
    last_close: Optional[float],
    entry: Optional[float],
    stop: Optional[float],
    t1: Optional[float],
    t2: Optional[float],
    last_status: str = "",
    decision: str = "",
) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Compute DAILY monitoring signal from price crosses.

    Returns: (signal_type, new_status, note)
      signal_type in {"BREAKOUT","T1","T2","STOP"} or None
      new_status mirrors signal_type when present; otherwise keeps last_status.
    """
    if last_close is None:
        return None, (last_status or None), None

    ls = (last_status or "").upper().strip()
    dec = (decision or "").upper().strip()

    # If already terminal, do nothing
    if ls in ("T2", "STOP", "STOP_HIT", "T2_HIT"):
        return None, ls, None

    def crossed_up(level: Optional[float]) -> bool:
        if level is None:
            return False
        if prev_close is None:
            return last_close >= level
        return prev_close < level <= last_close

    def crossed_down(level: Optional[float]) -> bool:
        if level is None:
            return False
        if prev_close is None:
            return last_close <= level
        return prev_close > level >= last_close

    # Stop logic: only meaningful when we consider the setup active-ish
    activeish = dec in ("TRADE", "FUTURE_SETUP") or ls in ("BREAKOUT", "T1")
    if activeish and stop is not None and crossed_down(stop):
        note = f"STOP hit: close {last_close:.2f} crossed below/at stop {stop:.2f}"
        return "STOP", "STOP", note

    # Progression logic by status
    if ls in ("T1", "T1_HIT"):
        if t2 is not None and crossed_up(t2):
            note = f"T2 hit: close {last_close:.2f} crossed above/at t2 {t2:.2f}"
            return "T2", "T2", note
        return None, ls, None

    if ls in ("BREAKOUT", "ENTRY", "ENTRY_HIT"):
        if t2 is not None and crossed_up(t2):
            note = f"T2 hit: close {last_close:.2f} crossed above/at t2 {t2:.2f}"
            return "T2", "T2", note
        if t1 is not None and crossed_up(t1):
            note = f"T1 hit: close {last_close:.2f} crossed above/at t1 {t1:.2f}"
            return "T1", "T1", note
        return None, ls, None

    # Pre-entry: check breakout
    if entry is not None and crossed_up(entry):
        note = f"BREAKOUT: close {last_close:.2f} crossed above/at entry {entry:.2f}"
        return "BREAKOUT", "BREAKOUT", note

    return None, (ls or None), None

def main() -> None:

    network_probe()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logs_dir = OUTPUT_DIR / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    charts_dir = OUTPUT_DIR / "charts" / today_iso()
    if SAVE_CHARTS:
        charts_dir.mkdir(parents=True, exist_ok=True)

    log_path = logs_dir / f"run_{today_iso()}_{RUN_MODE}.log"
    summary_path = OUTPUT_DIR / f"summary_{today_iso()}_{RUN_MODE}.txt"

    def log(msg: str) -> None:
        line = f"[{now_str_local()}] {msg}"
        print(line)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")

    if not SHEET_ID or SHEET_ID.startswith("PUT_YOUR"):
        raise RuntimeError("SHEET_ID not set (env SHEET_ID or edit script).")

    ws_watch, ws_hist, ws_gem = connect_sheets()
    col_map = ensure_headers(ws_watch, WATCHLIST_HEADERS)
    gem_col_map = ensure_headers(ws_gem, GEM_OUTPUT_HEADERS)
    ensure_headers(ws_hist, HISTORY_HEADERS)

    if RUN_MODE == "weekly":
        log("Weekly mode: creating sheet snapshots and clearing previous outputs.")
        prepare_weekly_sheets(ws_watch, ws_gem)
        col_map = ensure_headers(ws_watch, WATCHLIST_HEADERS)
        gem_col_map = ensure_headers(ws_gem, GEM_OUTPUT_HEADERS)

    gem_col_map = ensure_headers(ws_gem, GEM_OUTPUT_HEADERS)
    gem_symbol_to_row = build_symbol_row_map(ws_gem, "symbol")

    rows = ws_watch.get_all_values()
    if len(rows) < 2:
        log("Watchlist has no rows.")
        return


    # Build caches for existing values (notes merging + status-change detection)
    watch_row_by_symbol: Dict[str, List[str]] = {}
    for r in rows[1:]:
        if r and len(r) > 0:
            sym = (r[0] or "").strip()
            if sym:
                watch_row_by_symbol[sym] = r

    gem_rows = ws_gem.get_all_values()
    gem_row_by_symbol: Dict[str, List[str]] = {}
    if gem_rows and len(gem_rows) >= 2:
        for r in gem_rows[1:]:
            if r and len(r) > 0:
                sym = (r[0] or "").strip()
                if sym:
                    gem_row_by_symbol[sym] = r

    # IMPORTANT: Daily mode is a monitoring run (no AI calls).
    openai_cli = openai_client() if (RUN_MODE == "weekly" and ANALYSIS_PROVIDER in ("openai", "both")) else None
    gemini_cli = gemini_client() if (RUN_MODE == "weekly" and ANALYSIS_PROVIDER in ("gemini", "both")) else None

    alerts: List[Dict[str, Any]] = []
    status_changes: List[Dict[str, Any]] = []
    history_buffer: List[List[Any]] = []
    last_run_payload: List[Dict[str, Any]] = []
    last_run_payload_gem: List[Dict[str, Any]] = []
    weekly_selector_candidates: List[Dict[str, Any]] = []
    selector_market_cache: Dict[str, Optional[pd.DataFrame]] = {}

    log(f"Run start: mode={RUN_MODE} symbols_rows={len(rows)-1} model={OPENAI_MODEL}")
    log(f"Run start: mode={RUN_MODE} symbols_rows={len(rows)-1} model={GEMINI_MODEL}")
 
    for r_idx in range(2, len(rows) + 1):
        row = rows[r_idx - 1]

        symbol = get_cell(row, col_map, "symbol")
        enabled = get_cell(row, col_map, "enabled")
        if not symbol or not truthy(enabled, default=False):
            continue

        min_grade = to_int(get_cell(row, col_map, "min_grade"), default=7)
        only_alert_if_trade = truthy(get_cell(row, col_map, "only_alert_if_trade"), default=True)
        update_only_on_change = truthy(get_cell(row, col_map, "update_only_on_change"), default=True)

        old_status = get_cell(row, col_map, "last_status")
        safe_sym = safe_filename(symbol)

        try:
            log(f"{symbol}: downloading OHLCV from Yahoo Finance...")
            yf_ticker = symbol_to_yf_ticker(symbol)
            df = yf_download_ohlcv(yf_ticker)

            # Compute closes for both modes (used for last_close column and entry proximity checks)
            last_close = float(df["Close"].iloc[-1]) if not df.empty else None
            prev_close = float(df["Close"].iloc[-2]) if len(df) >= 2 else None

            # Always refresh last_run/last_close columns (even if update_only_on_change skips other fields)
            if RUN_MODE != "daily":
                if "last_run" in col_map:
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_run"]),
                        "values": [[now_str_local()]],
                    })
                if "last_close" in col_map:
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_close"]),
                        "values": [[last_close if last_close is not None else ""]],
                    })

            if SAVE_CHARTS:
                png = render_chart_png_bytes(df, title=symbol)
                chart_path = charts_dir / f"{safe_sym}.png"
                chart_path.write_bytes(png)

            # Daily mode: no AI. Monitor existing levels (entry/stop/t1/t2) and log signals.
            if RUN_MODE != "weekly":
                # (last_close/prev_close already computed above)

                # Read existing plan from the sheet row (produced by weekly runs)
                decision_cell = get_cell(row, col_map, "decision")
                # DAILY mode should operate on TRADE/NO_TRADE only.
                # If a setup is marked FUTURE_SETUP from a weekly run, we can PROMOTE it to TRADE
                # once price comes within the entry proximity threshold.
                decision_raw = (decision_cell or "").strip().upper()
                decision_daily = "NO_TRADE"
                promoted_to_trade = False
                if decision_raw == "TRADE":
                    decision_daily = "TRADE"
                elif decision_raw == "FUTURE_SETUP":
                    entry_v = to_float(entry_cell)
                    if entry_v is not None and last_close is not None and last_close > 0:
                        gap = abs(entry_v - last_close) / last_close
                        if gap <= ENTRY_MAX_GAP_PCT:
                            decision_daily = "TRADE"
                            promoted_to_trade = True
                # else: any other value treated as NO_TRADE
                entry_cell = to_float(get_cell(row, col_map, "entry"))
                stop_cell = to_float(get_cell(row, col_map, "stop"))
                t1_cell = to_float(get_cell(row, col_map, "t1"))
                t2_cell = to_float(get_cell(row, col_map, "t2"))

                # If we promoted FUTURE_SETUP -> TRADE, write it back so future daily runs treat it as TRADE.

                if promoted_to_trade:

                    try:

                        batch_updates.append((symbol, "decision", "TRADE"))

                        existing_notes = get_cell(row, col_map, "notes") or ""

                        promo_note = f"[DAILY_PROMOTE] Promoted FUTURE_SETUP -> TRADE (gap within {ENTRY_MAX_GAP_PCT*100:.2f}%)."

                        if promo_note not in existing_notes:

                            new_notes = (existing_notes + "\\n" + promo_note).strip() if existing_notes else promo_note

                            batch_updates.append((symbol, "notes", new_notes))

                    except Exception:

                        pass


                signal, new_status, sig_note = compute_daily_signal(
                    prev_close=prev_close,
                    last_close=last_close,
                    entry=entry_cell,
                    stop=stop_cell,
                    t1=t1_cell,
                    t2=t2_cell,
                    last_status=old_status or "",
                    decision=decision_daily,
                )

                # Always refresh last_run
                if "last_run" in col_map:
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_run"]),
                        "values": [[now_str_local()]],
                    })
                # Always refresh last_close
                if "last_close" in col_map:
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_close"]),
                        "values": [[last_close if last_close is not None else ""]],
                    })

                status_fields: Dict[str, Any] = {}
                if signal and new_status:
                    status_fields["last_status"] = new_status
                    status_fields["last_signal_ts"] = now_str_local()
                    if (old_status or "").strip().upper() != new_status.upper():
                        status_fields["last_change_ts"] = now_str_local()
                        status_changes.append({
                            "symbol": symbol,
                            "old": old_status,
                            "new": new_status,
                            "grade": to_int(get_cell(row, col_map, "grade_0_10"), default=None),
                            "pattern": get_cell(row, col_map, "pattern"),
                        })

                    # Append signal note to notes (preserve history)
                    if "notes" in col_map and sig_note:
                        old_notes = get_cell(row, col_map, "notes") or ""
                        new_notes = merge_notes(old_notes, f"[DAILY_SIGNAL] {sig_note}")
                        ws_watch.update(
                            gspread.utils.rowcol_to_a1(r_idx, col_map["notes"]),
                            [[new_notes]],
                        )

                    # Write to DailySignals history tab (lightweight row)
                    hist_row = [
                        now_str_local(),
                        RUN_MODE,
                        symbol,
                        decision_cell,
                        get_cell(row, col_map, "grade_0_10"),
                        get_cell(row, col_map, "pattern"),
                        entry_cell,
                        stop_cell,
                        t1_cell,
                        t2_cell,
                        f"[DAILY_SIGNAL] {sig_note}" if sig_note else "",
                        "",  # raw_json not recomputed in daily mode
                    ]
                    history_buffer.append(hist_row)

                    # Daily alerts list (optional, used in summary)
                    dec_norm = decision_daily
                    if only_alert_if_trade:
                        if dec_norm == "TRADE":
                            alerts.append({
                                "symbol": symbol,
                                "decision": decision_cell,
                                "grade": to_int(get_cell(row, col_map, "grade_0_10"), default=None),
                                "pattern": get_cell(row, col_map, "pattern"),
                                "entry": entry_cell,
                                "stop": stop_cell,
                                "t1": t1_cell,
                                "t2": t2_cell,
                                "signal": signal,
                            })
                    else:
                        alerts.append({
                            "symbol": symbol,
                            "decision": decision_cell,
                            "grade": to_int(get_cell(row, col_map, "grade_0_10"), default=None),
                            "pattern": get_cell(row, col_map, "pattern"),
                            "entry": entry_cell,
                            "stop": stop_cell,
                            "t1": t1_cell,
                            "t2": t2_cell,
                            "signal": signal,
                        })

                    log(f"{symbol}: DAILY signal -> {signal} ({sig_note})")

                    # Persist status fields in Watchlist row
                    update_watchlist_row(ws_watch, col_map, r_idx, {}, status_fields, do_update=True)
                else:
                    log(f"{symbol}: DAILY mode -> no signal (close={last_close})")

                time.sleep(SLEEP_BETWEEN_SYMBOLS_SEC)
                continue


            result = None
            gem_result = None

            if ANALYSIS_PROVIDER in ("openai", "both"):
                log(f"{symbol}: OpenAI analysis")
                result = analyze_ohlcv(symbol, df, openai_cli)
                if isinstance(result, dict):
                    result["last_close"] = last_close
                    result["prev_close"] = prev_close

            if ANALYSIS_PROVIDER in ("gemini", "both"):
                log(f"{symbol}: Gemini analysis")
                gem_result = analyze_ohlcv_gemini(symbol, df, gemini_cli)
                if isinstance(gem_result, dict):
                    gem_result["last_close"] = last_close
                    gem_result["prev_close"] = prev_close
                
            # =========================
            # OPENAI POST-PROCESSING
            # =========================
            if result is not None:
                result, filter_notes = enforce_plan_filters(result)
                result.setdefault("post_filter_notes", []).extend(filter_notes)
                if filter_notes:
                    log(f"{symbol}: plan filters -> {filter_notes}")

                last_close = float(df["Close"].iloc[-1]) if not df.empty else 0.0
                result, proximity_notes = enforce_entry_proximity(result, last_close)
                result.setdefault("post_filter_notes", []).extend(proximity_notes)
                if proximity_notes:
                    log(f"{symbol}: entry proximity -> {proximity_notes}")

                result, align_notes = enforce_entry_breakout_alignment(result)
                result.setdefault("post_filter_notes", []).extend(align_notes)
                if align_notes:
                    log(f"{symbol}: entry/breakout alignment -> {align_notes}")

                decision = normalize_decision(result)
                g = grade_val(result)
                pat = best_pattern(result)

                wb = build_watchlist_writeback(result)

                # Merge notes so previous context is kept
                try:
                    old_notes = ""
                    old_row = watch_row_by_symbol.get(symbol, [])
                    if old_row and "notes" in col_map:
                        n_idx = col_map["notes"] - 1
                        if 0 <= n_idx < len(old_row):
                            old_notes = old_row[n_idx]
                    if isinstance(wb, dict) and "notes" in wb:
                        wb["notes"] = (wb.get("notes") or "")  # WEEKLY: overwrite notes (clear old before writing)
                except Exception:
                    pass

                changed = status_changed(old_status, decision)
                status_fields: Dict[str, Any] = {
                    "last_status": decision,
                    "last_grade": g,
                    "last_pattern": pat,
                }

                if changed:
                    status_fields["last_change_ts"] = now_str_local()
                    status_changes.append({
                        "symbol": symbol,
                        "old": old_status,
                        "new": decision,
                        "grade": g,
                        "pattern": pat,
                    })

                if decision == "TRADE":
                    status_fields["last_signal_ts"] = now_str_local()

                do_update = True
                if update_only_on_change and not changed:
                    do_update = False
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_run"]),
                        "values": [[now_str_local()]],
                    })

                if not do_update:
                    log(f"{symbol}: unchanged ({decision}); skipped writeback")
                else:
                    update_watchlist_row(ws_watch, col_map, r_idx, wb, status_fields, do_update=True)
                    log(f"{symbol}: updated. decision={decision} grade={g} pattern={pat}")

                if passes_user_thresholds(result, min_grade=min_grade, only_alert_if_trade=only_alert_if_trade):
                    entry, stop, t1, t2 = entry_fields(result)
                    alerts.append({
                        "symbol": symbol,
                        "decision": decision,
                        "grade": g,
                        "pattern": pat,
                        "entry": entry,
                        "stop": stop,
                        "t1": t1,
                        "t2": t2,
                    })

                history_buffer.append(build_history_row(result))

            # =========================
            # GEMINI POST-PROCESSING
            # =========================
            if gem_result is not None:
                try:
                    # Unified post-filters (same as OpenAI) to make results apples-to-apples
                    gem_result, _plan_notes = enforce_plan_filters(gem_result)
                    gem_result, _prox_notes = enforce_entry_proximity(gem_result, last_close=last_close)
                    gem_result, _align_notes = enforce_entry_breakout_alignment(gem_result)

                    # Surface filter notes in risk_notes for easier debugging (optional but handy)
                    _all_notes = []
                    _all_notes.extend(_plan_notes or [])
                    _all_notes.extend(_prox_notes or [])
                    _all_notes.extend(_align_notes or [])
                    if _all_notes:
                        rn = gem_result.get("risk_notes")
                        if not isinstance(rn, list):
                            rn = []
                        rn.extend(_all_notes)
                        gem_result["risk_notes"] = rn

                except Exception as _pp_e:
                    log(f"{symbol}: Gemini post-processing error -> {_pp_e}")

                # ---- GEMINI VISION CONFIRMATION (image-based) ----
                # Run ONLY if either model suggested TRADE (after unified post-filters).
                vision = None
                try:
                    openai_dec = ((result or {}).get("entry_plan") or {}).get("decision")
                    gemini_text_dec = ((gem_result or {}).get("entry_plan") or {}).get("decision")
                    if str(openai_dec).upper() == "TRADE" or str(gemini_text_dec).upper() == "TRADE":
                        log(f"{symbol}: Gemini vision confirmation (chart image)")
                        chart_png = render_chart_png_bytes(df, symbol)
                        vision = analyze_trade_confirmation_gemini_image(
                            symbol=symbol,
                            chart_png_bytes=chart_png,
                            last_close=float(last_close),
                            openai_result=result,
                            gemini_text_result=gem_result,
                            gemini_client=gemini_cli,
                            logger=log,
                        )
                        v_dec = str(vision.get("decision", "NO_TRADE")).upper()
                        # Attach vision payload for audit/debugging
                        if isinstance(gem_result, dict):
                            gem_result["vision_confirmation"] = vision
                        if isinstance(result, dict):
                            result["vision_confirmation"] = vision

                        if v_dec != "TRADE":
                            # Downgrade both model decisions to NO_TRADE (keep original numbers in notes)
                            for _r in (result, gem_result):
                                if isinstance(_r, dict):
                                    ep = _r.get("entry_plan")
                                    if isinstance(ep, dict):
                                        ep["decision"] = "FUTURE_SETUP"
                                    rn = _r.get("risk_notes")
                                    if rn is None:
                                        rn = []
                                        _r["risk_notes"] = rn
                                    if isinstance(rn, list):
                                        rn.append(f"VISION_REJECTED: {vision.get('reason','').strip()[:180]}")
                            log(f"{symbol}: Vision rejected trade -> NO_TRADE")
                        else:
                            for _r in (result, gem_result):
                                if isinstance(_r, dict):
                                    rn = _r.get("risk_notes")
                                    if rn is None:
                                        rn = []
                                        _r["risk_notes"] = rn
                                    if isinstance(rn, list):
                                        rn.append(f"VISION_CONFIRMED ({vision.get('confidence_0_100', '')})")
                except Exception as _vision_e:
                    log(f"{symbol}: Gemini vision confirmation error -> {_vision_e}")

                # =========================
                # GEMINI WRITEBACK (output_gem) + FINAL WATCHLIST SYNC
                # =========================
                try:
                    # Final (post-filter, post-vision) Gemini decision snapshot
                    g_decision = normalize_decision(gem_result)
                    g_grade = grade_val(gem_result)
                    g_pat = best_pattern(gem_result)
                    g_entry, g_stop, g_t1, g_t2 = entry_fields(gem_result)
                    g_time_stop = ((gem_result.get("entry_plan") or {}).get("time_stop_days")) if isinstance(gem_result, dict) else None

                    # Merge notes (keep existing notes for reference)
                    g_old_row = gem_row_by_symbol.get(symbol, [])
                    g_old_notes = ""
                    if g_old_row and "notes" in gem_col_map:
                        _ni = gem_col_map["notes"] - 1
                        if 0 <= _ni < len(g_old_row):
                            g_old_notes = g_old_row[_ni] or ""

                    g_wb = build_watchlist_writeback(gem_result)  # reuse existing helper to format notes
                    g_new_notes = g_wb.get("notes") if isinstance(g_wb, dict) else ""
                    g_notes = (g_new_notes or "")  # WEEKLY: overwrite notes (clear old before writing)

                    # Respect update_only_on_change (same flag as watchlist)
                    g_old_dec = ""
                    if g_old_row and "decision" in gem_col_map:
                        _di = gem_col_map["decision"] - 1
                        if 0 <= _di < len(g_old_row):
                            g_old_dec = (g_old_row[_di] or "").strip().upper()

                    g_changed = (g_old_dec != (g_decision or "").strip().upper())

                    if update_only_on_change and not g_changed:
                        log(f"{symbol}: output_gem unchanged ({g_decision}); skipped writeback")
                    else:
                        row_dict = {
                            "symbol": symbol,
                            "last_run": now_str_local(),
                            "decision": g_decision,
                            "grade_0_10": g_grade,
                            "pattern": g_pat,
                            "entry": g_entry,
                            "stop": g_stop,
                            "t1": g_t1,
                            "t2": g_t2,
                            "notes": g_notes,
                            "raw_json": json.dumps(gem_result, ensure_ascii=False) if isinstance(gem_result, dict) else "",
                        }
                        upsert_row_by_symbol(
                            ws=ws_gem,
                            col_map=gem_col_map,
                            symbol_to_row=gem_symbol_to_row,
                            symbol=symbol,
                            values_by_col=row_dict,
                        )

                    # Watchlist must reflect FINAL decision (post-vision).
                    # If OpenAI ran, we update from its (possibly vision-adjusted) result; otherwise from Gemini.
                    wl_src = result if isinstance(result, dict) else gem_result
                    wl_decision = normalize_decision(wl_src)
                    wl_grade = grade_val(wl_src)
                    wl_pat = best_pattern(wl_src)

                    wl_wb = build_watchlist_writeback(wl_src)

                    # Merge notes with existing watchlist notes
                    try:
                        wl_old_notes = ""
                        old_row = watch_row_by_symbol.get(symbol, [])
                        if old_row and "notes" in col_map:
                            n_idx = col_map["notes"] - 1
                            if 0 <= n_idx < len(old_row):
                                wl_old_notes = old_row[n_idx] or ""
                        if isinstance(wl_wb, dict) and "notes" in wl_wb:
                            wl_wb["notes"] = (wl_wb.get("notes") or "")  # WEEKLY: overwrite notes (clear old before writing)
                    except Exception:
                        pass

                    wl_status_fields = {
                        "last_status": wl_decision,
                        "last_grade": wl_grade,
                        "last_pattern": wl_pat,
                    }

                    wl_changed = status_changed(old_status, wl_decision)
                    if wl_changed:
                        wl_status_fields["last_change_ts"] = now_str_local()
                    if wl_decision == "TRADE":
                        wl_status_fields["last_signal_ts"] = now_str_local()

                    # Mirror watchlist behavior: if update_only_on_change and no change, skip.
                    if update_only_on_change and not wl_changed:
                        log(f"{symbol}: watchlist unchanged ({wl_decision}); skipped writeback (final sync)")
                    else:
                        update_watchlist_row(ws_watch, col_map, r_idx, wl_wb, wl_status_fields, do_update=True)
                        log(f"{symbol}: watchlist updated (final sync). decision={wl_decision} grade={wl_grade} pattern={wl_pat}")

                except Exception as _wb_e:
                    log(f"{symbol}: gem/writeback sync error -> {_wb_e}")

            # Phase-2.5 selector feature calculation. This runs after AI/provider post-processing,
            # but before final Top-N selection, which is applied after all symbols are processed.
            if RUN_MODE == "weekly" and PHASE25_ENABLED:
                wl_src_for_selector = result if isinstance(result, dict) else gem_result
                if isinstance(wl_src_for_selector, dict):
                    try:
                        features = compute_phase25_selector(symbol, df, wl_src_for_selector, selector_market_cache)
                        wl_src_for_selector["phase25"] = dict(features)
                        weekly_selector_candidates.append({
                            "symbol": symbol,
                            "row_index": r_idx,
                            "result": wl_src_for_selector,
                            "features": features,
                        })
                        log(f"{symbol}: Phase-2.5 score={features.get('final_score')} regime={features.get('market_regime')} sector={features.get('sector_group')}")
                    except Exception as _sel_e:
                        log(f"{symbol}: Phase-2.5 selector error -> {_sel_e}")

        except Exception as e:
            err = f"{type(e).__name__}: {e}"
            log(f"{symbol}: ERROR -> {err}")

            fail_updates = {
                "last_run": now_str_local(),
                "decision": "ERROR",
                "notes": err,
                "last_status": "ERROR",
                "last_change_ts": now_str_local(),
            }

            update_watchlist_row(ws_watch, col_map, r_idx, fail_updates, {}, do_update=True)

        time.sleep(SLEEP_BETWEEN_SYMBOLS_SEC)

    if RUN_MODE == "weekly" and PHASE25_ENABLED:
        selector_summary = apply_phase25_weekly_selection(ws_watch, col_map, weekly_selector_candidates, log)
        if selector_summary:
            selected_count = sum(1 for x in selector_summary if x.get("selected"))
            log(f"Phase-2.5 final selection completed: selected={selected_count}/{len(selector_summary)}")

    if last_run_payload:
        ws_watch.batch_update(last_run_payload)

    if last_run_payload_gem:
        ws_gem.batch_update(last_run_payload_gem)

    if history_buffer:
        ws_hist.append_rows(history_buffer, value_input_option="RAW")

    alerts_sorted = sorted(alerts, key=lambda x: (x["decision"] != "TRADE", -int(x["grade"])))

    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"Run summary ({RUN_MODE}) @ {now_str_local()}\n")
        f.write(f"Lookback: {LOOKBACK_PERIOD}  Interval: {INTERVAL}\n")
        f.write(f"Alerts: {len(alerts_sorted)}\n\n")

        for a in alerts_sorted[:25]:
            f.write(
                f"- {a['symbol']} | {a['decision']} | grade={a['grade']} | {a['pattern']} "
                f"| entry={a['entry']} stop={a['stop']} t1={a['t1']} t2={a['t2']}\n"
            )

        f.write("\nStatus changes:\n")
        if not status_changes:
            f.write("- none\n")
        else:
            for sc in status_changes:
                f.write(
                    f"- {sc['symbol']}: {sc['old']} -> {sc['new']} "
                    f"(grade={sc['grade']} pattern={sc['pattern']})\n"
                )

    log(f"Run complete. Summary written to: {summary_path}")



if __name__ == "__main__":
    main()