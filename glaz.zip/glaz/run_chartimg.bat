@echo off
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0chartimg_test.ps1"
pause
