import math
import time
from datetime import timedelta
from typing import Optional, Dict, Any, Tuple, List

import pandas as pd
import yfinance as yf

# ==================================================
# CONFIG
# ==================================================
INPUT_FILE = "trade_evaluation.csv"
OUTPUT_TRADES_FILE = "exit_rule_trade_results.csv"
OUTPUT_SUMMARY_FILE = "exit_rule_summary.csv"

INITIAL_CAPITAL_PER_TRADE = 1000.0
MAX_HOLDING_SESSIONS = 30          # approx. one trading month / 6 weeks calendar
HARD_STOP_PCT = -2.0               # current system stop
SLEEP_SECONDS = 0.25

# Fallback targets if your CSV does not contain t1/t2 columns
FALLBACK_T1_PCT = 5.0
FALLBACK_T2_PCT = 10.0

# Optional: skip symbols with no Yahoo data
VERBOSE = True


# ==================================================
# SYMBOL / DATA HELPERS
# ==================================================
def normalize_symbol(symbol: str) -> str:
    symbol = str(symbol).strip()
    if symbol.startswith("NASDAQ:"):
        return symbol.replace("NASDAQ:", "")
    if symbol.startswith("NYSE:"):
        return symbol.replace("NYSE:", "")
    if symbol.startswith("ATHEX:"):
        return symbol.replace("ATHEX:", "")
    return symbol


def flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df


def get_column_as_series(df: pd.DataFrame, col_name: str) -> pd.Series:
    col = df[col_name]
    if isinstance(col, pd.DataFrame):
        col = col.iloc[:, 0]
    return col.dropna()


def to_float(value) -> Optional[float]:
    if value is None or pd.isna(value):
        return None
    s = str(value).strip()
    if not s:
        return None
    try:
        return float(s.replace(",", "."))
    except Exception:
        return None


def first_valid_price(row: pd.Series, preferred_cols: List[str]) -> Optional[float]:
    # exact and case-insensitive column matching
    col_map = {str(c).strip().lower(): c for c in row.index}
    for wanted in preferred_cols:
        key = wanted.strip().lower()
        if key in col_map:
            val = to_float(row[col_map[key]])
            if val is not None:
                return val
    return None


def download_history(symbol: str, start, end) -> pd.DataFrame:
    hist = yf.download(
        symbol,
        start=start.strftime("%Y-%m-%d"),
        end=end.strftime("%Y-%m-%d"),
        progress=False,
        auto_adjust=False,
        group_by="column",
        threads=False,
    )
    if hist is None or hist.empty:
        return pd.DataFrame()
    hist = flatten_columns(hist)
    hist = hist.dropna(how="all")
    return hist


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    close = get_column_as_series(out, "Close")

    out["EMA5"] = close.ewm(span=5, adjust=False).mean()
    out["EMA10"] = close.ewm(span=10, adjust=False).mean()
    out["SMA5"] = close.rolling(5).mean()
    out["SMA10"] = close.rolling(10).mean()
    out["RET1"] = close.pct_change()

    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(14).mean()
    avg_loss = loss.rolling(14).mean()
    rs = avg_gain / avg_loss.replace(0, math.nan)
    out["RSI14"] = 100 - (100 / (1 + rs))
    out["RSI14_PREV"] = out["RSI14"].shift(1)

    return out


def pct(price: float, entry: float) -> float:
    return (price / entry - 1.0) * 100.0


def get_entry_price_from_row(row: pd.Series) -> Optional[float]:
    return first_valid_price(row, [
        "entry_price", "entry price", "ENTRY PRICE", "entry", "Entry", "ENTRY"
    ])


def get_t1_from_row(row: pd.Series, entry: float) -> Tuple[float, str]:
    explicit = first_valid_price(row, ["t1", "T1", "target1", "target_1", "target price 1"])
    if explicit is not None:
        return explicit, "CSV_T1"
    return entry * (1 + FALLBACK_T1_PCT / 100.0), f"FALLBACK_{FALLBACK_T1_PCT:.0f}PCT"


def get_t2_from_row(row: pd.Series, entry: float) -> Tuple[float, str]:
    explicit = first_valid_price(row, ["t2", "T2", "target2", "target_2", "target price 2"])
    if explicit is not None:
        return explicit, "CSV_T2"
    return entry * (1 + FALLBACK_T2_PCT / 100.0), f"FALLBACK_{FALLBACK_T2_PCT:.0f}PCT"


def get_stop_from_row(row: pd.Series, entry: float) -> Tuple[float, str]:
    explicit = first_valid_price(row, ["stop", "STOP", "stop_price", "stop price"])
    if explicit is not None:
        return explicit, "CSV_STOP"
    return entry * (1 + HARD_STOP_PCT / 100.0), f"FALLBACK_{HARD_STOP_PCT:.1f}PCT"


def prepare_trade_window(hist: pd.DataFrame, entry_date) -> pd.DataFrame:
    entry_date = pd.to_datetime(entry_date)
    window = hist[hist.index >= entry_date].copy()
    return window.iloc[:MAX_HOLDING_SESSIONS]


def infer_entry_price(row: pd.Series, window: pd.DataFrame) -> Tuple[Optional[float], str]:
    explicit = get_entry_price_from_row(row)
    if explicit is not None:
        return explicit, "CSV_ENTRY"

    # Fallback: use the first available close on/after entry_date.
    # This is a proxy, but it allows exit-rule testing from your compact CSV.
    if window.empty or "Close" not in window.columns:
        return None, "NO_ENTRY_AND_NO_PRICE_DATA"

    close = get_column_as_series(window, "Close")
    if close.empty:
        return None, "NO_ENTRY_AND_EMPTY_CLOSE"

    return float(close.iloc[0]), "INFERRED_ENTRY_FROM_ENTRY_DAY_CLOSE"


# ==================================================
# EXIT RULES
# Every rule returns dict with pnl_pct, exit_date, exit_reason.
# ==================================================
def result(rule, exit_date, exit_price, exit_reason, pnl_pct, extra=None):
    d = {
        "rule": rule,
        "exit_date_sim": exit_date,
        "exit_price_sim": round(exit_price, 4) if isinstance(exit_price, (float, int)) else exit_price,
        "exit_reason": exit_reason,
        "pnl_pct_sim": round(float(pnl_pct), 4),
        "profit_eur_per_1000": round(INITIAL_CAPITAL_PER_TRADE * float(pnl_pct) / 100.0, 2),
    }
    if extra:
        d.update(extra)
    return d


def actual_input_rule(row: pd.Series):
    p = pd.to_numeric(row.get("pnl_pct", None), errors="coerce")
    if pd.isna(p):
        return None
    return result("ACTUAL_INPUT", row.get("exit_date", ""), None, "INPUT_PNL", float(p))


def hard_stop_or_max_hold(window, entry, stop):
    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        if low <= stop:
            return result("HARD_STOP_OR_MAX_HOLD", dt.date(), stop, "HARD_STOP", pct(stop, entry))
    last_close = float(window.iloc[-1]["Close"])
    return result("HARD_STOP_OR_MAX_HOLD", window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def full_exit_at_target(window, entry, stop, target, name):
    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        if low <= stop:
            return result(name, dt.date(), stop, "HARD_STOP", pct(stop, entry))
        if high >= target:
            return result(name, dt.date(), target, "TARGET_FULL_EXIT", pct(target, entry))
    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def full_exit_at_pct_target(window, entry, stop, target_pct):
    target = entry * (1 + target_pct / 100.0)
    return full_exit_at_target(window, entry, stop, target, f"FULL_EXIT_AT_{target_pct:.0f}PCT")


def ema_exit_after_profit(window, entry, stop, min_profit_pct=3.0, ema_col="EMA5"):
    highest_close = entry
    activated = False
    name = f"{ema_col}_EXIT_AFTER_{min_profit_pct:.0f}PCT"

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        close = float(bar["Close"])
        ema = float(bar[ema_col]) if ema_col in bar and pd.notna(bar[ema_col]) else None

        if low <= stop:
            return result(name, dt.date(), stop, "HARD_STOP", pct(stop, entry))

        highest_close = max(highest_close, close)
        if pct(highest_close, entry) >= min_profit_pct:
            activated = True

        if activated and ema is not None and close < ema:
            return result(name, dt.date(), close, f"CLOSE_BELOW_{ema_col}", pct(close, entry))

    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def trailing_stop_after_profit(window, entry, stop, activation_pct=3.0, trail_pct=2.0):
    name = f"TRAIL_{trail_pct:.1f}PCT_AFTER_{activation_pct:.0f}PCT"
    highest_high = entry
    active_stop = stop
    activated = False

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        close = float(bar["Close"])

        highest_high = max(highest_high, high)

        if pct(highest_high, entry) >= activation_pct:
            activated = True
            active_stop = max(active_stop, highest_high * (1 - trail_pct / 100.0))

        if low <= active_stop:
            reason = "TRAIL_STOP" if activated else "HARD_STOP"
            return result(name, dt.date(), active_stop, reason, pct(active_stop, entry))

    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def time_progress_exit(window, entry, stop):
    name = "TIME_PROGRESS_EXIT"
    for i, (dt, bar) in enumerate(window.iterrows(), start=1):
        low = float(bar["Low"])
        close = float(bar["Close"])
        current_pnl = pct(close, entry)

        if low <= stop:
            return result(name, dt.date(), stop, "HARD_STOP", pct(stop, entry))

        if i >= 10 and current_pnl < 1.5:
            return result(name, dt.date(), close, "DAY10_WEAK_PROGRESS", current_pnl)
        if i >= 15 and current_pnl < 2.5:
            return result(name, dt.date(), close, "DAY15_WEAK_PROGRESS", current_pnl)
        if i >= 20 and current_pnl < 3.0:
            return result(name, dt.date(), close, "DAY20_WEAK_PROGRESS", current_pnl)

    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry))


def exit_score_dynamic(window, entry, stop):
    name = "EXIT_SCORE_DYNAMIC"
    prev_close = None
    red_streak = 0
    highest_close = entry

    for i, (dt, bar) in enumerate(window.iterrows(), start=1):
        low = float(bar["Low"])
        close = float(bar["Close"])
        ema5 = float(bar["EMA5"]) if pd.notna(bar.get("EMA5")) else None
        rsi = float(bar["RSI14"]) if pd.notna(bar.get("RSI14")) else None
        rsi_prev = float(bar["RSI14_PREV"]) if pd.notna(bar.get("RSI14_PREV")) else None

        if low <= stop:
            return result(name, dt.date(), stop, "HARD_STOP", pct(stop, entry), {"exit_score": None})

        highest_close = max(highest_close, close)

        if prev_close is not None and close < prev_close:
            red_streak += 1
        else:
            red_streak = 0
        prev_close = close

        current_pnl = pct(close, entry)
        giveback_from_high = pct(close, highest_close) if highest_close > 0 else 0

        score = 0
        if current_pnl >= 2.0 and ema5 is not None and close < ema5:
            score += 1
        if red_streak >= 2 and current_pnl > 1.0:
            score += 1
        if rsi is not None and rsi_prev is not None and rsi_prev > 65 and rsi < rsi_prev:
            score += 1
        if current_pnl >= 3.0 and giveback_from_high <= -2.0:
            score += 1
        if i >= 20:
            score += 1

        if score >= 3:
            return result(name, dt.date(), close, "EXIT_SCORE_GE_3", current_pnl, {"exit_score": score})

    last_close = float(window.iloc[-1]["Close"])
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", pct(last_close, entry), {"exit_score": None})


def half_t1_half_ema5_runner(window, entry, stop, t1):
    name = "HALF_T1_HALF_EMA5_RUNNER"
    remaining = 1.0
    realized_pct = 0.0
    t1_taken = False
    active_stop = stop

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        close = float(bar["Close"])
        ema5 = float(bar["EMA5"]) if pd.notna(bar.get("EMA5")) else None

        if low <= active_stop:
            realized_pct += remaining * pct(active_stop, entry)
            return result(name, dt.date(), active_stop, "STOP_REMAINDER", realized_pct, {"partial_model": "YES"})

        if not t1_taken and high >= t1:
            realized_pct += 0.5 * pct(t1, entry)
            remaining = 0.5
            t1_taken = True
            active_stop = max(active_stop, entry)  # breakeven for runner

        if t1_taken and ema5 is not None and close < ema5:
            realized_pct += remaining * pct(close, entry)
            return result(name, dt.date(), close, "EMA5_EXIT_AFTER_T1", realized_pct, {"partial_model": "YES"})

    last_close = float(window.iloc[-1]["Close"])
    realized_pct += remaining * pct(last_close, entry)
    return result(name, window.index[-1].date(), last_close, "MAX_HOLD_EXIT", realized_pct, {"partial_model": "YES"})


def run_rules(row, window, entry, stop, t1, t2):
    rules = []

    actual = actual_input_rule(row)
    if actual:
        rules.append(actual)

    rules.extend([
        hard_stop_or_max_hold(window, entry, stop),
        full_exit_at_target(window, entry, stop, t1, "FULL_EXIT_AT_T1"),
        full_exit_at_target(window, entry, stop, t2, "FULL_EXIT_AT_T2"),
        full_exit_at_pct_target(window, entry, stop, 3.0),
        full_exit_at_pct_target(window, entry, stop, 5.0),
        full_exit_at_pct_target(window, entry, stop, 8.0),
        full_exit_at_pct_target(window, entry, stop, 10.0),
        ema_exit_after_profit(window, entry, stop, 3.0, "EMA5"),
        ema_exit_after_profit(window, entry, stop, 5.0, "EMA5"),
        ema_exit_after_profit(window, entry, stop, 3.0, "EMA10"),
        trailing_stop_after_profit(window, entry, stop, 3.0, 2.0),
        trailing_stop_after_profit(window, entry, stop, 5.0, 2.5),
        trailing_stop_after_profit(window, entry, stop, 5.0, 3.0),
        time_progress_exit(window, entry, stop),
        exit_score_dynamic(window, entry, stop),
        half_t1_half_ema5_runner(window, entry, stop, t1),
    ])
    return rules


# ==================================================
# MAIN
# ==================================================
def main():
    df = pd.read_csv(INPUT_FILE)
    df["status"] = df["status"].astype(str).str.upper().str.strip()
    df["symbol"] = df["symbol"].astype(str).str.strip()

    executed = df[~df["status"].isin(["NOT_TRIGGERED", "NO_TRADE", "FUTURE_SETUP"])].copy()

    print(f"Loaded trades: {len(df)}")
    print(f"Executed trades to simulate: {len(executed)}")

    all_results = []
    skipped = []

    for _, row in executed.iterrows():
        symbol = row["symbol"]
        yf_symbol = normalize_symbol(symbol)
        entry_date = pd.to_datetime(row.get("entry_date", None), errors="coerce")

        if pd.isna(entry_date):
            print(f"Skipping {symbol}: missing entry_date")
            skipped.append({"symbol": symbol, "reason": "missing entry_date"})
            continue

        # Fetch enough after entry to simulate max holding period; add buffer for non-trading days.
        start = entry_date - timedelta(days=5)
        end = entry_date + timedelta(days=MAX_HOLDING_SESSIONS + 20)

        if VERBOSE:
            print(f"Fetching {symbol} -> {yf_symbol} from {start.date()} to {end.date()}")

        hist = download_history(yf_symbol, start, end)
        if hist.empty or not {"Open", "High", "Low", "Close"}.issubset(set(hist.columns)):
            print(f"Skipping {symbol}: no usable OHLC data")
            skipped.append({"symbol": symbol, "reason": "no usable OHLC data"})
            continue

        hist = add_indicators(hist)
        window = prepare_trade_window(hist, entry_date)

        if window.empty:
            print(f"Skipping {symbol}: no price window after entry_date")
            skipped.append({"symbol": symbol, "reason": "no price window after entry_date"})
            continue

        entry, entry_source = infer_entry_price(row, window)
        if entry is None:
            print(f"Skipping {symbol}: no entry price and cannot infer")
            skipped.append({"symbol": symbol, "reason": "no entry price and cannot infer"})
            continue

        stop, stop_source = get_stop_from_row(row, entry)
        t1, t1_source = get_t1_from_row(row, entry)
        t2, t2_source = get_t2_from_row(row, entry)

        rule_results = run_rules(row, window, entry, stop, t1, t2)

        for rr in rule_results:
            all_results.append({
                "week": row.get("week", ""),
                "symbol": symbol,
                "yf_symbol": yf_symbol,
                "status_input": row.get("status", ""),
                "entry_date": entry_date.date(),
                "entry_price_used": round(entry, 4),
                "entry_source": entry_source,
                "stop_used": round(stop, 4),
                "stop_source": stop_source,
                "t1_used": round(t1, 4),
                "t1_source": t1_source,
                "t2_used": round(t2, 4),
                "t2_source": t2_source,
                "input_pnl_pct": row.get("pnl_pct", ""),
                "input_exit_date": row.get("exit_date", ""),
                **rr,
            })

        time.sleep(SLEEP_SECONDS)

    results = pd.DataFrame(all_results)

    if results.empty:
        print("No simulated results produced.")
        if skipped:
            pd.DataFrame(skipped).to_csv("exit_rule_skipped.csv", index=False, encoding="utf-8-sig")
            print("Saved skipped symbols to exit_rule_skipped.csv")
        return

    results.to_csv(OUTPUT_TRADES_FILE, index=False, encoding="utf-8-sig")

    summary = (
        results.groupby("rule")
        .agg(
            trades=("symbol", "count"),
            avg_pnl_pct=("pnl_pct_sim", "mean"),
            median_pnl_pct=("pnl_pct_sim", "median"),
            total_profit_eur=("profit_eur_per_1000", "sum"),
            win_rate_pct=("pnl_pct_sim", lambda x: (x > 0).mean() * 100),
            loss_rate_pct=("pnl_pct_sim", lambda x: (x < 0).mean() * 100),
            best_trade_pct=("pnl_pct_sim", "max"),
            worst_trade_pct=("pnl_pct_sim", "min"),
        )
        .reset_index()
        .sort_values("total_profit_eur", ascending=False)
    )

    summary["avg_pnl_pct"] = summary["avg_pnl_pct"].round(3)
    summary["median_pnl_pct"] = summary["median_pnl_pct"].round(3)
    summary["win_rate_pct"] = summary["win_rate_pct"].round(1)
    summary["loss_rate_pct"] = summary["loss_rate_pct"].round(1)
    summary["best_trade_pct"] = summary["best_trade_pct"].round(3)
    summary["worst_trade_pct"] = summary["worst_trade_pct"].round(3)

    summary.to_csv(OUTPUT_SUMMARY_FILE, index=False, encoding="utf-8-sig")

    print("\nSaved:", OUTPUT_TRADES_FILE)
    print("Saved:", OUTPUT_SUMMARY_FILE)

    if skipped:
        pd.DataFrame(skipped).to_csv("exit_rule_skipped.csv", index=False, encoding="utf-8-sig")
        print("Saved skipped symbols to exit_rule_skipped.csv")

    print("\n================ EXIT RULE SUMMARY ================")
    print(summary.to_string(index=False))

    print("\nImportant note:")
    print("- If your CSV has no entry/t1/t2/stop columns, the script uses entry-day close as entry,")
    print(f"  T1={FALLBACK_T1_PCT:.0f}% and T2={FALLBACK_T2_PCT:.0f}% as fallback targets.")
    print("- This is good for comparing exit rule behavior, but final production testing should use actual entry/target/stop from your watchlist snapshots.")


if __name__ == "__main__":
    main()
