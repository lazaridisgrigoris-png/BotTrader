import pandas as pd
import yfinance as yf
from datetime import timedelta
import time
import math

# ==================================================
# CONFIG
# ==================================================
INPUT_FILE = "trade_evaluation.csv"
OUTPUT_TRADES_FILE = "exit_rule_trade_results.csv"
OUTPUT_SUMMARY_FILE = "exit_rule_summary.csv"

INITIAL_CAPITAL_PER_TRADE = 1000.0
MAX_HOLDING_DAYS = 30
HARD_STOP_PCT = -2.0

# Yahoo/VIX benchmark config is optional for future enhancement
SLEEP_SECONDS = 0.25

# ==================================================
# SYMBOL HELPERS
# ==================================================
def normalize_symbol(symbol: str) -> str:
    symbol = str(symbol).strip()
    if symbol.startswith("NASDAQ:"):
        return symbol.replace("NASDAQ:", "")
    if symbol.startswith("NYSE:"):
        return symbol.replace("NYSE:", "")
    if symbol.startswith("ATHEX:"):
        return symbol.replace("ATHEX:", "")
    return symbol


def flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df


def get_column_as_series(df: pd.DataFrame, col_name: str) -> pd.Series:
    col = df[col_name]
    if isinstance(col, pd.DataFrame):
        col = col.iloc[:, 0]
    return col.dropna()


def download_history(symbol: str, start, end) -> pd.DataFrame:
    hist = yf.download(
        symbol,
        start=start.strftime("%Y-%m-%d"),
        end=end.strftime("%Y-%m-%d"),
        progress=False,
        auto_adjust=False,
        group_by="column",
        threads=False,
    )
    if hist is None or hist.empty:
        return pd.DataFrame()
    hist = flatten_columns(hist)
    hist = hist.dropna(how="all")
    return hist


# ==================================================
# INDICATORS
# ==================================================
def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    out = df.copy()
    close = get_column_as_series(out, "Close")
    out["EMA5"] = close.ewm(span=5, adjust=False).mean()
    out["EMA10"] = close.ewm(span=10, adjust=False).mean()
    out["SMA5"] = close.rolling(5).mean()
    out["SMA10"] = close.rolling(10).mean()
    out["RET1"] = close.pct_change()

    # RSI 14
    delta = close.diff()
    gain = delta.clip(lower=0)
    loss = -delta.clip(upper=0)
    avg_gain = gain.rolling(14).mean()
    avg_loss = loss.rolling(14).mean()
    rs = avg_gain / avg_loss.replace(0, math.nan)
    out["RSI14"] = 100 - (100 / (1 + rs))

    return out


# ==================================================
# TRADE SIMULATION HELPERS
# ==================================================
def pct(price: float, entry: float) -> float:
    return (price / entry - 1.0) * 100.0


def first_valid_price(row, preferred_cols):
    for c in preferred_cols:
        if c in row and pd.notna(row[c]) and str(row[c]).strip() != "":
            try:
                return float(str(row[c]).replace(",", "."))
            except Exception:
                pass
    return None


def get_entry_price(row):
    return first_valid_price(row, ["entry_price", "entry", "ENTRY PRICE", "entry price"])


def get_t1(row):
    return first_valid_price(row, ["t1", "target1", "target_1", "T1"])


def get_t2(row):
    return first_valid_price(row, ["t2", "target2", "target_2", "T2"])


def get_stop(row, entry):
    explicit = first_valid_price(row, ["stop", "stop_price", "STOP"])
    if explicit is not None:
        return explicit
    return entry * (1 + HARD_STOP_PCT / 100.0)


def prepare_trade_window(hist: pd.DataFrame, entry_date, max_holding_days: int) -> pd.DataFrame:
    start = pd.to_datetime(entry_date)
    end = start + timedelta(days=max_holding_days + 10)
    window = hist[(hist.index >= start) & (hist.index <= end)].copy()
    # limit to max number of trading sessions approximately equal to max_holding_days
    return window.iloc[:max_holding_days]


# ==================================================
# EXIT RULES
# Each rule returns: exit_date, exit_price, exit_reason
# ==================================================
def simulate_baseline_actual(row):
    """Use current status pnl_pct from the input file as actual reported result."""
    pnl = pd.to_numeric(row.get("pnl_pct", None), errors="coerce")
    if pd.isna(pnl):
        return None
    return {
        "exit_date": row.get("exit_date", ""),
        "exit_price": None,
        "exit_reason": "INPUT_PNL",
        "pnl_pct": float(pnl),
        "partial_model": "NO",
    }


def simulate_hard_stop_or_end(window, entry, stop):
    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        close = float(bar["Close"])
        if low <= stop:
            return dt.date(), stop, "HARD_STOP"
    last = window.iloc[-1]
    return window.index[-1].date(), float(last["Close"]), "MAX_HOLD_EXIT"


def simulate_t1_full_then_stop_or_end(window, entry, stop, t1):
    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        if low <= stop:
            return dt.date(), stop, "HARD_STOP"
        if t1 is not None and high >= t1:
            return dt.date(), t1, "T1_FULL_EXIT"
    last = window.iloc[-1]
    return window.index[-1].date(), float(last["Close"]), "MAX_HOLD_EXIT"


def simulate_t2_full_then_stop_or_end(window, entry, stop, t2):
    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        if low <= stop:
            return dt.date(), stop, "HARD_STOP"
        if t2 is not None and high >= t2:
            return dt.date(), t2, "T2_FULL_EXIT"
    last = window.iloc[-1]
    return window.index[-1].date(), float(last["Close"]), "MAX_HOLD_EXIT"


def simulate_t1_half_rest_ema5(window, entry, stop, t1):
    remaining = 1.0
    realized_pct = 0.0
    t1_taken = False
    active_stop = stop

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        high = float(bar["High"])
        close = float(bar["Close"])
        ema5 = float(bar["EMA5"]) if pd.notna(bar.get("EMA5")) else None

        if low <= active_stop:
            realized_pct += remaining * pct(active_stop, entry)
            return dt.date(), None, "STOP_REMAINDER", realized_pct, "YES"

        if not t1_taken and t1 is not None and high >= t1:
            realized_pct += 0.5 * pct(t1, entry)
            remaining = 0.5
            t1_taken = True
            active_stop = max(active_stop, entry)  # breakeven for runner

        if t1_taken and ema5 is not None and close < ema5:
            realized_pct += remaining * pct(close, entry)
            return dt.date(), close, "EMA5_EXIT_AFTER_T1", realized_pct, "YES"

    last_close = float(window.iloc[-1]["Close"])
    realized_pct += remaining * pct(last_close, entry)
    return window.index[-1].date(), last_close, "MAX_HOLD_EXIT", realized_pct, "YES"


def simulate_ema5_after_profit(window, entry, stop, min_profit_pct=3.0):
    highest_close = entry
    activated = False

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        close = float(bar["Close"])
        ema5 = float(bar["EMA5"]) if pd.notna(bar.get("EMA5")) else None

        if low <= stop:
            return dt.date(), stop, "HARD_STOP"

        highest_close = max(highest_close, close)

        if pct(highest_close, entry) >= min_profit_pct:
            activated = True

        if activated and ema5 is not None and close < ema5:
            return dt.date(), close, f"EMA5_EXIT_AFTER_{min_profit_pct:.0f}PCT"

    last = window.iloc[-1]
    return window.index[-1].date(), float(last["Close"]), "MAX_HOLD_EXIT"


def simulate_trailing_stop_after_profit(window, entry, stop, activation_pct=3.0, trail_pct=2.0):
    highest_close = entry
    active_stop = stop
    trail_active = False

    for dt, bar in window.iterrows():
        low = float(bar["Low"])
        close = float(bar["Close"])

        highest_close = max(highest_close, close)

        if pct(highest_close, entry) >= activation_pct:
            trail_active = True
            active_stop = max(active_stop, entry, highest_close * (1 - trail_pct / 100.0))

        if low <= active_stop:
            reason = "TRAIL_STOP" if trail_active else "HARD_STOP"
            return dt.date(), active_stop, reason

    last = window.iloc[-1]
    return window.index[-1].date(), float(last["Close"]), "MAX_HOLD_EXIT"


def simulate_time_profit_exit(window, entry, stop):
    """Exit if trade is not progressing enough by day 10/15/20."""
    for i, (dt, bar) in enumerate(window.iterrows(), start=1):
        low = float(bar["Low"])
        close = float(bar["Close"])

        if low <= stop:
            return dt.date(), stop, "HARD_STOP"

        current_pct = pct(close, entry)
        if i >= 10 and current_pct < 1.5:
            return dt.date(), close, "TIME_EXIT_DAY10_WEAK"
        if i >= 15 and current_pct < 2.5:
            return dt.date(), close, "TIME_EXIT_DAY15_WEAK"
        if i >= 20 and current_pct < 4.0:
            return dt.date(), close, "TIME_EXIT_DAY20_WEAK"

    last = window.iloc[-1]
    return window.index[-1].date(), float(last["Close"]), "MAX_HOLD_EXIT"


def simulate_exit_score(window, entry, stop):
    """
    Exit score:
    +1 close < EMA5
    +1 two consecutive red closes
    +1 RSI falling from >65
    +1 pnl > 3% and close is >1.5% below highest close
    +1 after day 20
    Exit when score >= 3, but only if pnl is positive or day >= 15.
    """
    prev_close = None
    prev_prev_close = None
    prev_rsi = None
    highest_close = entry

    for i, (dt, bar) in enumerate(window.iterrows(), start=1):
        low = float(bar["Low"])
        close = float(bar["Close"])
        ema5 = float(bar["EMA5"]) if pd.notna(bar.get("EMA5")) else None
        rsi = float(bar["RSI14"]) if pd.notna(bar.get("RSI14")) else None

        if low <= stop:
            return dt.date(), stop, "HARD_STOP"

        highest_close = max(highest_close, close)
        current_pct = pct(close, entry)

        score = 0
        if ema5 is not None and close < ema5:
            score += 1
        if prev_close is not None and prev_prev_close is not None:
            if close < prev_close and prev_close < prev_prev_close:
                score += 1
        if rsi is not None and prev_rsi is not None:
            if prev_rsi > 65 and rsi < prev_rsi:
                score += 1
        if pct(highest_close, entry) > 3.0 and pct(close, highest_close) <= -1.5:
            score += 1
        if i >= 20:
            score += 1

        if score >= 3 and (current_pct > 0 or i >= 15):
            return dt.date(), close, f"EXIT_SCORE_{score}"

        prev_prev_close = prev_close
        prev_close = close
        prev_rsi = rsi

    last = window.iloc[-1]
    return window.index[-1].date(), float(last["Close"]), "MAX_HOLD_EXIT"


# ==================================================
# MAIN
# ==================================================
def main():
    df = pd.read_csv(INPUT_FILE)
    df["status"] = df["status"].astype(str).str.upper().str.strip()
    df["symbol"] = df["symbol"].astype(str).str.strip()

    # Only executed trades: exclude not triggered and rows without entry date
    df["entry_date_parsed"] = pd.to_datetime(df.get("entry_date"), errors="coerce")
    trades = df[(df["status"] != "NOT_TRIGGERED") & df["entry_date_parsed"].notna()].copy()

    print(f"Loaded trades: {len(df)}")
    print(f"Executed trades to simulate: {len(trades)}")

    all_results = []

    for idx, row in trades.iterrows():
        symbol = row["symbol"]
        yf_symbol = normalize_symbol(symbol)
        entry_date = row["entry_date_parsed"]
        entry = get_entry_price(row)
        t1 = get_t1(row)
        t2 = get_t2(row)

        if entry is None:
            print(f"Skipping {symbol}: no entry price")
            continue

        stop = get_stop(row, entry)

        start = entry_date - timedelta(days=40)
        end = entry_date + timedelta(days=MAX_HOLDING_DAYS + 15)

        print(f"Fetching {symbol} -> {yf_symbol} from {start.date()} to {end.date()}")
        hist = download_history(yf_symbol, start, end)
        time.sleep(SLEEP_SECONDS)

        if hist.empty or not all(c in hist.columns for c in ["Open", "High", "Low", "Close"]):
            print(f"No usable data for {symbol}")
            continue

        hist = add_indicators(hist)
        window = prepare_trade_window(hist, entry_date, MAX_HOLDING_DAYS)

        if window.empty:
            print(f"No trade window for {symbol}")
            continue

        rule_outputs = []

        # Actual reported result
        actual = simulate_baseline_actual(row)
        if actual is not None:
            rule_outputs.append(("ACTUAL_INPUT", actual["pnl_pct"], actual["exit_date"], actual["exit_price"], actual["exit_reason"], actual["partial_model"]))

        # Rule simulations
        exit_date, exit_price, reason = simulate_hard_stop_or_end(window, entry, stop)
        rule_outputs.append(("HARD_STOP_OR_MAX_30D", pct(exit_price, entry), exit_date, exit_price, reason, "NO"))

        exit_date, exit_price, reason = simulate_t1_full_then_stop_or_end(window, entry, stop, t1)
        rule_outputs.append(("FULL_EXIT_AT_T1", pct(exit_price, entry), exit_date, exit_price, reason, "NO"))

        exit_date, exit_price, reason = simulate_t2_full_then_stop_or_end(window, entry, stop, t2)
        rule_outputs.append(("FULL_EXIT_AT_T2", pct(exit_price, entry), exit_date, exit_price, reason, "NO"))

        exit_date, exit_price, reason = simulate_ema5_after_profit(window, entry, stop, min_profit_pct=3.0)
        rule_outputs.append(("EMA5_EXIT_AFTER_3PCT", pct(exit_price, entry), exit_date, exit_price, reason, "NO"))

        exit_date, exit_price, reason = simulate_trailing_stop_after_profit(window, entry, stop, activation_pct=3.0, trail_pct=2.0)
        rule_outputs.append(("TRAIL_2PCT_AFTER_3PCT", pct(exit_price, entry), exit_date, exit_price, reason, "NO"))

        exit_date, exit_price, reason = simulate_trailing_stop_after_profit(window, entry, stop, activation_pct=5.0, trail_pct=2.5)
        rule_outputs.append(("TRAIL_2_5PCT_AFTER_5PCT", pct(exit_price, entry), exit_date, exit_price, reason, "NO"))

        exit_date, exit_price, reason = simulate_time_profit_exit(window, entry, stop)
        rule_outputs.append(("TIME_PROGRESS_EXIT", pct(exit_price, entry), exit_date, exit_price, reason, "NO"))

        exit_date, exit_price, reason = simulate_exit_score(window, entry, stop)
        rule_outputs.append(("EXIT_SCORE_DYNAMIC", pct(exit_price, entry), exit_date, exit_price, reason, "NO"))

        exit_date, exit_price, reason, pnl_pct_value, partial_model = simulate_t1_half_rest_ema5(window, entry, stop, t1)
        rule_outputs.append(("HALF_T1_HALF_EMA5_RUNNER", pnl_pct_value, exit_date, exit_price, reason, partial_model))

        for rule_name, pnl_pct_value, exit_date_value, exit_price_value, reason_value, partial_model in rule_outputs:
            all_results.append({
                "week": row.get("week", ""),
                "symbol": symbol,
                "yf_symbol": yf_symbol,
                "status_input": row.get("status", ""),
                "entry_date": entry_date.date(),
                "entry_price": round(entry, 4),
                "stop_price": round(stop, 4),
                "t1": round(t1, 4) if t1 is not None else None,
                "t2": round(t2, 4) if t2 is not None else None,
                "rule": rule_name,
                "exit_date": exit_date_value,
                "exit_price": round(exit_price_value, 4) if exit_price_value is not None else None,
                "exit_reason": reason_value,
                "partial_model": partial_model,
                "pnl_pct": round(pnl_pct_value, 2),
                "pnl_eur_per_1000": round(INITIAL_CAPITAL_PER_TRADE * pnl_pct_value / 100.0, 2),
            })

    results_df = pd.DataFrame(all_results)
    results_df.to_csv(OUTPUT_TRADES_FILE, index=False, encoding="utf-8-sig")

    if results_df.empty:
        print("No results generated.")
        return

    summary = results_df.groupby("rule").agg(
        trades=("symbol", "count"),
        total_pnl_pct_points=("pnl_pct", "sum"),
        avg_pnl_pct=("pnl_pct", "mean"),
        median_pnl_pct=("pnl_pct", "median"),
        total_pnl_eur_per_1000=("pnl_eur_per_1000", "sum"),
        win_rate_pct=("pnl_pct", lambda x: (x > 0).mean() * 100),
        loss_rate_pct=("pnl_pct", lambda x: (x < 0).mean() * 100),
        best_trade_pct=("pnl_pct", "max"),
        worst_trade_pct=("pnl_pct", "min"),
    ).reset_index()

    summary = summary.sort_values("total_pnl_eur_per_1000", ascending=False)
    summary.to_csv(OUTPUT_SUMMARY_FILE, index=False, encoding="utf-8-sig")

    print("\nSaved:", OUTPUT_TRADES_FILE)
    print("Saved:", OUTPUT_SUMMARY_FILE)

    print("\n================ EXIT RULE SUMMARY ================")
    print(summary.to_string(index=False))

    print("\nBest rule by total P/L:")
    print(summary.iloc[0].to_string())


if __name__ == "__main__":
    main()
