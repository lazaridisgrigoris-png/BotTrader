import base64
import json
from openai import OpenAI

client = OpenAI()  # uses OPENAI_API_KEY env var

BULKOWSKI_PROMPT = """
You evaluate daily stock charts using Bulkowski-style chart patterns with highest probability.
We are trading LONG only.

Constraints:
- Timeframe: Daily
- Lookback: Year-to-date (chart image shows YTD)
- Max holding time: 1 month
- Target: +5% to +10%
- Stop loss: -1% to -2% (flag if unrealistic given volatility / structure)

Instructions:
1) Identify the top 1–3 pattern candidates (Bulkowski names if possible), and whether price is at/near a valid breakout point.
2) If a trade is valid, propose an entry trigger, stop, and 2 targets (5% and 10%).
3) If no trade, say why with specific conditions to re-check.
4) Be conservative: if the 1–2% stop is likely to be hit by normal noise, mark NO TRADE.

Return STRICT JSON only, exactly this schema:
{
  "symbol": "EXCHANGE:TICKER",
  "pattern_candidates": [
    {"name": "string", "confidence_0_100": 0, "breakout_level": 0.0, "invalidation_level": 0.0}
  ],
  "entry_plan": {
    "decision": "TRADE" or "NO_TRADE",
    "trigger": "string",
    "entry_price": 0.0,
    "stop_price": 0.0,
    "target_price_1": 0.0,
    "target_price_2": 0.0,
    "time_stop_days": 20
  },
  "risk_notes": ["string"],
  "grade_0_10": 0,
  "no_trade_if": ["string"]
}
"""

def png_file_to_data_url(path: str) -> str:
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("ascii")
    return f"data:image/png;base64,{b64}"

def evaluate_chart_png(symbol: str, png_path: str) -> dict:
    img = png_file_to_data_url(png_path)

    resp = client.responses.create(
        model="gpt-5",  # or your preferred vision-capable model
        input=[{
            "role": "user",
            "content": [
                {"type": "input_text", "text": f"Symbol: {symbol}\n\n{BULKOWSKI_PROMPT}"},
                {"type": "input_image", "image_url": img}
            ],
        }],
    )

    # The model returns text; we forced STRICT JSON.
    text = resp.output_text.strip()
    return json.loads(text)

if __name__ == "__main__":
    result = evaluate_chart_png("NASDAQ:AAPL", "test.png")
    print(json.dumps(result, indent=2))
