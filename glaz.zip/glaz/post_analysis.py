#!/usr/bin/env python3
from __future__ import annotations

import datetime as dt
import os
from typing import Any, Dict, List, Optional, Tuple

import gspread
from google.oauth2.service_account import Credentials

SHEET_ID = os.getenv("SHEET_ID", "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg")
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "auto-trading-481921-980bcad6baf5.json")
WATCHLIST_TAB = os.getenv("WATCHLIST_TAB", "Watchlist")
POST_ANALYSIS_TAB = os.getenv("POST_ANALYSIS_TAB", "PostAnalysis")
POST_TOP_N = int(os.getenv("POST_TOP_N", "50"))
POST_INCLUDE_FUTURE_SETUP = os.getenv("POST_INCLUDE_FUTURE_SETUP", "true").strip().lower() == "true"
POST_INCLUDE_NO_TRADE = os.getenv("POST_INCLUDE_NO_TRADE", "false").strip().lower() == "true"

POST_HEADERS = [
    "run_ts","symbol","country","market","asset_type","decision","grade_0_10","pattern",
    "last_close","entry","stop","t1","t2","risk_reward_t1","risk_reward_t2","entry_gap_pct",
    "stop_pct","target1_pct","target2_pct","trading_score","fit_for_you","priority_score",
    "priority_rank","final_action","comment",
]

def now_str_local() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def to_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        s = str(x).strip()
        if not s:
            return None
        return float(s)
    except Exception:
        return None

def to_int(x: Any, default: int = 0) -> int:
    try:
        if x is None:
            return default
        s = str(x).strip()
        if not s:
            return default
        return int(float(s))
    except Exception:
        return default

def clamp(x: float, lo: float, hi: float) -> float:
    return max(lo, min(hi, x))

def get_cell(row: List[str], col_map: Dict[str, int], name: str, default: str = "") -> str:
    idx = col_map.get(name.lower())
    if not idx:
        return default
    z = idx - 1
    return (row[z] or "").strip() if 0 <= z < len(row) else default

def build_col_map(header: List[str]) -> Dict[str, int]:
    out = {}
    for i, h in enumerate(header, start=1):
        k = str(h).strip().lower()
        if k:
            out[k] = i
            out[k.replace(" ", "_")] = i
    return out

def safe_div(a: Optional[float], b: Optional[float]) -> Optional[float]:
    if a is None or b is None or b == 0:
        return None
    return a / b

def pct_diff(a: Optional[float], b: Optional[float]) -> Optional[float]:
    if a is None or b is None or b == 0:
        return None
    return (a - b) / b

SPECIAL_MAP = {
    "HEAL": ("DE", "XETRA", "ETF"), "IBGL": ("DE", "XETRA", "ETF"), "IDTL": ("DE", "XETRA", "ETF"),
    "SPXS": ("DE", "XETRA", "ETF"), "LCUW": ("DE", "XETRA", "ETF"), "AEMU": ("DE", "XETRA", "ETF"),
    "IEUR": ("DE", "XETRA", "ETF"), "IJPN": ("DE", "XETRA", "ETF"), "FRIN": ("DE", "XETRA", "ETF"),
    "ITWN": ("DE", "XETRA", "ETF"), "EMIM": ("DE", "XETRA", "ETF"), "XRSU": ("DE", "XETRA", "ETF"),
    "DPW": ("DE", "XETRA", "Stock"), "ALTI": ("FR", "Euronext Paris", "Stock"), "AGGH": ("UK", "LSE", "ETF"),
    "SPY": ("US", "NYSE Arca", "ETF"), "QQQ": ("US", "NASDAQ", "ETF"), "IWM": ("US", "NYSE Arca", "ETF"),
    "DIA": ("US", "NYSE Arca", "ETF"), "XLK": ("US", "NYSE Arca", "ETF"), "XLF": ("US", "NYSE Arca", "ETF"),
    "XLE": ("US", "NYSE Arca", "ETF"), "XLV": ("US", "NYSE Arca", "ETF"), "XLI": ("US", "NYSE Arca", "ETF"),
    "XLY": ("US", "NYSE Arca", "ETF"), "SMH": ("US", "NASDAQ", "ETF"), "SOXX": ("US", "NASDAQ", "ETF"),
    "XBI": ("US", "NYSE Arca", "ETF"), "ARKK": ("US", "NYSE Arca", "ETF"), "KRE": ("US", "NYSE Arca", "ETF"),
    "GDX": ("US", "NYSE Arca", "ETF"), "SLV": ("US", "NYSE Arca", "ETF"), "USO": ("US", "NYSE Arca", "ETF"),
    "TLT": ("US", "NASDAQ", "ETF"), "VIXY": ("US", "BATS", "ETF"),
}
REITS = {"PRODEA.AT","PREMIA.AT","TRASTOR.AT","BRIQ.AT","NOVAL.AT","ORILINA.AT","TRESTATES.AT"}

def infer_symbol_metadata(symbol: str) -> Tuple[str, str, str]:
    s = (symbol or "").strip()
    if s in SPECIAL_MAP:
        return SPECIAL_MAP[s]
    if ":" in s:
        exch, tick = s.split(":", 1)
        if exch == "ATHEX":
            return "GR", "ATHEX", "Stock"
        if exch == "NASDAQ":
            return "US", "NASDAQ", "Stock"
        if exch == "NYSE":
            return "US", "NYSE", "Stock"
        return "", exch, "Unknown"
    u = s.upper()
    if u in REITS:
        return "GR", "ATHEX", "REIT"
    if u.endswith(".AT"):
        return "GR", "ATHEX", "Stock"
    if u.endswith(".DE"):
        return "DE", "XETRA", "ETF" if any(k in u for k in ("VWCE","IWDA","EIMI","SXR","XRSU","WNRG","EUNA","VAGF","EMIM","IEUR","CNDX","EQQQ")) else "Stock"
    if u.endswith(".L"):
        return "UK", "LSE", "ETF" if any(k in u for k in ("IWDA","EIMI","SGLN","IGLN","SBIO","ROBO","AIAG","CNDX","EQQQ","AGGH","CSPX")) else "Stock"
    if u.endswith(".PA"):
        return "FR", "Euronext Paris", "Stock"
    if u.endswith(".MI"):
        return "IT", "Euronext Milan", "Stock"
    return "", "", "Unknown"

def liquidity_score(country: str, market: str, asset_type: str, symbol: str) -> int:
    s = symbol.upper()
    score = 50
    if market in ("NASDAQ","NYSE","NYSE Arca"):
        score += 25
    elif market in ("XETRA","LSE","Euronext Paris","Euronext Milan"):
        score += 18
    elif market == "ATHEX":
        score += 8
    if asset_type == "ETF":
        score += 10
    elif asset_type == "REIT":
        score -= 5
    if any(k in s for k in ("ALPHA.AT","EUROB.AT","ETE.AT","TPEIR.AT","PPC.AT","MTLN.AT","MOH.AT","OPAP.AT","GEKTERNA.AT","CENER.AT","HTO.AT")):
        score += 18
    if any(k in s for k in ("BIOT.AT","BYLOT.AT","YALCO.AT","LEBEK.AT","LEBEP.AT","SAR.AT")):
        score -= 50
    return int(clamp(score, 0, 100))

def trading_score(decision: str, grade: int, country: str, market: str, asset_type: str, symbol: str,
                  stop_pct: Optional[float], rr2: Optional[float], entry_gap_pct: Optional[float]) -> int:
    score = 45
    score += int(liquidity_score(country, market, asset_type, symbol) * 0.35)
    if decision == "TRADE":
        score += 22
    elif decision == "FUTURE_SETUP":
        score += 12
    elif decision == "NO_TRADE":
        score -= 12
    score += int((grade / 10.0) * 28)
    if rr2 is not None:
        score += int(clamp(rr2 / 3.0, 0, 1) * 18)
    if entry_gap_pct is not None:
        if entry_gap_pct <= 0.01:
            score += 14
        elif entry_gap_pct <= 0.02:
            score += 10
        elif entry_gap_pct <= 0.04:
            score += 5
        else:
            score -= 8
    if stop_pct is not None:
        if 0 < stop_pct <= 0.02:
            score += 8
        elif stop_pct > 0.03:
            score -= 10
    s = symbol.upper()
    if any(k in s for k in ("QQQ","SPY","SMH","SOXX","SXRV","XRSU","WNRG","BTCE","ETHC","EQQQ","CNDX")):
        score += 10
    if any(k in s for k in ("SAP.DE","RHM.DE","AIR.PA","MC.PA","OR.PA")):
        score += 6
    return int(clamp(score, 0, 100))

def long_term_score(country: str, market: str, asset_type: str, symbol: str) -> int:
    s = symbol.upper()
    score = 50
    if asset_type == "ETF":
        score += 22
    elif asset_type == "REIT":
        score += 8
    if country == "US":
        score += 14
    elif country in ("DE","UK","FR","IT"):
        score += 9
    elif country == "GR":
        score -= 4
    if any(k in s for k in ("VWCE","IWDA","CSPX","SXR8","EUNL","VAGF","EUNA","EIMI")):
        score = 95
    if any(k in s for k in ("AAPL","MSFT","NVDA","AMZN","GOOG","GOOGL","META","ASML")):
        score = max(score, 90)
    if any(k in s for k in ("BIOT.AT","BYLOT.AT","YALCO.AT","LEBEK.AT","LEBEP.AT")):
        score = 15
    return int(clamp(score, 0, 100))

def fit_for_you(asset_type: str, lt: int, tr: int) -> int:
    if asset_type in ("ETF","REIT"):
        return int(round(clamp(0.7 * lt + 0.3 * tr, 0, 100)))
    return int(round(clamp(0.4 * lt + 0.6 * tr, 0, 100)))

def final_action(decision: str, priority_score: int) -> str:
    if decision == "TRADE":
        if priority_score >= 82:
            return "KEEP"
        if priority_score >= 72:
            return "KEEP_SECONDARY"
        return "DOWNGRADE"
    if decision == "FUTURE_SETUP":
        return "WATCH" if priority_score >= 70 else "IGNORE"
    return "WATCH" if priority_score >= 68 else "IGNORE"

def connect_sheets():
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON, scopes=scopes)
    gc = gspread.authorize(creds)
    sh = gc.open_by_key(SHEET_ID)
    ws_watch = sh.worksheet(WATCHLIST_TAB)
    return sh, ws_watch

def ensure_post_tab(sh):
    try:
        ws = sh.worksheet(POST_ANALYSIS_TAB)
        ws.clear()
    except gspread.WorksheetNotFound:
        ws = sh.add_worksheet(title=POST_ANALYSIS_TAB, rows=2000, cols=40)
    ws.append_row(POST_HEADERS)
    return ws

def main() -> None:
    sh, ws_watch = connect_sheets()
    ws_post = ensure_post_tab(sh)
    values = ws_watch.get_all_values()
    if len(values) < 2:
        print("Watchlist has no data rows.")
        return

    col_map = build_col_map(values[0])
    run_ts = now_str_local()
    ranked = []

    for row in values[1:]:
        symbol = get_cell(row, col_map, "symbol")
        if not symbol:
            continue
        decision = get_cell(row, col_map, "decision").upper()
        if decision not in ("TRADE","FUTURE_SETUP","NO_TRADE","ERROR"):
            continue
        if decision == "NO_TRADE" and not POST_INCLUDE_NO_TRADE:
            continue
        if decision == "FUTURE_SETUP" and not POST_INCLUDE_FUTURE_SETUP:
            continue
        if decision == "ERROR":
            continue

        grade = to_int(get_cell(row, col_map, "grade_0_10"), 0)
        pattern = get_cell(row, col_map, "pattern")
        last_close = to_float(get_cell(row, col_map, "last_close"))
        entry = to_float(get_cell(row, col_map, "entry"))
        stop = to_float(get_cell(row, col_map, "stop"))
        t1 = to_float(get_cell(row, col_map, "t1"))
        t2 = to_float(get_cell(row, col_map, "t2"))

        country, market, asset_type = infer_symbol_metadata(symbol)
        stop_pct = pct_diff(entry, stop) if entry is not None and stop is not None else None
        target1_pct = pct_diff(t1, entry) if t1 is not None and entry is not None else None
        target2_pct = pct_diff(t2, entry) if t2 is not None and entry is not None else None
        entry_gap_pct = abs(pct_diff(entry, last_close)) if entry is not None and last_close is not None else None

        risk = (entry - stop) if entry is not None and stop is not None else None
        reward1 = (t1 - entry) if t1 is not None and entry is not None else None
        reward2 = (t2 - entry) if t2 is not None and entry is not None else None
        rr1 = safe_div(reward1, risk)
        rr2 = safe_div(reward2, risk)

        tr_score = trading_score(decision, grade, country, market, asset_type, symbol, stop_pct, rr2, entry_gap_pct)
        lt_score = long_term_score(country, market, asset_type, symbol)
        fit = fit_for_you(asset_type, lt_score, tr_score)
        liq = liquidity_score(country, market, asset_type, symbol)

        decision_component = {"TRADE": 100, "FUTURE_SETUP": 60, "NO_TRADE": 20}.get(decision, 0)
        grade_component = grade * 10
        rr_component = int(clamp((rr2 or 0) / 3.0, 0, 1) * 100)
        prox_component = 0
        if entry_gap_pct is not None:
            if entry_gap_pct <= 0.01:
                prox_component = 100
            elif entry_gap_pct <= 0.02:
                prox_component = 80
            elif entry_gap_pct <= 0.04:
                prox_component = 45
            else:
                prox_component = 20

        priority = int(round(
            (decision_component * 22 + grade_component * 28 + rr_component * 18 + prox_component * 14 + liq * 10 + fit * 8)
            / (22 + 28 + 18 + 14 + 10 + 8)
        ))
        priority = int(clamp(priority, 0, 100))
        action = final_action(decision, priority)

        comments = []
        if decision == "TRADE":
            comments.append("AI trade candidate")
        elif decision == "FUTURE_SETUP":
            comments.append("Valid setup but not actionable yet")
        if rr2 is not None:
            comments.append(f"RR2={rr2:.2f}")
        if entry_gap_pct is not None:
            comments.append(f"entry_gap={entry_gap_pct*100:.2f}%")
        if country == "GR" and liq < 70:
            comments.append("Greek liquidity caution")

        ranked.append({
            "run_ts": run_ts, "symbol": symbol, "country": country, "market": market, "asset_type": asset_type,
            "decision": decision, "grade_0_10": grade, "pattern": pattern, "last_close": last_close,
            "entry": entry, "stop": stop, "t1": t1, "t2": t2, "risk_reward_t1": rr1, "risk_reward_t2": rr2,
            "entry_gap_pct": entry_gap_pct, "stop_pct": stop_pct, "target1_pct": target1_pct, "target2_pct": target2_pct,
            "trading_score": tr_score, "fit_for_you": fit, "priority_score": priority, "final_action": action,
            "comment": " | ".join(comments),
        })

    action_order = {"KEEP": 0, "KEEP_SECONDARY": 1, "WATCH": 2, "DOWNGRADE": 3, "IGNORE": 4}
    ranked.sort(key=lambda x: (action_order.get(x["final_action"], 99), -x["priority_score"], -x["grade_0_10"], x["symbol"]))

    out_rows = []
    for i, item in enumerate(ranked[:POST_TOP_N], start=1):
        out_rows.append([
            item["run_ts"], item["symbol"], item["country"], item["market"], item["asset_type"], item["decision"],
            item["grade_0_10"], item["pattern"],
            "" if item["last_close"] is None else round(item["last_close"], 4),
            "" if item["entry"] is None else round(item["entry"], 4),
            "" if item["stop"] is None else round(item["stop"], 4),
            "" if item["t1"] is None else round(item["t1"], 4),
            "" if item["t2"] is None else round(item["t2"], 4),
            "" if item["risk_reward_t1"] is None else round(item["risk_reward_t1"], 3),
            "" if item["risk_reward_t2"] is None else round(item["risk_reward_t2"], 3),
            "" if item["entry_gap_pct"] is None else round(item["entry_gap_pct"], 4),
            "" if item["stop_pct"] is None else round(item["stop_pct"], 4),
            "" if item["target1_pct"] is None else round(item["target1_pct"], 4),
            "" if item["target2_pct"] is None else round(item["target2_pct"], 4),
            item["trading_score"], item["fit_for_you"], item["priority_score"], i, item["final_action"], item["comment"],
        ])

    if out_rows:
        ws_post.append_rows(out_rows, value_input_option="RAW")
    print(f"Post-analysis complete. Wrote {len(out_rows)} rows to tab '{POST_ANALYSIS_TAB}'.")

if __name__ == "__main__":
    main()
