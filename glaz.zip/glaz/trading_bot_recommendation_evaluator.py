import os
import math
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List

import yfinance as yf
import gspread
from google.oauth2.service_account import Credentials

SHEET_ID = os.getenv("SHEET_ID")
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON")

SNAPSHOT_SUFFIX = os.getenv("SNAPSHOT_SUFFIX", "Watchlist")
GEM_SNAPSHOT_SUFFIX = os.getenv("GEM_SNAPSHOT_SUFFIX", "Output_gem")
EVAL_LOOKBACK_WEEKS = int(os.getenv("EVAL_LOOKBACK_WEEKS", "4"))

EVALUATOR_TAB = os.getenv("EVALUATOR_TAB", "Evaluator")
EVALUATOR_SUMMARY_TAB = os.getenv("EVALUATOR_SUMMARY_TAB", "Evaluator_Summary")
GEM_EVALUATOR_TAB = os.getenv("GEM_EVALUATOR_TAB", "Gem_Evaluator")
GEM_EVALUATOR_SUMMARY_TAB = os.getenv("GEM_EVALUATOR_SUMMARY_TAB", "Gem_Evaluator_Summary")


def log(msg: str) -> None:
    print(f"[{datetime.now()}] {msg}", flush=True)


def iso_week_title(offset_weeks: int, suffix: str) -> str:
    d = datetime.now() - timedelta(weeks=offset_weeks)
    iso = d.isocalendar()
    return f"Y{iso.year % 100:02d}W{iso.week:02d} {suffix}"


def to_float(v: Any) -> Optional[float]:
    try:
        if v is None:
            return None
        x = float(v)
        if math.isnan(x) or math.isinf(x):
            return None
        return x
    except Exception:
        return None


def to_serializable(v: Any) -> Any:
    if v is None:
        return ""
    if hasattr(v, "to_pydatetime"):
        try:
            v = v.to_pydatetime()
        except Exception:
            pass
    if hasattr(v, "strftime"):
        try:
            return v.strftime("%Y-%m-%d")
        except Exception:
            pass
    if isinstance(v, float):
        if math.isnan(v) or math.isinf(v):
            return ""
        return round(v, 2)
    try:
        # catches numpy scalar NaN-like values
        x = float(v)
        if math.isnan(x) or math.isinf(x):
            return ""
    except Exception:
        pass
    return v


def sanitize_2d(values: List[List[Any]]) -> List[List[Any]]:
    return [[to_serializable(cell) for cell in row] for row in values]


def tv_to_yahoo_symbol(symbol: str) -> str:
    s = (symbol or "").strip()
    if not s:
        return s
    if ":" not in s:
        return s

    exchange, ticker = s.split(":", 1)
    exchange = exchange.strip().upper()
    ticker = ticker.strip()

    if exchange in ("NASDAQ", "NYSE", "AMEX", "ARCA", "BATS"):
        return ticker
    if exchange == "ATHEX":
        return ticker
    return ticker


def normalize_yf_df(df):
    if df is None or df.empty:
        return df
    if hasattr(df.columns, "nlevels") and df.columns.nlevels > 1:
        df.columns = df.columns.get_level_values(0)

    wanted = ["Open", "High", "Low", "Close"]
    keep = [c for c in wanted if c in df.columns]
    if not keep:
        return df

    df = df[keep].copy()
    for c in keep:
        try:
            df[c] = df[c].squeeze()
        except Exception:
            pass
    return df


def get_or_create_worksheet(sh: gspread.Spreadsheet, title: str, rows: int, cols: int):
    try:
        return sh.worksheet(title)
    except Exception:
        return sh.add_worksheet(title, rows, cols)


def connect_sheets():
    if not SHEET_ID:
        raise RuntimeError("SHEET_ID env var is required")
    if not SERVICE_ACCOUNT_JSON:
        raise RuntimeError("SERVICE_ACCOUNT_JSON env var is required")

    creds = Credentials.from_service_account_file(
        SERVICE_ACCOUNT_JSON,
        scopes=["https://www.googleapis.com/auth/spreadsheets"],
    )
    gc = gspread.authorize(creds)
    sh = gc.open_by_key(SHEET_ID)

    ws_eval = get_or_create_worksheet(sh, EVALUATOR_TAB, 1000, 20)
    ws_summary = get_or_create_worksheet(sh, EVALUATOR_SUMMARY_TAB, 100, 20)
    ws_gem_eval = get_or_create_worksheet(sh, GEM_EVALUATOR_TAB, 1000, 20)
    ws_gem_summary = get_or_create_worksheet(sh, GEM_EVALUATOR_SUMMARY_TAB, 100, 20)

    return sh, ws_eval, ws_summary, ws_gem_eval, ws_gem_summary


def fetch_data(symbol: str, start_date: datetime):
    yahoo_symbol = tv_to_yahoo_symbol(symbol)
    try:
        df = yf.download(
            yahoo_symbol,
            start=start_date.strftime("%Y-%m-%d"),
            progress=False,
            auto_adjust=False,
            group_by="column",
            threads=False,
        )
        return normalize_yf_df(df)
    except Exception as e:
        log(f"Error fetching {symbol} -> {yahoo_symbol}: {e}")
        return None


def simulate_trade(row: Dict[str, Any], df) -> Dict[str, Any]:
    entry = to_float(row.get("entry"))
    stop = to_float(row.get("stop"))
    t1 = to_float(row.get("t1"))
    t2 = to_float(row.get("t2"))

    if df is None or df.empty:
        return {"status": "NO_DATA", "t1_hit": False}

    triggered = False
    entry_date = None
    t1_hit = False

    for idx, r in df.iterrows():
        high = to_float(r.get("High"))
        low = to_float(r.get("Low"))
        close = to_float(r.get("Close"))

        if high is None or low is None or close is None:
            continue

        if not triggered and entry is not None and high >= entry:
            triggered = True
            entry_date = idx
            if stop is not None and low <= stop:
                return {
                    "status": "STOPPED",
                    "entry_date": entry_date,
                    "exit_date": idx,
                    "exit_price": stop,
                    "pnl_pct": round((stop - entry) / entry * 100, 2),
                    "t1_hit": False,
                }

        if not triggered:
            continue

        if t1 is not None and high >= t1:
            t1_hit = True

        if stop is not None and low <= stop:
            return {
                "status": "STOPPED",
                "entry_date": entry_date,
                "exit_date": idx,
                "exit_price": stop,
                "pnl_pct": round((stop - entry) / entry * 100, 2),
                "t1_hit": t1_hit,
            }

        if t2 is not None and high >= t2:
            return {
                "status": "T2_HIT",
                "entry_date": entry_date,
                "exit_date": idx,
                "exit_price": t2,
                "pnl_pct": round((t2 - entry) / entry * 100, 2),
                "t1_hit": t1_hit,
            }

    if triggered:
        last_close = to_float(df.iloc[-1].get("Close"))
        if last_close is None:
            return {
                "status": "OPEN",
                "entry_date": entry_date,
                "exit_date": None,
                "exit_price": "",
                "pnl_pct": "",
                "t1_hit": t1_hit,
            }
        return {
            "status": "OPEN",
            "entry_date": entry_date,
            "exit_date": None,
            "exit_price": last_close,
            "pnl_pct": round((last_close - entry) / entry * 100, 2),
            "t1_hit": t1_hit,
        }

    return {"status": "NOT_TRIGGERED", "t1_hit": False}


def evaluate_snapshot_family(sh: gspread.Spreadsheet, snapshot_suffix: str) -> List[Dict[str, Any]]:
    results: List[Dict[str, Any]] = []

    for i in range(1, EVAL_LOOKBACK_WEEKS + 1):
        title = iso_week_title(i, snapshot_suffix)
        try:
            ws = sh.worksheet(title)
        except Exception:
            log(f"Skipping missing sheet {title}")
            continue

        rows = ws.get_all_records()

        for r in rows:
            if str(r.get("decision", "")).upper() != "TRADE":
                continue

            symbol = r.get("symbol")
            if not symbol:
                continue

            yahoo_symbol = tv_to_yahoo_symbol(symbol)
            log(f"Processing {symbol} -> {yahoo_symbol} ({title})")

            start_date = datetime.now() - timedelta(weeks=i + 1)
            df = fetch_data(symbol, start_date)

            if df is None or df.empty:
                results.append({
                    "week": title,
                    "symbol": symbol,
                    "status": "NO_DATA",
                    "pnl_pct": "",
                    "entry_date": "",
                    "exit_date": "",
                    "t1_hit": False,
                })
                continue

            sim = simulate_trade(r, df)
            results.append({
                "week": title,
                "symbol": symbol,
                "status": sim.get("status", "NO_DATA"),
                "pnl_pct": sim.get("pnl_pct", ""),
                "entry_date": sim.get("entry_date"),
                "exit_date": sim.get("exit_date"),
                "t1_hit": sim.get("t1_hit", False),
            })

    return results


def write_results_and_summary(ws_eval: gspread.Worksheet, ws_summary: gspread.Worksheet, results: List[Dict[str, Any]]) -> None:
    ws_eval.clear()

    headers = ["week", "symbol", "status", "pnl_pct", "entry_date", "exit_date", "t1_hit"]
    eval_values = [headers] + [[r.get(h, "") for h in headers] for r in results]
    ws_eval.update(sanitize_2d(eval_values))

    total = len(results)
    triggered = sum(1 for r in results if r["status"] not in ("NOT_TRIGGERED", "NO_DATA"))
    wins = sum(1 for r in results if r["status"] == "T2_HIT")
    stops = sum(1 for r in results if r["status"] == "STOPPED")
    no_data = sum(1 for r in results if r["status"] == "NO_DATA")

    pnl_values = [to_float(r["pnl_pct"]) for r in results]
    pnl_values = [x for x in pnl_values if x is not None]
    avg_pnl = sum(pnl_values) / len(pnl_values) if pnl_values else 0
    total_pnl = sum(pnl_values) if pnl_values else 0

    summary = [
        ["metric", "value"],
        ["total_trades", total],
        ["triggered", triggered],
        ["win_rate", round(wins / triggered * 100, 2) if triggered else 0],
        ["stop_rate", round(stops / triggered * 100, 2) if triggered else 0],
        ["avg_pnl_pct", round(avg_pnl, 2)],
        ["total_pnl_pct", round(total_pnl, 2)],
        ["no_data_count", no_data],
    ]

    ws_summary.clear()
    ws_summary.update(sanitize_2d(summary))


def main() -> None:
    sh, ws_eval, ws_summary, ws_gem_eval, ws_gem_summary = connect_sheets()

    log("Starting Watchlist evaluator...")
    watchlist_results = evaluate_snapshot_family(sh, SNAPSHOT_SUFFIX)
    write_results_and_summary(ws_eval, ws_summary, watchlist_results)
    log("Watchlist evaluation completed.")

    log("Starting Gemini Output evaluator...")
    gem_results = evaluate_snapshot_family(sh, GEM_SNAPSHOT_SUFFIX)
    write_results_and_summary(ws_gem_eval, ws_gem_summary, gem_results)
    log("Gemini Output evaluation completed.")

    log("All evaluations completed.")


if __name__ == "__main__":
    main()
