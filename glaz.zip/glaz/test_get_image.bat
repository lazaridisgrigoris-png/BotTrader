curl --ssl-no-revoke -X POST "https://api.chart-img.com/v1/tradingview/advanced-chart" -H "x-api-key: 0nG77A6Hc6ajztBP6lfXN7HJpwQJUsIHaArnOMnW" -H "Content-Type: application/json" -d "{\"symbol\":\"NASDAQ:AAPL\",\"interval\":\"1D\",\"range\":\"YTD\",\"theme\":\"dark\",\"width\":800,\"height\":600}" -o test.png

