#!/usr/bin/env python3
"""
historical_setup_classifier.py

Phase A backtest component for the trading-bot.

Purpose
-------
Recreate weekly historical setup classification from 2026-01-01 onward:

1. Read symbols from Google Sheets historical weekly Watchlist tabs where available.
2. Fall back to the current Watchlist tab or optional CSV if requested.
3. Download OHLCV only up to each historical week.
4. Compute deterministic features for every symbol.
5. Select a research sample for AI classification using:
   - minimum percentage of the weekly universe, default 10%;
   - deterministic score ranking;
   - bucket/category diversity;
   - exploratory random sampling.
6. Call AI only for selected symbols.
7. Cache every AI classification.
8. Store one row per symbol-week, including non-AI-classified rows.

Important
---------
This script is Phase A only: setup classification.
It also stores methodology-analysis fields needed by Phase B, such as stop distance,
target distance, risk/reward, ATR-normalized stop, and suggested exit style.

Cost controls
-------------
- AI only for selected sample, default 10% of weekly universe.
- Cache by symbol + week + data hash.
- Resume-safe output.
- Deterministic-only/dry-run modes.
- Compact OHLCV JSON instead of chart images.

Typical Google Sheets run
-------------------------
python historical_setup_classifier.py \
  --spreadsheet-id YOUR_SHEET_ID \
  --service-account-file service_account.json \
  --start-date 2026-01-01 \
  --end-date 2026-05-24 \
  --ai-mode sampled \
  --ai-sample-pct 0.10 \
  --min-ai-per-week 80 \
  --output backtest_ai_setups.csv

Typical local CSV test run
--------------------------
python historical_setup_classifier.py \
  --watchlist-csv watchlist.csv \
  --start-date 2026-01-01 \
  --end-date 2026-05-24 \
  --ai-mode sampled \
  --ai-sample-pct 0.10 \
  --output backtest_ai_setups.csv

Environment variables
---------------------
OPENAI_API_KEY       required only when AI is enabled and provider=openai
OPENAI_MODEL         optional, default: gpt-4.1-mini

Optional Google Sheets env alternatives
--------------------------------------
GOOGLE_SHEET_ID
GOOGLE_APPLICATION_CREDENTIALS

Dependencies
------------
pip install pandas numpy yfinance openai gspread google-auth
"""

from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import random
import sys
import time
from dataclasses import asdict, dataclass
from datetime import date
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd
import yfinance as yf

try:
    from openai import OpenAI
except Exception:  # pragma: no cover
    OpenAI = None

try:
    import gspread
except Exception:  # pragma: no cover
    gspread = None


# -----------------------------
# Data models
# -----------------------------


@dataclass
class DeterministicFeatures:
    symbol: str
    yahoo_symbol: str
    week: str
    snapshot_date: str
    close: float
    avg_volume_20d: float
    liquidity_ok: bool
    trend_ma20: float
    trend_ma50: float
    trend_ma200: float
    above_ma20: bool
    above_ma50: bool
    above_ma200: bool
    ret_20d: float
    ret_60d: float
    rs_20d_vs_benchmark: float
    rs_60d_vs_benchmark: float
    atr_pct_14d: float
    atr_pct_20d: float
    atr_pct_60d: float
    volatility_contraction_raw: float
    volume_dryup_raw: float
    near_20d_high_pct: float
    near_60d_high_pct: float
    drawdown_from_60d_high_pct: float
    deterministic_pre_score: float
    deterministic_bucket: str
    deterministic_label: str
    skip_reason: str


@dataclass
class AIClassification:
    decision: str
    grade_0_10: float
    bulkowski_pattern: str
    setup_archetype: str
    trend_stage: str
    relative_strength_score: float
    volume_quality_score: float
    volatility_contraction_score: float
    risk_reward_score: float
    market_dependency: str
    entry: Optional[float]
    stop: Optional[float]
    t1: Optional[float]
    t2: Optional[float]
    suggested_exit_style: str
    stop_comment: str
    target_comment: str
    notes: str
    avoid_reason: str
    raw_json: str


# -----------------------------
# CLI and helpers
# -----------------------------


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Historical setup classifier for Phase A backtesting")

    source = p.add_argument_group("watchlist source")
    source.add_argument("--spreadsheet-id", default=os.environ.get("GOOGLE_SHEET_ID", ""), help="Google Sheet ID")
    source.add_argument("--service-account-file", default=os.environ.get("GOOGLE_APPLICATION_CREDENTIALS", ""), help="Service account JSON file")
    source.add_argument("--watchlist-csv", default="", help="Optional local CSV fallback/test file")
    source.add_argument("--current-watchlist-tab", default="Watchlist")
    source.add_argument("--weekly-watchlist-suffix", default=" Watchlist", help="Historical tab pattern is Y26W01 + suffix")
    source.add_argument("--strict-weekly-tabs", action="store_true", default=True, help="Use only exact weekly tabs like Y26W11 Watchlist; do not fall back to current Watchlist")
    source.add_argument("--skip-missing-weekly-tabs", action="store_true", default=True, help="Skip weeks where the exact weekly Watchlist tab does not exist")

    dates = p.add_argument_group("date range")
    dates.add_argument("--start-date", default="2026-01-01")
    dates.add_argument("--end-date", default=date.today().isoformat())
    dates.add_argument("--benchmark", default="SPY", help="Benchmark for relative strength. QQQ is also useful for Nasdaq-heavy lists.")

    out = p.add_argument_group("outputs")
    out.add_argument("--output", default="backtest_ai_setups.csv")
    out.add_argument("--cache-dir", default=".ai_cache_historical_setups")

    ai = p.add_argument_group("AI sampling and cost control")
    ai.add_argument("--ai-mode", choices=["off", "sampled", "all"], default="sampled")
    ai.add_argument("--ai-sample-pct", type=float, default=0.10, help="Minimum weekly universe percentage to AI-classify. 0.10 = 10%.")
    ai.add_argument("--min-ai-per-week", type=int, default=80, help="Minimum AI selected names per week when available.")
    ai.add_argument("--max-ai-per-week", type=int, default=120, help="Cost safety cap. Set 0 for no cap.")
    ai.add_argument("--exploration-pct", type=float, default=0.25, help="Share of selected names reserved for lower-score/exploratory candidates.")
    ai.add_argument("--bucket-min-per-week", type=int, default=6, help="Try to select at least this many from each deterministic bucket.")
    ai.add_argument("--random-seed", type=int, default=42)
    ai.add_argument("--sleep-between-ai-calls", type=float, default=0.5)

    data = p.add_argument_group("data filters")
    data.add_argument("--min-history-days", type=int, default=180)
    data.add_argument("--lookback-days", type=int, default=260)
    data.add_argument("--min-avg-volume", type=float, default=100_000)
    data.add_argument("--max-symbols", type=int, default=0, help="Debug limit. 0 means no limit.")
    data.add_argument("--dry-run", action="store_true")

    return p.parse_args()


def iso_week_key(d: pd.Timestamp) -> str:
    y, w, _ = d.isocalendar()
    return f"Y{str(y)[-2:]}W{int(w):02d}"


def weekly_fridays(start: str, end: str) -> List[pd.Timestamp]:
    return list(pd.date_range(pd.Timestamp(start).normalize(), pd.Timestamp(end).normalize(), freq="W-FRI"))


def safe_float(x: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if x is None or x == "" or (isinstance(x, float) and math.isnan(x)):
            return default
        return float(x)
    except Exception:
        return default


def hash_dataframe_tail(df: pd.DataFrame, n: int = 90) -> str:
    if df is None or df.empty or not isinstance(df.index, pd.DatetimeIndex):
        return "empty"
    tail = df.tail(n).round(4).to_csv(index=True)
    return hashlib.sha256(tail.encode("utf-8")).hexdigest()[:16]


def normalize_yahoo_symbol(symbol: str) -> str:
    s = str(symbol).strip()
    if ":" in s:
        _exchange, rest = s.split(":", 1)
        return rest.strip()
    return s


def clean_bool(v: Any, default: bool = True) -> bool:
    if v is None or str(v).strip() == "":
        return default
    return str(v).strip().upper() in {"TRUE", "YES", "1", "Y", "ENABLED"}


# -----------------------------
# Watchlist readers
# -----------------------------


def normalize_watchlist_df(df: pd.DataFrame, max_symbols: int = 0) -> pd.DataFrame:
    """Normalize a Watchlist worksheet to a single-column symbol DataFrame.

    Some Google Sheet backup tabs may contain duplicate headers such as multiple
    'symbol' columns. In that case pandas returns a DataFrame for df['symbol'],
    not a Series. We explicitly keep the first usable symbol column.
    """
    if df.empty:
        return pd.DataFrame(columns=["symbol"])

    # Normalize headers and make duplicate names unique enough for safe handling.
    original_columns = list(df.columns)
    normalized_columns = [str(c).strip().lower() for c in original_columns]
    df.columns = normalized_columns

    symbol_positions = [i for i, c in enumerate(normalized_columns) if c == "symbol"]
    if not symbol_positions:
        raise ValueError(f"Watchlist must contain a symbol column. Headers found: {original_columns}")

    symbol_series = df.iloc[:, symbol_positions[0]].astype(str).str.strip()

    enabled_mask = pd.Series([True] * len(df), index=df.index)
    enabled_positions = [i for i, c in enumerate(normalized_columns) if c == "enabled"]
    if enabled_positions:
        enabled_series = df.iloc[:, enabled_positions[0]]
        enabled_mask = enabled_series.apply(lambda x: clean_bool(x, default=True))

    out = pd.DataFrame({"symbol": symbol_series})
    out = out[enabled_mask]
    out = out.dropna(subset=["symbol"])
    out["symbol"] = out["symbol"].astype(str).str.strip()
    out = out[(out["symbol"] != "") & (out["symbol"].str.lower() != "nan")]
    out = out.drop_duplicates(subset=["symbol"])

    if max_symbols and max_symbols > 0:
        out = out.head(max_symbols)
    return out[["symbol"]]


def read_watchlist_csv(path: str, max_symbols: int = 0) -> pd.DataFrame:
    return normalize_watchlist_df(pd.read_csv(path), max_symbols=max_symbols)


def open_gsheet(spreadsheet_id: str, service_account_file: str):
    if gspread is None:
        raise RuntimeError("gspread is not installed. Run: pip install gspread google-auth")
    if service_account_file:
        gc = gspread.service_account(filename=service_account_file)
    else:
        gc = gspread.service_account()
    return gc.open_by_key(spreadsheet_id)


def worksheet_to_df(ws) -> pd.DataFrame:
    values = ws.get_all_values()
    if not values:
        return pd.DataFrame()
    header = values[0]
    rows = values[1:]
    return pd.DataFrame(rows, columns=header)


def find_weekly_watchlist_tab(available_tab_names: set[str], week_key: str) -> Optional[str]:
    """Find weekly Watchlist tab robustly while excluding gem/output tabs.

    Accepts names like:
    - Y26W20 Watchlist
    - Y26W20 Watchlist  (trailing spaces)

    Rejects names like:
    - Y26W20 Output_gem
    - Y26W20 Watchlist_gem
    """
    target = f"{week_key} Watchlist"
    for title in available_tab_names:
        clean = " ".join(str(title).strip().split())
        clean_lower = clean.lower()
        if clean == target and "gem" not in clean_lower and "output" not in clean_lower:
            return title
    return None


def read_watchlist_for_week(
    sh: Any,
    week_key: str,
    weekly_suffix: str,
    current_tab: str,
    fallback_csv: str,
    max_symbols: int,
    strict_weekly_tabs: bool = True,
    available_tab_names: Optional[set[str]] = None,
) -> Tuple[pd.DataFrame, str]:
    """Read the exact weekly Watchlist tab, tolerant to trailing/multiple spaces.

    By default this avoids survivorship bias: if Y26W12 Watchlist is missing,
    we do NOT silently use today's Watchlist.
    """
    if sh is not None:
        if available_tab_names is None:
            available_tab_names = {ws.title for ws in sh.worksheets()}

        matched_tab = find_weekly_watchlist_tab(available_tab_names, week_key)
        tabs_to_try = [matched_tab] if matched_tab else []
        if not strict_weekly_tabs:
            tabs_to_try.append(current_tab)

        for tab in tabs_to_try:
            if not tab:
                continue
            try:
                ws = sh.worksheet(tab)
                return normalize_watchlist_df(worksheet_to_df(ws), max_symbols=max_symbols), tab
            except Exception:
                continue

    if fallback_csv and not strict_weekly_tabs:
        return read_watchlist_csv(fallback_csv, max_symbols=max_symbols), fallback_csv

    raise RuntimeError(f"Missing weekly tab matching: {week_key} Watchlist")


# -----------------------------
# Market data and deterministic features
# -----------------------------


def download_history(symbols: List[str], start: str, end: str) -> Dict[str, pd.DataFrame]:
    data: Dict[str, pd.DataFrame] = {}
    for original in symbols:
        yf_symbol = normalize_yahoo_symbol(original)
        try:
            df = yf.download(
                yf_symbol,
                start=start,
                end=(pd.Timestamp(end) + pd.Timedelta(days=1)).date().isoformat(),
                progress=False,
                auto_adjust=True,
                threads=False,
            )
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            df = df.rename(columns=str.title)
            needed = ["Open", "High", "Low", "Close", "Volume"]
            if df.empty or not all(c in df.columns for c in needed):
                data[original] = pd.DataFrame()
            else:
                data[original] = df[needed].dropna(subset=["Close"])
        except Exception as e:
            print(f"WARN: failed downloading {original}: {e}", file=sys.stderr)
            data[original] = pd.DataFrame()
    return data


def compute_atr_pct(df: pd.DataFrame, window: int) -> pd.Series:
    high = df["High"]
    low = df["Low"]
    close = df["Close"]
    prev_close = close.shift(1)
    tr = pd.concat([(high - low), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
    atr = tr.rolling(window).mean()
    return (atr / close) * 100.0


def pct_change_bars(s: pd.Series, bars: int) -> float:
    s = s.dropna()
    if len(s) <= bars:
        return np.nan
    return ((s.iloc[-1] / s.iloc[-bars - 1]) - 1.0) * 100.0


def assign_bucket(
    liquidity_ok: bool,
    close: float,
    ma20: float,
    ma50: float,
    ma200: float,
    rs20: float,
    vol_contract: float,
    near60: float,
    dd60: float,
    atr20: float,
) -> str:
    if not liquidity_ok:
        return "SKIP_LOW_LIQUIDITY"
    above50 = close > ma50 if not np.isnan(ma50) else False
    above200 = close > ma200 if not np.isnan(ma200) else False
    strong_rs = not np.isnan(rs20) and rs20 >= 3
    contraction = not np.isnan(vol_contract) and vol_contract >= 10
    near_high = not np.isnan(near60) and near60 >= -8
    deep_dd = not np.isnan(dd60) and dd60 <= -18
    high_vol = not np.isnan(atr20) and atr20 >= 4.5

    if above50 and above200 and strong_rs and near_high:
        return "A_STRONG_TREND_RS"
    if contraction and near_high:
        return "B_COMPRESSION_NEAR_HIGH"
    if above50 and not near_high:
        return "C_PULLBACK_CONTINUATION"
    if deep_dd and close > ma20:
        return "D_RECOVERY_REVERSAL"
    if high_vol:
        return "E_HIGH_VOLATILITY"
    if abs(near60) <= 15 or above50:
        return "F_SIDEWAYS_BASE"
    return "G_WEAK_OR_DOWN"


def compute_features(
    symbol: str,
    week_key: str,
    snapshot_date: pd.Timestamp,
    df_full: pd.DataFrame,
    bench_full: pd.DataFrame,
    min_history_days: int,
    lookback_days: int,
    min_avg_volume: float,
) -> DeterministicFeatures:
    yahoo_symbol = normalize_yahoo_symbol(symbol)

    # Some Yahoo failures return an empty DataFrame with a RangeIndex. Check before
    # comparing index values with Timestamp.
    if df_full is None or df_full.empty or not isinstance(df_full.index, pd.DatetimeIndex):
        return DeterministicFeatures(
            symbol, yahoo_symbol, week_key, snapshot_date.date().isoformat(), np.nan, np.nan, False,
            np.nan, np.nan, np.nan, False, False, False, np.nan, np.nan, np.nan, np.nan,
            np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan,
            0.0, "SKIP_NO_PRICE_DATA", "SKIP", "no_price_data"
        )

    if bench_full is None or bench_full.empty or not isinstance(bench_full.index, pd.DatetimeIndex):
        bench = pd.DataFrame()
    else:
        bench = bench_full[bench_full.index <= snapshot_date].tail(lookback_days).copy()

    df = df_full[df_full.index <= snapshot_date].tail(lookback_days).copy()

    if df.empty or len(df) < min_history_days:
        return DeterministicFeatures(
            symbol, yahoo_symbol, week_key, snapshot_date.date().isoformat(), np.nan, np.nan, False,
            np.nan, np.nan, np.nan, False, False, False, np.nan, np.nan, np.nan, np.nan,
            np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan, np.nan,
            0.0, "SKIP_INSUFFICIENT_HISTORY", "SKIP", "insufficient_history"
        )

    close_s = df["Close"]
    volume_s = df["Volume"]
    close = float(close_s.iloc[-1])
    avg_vol_20 = float(volume_s.tail(20).mean())
    liquidity_ok = bool(avg_vol_20 >= min_avg_volume)

    ma20 = float(close_s.rolling(20).mean().iloc[-1])
    ma50 = float(close_s.rolling(50).mean().iloc[-1])
    ma200 = float(close_s.rolling(200).mean().iloc[-1]) if len(close_s) >= 200 else np.nan

    ret20 = pct_change_bars(close_s, 20)
    ret60 = pct_change_bars(close_s, 60)
    bench_close = bench["Close"] if not bench.empty else pd.Series(dtype=float)
    bret20 = pct_change_bars(bench_close, 20)
    bret60 = pct_change_bars(bench_close, 60)
    rs20 = ret20 - bret20 if not np.isnan(ret20) and not np.isnan(bret20) else np.nan
    rs60 = ret60 - bret60 if not np.isnan(ret60) and not np.isnan(bret60) else np.nan

    atr14 = compute_atr_pct(df, 14)
    atr20 = compute_atr_pct(df, 20)
    atr60 = compute_atr_pct(df, 60)
    atr14_last = float(atr14.iloc[-1]) if not np.isnan(atr14.iloc[-1]) else np.nan
    atr20_last = float(atr20.iloc[-1]) if not np.isnan(atr20.iloc[-1]) else np.nan
    atr60_last = float(atr60.iloc[-1]) if not np.isnan(atr60.iloc[-1]) else np.nan
    vol_contract = ((atr60_last - atr20_last) / atr60_last) * 100.0 if atr60_last and not np.isnan(atr60_last) else np.nan

    vol10 = float(volume_s.tail(10).mean())
    vol50 = float(volume_s.tail(50).mean()) if len(volume_s) >= 50 else np.nan
    volume_dryup = ((vol50 - vol10) / vol50) * 100.0 if vol50 and not np.isnan(vol50) else np.nan

    high20 = float(df["High"].tail(20).max())
    high60 = float(df["High"].tail(60).max())
    near20 = ((close / high20) - 1.0) * 100.0 if high20 else np.nan
    near60 = ((close / high60) - 1.0) * 100.0 if high60 else np.nan
    dd60 = near60

    bucket = assign_bucket(liquidity_ok, close, ma20, ma50, ma200, rs20, vol_contract, near60, dd60, atr20_last)

    # Interestingness score, not final trade quality.
    score = 0.0
    if liquidity_ok:
        score += 10
    if close > ma20:
        score += 8
    if close > ma50:
        score += 10
    if not np.isnan(ma200) and close > ma200:
        score += 8
    if not np.isnan(rs20):
        score += max(0, min(15, 7.5 + rs20))
    if not np.isnan(rs60):
        score += max(0, min(12, 6 + rs60 / 3))
    if not np.isnan(vol_contract):
        score += max(0, min(12, 6 + vol_contract / 5))
    if not np.isnan(volume_dryup):
        score += max(0, min(6, 3 + volume_dryup / 12))
    if not np.isnan(near60):
        score += max(0, min(12, 12 + near60))
    # Recovery/high-vol names still need representation.
    if bucket in {"D_RECOVERY_REVERSAL", "E_HIGH_VOLATILITY", "F_SIDEWAYS_BASE"}:
        score += 5

    if not liquidity_ok:
        label = "SKIP"
        skip = "low_liquidity"
    elif score >= 70:
        label = "STRONG_CANDIDATE"
        skip = ""
    elif score >= 55:
        label = "CANDIDATE"
        skip = ""
    elif bucket in {"D_RECOVERY_REVERSAL", "E_HIGH_VOLATILITY", "F_SIDEWAYS_BASE"}:
        label = "EXPLORATORY"
        skip = ""
    else:
        label = "WEAK"
        skip = "weak_deterministic_score"

    return DeterministicFeatures(
        symbol=symbol,
        yahoo_symbol=yahoo_symbol,
        week=week_key,
        snapshot_date=snapshot_date.date().isoformat(),
        close=close,
        avg_volume_20d=avg_vol_20,
        liquidity_ok=liquidity_ok,
        trend_ma20=ma20,
        trend_ma50=ma50,
        trend_ma200=ma200,
        above_ma20=bool(close > ma20),
        above_ma50=bool(close > ma50),
        above_ma200=bool(not np.isnan(ma200) and close > ma200),
        ret_20d=float(ret20) if not np.isnan(ret20) else np.nan,
        ret_60d=float(ret60) if not np.isnan(ret60) else np.nan,
        rs_20d_vs_benchmark=float(rs20) if not np.isnan(rs20) else np.nan,
        rs_60d_vs_benchmark=float(rs60) if not np.isnan(rs60) else np.nan,
        atr_pct_14d=atr14_last,
        atr_pct_20d=atr20_last,
        atr_pct_60d=atr60_last,
        volatility_contraction_raw=float(vol_contract) if not np.isnan(vol_contract) else np.nan,
        volume_dryup_raw=float(volume_dryup) if not np.isnan(volume_dryup) else np.nan,
        near_20d_high_pct=float(near20) if not np.isnan(near20) else np.nan,
        near_60d_high_pct=float(near60) if not np.isnan(near60) else np.nan,
        drawdown_from_60d_high_pct=float(dd60) if not np.isnan(dd60) else np.nan,
        deterministic_pre_score=round(float(score), 2),
        deterministic_bucket=bucket,
        deterministic_label=label,
        skip_reason=skip,
    )


# -----------------------------
# AI selection
# -----------------------------


def select_ai_universe(
    features: List[DeterministicFeatures],
    sample_pct: float,
    min_ai: int,
    max_ai: int,
    exploration_pct: float,
    bucket_min: int,
    rng: random.Random,
) -> List[str]:
    eligible = [f for f in features if f.deterministic_label != "SKIP"]
    if not eligible:
        return []

    target = max(min_ai, math.ceil(len(features) * sample_pct))
    target = min(target, len(eligible))
    if max_ai and max_ai > 0:
        target = min(target, max_ai)

    selected: Dict[str, DeterministicFeatures] = {}

    # 1) Bucket diversity first.
    buckets: Dict[str, List[DeterministicFeatures]] = {}
    for f in eligible:
        buckets.setdefault(f.deterministic_bucket, []).append(f)
    for bucket_items in buckets.values():
        bucket_items.sort(key=lambda x: x.deterministic_pre_score, reverse=True)
        for f in bucket_items[:bucket_min]:
            if len(selected) < target:
                selected[f.symbol] = f

    # 2) Exploitation: best overall scores.
    exploitation_target = int(round(target * (1.0 - exploration_pct)))
    ranked = sorted(eligible, key=lambda x: x.deterministic_pre_score, reverse=True)
    for f in ranked:
        if len(selected) >= exploitation_target:
            break
        selected[f.symbol] = f

    # 3) Exploration: random from remaining, weighted toward underrepresented/weaker categories.
    remaining = [f for f in eligible if f.symbol not in selected]
    rng.shuffle(remaining)
    exploratory_pool = [f for f in remaining if f.deterministic_label in {"EXPLORATORY", "WEAK"}]
    exploratory_pool += [f for f in remaining if f not in exploratory_pool]
    for f in exploratory_pool:
        if len(selected) >= target:
            break
        selected[f.symbol] = f

    return list(selected.keys())


# -----------------------------
# AI prompt/call/cache
# -----------------------------


def compact_ohlcv_payload(df_full: pd.DataFrame, snapshot_date: pd.Timestamp, bars: int = 90) -> str:
    if df_full is None or df_full.empty or not isinstance(df_full.index, pd.DatetimeIndex):
        return "[]"
    df = df_full[df_full.index <= snapshot_date].tail(bars).copy()
    if df.empty:
        return "[]"
    df = df[["Open", "High", "Low", "Close", "Volume"]].round(4)
    df.index = pd.to_datetime(df.index).date.astype(str)
    rows = [[idx, r.Open, r.High, r.Low, r.Close, int(r.Volume)] for idx, r in df.iterrows()]
    return json.dumps(rows, separators=(",", ":"))


def ai_cache_path(cache_dir: Path, symbol: str, week: str, data_hash: str) -> Path:
    safe_symbol = symbol.replace(":", "_").replace("/", "_")
    return cache_dir / f"{safe_symbol}_{week}_{data_hash}.json"


def build_ai_prompt(symbol: str, features: DeterministicFeatures, ohlcv_json: str) -> str:
    return f"""
You are classifying a historical weekly swing-trading setup using ONLY data up to the snapshot date.
Do not use future knowledge. Do not assume anything after the snapshot date.

Trading style to evaluate:
- short/mid-term swing trade
- intended holding period up to about 1 month
- target gain usually 5-10%
- strict stop often 1-2%

Critical research objective:
We are not only checking if a pattern exists. We are also collecting evidence to later test whether:
- stops are too tight or reasonable;
- targets are too optimistic or realistic;
- certain setup archetypes need different stop/target methodology;
- ATR-based stops or trailing exits would be better than fixed percentage stops.

Return STRICT JSON only. No markdown.

Symbol: {symbol}
Snapshot date: {features.snapshot_date}
Close at snapshot: {features.close}

Deterministic context:
{json.dumps(asdict(features), default=str, separators=(",", ":"))}

OHLCV rows, last 90 trading bars ending at snapshot.
Format: [date, open, high, low, close, volume]
{ohlcv_json}

Allowed decision values:
- TRADE
- FUTURE_SETUP
- NO_TRADE

Allowed setup_archetype examples:
- COMPRESSION_BREAKOUT
- BASE_BREAKOUT
- PULLBACK_CONTINUATION
- RS_LEADER
- MEAN_REVERSION
- FAILED_BREAKOUT_RECOVERY
- DEFENSIVE_PULLBACK
- EXTENDED_AVOID
- CHOP_AVOID
- NO_CLEAR_SETUP

Allowed trend_stage values:
- EARLY
- MID
- LATE
- EXHAUSTED
- DOWN_TREND
- SIDEWAYS
- UNKNOWN

Allowed suggested_exit_style examples:
- FIXED_T1_T2
- TIGHT_STOP_FAST_TARGET
- ATR_STOP
- TRAILING_AFTER_T1
- EMA10_EXIT
- TIME_EXIT
- AVOID_NO_EDGE

JSON schema:
{{
  "decision": "TRADE|FUTURE_SETUP|NO_TRADE",
  "grade_0_10": number,
  "bulkowski_pattern": "string or NONE",
  "setup_archetype": "string",
  "trend_stage": "string",
  "relative_strength_score": number,
  "volume_quality_score": number,
  "volatility_contraction_score": number,
  "risk_reward_score": number,
  "market_dependency": "NEEDS_BULL|WORKS_IN_MIXED|DEFENSIVE|AVOID_IN_WEAK_MARKET|UNKNOWN",
  "entry": number or null,
  "stop": number or null,
  "t1": number or null,
  "t2": number or null,
  "suggested_exit_style": "string",
  "stop_comment": "short comment on whether stop should be tight, ATR-based, below structure, or avoided",
  "target_comment": "short comment on whether targets look realistic or optimistic",
  "notes": "short explanation",
  "avoid_reason": "short reason or empty"
}}

Rules:
- Scores must be 0-10.
- If no clean setup exists, decision must be NO_TRADE.
- If setup is interesting but price is not close to entry, use FUTURE_SETUP.
- Prefer practical price levels, not false precision.
- Do not force fixed 1-2% stops if chart structure clearly requires wider risk; record that in stop_comment.
""".strip()


def call_openai_json(prompt: str, model: str) -> Dict[str, Any]:
    if OpenAI is None:
        raise RuntimeError("openai package is not installed. Run: pip install openai")
    client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
    resp = client.chat.completions.create(
        model=model,
        temperature=0.0,
        response_format={"type": "json_object"},
        messages=[
            {"role": "system", "content": "You are a disciplined technical-analysis classifier. Return valid JSON only."},
            {"role": "user", "content": prompt},
        ],
    )
    return json.loads(resp.choices[0].message.content or "{}")


def parse_ai_classification(obj: Dict[str, Any]) -> AIClassification:
    def score(name: str) -> float:
        val = safe_float(obj.get(name), 0.0) or 0.0
        return max(0.0, min(10.0, val))

    return AIClassification(
        decision=str(obj.get("decision", "NO_TRADE")).upper(),
        grade_0_10=score("grade_0_10"),
        bulkowski_pattern=str(obj.get("bulkowski_pattern", "NONE")),
        setup_archetype=str(obj.get("setup_archetype", "UNKNOWN")),
        trend_stage=str(obj.get("trend_stage", "UNKNOWN")),
        relative_strength_score=score("relative_strength_score"),
        volume_quality_score=score("volume_quality_score"),
        volatility_contraction_score=score("volatility_contraction_score"),
        risk_reward_score=score("risk_reward_score"),
        market_dependency=str(obj.get("market_dependency", "UNKNOWN")),
        entry=safe_float(obj.get("entry")),
        stop=safe_float(obj.get("stop")),
        t1=safe_float(obj.get("t1")),
        t2=safe_float(obj.get("t2")),
        suggested_exit_style=str(obj.get("suggested_exit_style", "UNKNOWN")),
        stop_comment=str(obj.get("stop_comment", ""))[:500],
        target_comment=str(obj.get("target_comment", ""))[:500],
        notes=str(obj.get("notes", ""))[:1000],
        avoid_reason=str(obj.get("avoid_reason", ""))[:500],
        raw_json=json.dumps(obj, ensure_ascii=False),
    )


def empty_ai(reason: str = "AI_NOT_RUN") -> AIClassification:
    return AIClassification(
        decision="NOT_CLASSIFIED",
        grade_0_10=0.0,
        bulkowski_pattern="",
        setup_archetype="",
        trend_stage="",
        relative_strength_score=0.0,
        volume_quality_score=0.0,
        volatility_contraction_score=0.0,
        risk_reward_score=0.0,
        market_dependency="",
        entry=None,
        stop=None,
        t1=None,
        t2=None,
        suggested_exit_style="",
        stop_comment=reason,
        target_comment=reason,
        notes=reason,
        avoid_reason=reason,
        raw_json="{}",
    )


def enrich_methodology_metrics(row: Dict[str, Any]) -> Dict[str, Any]:
    close = safe_float(row.get("close"))
    atr_pct_14d = safe_float(row.get("atr_pct_14d"))
    entry = safe_float(row.get("ai_entry"))
    stop = safe_float(row.get("ai_stop"))
    t1 = safe_float(row.get("ai_t1"))
    t2 = safe_float(row.get("ai_t2"))

    def pct(a: Optional[float], b: Optional[float]) -> Optional[float]:
        if a is None or b is None or b == 0:
            return None
        return ((a / b) - 1.0) * 100.0

    stop_pct_from_entry = pct(stop, entry) if stop and entry else None
    t1_pct_from_entry = pct(t1, entry) if t1 and entry else None
    t2_pct_from_entry = pct(t2, entry) if t2 and entry else None
    entry_distance_pct = pct(entry, close) if entry and close else None

    risk = abs(entry - stop) if entry and stop else None
    reward1 = abs(t1 - entry) if entry and t1 else None
    reward2 = abs(t2 - entry) if entry and t2 else None

    row["entry_distance_pct"] = round(entry_distance_pct, 4) if entry_distance_pct is not None else ""
    row["stop_pct_from_entry"] = round(stop_pct_from_entry, 4) if stop_pct_from_entry is not None else ""
    row["t1_pct_from_entry"] = round(t1_pct_from_entry, 4) if t1_pct_from_entry is not None else ""
    row["t2_pct_from_entry"] = round(t2_pct_from_entry, 4) if t2_pct_from_entry is not None else ""
    row["rr_to_t1"] = round(reward1 / risk, 4) if risk and reward1 else ""
    row["rr_to_t2"] = round(reward2 / risk, 4) if risk and reward2 else ""
    row["stop_atr_multiple"] = round(abs(stop_pct_from_entry) / atr_pct_14d, 4) if stop_pct_from_entry and atr_pct_14d else ""

    # Flags for later analysis, not decisions here.
    row["stop_tight_flag"] = bool(stop_pct_from_entry is not None and abs(stop_pct_from_entry) <= 2.0)
    row["target_optimistic_flag"] = bool(t1_pct_from_entry is not None and t1_pct_from_entry >= 8.0)
    row["target_very_optimistic_flag"] = bool(t2_pct_from_entry is not None and t2_pct_from_entry >= 15.0)
    return row


# -----------------------------
# Output helpers
# -----------------------------


def load_existing_keys(output_path: Path) -> set[Tuple[str, str]]:
    if not output_path.exists():
        return set()
    try:
        df = pd.read_csv(output_path, usecols=["week", "symbol"])
        return set(zip(df["week"].astype(str), df["symbol"].astype(str)))
    except Exception:
        return set()


def append_rows_csv(output_path: Path, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    output_path.parent.mkdir(parents=True, exist_ok=True)
    exists = output_path.exists()
    with output_path.open("a", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        if not exists:
            writer.writeheader()
        for row in rows:
            writer.writerow(row)


# -----------------------------
# Main flow
# -----------------------------


def main() -> int:
    args = parse_args()
    rng = random.Random(args.random_seed)
    output_path = Path(args.output)
    cache_dir = Path(args.cache_dir)
    cache_dir.mkdir(parents=True, exist_ok=True)

    if args.ai_mode != "off" and not os.environ.get("OPENAI_API_KEY"):
        raise RuntimeError("OPENAI_API_KEY is required unless --ai-mode off")

    model = os.environ.get("OPENAI_MODEL", "gpt-4.1-mini")

    sh = None
    if args.spreadsheet_id:
        sh = open_gsheet(args.spreadsheet_id, args.service_account_file)
        print(f"Connected to Google Sheet {args.spreadsheet_id}")
    elif not args.watchlist_csv:
        raise RuntimeError("Provide either --spreadsheet-id or --watchlist-csv")

    weeks = weekly_fridays(args.start_date, args.end_date)
    existing_keys = load_existing_keys(output_path)
    print(f"Processing {len(weeks)} weekly snapshots from {args.start_date} to {args.end_date}")
    print(f"AI mode={args.ai_mode}; sample_pct={args.ai_sample_pct:.2%}; min_ai={args.min_ai_per_week}; max_ai={args.max_ai_per_week}")
    print("Weekly snapshot dates:", ", ".join([f"{iso_week_key(w)}={w.date()}" for w in weeks]))

    # Discover actual sheet tabs and only use exact historical Watchlist tabs.
    available_tab_names: set[str] = set()
    if sh is not None:
        available_tab_names = {ws.title for ws in sh.worksheets()}
        exact_weekly_tabs = sorted([
            t for t in available_tab_names
            if find_weekly_watchlist_tab(available_tab_names, str(t).strip().split()[0]) == t
        ])
        print(f"Exact weekly Watchlist tabs found: {len(exact_weekly_tabs)}")
        if exact_weekly_tabs:
            print("Weekly tabs:", ", ".join(exact_weekly_tabs))
        else:
            sample_tabs = sorted(list(available_tab_names))[:30]
            print("No exact weekly Watchlist tabs found. First tabs in spreadsheet:", sample_tabs)

    # Build union of symbols across available weekly tabs first, so yfinance downloads once per symbol.
    weekly_watchlists: Dict[str, Tuple[pd.DataFrame, str]] = {}
    valid_weeks: List[pd.Timestamp] = []
    symbol_union: set[str] = set()

    for snapshot_date in weeks:
        week_key = iso_week_key(snapshot_date)
        expected_tab = f"{week_key}{args.weekly_watchlist_suffix}"
        matched_tab = find_weekly_watchlist_tab(available_tab_names, week_key) if sh is not None else None

        if sh is not None and not matched_tab:
            near_tabs = sorted([repr(t) for t in available_tab_names if str(t).strip().startswith(week_key)])
            print(f"{week_key}: SKIP - Missing weekly tab matching '{week_key} Watchlist'. Near tabs: {near_tabs}")
            continue

        try:
            if sh is not None and matched_tab:
                ws = sh.worksheet(matched_tab)
                wl = normalize_watchlist_df(worksheet_to_df(ws), max_symbols=args.max_symbols)
                source_name = matched_tab
            else:
                wl, source_name = read_watchlist_for_week(
                    sh,
                    week_key,
                    args.weekly_watchlist_suffix,
                    args.current_watchlist_tab,
                    args.watchlist_csv,
                    args.max_symbols,
                    strict_weekly_tabs=True,
                    available_tab_names=available_tab_names,
                )
        except Exception as e:
            print(f"{week_key}: SKIP - failed reading tab {matched_tab or expected_tab}: {e}")
            continue

        weekly_watchlists[week_key] = (wl, source_name)
        valid_weeks.append(snapshot_date)
        symbol_union.update(wl["symbol"].tolist())
        print(f"{week_key}: watchlist symbols={len(wl)} source={source_name}")

    if not valid_weeks:
        raise RuntimeError(
            "No weekly Watchlist tabs were loaded. Check that tabs are exactly like 'Y26W11 Watchlist' "
            "and that --weekly-watchlist-suffix is exactly ' Watchlist'."
        )

    all_symbols = sorted(symbol_union) + [args.benchmark]
    download_start = (pd.Timestamp(args.start_date) - pd.Timedelta(days=args.lookback_days + 30)).date().isoformat()
    print(f"Downloading OHLCV for {len(all_symbols)} symbols from {download_start} to {args.end_date}")
    histories = download_history(all_symbols, download_start, args.end_date)
    benchmark_hist = histories.get(args.benchmark, pd.DataFrame())

    total_ai_calls = 0
    total_rows = 0

    for snapshot_date in valid_weeks:
        week_key = iso_week_key(snapshot_date)
        wl, source_name = weekly_watchlists[week_key]
        symbols = wl["symbol"].tolist()

        week_features: List[Tuple[DeterministicFeatures, pd.DataFrame]] = []
        for symbol in symbols:
            if (week_key, symbol) in existing_keys:
                continue
            df_full = histories.get(symbol, pd.DataFrame())
            f = compute_features(
                symbol=symbol,
                week_key=week_key,
                snapshot_date=snapshot_date,
                df_full=df_full,
                bench_full=benchmark_hist,
                min_history_days=args.min_history_days,
                lookback_days=args.lookback_days,
                min_avg_volume=args.min_avg_volume,
            )
            week_features.append((f, df_full))

        if args.ai_mode == "all":
            ai_symbols = [f.symbol for f, _ in week_features if f.deterministic_label != "SKIP"]
        elif args.ai_mode == "sampled":
            ai_symbols = select_ai_universe(
                [f for f, _ in week_features],
                sample_pct=args.ai_sample_pct,
                min_ai=args.min_ai_per_week,
                max_ai=args.max_ai_per_week,
                exploration_pct=args.exploration_pct,
                bucket_min=args.bucket_min_per_week,
                rng=rng,
            )
        else:
            ai_symbols = []
        ai_allowed = set(ai_symbols)

        rows: List[Dict[str, Any]] = []
        for features, df_full in week_features:
            ai_obj = empty_ai("AI_NOT_SELECTED_BY_FILTER")
            ai_was_run = False
            data_hash = ""

            if args.ai_mode != "off" and features.symbol in ai_allowed and not df_full.empty:
                data_hash = hash_dataframe_tail(df_full[df_full.index <= snapshot_date], 90)
                cpath = ai_cache_path(cache_dir, features.symbol, week_key, data_hash)
                if cpath.exists():
                    try:
                        cached = json.loads(cpath.read_text(encoding="utf-8"))
                        ai_obj = parse_ai_classification(cached)
                    except Exception as e:
                        print(f"WARN: bad cache {cpath}: {e}", file=sys.stderr)
                elif not args.dry_run:
                    try:
                        prompt = build_ai_prompt(features.symbol, features, compact_ohlcv_payload(df_full, snapshot_date, bars=90))
                        raw = call_openai_json(prompt, model=model)
                        ai_obj = parse_ai_classification(raw)
                        cpath.write_text(json.dumps(raw, ensure_ascii=False, indent=2), encoding="utf-8")
                        ai_was_run = True
                        total_ai_calls += 1
                        time.sleep(args.sleep_between_ai_calls)
                    except Exception as e:
                        print(f"ERROR: AI failed for {features.symbol} {week_key}: {e}", file=sys.stderr)
                        ai_obj = empty_ai(f"AI_ERROR: {e}")
                else:
                    ai_obj = empty_ai("DRY_RUN_AI_SKIPPED")

            row = {
                **asdict(features),
                **{f"ai_{k}": v for k, v in asdict(ai_obj).items()},
                "watchlist_source": source_name,
                "weekly_universe_size": len(symbols),
                "ai_selected": features.symbol in ai_allowed,
                "ai_was_run": ai_was_run,
                "ai_cache_hash": data_hash,
            }
            row = enrich_methodology_metrics(row)
            rows.append(row)

        if not args.dry_run:
            append_rows_csv(output_path, rows)
        total_rows += len(rows)
        print(
            f"{week_key} {snapshot_date.date()}: rows={len(rows)}, universe={len(symbols)}, "
            f"ai_selected={len(ai_allowed)}, new_ai_calls={total_ai_calls}"
        )

    print(f"Done. rows={total_rows}, new_ai_calls={total_ai_calls}, output={output_path}")
    if args.dry_run:
        print("Dry run only: no output file was written and no AI calls were made.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
