#!/usr/bin/env python3
"""
AutoTrader - Global Opportunity Validation, Phase 3

Reads the already-created GlobalOppBacktestTrades output from Phase 2 v5.
It DOES NOT recalculate Global Opportunity and DOES NOT use Yahoo/OpenAI.

Goal:
Test whether trade quality changes systematically with the frozen market
environment, especially:
  PRIORITY -> ACTIVE -> SELECTIVE -> AVOID

Outputs:
  GlobalOppAnalysisStatus
  GlobalOppAnalysisMarket
  GlobalOppAnalysisScore
  GlobalOppAnalysisWeekly
  GlobalOppAnalysisKeptRejected

All monetary results assume the Phase-2 experiment's flat €1,000 full trade.
"""

import os
import re
import numpy as np
import pandas as pd
import gspread
from google.oauth2.service_account import Credentials

SHEET_ID = os.getenv(
    "SHEET_ID_PROD",
    "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg"
)

SERVICE_ACCOUNT_JSON = os.getenv(
    "SERVICE_ACCOUNT_JSON_PROD",
    "bottrader-494519-30132dfab247.json"
)

INPUT_TAB = os.getenv("GLOBAL_OPP_ANALYSIS_INPUT", "GlobalOppBacktestTrades")
OUT_STATUS = "GlobalOppAnalysisStatus"
OUT_MARKET = "GlobalOppAnalysisMarket"
OUT_SCORE = "GlobalOppAnalysisScore"
OUT_WEEKLY = "GlobalOppAnalysisWeekly"
OUT_KEEP = "GlobalOppAnalysisKeptRejected"

FLAT_EUR = float(os.getenv("GLOBAL_OPP_BT_FLAT_TRADE_EUR", "1000"))

STATUS_ORDER = ["PRIORITY", "ACTIVE", "SELECTIVE", "AVOID"]


def txt(x):
    return str(x if x is not None else "").strip()


def num(x):
    if x is None:
        return np.nan
    s = txt(x).replace("€", "").replace("%", "").replace(" ", "")
    if not s:
        return np.nan
    if "," in s and "." not in s:
        s = s.replace(",", ".")
    elif "," in s and "." in s:
        s = s.replace(",", "")
    try:
        v = float(s)
        return v if np.isfinite(v) else np.nan
    except Exception:
        return np.nan


def boolish(x):
    if isinstance(x, bool):
        return x
    return txt(x).lower() in {"true", "1", "yes", "y"}


def connect():
    creds = Credentials.from_service_account_file(
        SERVICE_ACCOUNT_JSON,
        scopes=["https://www.googleapis.com/auth/spreadsheets"]
    )
    return gspread.authorize(creds).open_by_key(SHEET_ID)


def read_df(sh, tab):
    ws = sh.worksheet(tab)
    vals = ws.get_all_values()
    if not vals:
        return pd.DataFrame()
    headers = vals[0]
    rows = [(r + [""] * len(headers))[:len(headers)] for r in vals[1:]]
    return pd.DataFrame(rows, columns=headers)


def safe_cell(x):
    if x is None:
        return ""
    if isinstance(x, (np.floating, float)):
        return "" if not np.isfinite(float(x)) else float(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    try:
        if pd.isna(x):
            return ""
    except Exception:
        pass
    if isinstance(x, pd.Timestamp):
        return x.strftime("%Y-%m-%d")
    return x


def write_df(sh, tab, df):
    try:
        ws = sh.worksheet(tab)
        ws.clear()
    except gspread.exceptions.WorksheetNotFound:
        ws = sh.add_worksheet(
            title=tab,
            rows=max(100, len(df) + 20),
            cols=max(20, len(df.columns) + 5)
        )

    if df.empty:
        ws.update([["No rows"]], "A1")
        return

    out = df.astype(object).copy()
    for c in out.columns:
        out[c] = out[c].map(safe_cell)
    values = [list(out.columns)] + out.values.tolist()
    ws.resize(
        rows=max(100, len(values) + 10),
        cols=max(20, len(out.columns) + 3)
    )
    ws.update(values, "A1", value_input_option="USER_ENTERED")
    ws.freeze(rows=1)


def prepare(df):
    required = [
        "symbol", "entry_date", "market", "global_status",
        "global_score", "global_rank", "derived_pnl_pct",
        "derived_pnl_cash", "t1_hit", "stop_hit", "pnl_eligible"
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(
            f"{INPUT_TAB} missing required columns: {missing}\n"
            f"Available: {list(df.columns)}"
        )

    d = df.copy()
    d["global_status"] = d["global_status"].map(lambda x: txt(x).upper())
    d["market"] = d["market"].map(lambda x: txt(x).upper())
    d["global_score"] = d["global_score"].map(num)
    d["global_rank"] = d["global_rank"].map(num)
    d["pnl_pct"] = d["derived_pnl_pct"].map(num)
    d["pnl_eur"] = d["derived_pnl_cash"].map(num)
    d["t1"] = d["t1_hit"].map(boolish)
    d["stop"] = d["stop_hit"].map(boolish)
    d["eligible"] = d["pnl_eligible"].map(boolish)
    d["entry_dt"] = pd.to_datetime(
        d["entry_date"], errors="coerce", dayfirst=True, format="mixed"
    )

    # Keep only resolved trades for outcome comparisons.
    d = d[d["eligible"] & d["pnl_pct"].notna()].copy()
    d["win"] = d["pnl_pct"] > 0
    d["loss"] = d["pnl_pct"] < 0

    # Equal-notional safety: derive EUR from percentage if the previous output
    # lacks it for any reason.
    d["pnl_eur"] = d["pnl_eur"].where(
        d["pnl_eur"].notna(), FLAT_EUR * d["pnl_pct"] / 100.0
    )

    d["score_bucket"] = pd.cut(
        d["global_score"],
        [-np.inf, 4.5, 5.5, 6.5, 7.0, 8.0, np.inf],
        labels=["<4.5", "4.5-5.49", "5.5-6.49", "6.5-6.99", "7.0-7.99", ">=8.0"],
        right=False
    ).astype(str)

    return d


def max_dd_eur(values):
    eq = np.r_[0.0, np.cumsum(np.asarray(values, dtype=float))]
    peak = np.maximum.accumulate(eq)
    return float(np.min(eq - peak))


def summary(group):
    p = group["pnl_pct"].dropna()
    pe = group["pnl_eur"].dropna()
    return pd.Series({
        "trades": len(group),
        "wins": int(group["win"].sum()),
        "losses": int(group["loss"].sum()),
        "win_rate_pct": 100.0 * group["win"].mean() if len(group) else np.nan,
        "t1_hits": int(group["t1"].sum()),
        "t1_rate_pct": 100.0 * group["t1"].mean() if len(group) else np.nan,
        "stop_hits": int(group["stop"].sum()),
        "stop_rate_pct": 100.0 * group["stop"].mean() if len(group) else np.nan,
        "avg_pnl_pct": p.mean() if len(p) else np.nan,
        "median_pnl_pct": p.median() if len(p) else np.nan,
        "total_pnl_eur": pe.sum() if len(pe) else np.nan,
        "expectancy_eur_per_trade": pe.mean() if len(pe) else np.nan,
        "max_drawdown_eur_additive": max_dd_eur(pe.values) if len(pe) else np.nan,
        "avg_global_score": group["global_score"].mean(),
        "avg_global_rank": group["global_rank"].mean(),
    })


def grouped_summary(d, cols):
    result = d.groupby(cols, dropna=False).apply(
        summary, include_groups=False
    ).reset_index()
    return result


def kept_rejected(d):
    """
    Diagnose what Scenario A/B remove, not merely their aggregate result.
    B is separated into full / half / rejected.
    """
    rows = []

    masks = {
        "A_KEPT_PRIORITY_ACTIVE": d["global_status"].isin(["PRIORITY", "ACTIVE"]),
        "A_REJECTED_SELECTIVE_AVOID": d["global_status"].isin(["SELECTIVE", "AVOID"]),
        "B_FULL_PRIORITY_ACTIVE": d["global_status"].isin(["PRIORITY", "ACTIVE"]),
        "B_HALF_SELECTIVE": d["global_status"].eq("SELECTIVE"),
        "B_REJECTED_AVOID": d["global_status"].eq("AVOID"),
    }

    for label, mask in masks.items():
        g = d[mask].copy()
        if g.empty:
            continue
        s = summary(g).to_dict()
        s["group"] = label
        s["share_of_all_trades_pct"] = 100.0 * len(g) / len(d)

        # Explicitly show winners/losers accepted/rejected.
        s["winner_pnl_eur"] = g.loc[g["win"], "pnl_eur"].sum()
        s["loser_pnl_eur"] = g.loc[g["loss"], "pnl_eur"].sum()
        s["zero_pnl_trades"] = int((g["pnl_pct"] == 0).sum())
        rows.append(s)

    out = pd.DataFrame(rows)
    if not out.empty:
        first = ["group", "share_of_all_trades_pct"]
        out = out[first + [c for c in out.columns if c not in first]]
    return out


def add_monotonic_diagnostics(status_df):
    """
    Adds simple adjacent comparisons. We do not claim significance from these;
    they are descriptive checks of the expected ordering.
    """
    if status_df.empty:
        return status_df

    order_map = {s: i + 1 for i, s in enumerate(STATUS_ORDER)}
    status_df["expected_strength_order"] = status_df["global_status"].map(order_map)
    status_df = status_df.sort_values("expected_strength_order").reset_index(drop=True)

    status_df["expectancy_change_vs_stronger_eur"] = (
        status_df["expectancy_eur_per_trade"].diff()
    )
    status_df["win_rate_change_vs_stronger_pp"] = (
        status_df["win_rate_pct"].diff()
    )
    status_df["t1_rate_change_vs_stronger_pp"] = (
        status_df["t1_rate_pct"].diff()
    )
    status_df["stop_rate_change_vs_stronger_pp"] = (
        status_df["stop_rate_pct"].diff()
    )
    return status_df


def main():
    print("=== Global Opportunity Validation / Phase 3 ===")
    print("No market scores are recalculated. No Yahoo/OpenAI calls.")
    print(f"Input: {INPUT_TAB}")
    print(f"Equal notional: EUR {FLAT_EUR:,.0f} per full trade")
    print()

    sh = connect()
    raw = read_df(sh, INPUT_TAB)
    d = prepare(raw)

    print(f"Resolved/eligible trades analysed: {len(d)}")

    status = grouped_summary(d, ["global_status"])
    status = add_monotonic_diagnostics(status)

    market = grouped_summary(d, ["market", "global_status"])
    market = market.sort_values(
        ["market", "global_status"]
    ).reset_index(drop=True)

    score = grouped_summary(d, ["score_bucket"])

    # Week-by-week view to see whether one or two weeks dominate the finding.
    if "global_iso_week" in d.columns:
        weekly = grouped_summary(d, ["global_iso_week", "global_status"])
    else:
        d["entry_week"] = d["entry_dt"].map(
            lambda x: (
                f"{x.isocalendar().year}-W{x.isocalendar().week:02d}"
                if pd.notna(x) else ""
            )
        )
        weekly = grouped_summary(d, ["entry_week", "global_status"])

    keep = kept_rejected(d)

    print()
    print("Status test:")
    display_cols = [
        "global_status", "trades", "win_rate_pct", "t1_rate_pct",
        "stop_rate_pct", "expectancy_eur_per_trade", "total_pnl_eur",
        "max_drawdown_eur_additive"
    ]
    print(status[display_cols].to_string(index=False))

    print()
    print("Kept/rejected diagnostic:")
    keep_cols = [
        "group", "trades", "wins", "losses",
        "expectancy_eur_per_trade", "total_pnl_eur",
        "winner_pnl_eur", "loser_pnl_eur"
    ]
    print(keep[keep_cols].to_string(index=False))

    print()
    print("Writing analysis tabs...")
    write_df(sh, OUT_STATUS, status)
    write_df(sh, OUT_MARKET, market)
    write_df(sh, OUT_SCORE, score)
    write_df(sh, OUT_WEEKLY, weekly)
    write_df(sh, OUT_KEEP, keep)

    print("Done.")
    print("Created/updated:")
    for x in [OUT_STATUS, OUT_MARKET, OUT_SCORE, OUT_WEEKLY, OUT_KEEP]:
        print(" -", x)

    print()
    print(
        "Primary test: check whether expectancy/win/T1 generally deteriorate "
        "from PRIORITY -> ACTIVE -> SELECTIVE -> AVOID, and whether the effect "
        "is repeated across markets/weeks rather than driven by one subgroup."
    )


if __name__ == "__main__":
    main()
