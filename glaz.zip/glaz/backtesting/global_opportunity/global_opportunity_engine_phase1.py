#!/usr/bin/env python3
"""
AutoTrader Global Opportunity Engine - Phase 1 / independent market evaluation

Purpose
-------
Reconstruct weekly "WHERE should we look for LONG trades?" market conditions
WITHOUT using Trades outcomes. This is intentionally the first, non-circular
experiment before comparing the scores with actual trade results.

Inputs
------
1) Google Sheet Security Metadata (same workbook as AutoTrader)
   - symbol / yahoo_symbol
   - country / region / asset_type where available
   - local_benchmark / regional_benchmark / sector_group
2) Yahoo Finance daily OHLCV
3) Optional explicit market definitions below for countries/assets that are
   not sufficiently represented by Security Metadata.

Outputs (new Google Sheet tabs)
-------------------------------
GlobalOpportunityWeekly
GlobalOpportunityLatest

The script DOES NOT read Trades in Phase 1.
"""

import os
import math
import time
from datetime import date, datetime, timedelta, timezone
from collections import defaultdict

import numpy as np
import pandas as pd
import yfinance as yf
import gspread
from google.oauth2.service_account import Credentials


# ============================================================
# CONFIG - aligned with the existing AutoTrader workbook
# ============================================================
SHEET_ID = os.getenv("SHEET_ID_PROD", "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg")
SERVICE_ACCOUNT_JSON = os.getenv(
    "SERVICE_ACCOUNT_JSON_PROD", "bottrader-494519-30132dfab247.json"
)

SECURITY_METADATA_TAB = os.getenv("SECURITY_METADATA_TAB", "Security Metadata")
OUTPUT_WEEKLY_TAB = os.getenv("GLOBAL_OPP_WEEKLY_TAB", "GlobalOpportunityWeekly")
OUTPUT_LATEST_TAB = os.getenv("GLOBAL_OPP_LATEST_TAB", "GlobalOpportunityLatest")

# Default: 3 months of weekly observations. Increase to 180/365 for research.
LOOKBACK_DAYS = int(os.getenv("GLOBAL_OPP_LOOKBACK_DAYS", "100"))
PRICE_HISTORY_DAYS = int(os.getenv("GLOBAL_OPP_PRICE_HISTORY_DAYS", "420"))

# Minimum constituents required before constituent breadth is trusted.
MIN_BREADTH_STOCKS = int(os.getenv("GLOBAL_OPP_MIN_BREADTH_STOCKS", "8"))

# Common benchmark for cross-market relative strength.
GLOBAL_REFERENCE = os.getenv("GLOBAL_OPP_GLOBAL_REFERENCE", "ACWI")

# Initial weights are deliberately transparent starting hypotheses.
# We should freeze these BEFORE opening the Trades outcomes, then validate.
W_TREND = 0.25
W_RS = 0.25
W_ACCEL = 0.15
W_BREADTH = 0.20
W_RISK = 0.15

# Classification thresholds are research defaults, not production gates.
PRIORITY_MIN = 8.0
ACTIVE_MIN = 7.0
SELECTIVE_MIN = 5.5


# ============================================================
# MARKET DEFINITIONS
#
# benchmark = market/asset proxy whose OHLCV defines trend/risk.
# Yahoo symbols are intentionally configurable: if one is unavailable in
# your environment, change only this table rather than the scoring code.
#
# execution tells us where we could ultimately execute. It does NOT affect
# the opportunity score.
# ============================================================
MARKETS = {
    "GREECE": {
        "kind": "COUNTRY", "benchmark": "GD.AT",
        "country_aliases": {"greece"}, "execution": "LOCAL_BROKER"
    },
    "US": {
        "kind": "COUNTRY", "benchmark": "SPY",
        "country_aliases": {"united states", "usa", "us"}, "execution": "IBKR"
    },
    "UK": {
        "kind": "COUNTRY", "benchmark": "^FTSE",
        "country_aliases": {"united kingdom", "uk", "great britain"}, "execution": "IBKR"
    },
    "GERMANY": {
        "kind": "COUNTRY", "benchmark": "^GDAXI",
        "country_aliases": {"germany"}, "execution": "IBKR"
    },
    "FRANCE": {
        "kind": "COUNTRY", "benchmark": "^FCHI",
        "country_aliases": {"france"}, "execution": "IBKR"
    },
    "ITALY": {
        "kind": "COUNTRY", "benchmark": "FTSEMIB.MI",
        "country_aliases": {"italy"}, "execution": "IBKR"
    },
    "SPAIN": {
        "kind": "COUNTRY", "benchmark": "^IBEX",
        "country_aliases": {"spain"}, "execution": "IBKR"
    },
    "NETHERLANDS": {
        "kind": "COUNTRY", "benchmark": "^AEX",
        "country_aliases": {"netherlands"}, "execution": "IBKR"
    },
    "SWITZERLAND": {
        "kind": "COUNTRY", "benchmark": "^SSMI",
        "country_aliases": {"switzerland"}, "execution": "IBKR"
    },
    "JAPAN": {
        "kind": "COUNTRY", "benchmark": "^N225",
        "country_aliases": {"japan"}, "execution": "IBKR"
    },
    "INDIA": {
        "kind": "COUNTRY", "benchmark": "^NSEI",
        "country_aliases": {"india"}, "execution": "IBKR_IF_PERMISSION"
    },
    "HONG_KONG": {
        "kind": "COUNTRY", "benchmark": "^HSI",
        "country_aliases": {"hong kong"}, "execution": "IBKR"
    },
    "CANADA": {
        "kind": "COUNTRY", "benchmark": "^GSPTSE",
        "country_aliases": {"canada"}, "execution": "IBKR"
    },
    "AUSTRALIA": {
        "kind": "COUNTRY", "benchmark": "^AXJO",
        "country_aliases": {"australia"}, "execution": "IBKR"
    },

    # Asset opportunity sleeves. Breadth is proxy-based until we define
    # dedicated constituent baskets (e.g. miners, energy producers).
    "GOLD": {
        "kind": "ASSET", "benchmark": "GLD",
        "country_aliases": set(), "execution": "IBKR"
    },
    "SILVER": {
        "kind": "ASSET", "benchmark": "SLV",
        "country_aliases": set(), "execution": "IBKR"
    },
    "ENERGY": {
        "kind": "ASSET", "benchmark": "XLE",
        "country_aliases": set(), "execution": "IBKR"
    },
    "INDUSTRIAL_METALS": {
        "kind": "ASSET", "benchmark": "DBB",
        "country_aliases": set(), "execution": "IBKR"
    },
    "AGRICULTURE": {
        "kind": "ASSET", "benchmark": "DBA",
        "country_aliases": set(), "execution": "IBKR"
    },
}


# ============================================================
# HELPERS
# ============================================================
def clamp(x, lo=0.0, hi=10.0):
    return max(lo, min(hi, float(x)))


def safe_float(x, default=np.nan):
    try:
        v = float(x)
        return v if np.isfinite(v) else default
    except Exception:
        return default


def normalize_text(x):
    return str(x or "").strip().lower()


def normalize_yahoo_symbol(symbol):
    s = str(symbol or "").strip()
    if ":" in s:
        s = s.split(":", 1)[1]
    return s


def connect_workbook():
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON, scopes=scopes)
    gc = gspread.authorize(creds)
    return gc.open_by_key(SHEET_ID)


def read_metadata(sh):
    ws = sh.worksheet(SECURITY_METADATA_TAB)
    rows = ws.get_all_records()
    df = pd.DataFrame(rows)
    if df.empty:
        raise RuntimeError("Security Metadata is empty.")

    for c in ["symbol", "yahoo_symbol", "country", "region", "asset_type",
              "local_benchmark", "regional_benchmark", "sector_group"]:
        if c not in df.columns:
            df[c] = ""

    df["yahoo"] = df.apply(
        lambda r: normalize_yahoo_symbol(r["yahoo_symbol"] or r["symbol"]), axis=1
    )
    df = df[df["yahoo"].astype(str).str.len() > 0].copy()
    return df


def market_constituents(metadata, market_name, cfg):
    if cfg["kind"] != "COUNTRY":
        return []

    aliases = {normalize_text(x) for x in cfg.get("country_aliases", set())}
    country = metadata["country"].map(normalize_text)
    syms = metadata.loc[country.isin(aliases), "yahoo"].dropna().astype(str).tolist()

    # Fallbacks for older metadata where country is missing but local benchmark
    # is correct. This is especially useful for Greece/Europe.
    if not syms:
        bm = normalize_text(cfg["benchmark"])
        lb = metadata["local_benchmark"].map(normalize_text)
        syms = metadata.loc[lb == bm, "yahoo"].dropna().astype(str).tolist()

    # Avoid benchmarks/ETFs being treated as constituent stocks where possible.
    syms = list(dict.fromkeys(s for s in syms if s and s != cfg["benchmark"]))
    return syms


def download_one(symbol, start, end):
    try:
        df = yf.download(
            symbol, start=start, end=end, interval="1d",
            auto_adjust=True, progress=False, threads=False
        )
        if df is None or df.empty:
            return None

        # yfinance can return MultiIndex columns even for one symbol.
        if isinstance(df.columns, pd.MultiIndex):
            df.columns = df.columns.get_level_values(0)

        need = {"Open", "High", "Low", "Close"}
        if not need.issubset(set(df.columns)):
            return None

        df = df.copy()
        df.index = pd.to_datetime(df.index).tz_localize(None)
        return df[~df.index.duplicated(keep="last")].sort_index()
    except Exception as e:
        print(f"[WARN] download failed {symbol}: {e}")
        return None


def build_price_cache(symbols, start, end):
    cache = {}
    symbols = list(dict.fromkeys(s for s in symbols if s))
    print(f"[DATA] Downloading {len(symbols)} Yahoo series...")
    for i, sym in enumerate(symbols, 1):
        cache[sym] = download_one(sym, start, end)
        if i % 25 == 0 or i == len(symbols):
            print(f"[DATA] {i}/{len(symbols)}")
        time.sleep(0.03)
    return cache


def asof_df(df, asof_date):
    if df is None or df.empty:
        return None
    x = df.loc[df.index <= pd.Timestamp(asof_date)]
    return x if len(x) else None


def pct_return(close, days):
    if len(close) <= days:
        return np.nan
    return (close.iloc[-1] / close.iloc[-1-days] - 1.0) * 100.0


def atr_pct(df, n=14):
    if df is None or len(df) < n + 2:
        return np.nan
    prev = df["Close"].shift(1)
    tr = pd.concat([
        df["High"] - df["Low"],
        (df["High"] - prev).abs(),
        (df["Low"] - prev).abs()
    ], axis=1).max(axis=1)
    atr = tr.rolling(n).mean().iloc[-1]
    close = df["Close"].iloc[-1]
    return float(100.0 * atr / close) if close else np.nan


# ============================================================
# FIVE INDEPENDENT DIMENSIONS
# ============================================================
def trend_score(df):
    """Absolute health: price/EMA alignment, EMA slopes, recent return/high."""
    if df is None or len(df) < 70:
        return np.nan, {}

    c = df["Close"].dropna()
    e13 = c.ewm(span=13, adjust=False).mean()
    e34 = c.ewm(span=34, adjust=False).mean()
    e50 = c.ewm(span=50, adjust=False).mean()

    score = 0.0
    score += 2.0 if c.iloc[-1] > e13.iloc[-1] else 0.0
    score += 2.0 if e13.iloc[-1] > e34.iloc[-1] else 0.0
    score += 1.5 if e34.iloc[-1] > e50.iloc[-1] else 0.0
    score += 1.5 if e13.iloc[-1] > e13.iloc[-6] else 0.0
    score += 1.0 if e34.iloc[-1] > e34.iloc[-6] else 0.0

    r21 = pct_return(c, 21)
    score += clamp((r21 + 4.0) / 8.0 * 1.0, 0, 1.0)

    hi63 = c.tail(63).max()
    dist_high = 100.0 * (c.iloc[-1] / hi63 - 1.0)
    score += clamp((dist_high + 12.0) / 12.0 * 1.0, 0, 1.0)

    return clamp(score), {
        "ret_21d_pct": r21,
        "ret_63d_pct": pct_return(c, 63),
        "price_vs_ema13_pct": 100.0 * (c.iloc[-1] / e13.iloc[-1] - 1.0),
        "ema13_vs_ema34_pct": 100.0 * (e13.iloc[-1] / e34.iloc[-1] - 1.0),
        "dist_63d_high_pct": dist_high,
    }


def rs_score(df, global_df):
    """
    Cross-market relative strength against ACWI/common reference.
    1w/1m/3m excess returns, emphasizing 1m.
    """
    if df is None or global_df is None:
        return np.nan, {}

    a = df["Close"].dropna()
    g = global_df["Close"].dropna()
    horizons = [(5, 0.25), (21, 0.40), (63, 0.35)]
    excesses = {}
    weighted = 0.0
    used = 0.0

    for days, w in horizons:
        ra, rg = pct_return(a, days), pct_return(g, days)
        if np.isfinite(ra) and np.isfinite(rg):
            ex = ra - rg
            excesses[f"excess_{days}d_pct"] = ex
            # +/-10% excess roughly spans the 0-10 score.
            s = clamp(5.0 + ex * 0.5)
            weighted += w * s
            used += w

    return (weighted / used if used else np.nan), excesses


def acceleration_score(df):
    """Is momentum improving now rather than merely strong in the past?"""
    if df is None or len(df) < 70:
        return np.nan, {}

    c = df["Close"].dropna()
    r5, r21, r63 = pct_return(c, 5), pct_return(c, 21), pct_return(c, 63)
    e13 = c.ewm(span=13, adjust=False).mean()
    slope_now = 100.0 * (e13.iloc[-1] / e13.iloc[-6] - 1.0) if len(e13) >= 6 else 0.0
    slope_prev = 100.0 * (e13.iloc[-6] / e13.iloc[-11] - 1.0) if len(e13) >= 11 else 0.0
    slope_delta = slope_now - slope_prev

    # Compare per-day momentum across horizons.
    m5 = r5 / 5.0 if np.isfinite(r5) else 0.0
    m21 = r21 / 21.0 if np.isfinite(r21) else 0.0
    m63 = r63 / 63.0 if np.isfinite(r63) else 0.0
    accel = 0.60 * (m5 - m21) + 0.40 * (m21 - m63) + 0.25 * slope_delta

    score = clamp(5.0 + accel * 12.0)
    return score, {
        "ret_5d_pct": r5,
        "accel_raw": accel,
        "ema13_slope_delta": slope_delta,
    }


def breadth_score(constituents, cache, asof_date):
    """
    Participation in OUR investable/watchlist universe.
    No AI and no Trades outcomes.
    """
    vals = []
    for sym in constituents:
        d = asof_df(cache.get(sym), asof_date)
        if d is None or len(d) < 55:
            continue
        c = d["Close"].dropna()
        e13 = c.ewm(span=13, adjust=False).mean().iloc[-1]
        e34 = c.ewm(span=34, adjust=False).mean().iloc[-1]
        e50 = c.ewm(span=50, adjust=False).mean().iloc[-1]
        r21 = pct_return(c, 21)
        hi20 = c.tail(20).max()

        vals.append({
            "gt13": c.iloc[-1] > e13,
            "gt34": c.iloc[-1] > e34,
            "gt50": c.iloc[-1] > e50,
            "pos21": np.isfinite(r21) and r21 > 0,
            "near20high": c.iloc[-1] >= 0.98 * hi20,
        })

    n = len(vals)
    if n < MIN_BREADTH_STOCKS:
        return np.nan, {"breadth_n": n, "breadth_method": "INSUFFICIENT_CONSTITUENTS"}

    def p(k):
        return 100.0 * sum(bool(v[k]) for v in vals) / n

    p13, p34, p50, p21, ph = p("gt13"), p("gt34"), p("gt50"), p("pos21"), p("near20high")
    participation = (
        0.20 * p13 + 0.25 * p34 + 0.25 * p50 +
        0.20 * p21 + 0.10 * ph
    )
    score = clamp(participation / 10.0)
    return score, {
        "breadth_n": n,
        "pct_gt_ema13": p13,
        "pct_gt_ema34": p34,
        "pct_gt_ema50": p50,
        "pct_positive_21d": p21,
        "pct_near_20d_high": ph,
        "breadth_method": "CONSTITUENTS",
    }


def proxy_breadth_score(df):
    """
    Fallback only when we don't have enough constituents.
    Kept explicitly labelled so it cannot masquerade as true breadth.
    """
    if df is None or len(df) < 70:
        return np.nan, {"breadth_method": "NO_DATA", "breadth_n": 0}
    t, _ = trend_score(df)
    return t, {"breadth_method": "BENCHMARK_PROXY", "breadth_n": 0}


def risk_score(df, global_vix_df=None):
    """
    Reward orderly trend/risk; penalize large drawdown and ATR expansion.
    VIX is a modest GLOBAL overlay, not the sole country-risk measure.
    """
    if df is None or len(df) < 70:
        return np.nan, {}

    c = df["Close"].dropna()
    atr_now = atr_pct(df, 14)

    old = df.iloc[:-10] if len(df) > 30 else df
    atr_old = atr_pct(old, 14)
    atr_ratio = atr_now / atr_old if np.isfinite(atr_now) and np.isfinite(atr_old) and atr_old > 0 else 1.0

    high63 = c.tail(63).max()
    dd63 = 100.0 * (c.iloc[-1] / high63 - 1.0)

    score = 8.5
    score -= clamp(max(0.0, -dd63 - 3.0) * 0.25, 0, 2.5)
    score -= clamp(max(0.0, atr_ratio - 1.0) * 3.0, 0, 2.0)
    score -= clamp(max(0.0, atr_now - 3.0) * 0.35, 0, 1.5) if np.isfinite(atr_now) else 0

    vix = np.nan
    if global_vix_df is not None and len(global_vix_df):
        vix = safe_float(global_vix_df["Close"].iloc[-1])
        if np.isfinite(vix):
            if vix >= 35:
                score -= 2.0
            elif vix >= 28:
                score -= 1.2
            elif vix >= 22:
                score -= 0.6

    return clamp(score), {
        "atr14_pct": atr_now,
        "atr_expansion_ratio": atr_ratio,
        "drawdown_from_63d_high_pct": dd63,
        "vix": vix,
    }


def weighted_opportunity(parts):
    weights = {
        "trend": W_TREND, "rs": W_RS, "acceleration": W_ACCEL,
        "breadth": W_BREADTH, "risk": W_RISK
    }
    total = 0.0
    used = 0.0
    for k, w in weights.items():
        v = parts.get(k, np.nan)
        if np.isfinite(v):
            total += w * v
            used += w
    return total / used if used else np.nan


def status_from_score(score):
    if not np.isfinite(score):
        return "NO_DATA"
    if score >= PRIORITY_MIN:
        return "PRIORITY"
    if score >= ACTIVE_MIN:
        return "ACTIVE"
    if score >= SELECTIVE_MIN:
        return "SELECTIVE"
    return "AVOID"


# ============================================================
# WEEKLY RECONSTRUCTION
# ============================================================
def weekly_dates(start_date, end_date):
    """
    Use Friday/as-of-last-trading-day snapshots. Each score uses only data
    <= that date. This is what we will later join to next week's entries.
    """
    dates = pd.date_range(start=start_date, end=end_date, freq="W-FRI")
    return [d.date() for d in dates]


def evaluate_market(market, cfg, asof_date, cache, constituents):
    bm = cfg["benchmark"]
    df = asof_df(cache.get(bm), asof_date)
    global_df = asof_df(cache.get(GLOBAL_REFERENCE), asof_date)
    vix_df = asof_df(cache.get("^VIX"), asof_date)

    if df is None or len(df) < 70:
        return {
            "asof_date": str(asof_date), "market": market, "kind": cfg["kind"],
            "benchmark": bm, "execution": cfg["execution"],
            "status": "NO_DATA", "opportunity_score": np.nan,
            "notes": "Benchmark data unavailable/insufficient"
        }

    trend, td = trend_score(df)
    rs, rd = rs_score(df, global_df)
    accel, ad = acceleration_score(df)

    breadth, bd = breadth_score(constituents, cache, asof_date)
    if not np.isfinite(breadth):
        breadth, proxy_bd = proxy_breadth_score(df)
        bd.update(proxy_bd)

    risk, riskd = risk_score(df, vix_df)

    parts = {
        "trend": trend, "rs": rs, "acceleration": accel,
        "breadth": breadth, "risk": risk
    }
    opp = weighted_opportunity(parts)

    row = {
        "asof_date": str(asof_date),
        "iso_week": f"{asof_date.isocalendar().year}-W{asof_date.isocalendar().week:02d}",
        "market": market,
        "kind": cfg["kind"],
        "benchmark": bm,
        "execution": cfg["execution"],
        "trend_score": round(trend, 3),
        "rs_score": round(rs, 3),
        "acceleration_score": round(accel, 3),
        "breadth_score": round(breadth, 3),
        "risk_score": round(risk, 3),
        "opportunity_score": round(opp, 3),
        "status": status_from_score(opp),
        "breadth_method": bd.get("breadth_method", ""),
        "breadth_n": bd.get("breadth_n", 0),
        "pct_gt_ema13": bd.get("pct_gt_ema13", np.nan),
        "pct_gt_ema34": bd.get("pct_gt_ema34", np.nan),
        "pct_gt_ema50": bd.get("pct_gt_ema50", np.nan),
        "pct_positive_21d": bd.get("pct_positive_21d", np.nan),
        "pct_near_20d_high": bd.get("pct_near_20d_high", np.nan),
        "ret_5d_pct": ad.get("ret_5d_pct", np.nan),
        "ret_21d_pct": td.get("ret_21d_pct", np.nan),
        "ret_63d_pct": td.get("ret_63d_pct", np.nan),
        "excess_5d_pct": rd.get("excess_5d_pct", np.nan),
        "excess_21d_pct": rd.get("excess_21d_pct", np.nan),
        "excess_63d_pct": rd.get("excess_63d_pct", np.nan),
        "atr14_pct": riskd.get("atr14_pct", np.nan),
        "atr_expansion_ratio": riskd.get("atr_expansion_ratio", np.nan),
        "drawdown_63d_pct": riskd.get("drawdown_from_63d_high_pct", np.nan),
        "vix": riskd.get("vix", np.nan),
        "notes": "PHASE1_MARKET_DATA_ONLY_NO_TRADES"
    }
    return row


def clean_for_sheet(df):
    out = df.copy()
    out = out.replace([np.inf, -np.inf], np.nan)
    return out.where(pd.notnull(out), "").astype(object)


def write_df(sh, tab_name, df):
    try:
        ws = sh.worksheet(tab_name)
        ws.clear()
    except gspread.WorksheetNotFound:
        ws = sh.add_worksheet(
            title=tab_name,
            rows=max(100, len(df) + 20),
            cols=max(30, len(df.columns) + 5)
        )

    clean = clean_for_sheet(df)
    values = [clean.columns.tolist()] + clean.values.tolist()
    ws.update(values=values, range_name="A1")

    # Basic readability without relying on external formatting packages.
    ws.freeze(rows=1)
    try:
        ws.format("A1:AZ1", {"textFormat": {"bold": True}})
    except Exception:
        pass
    return ws


def main():
    print("=== AutoTrader Global Opportunity Engine / Phase 1 ===")
    print("IMPORTANT: Trades outcomes are NOT read by this script.")

    sh = connect_workbook()
    metadata = read_metadata(sh)

    end_date = date.today()
    start_eval = end_date - timedelta(days=LOOKBACK_DAYS)
    start_prices = end_date - timedelta(days=PRICE_HISTORY_DAYS)
    end_prices = end_date + timedelta(days=1)

    constituents_by_market = {}
    all_symbols = {GLOBAL_REFERENCE, "^VIX"}

    for market, cfg in MARKETS.items():
        all_symbols.add(cfg["benchmark"])
        constituents = market_constituents(metadata, market, cfg)
        constituents_by_market[market] = constituents
        all_symbols.update(constituents)
        print(
            f"[UNIVERSE] {market:18s} benchmark={cfg['benchmark']:12s} "
            f"constituents={len(constituents)}"
        )

    cache = build_price_cache(sorted(all_symbols), start_prices, end_prices)

    rows = []
    weeks = weekly_dates(start_eval, end_date)
    print(f"[EVAL] Reconstructing {len(weeks)} weekly snapshots...")

    for d in weeks:
        for market, cfg in MARKETS.items():
            row = evaluate_market(
                market, cfg, d, cache, constituents_by_market.get(market, [])
            )
            rows.append(row)

    result = pd.DataFrame(rows)
    if result.empty:
        raise RuntimeError("No opportunity rows generated.")

    # Rank markets independently within each weekly snapshot.
    result["weekly_rank"] = (
        result.groupby("asof_date")["opportunity_score"]
        .rank(method="min", ascending=False)
    )

    cols = [
        "asof_date", "iso_week", "weekly_rank", "market", "kind",
        "benchmark", "execution", "status", "opportunity_score",
        "trend_score", "rs_score", "acceleration_score",
        "breadth_score", "risk_score", "breadth_method", "breadth_n",
        "pct_gt_ema13", "pct_gt_ema34", "pct_gt_ema50",
        "pct_positive_21d", "pct_near_20d_high",
        "ret_5d_pct", "ret_21d_pct", "ret_63d_pct",
        "excess_5d_pct", "excess_21d_pct", "excess_63d_pct",
        "atr14_pct", "atr_expansion_ratio", "drawdown_63d_pct",
        "vix", "notes"
    ]
    result = result[[c for c in cols if c in result.columns]]
    result = result.sort_values(["asof_date", "weekly_rank", "market"])

    latest_date = result["asof_date"].max()
    latest = result[result["asof_date"] == latest_date].copy()
    latest = latest.sort_values(["weekly_rank", "market"])

    write_df(sh, OUTPUT_WEEKLY_TAB, result)
    write_df(sh, OUTPUT_LATEST_TAB, latest)

    print()
    print(f"[DONE] Wrote {len(result)} rows to {OUTPUT_WEEKLY_TAB}")
    print(f"[DONE] Wrote latest snapshot ({latest_date}) to {OUTPUT_LATEST_TAB}")
    print()
    print(latest[
        ["weekly_rank", "market", "status", "opportunity_score",
         "trend_score", "rs_score", "acceleration_score",
         "breadth_score", "risk_score"]
    ].to_string(index=False))
    print()
    print("NEXT STEP (separate script): join these frozen weekly scores to Trades")
    print("and test whether PRIORITY/ACTIVE trades actually outperform.")


if __name__ == "__main__":
    main()
