#!/usr/bin/env python3
"""
AutoTrader Global Opportunity Backtest - Phase 2 v5

Purpose
-------
Validate the already-frozen GlobalOpportunityWeekly market classifications
against the actual Trades sheet WITHOUT changing/recalculating the Global
Opportunity Engine.

This script:
1) Reads GlobalOpportunityWeekly exactly as produced by Phase 1.
2) Reads Trades.
3) Assigns each trade the most recent market status/rank/score available
   STRICTLY BEFORE the trade entry date (no look-ahead).
4) Compares actual outcomes by:
      PRIORITY / ACTIVE / SELECTIVE / AVOID
      market
      opportunity-score bucket
5) Runs counterfactual allocation scenarios:
      ACTUAL : 100% of every trade
      A      : PRIORITY + ACTIVE only
      B      : PRIORITY/ACTIVE 100%, SELECTIVE 50%, AVOID 0%
      C      : only trades whose market was Top-3 that week
6) Writes diagnostic/output tabs back to the same Google workbook.

IMPORTANT
---------
- This script DOES NOT modify the Global Opportunity scores.
- This script DOES NOT use future GlobalOpportunity rows.
- It reads Trades only after the Phase-1 market history has already been frozen.
- It does not call OpenAI or Yahoo Finance.
- If your Trades sheet does not contain enough information to derive P/L,
  the script will still produce classification / stop / T1 diagnostics and
  will clearly flag P/L as unavailable rather than inventing values.

Recommended sequence
--------------------
Run Phase 1 first, inspect/freeze GlobalOpportunityWeekly, then run this script.
"""

import os
import re
import math
from datetime import datetime
from collections import defaultdict

import numpy as np
import pandas as pd
import gspread
from google.oauth2.service_account import Credentials


# ============================================================
# CONFIG
# ============================================================

SHEET_ID = os.getenv(
    "SHEET_ID_PROD",
    "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg"
)

SERVICE_ACCOUNT_JSON = os.getenv(
    "SERVICE_ACCOUNT_JSON_PROD",
    "bottrader-494519-30132dfab247.json"
)

TRADES_TAB = os.getenv("TRADES_TAB", "Trades")
GLOBAL_WEEKLY_TAB = os.getenv(
    "GLOBAL_OPP_WEEKLY_TAB", "GlobalOpportunityWeekly"
)
SECURITY_METADATA_TAB = os.getenv(
    "SECURITY_METADATA_TAB", "Security Metadata"
)

OUT_TRADES_TAB = os.getenv(
    "GLOBAL_OPP_BT_TRADES_TAB", "GlobalOppBacktestTrades"
)
OUT_STATUS_TAB = os.getenv(
    "GLOBAL_OPP_BT_STATUS_TAB", "GlobalOppBacktestStatus"
)
OUT_MARKETS_TAB = os.getenv(
    "GLOBAL_OPP_BT_MARKETS_TAB", "GlobalOppBacktestMarkets"
)
OUT_SCENARIOS_TAB = os.getenv(
    "GLOBAL_OPP_BT_SCENARIOS_TAB", "GlobalOppBacktestScenarios"
)
OUT_CURVE_TAB = os.getenv(
    "GLOBAL_OPP_BT_CURVE_TAB", "GlobalOppBacktestCurve"
)
OUT_DIAGNOSTICS_TAB = os.getenv(
    "GLOBAL_OPP_BT_DIAGNOSTICS_TAB", "GlobalOppBacktestDiagnostics"
)

# Used only when cash P/L is unavailable and we have to build a normalized
# percentage-return curve. It is NOT intended to reproduce the broker account.
NORMALIZED_START_CAPITAL = float(
    os.getenv("GLOBAL_OPP_BT_NORMALIZED_START_CAPITAL", "100.0")
)

# Experimental constant notional. We deliberately ignore Actual Trade Amount
# so this backtest tests selection quality rather than historical sizing.
FLAT_TRADE_EUR = float(
    os.getenv("GLOBAL_OPP_BT_FLAT_TRADE_EUR", "1000")
)

# If Trades has neither a cash P/L column nor an exit price, but it does have
# P/L %, scenario summaries still work using a normalized return index.
# Set 0 to keep open/unresolved trades out of P/L calculations.
INCLUDE_OPEN_TRADES_IN_PNL = (
    os.getenv("GLOBAL_OPP_BT_INCLUDE_OPEN_IN_PNL", "0").strip() == "1"
)

TOP_N_MARKETS_SCENARIO_C = int(
    os.getenv("GLOBAL_OPP_BT_TOP_N", "3")
)

# We use STRICTLY EARLIER market snapshots by default. This prevents a Friday
# snapshot from being applied to a trade entered earlier that same Friday.
STRICTLY_PRIOR_SNAPSHOT = (
    os.getenv("GLOBAL_OPP_BT_STRICT_PRIOR", "1").strip() != "0"
)


# ============================================================
# COLUMN ALIASES
# The script is intentionally tolerant because the Trades sheet evolved.
# ============================================================

ALIASES = {
    "symbol": [
        "symbol", "ticker", "yahoo_symbol", "security", "stock"
    ],
    "entry_date": [
        "entry_date", "open_date", "entrydate", "date_entry",
        "trade_date", "opened_at", "entry_alerted_at"
    ],
    "close_date": [
        "close_date", "closed_date", "exit_date", "closed_at",
        "exit_at", "close_at"
    ],
    "entry_price": [
        "entry", "entry_price", "actual_entry", "entryprice",
        "avg_entry", "average_entry_price"
    ],
    "exit_price": [
        "exit", "exit_price", "actual_exit", "exitprice",
        "close_price", "closed_price", "avg_exit",
        "average_exit_price"
    ],
    "status": [
        "status", "trade_status", "position_status", "last_status"
    ],
    "exit_reason": [
        "exit_reason", "reason", "close_reason", "result",
        "outcome", "exit_type"
    ],
    "pnl_pct": [
        "pnl_pct", "pnl_percent", "pnl_percentage", "profit_pct",
        "profit_percent", "return_pct", "return_percent",
        "pl_pct", "p_l_pct", "gain_pct", "gain_percent",
        "realized_pnl_pct"
    ],
    "pnl_cash": [
        "pnl", "pnl_eur", "profit_loss", "profit_loss_eur",
        "realized_pnl", "realized_pnl_eur", "pl", "p_l",
        "profit", "profit_eur", "net_pnl", "net_profit_loss"
    ],
    "quantity": [
        "quantity", "qty", "shares", "units"
    ],
    "position_value": [
        "position_value", "investment", "invested_amount",
        "cost_basis", "capital", "position_size", "trade_value",
        "actual_trade_amount"
    ],
    "source_sheet": [
        "source_sheet", "source", "recommendation_sheet",
        "week_sheet", "origin_sheet"
    ],
    "t1": [
        "t1", "target1", "target_1", "target1_price", "t1_price"
    ],
    "t2": [
        "t2", "target2", "target_2", "target2_price", "t2_price"
    ],
    "stop": [
        "stop", "stop_price", "stoploss", "stop_loss"
    ],
    "t1_alerted_at": [
        "t1_alerted_at", "t1_hit_at", "target1_hit_at",
        "target_1_hit_at"
    ],
    "stop_alerted_at": [
        "stop_alerted_at", "stop_hit_at", "stoploss_hit_at",
        "stop_loss_hit_at"
    ],
    "t2_alerted_at": [
        "t2_alerted_at", "t2_hit_at", "target2_hit_at", "target_2_hit_at"
    ],
    "take_profit_alerted_at": [
        "take_profit_alerted_at", "take_profit_at"
    ],
    "runner_trail_alerted_at": [
        "runner_trail_alerted_at", "runner_trail_at"
    ],
    "trail_stop_hit_alerted_at": [
        "trail_stop_hit_alerted_at", "trail_stop_hit_at"
    ],
    "exit_weak_alerted_at": [
        "exit_weak_alerted_at", "exit_weak_at"
    ],
    "max_hold_exit_alerted_at": [
        "max_hold_exit_alerted_at", "max_hold_exit_at"
    ],
}


# ============================================================
# MARKET MAPPING
# ============================================================

COUNTRY_TO_MARKET = {
    "greece": "GREECE",
    "united states": "US",
    "usa": "US",
    "us": "US",
    "united kingdom": "UK",
    "uk": "UK",
    "great britain": "UK",
    "germany": "GERMANY",
    "france": "FRANCE",
    "italy": "ITALY",
    "spain": "SPAIN",
    "netherlands": "NETHERLANDS",
    "switzerland": "SWITZERLAND",
    "japan": "JAPAN",
    "india": "INDIA",
    "hong kong": "HONG_KONG",
    "canada": "CANADA",
    "australia": "AUSTRALIA",
}

# These are direct asset proxies / ETCs / ETFs that should be evaluated
# against the asset sleeve rather than the listing country.
EXPLICIT_ASSET_SYMBOLS = {
    # Gold / gold ETC proxies commonly present in the AutoTrader universe.
    "GLD": "GOLD",
    "IGLN.L": "GOLD",
    "SGLN.L": "GOLD",
    "PHAU.L": "GOLD",
    "4GLD.DE": "GOLD",

    # Silver
    "SLV": "SILVER",
    "PHAG.L": "SILVER",

    # Energy
    "XLE": "ENERGY",

    # Industrial metals
    "DBB": "INDUSTRIAL_METALS",

    # Agriculture
    "DBA": "AGRICULTURE",
}


# ============================================================
# GENERIC HELPERS
# ============================================================

def ntext(x):
    return str(x if x is not None else "").strip()


def norm_header(x):
    s = ntext(x).lower()
    s = re.sub(r"[%/()\-]+", "_", s)
    s = re.sub(r"[^a-z0-9_]+", "_", s)
    s = re.sub(r"_+", "_", s).strip("_")
    return s


def norm_symbol(x):
    s = ntext(x).upper()
    if ":" in s:
        s = s.split(":", 1)[1]
    return s


def norm_country(x):
    return ntext(x).strip().lower()


def safe_float(x):
    if x is None:
        return np.nan
    if isinstance(x, (int, float, np.integer, np.floating)):
        try:
            v = float(x)
            return v if np.isfinite(v) else np.nan
        except Exception:
            return np.nan

    s = ntext(x)
    if not s:
        return np.nan

    # Remove currency symbols and spaces.
    s = s.replace("€", "").replace("$", "").replace("£", "").replace(" ", "")

    # Percent sign is handled as plain numeric percentage, e.g. "5%" -> 5.
    s = s.replace("%", "")

    # Handle European decimal comma conservatively.
    if "," in s and "." not in s:
        s = s.replace(",", ".")
    elif "," in s and "." in s:
        # Most likely thousands separator if both are present.
        s = s.replace(",", "")

    try:
        v = float(s)
        return v if np.isfinite(v) else np.nan
    except Exception:
        return np.nan


def parse_datetime_series(s):
    """
    Pandas mixed-format parser tolerant of ISO, dd/mm/yyyy and timestamps.
    """
    if s is None:
        return pd.Series(dtype="datetime64[ns]")
    out = pd.to_datetime(s, errors="coerce", dayfirst=True, format="mixed")
    try:
        out = out.dt.tz_localize(None)
    except Exception:
        pass
    return out


def is_blank_or_nan(v):
    return v is None or (isinstance(v, float) and np.isnan(v)) or ntext(v) == ""


def connect_workbook():
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(
        SERVICE_ACCOUNT_JSON, scopes=scopes
    )
    gc = gspread.authorize(creds)
    return gc.open_by_key(SHEET_ID)


def worksheet_to_df(sh, title, required=True):
    try:
        ws = sh.worksheet(title)
    except gspread.exceptions.WorksheetNotFound:
        if required:
            raise
        return pd.DataFrame()

    values = ws.get_all_values()
    if not values:
        return pd.DataFrame()

    headers = [ntext(x) for x in values[0]]
    # Make duplicate/blank headers safe for pandas.
    seen = defaultdict(int)
    safe_headers = []
    for i, h in enumerate(headers):
        h2 = h or f"blank_{i+1}"
        seen[h2] += 1
        if seen[h2] > 1:
            h2 = f"{h2}__{seen[h2]}"
        safe_headers.append(h2)

    rows = values[1:]
    width = len(safe_headers)
    rows = [(r + [""] * width)[:width] for r in rows]

    df = pd.DataFrame(rows, columns=safe_headers)
    # Remove fully blank rows.
    if not df.empty:
        mask = df.apply(
            lambda r: any(ntext(v) for v in r.values), axis=1
        )
        df = df[mask].reset_index(drop=True)
    return df


def find_column(df, logical_name, required=False):
    if df.empty:
        if required:
            raise RuntimeError(
                f"Cannot find required Trades column '{logical_name}' because sheet is empty."
            )
        return None

    normalized = {norm_header(c): c for c in df.columns}
    for alias in ALIASES.get(logical_name, []):
        k = norm_header(alias)
        if k in normalized:
            return normalized[k]

    if required:
        raise RuntimeError(
            f"Required Trades field '{logical_name}' not found.\n"
            f"Available columns: {list(df.columns)}"
        )
    return None


def upsert_dataframe(sh, title, df):
    """
    Replace only the named OUTPUT tab. Source tabs are never modified.
    """
    try:
        ws = sh.worksheet(title)
        ws.clear()
    except gspread.exceptions.WorksheetNotFound:
        rows = max(100, len(df) + 20)
        cols = max(20, len(df.columns) + 5)
        ws = sh.add_worksheet(title=title, rows=rows, cols=cols)

    if df is None or df.empty:
        ws.update([["No rows"]], "A1")
        return

    out = df.copy()

    # Convert ALL pandas/numpy missing/non-finite values to blank strings.
    # gspread/requests rejects NaN/inf because they are not JSON compliant.
    def sheets_safe_cell(x):
        if x is None:
            return ""
        if isinstance(x, (pd.Timestamp, datetime)):
            return "" if pd.isna(x) else x.isoformat(sep=" ")
        if isinstance(x, (np.floating, float)):
            return "" if not np.isfinite(float(x)) else float(x)
        if isinstance(x, (np.integer,)):
            return int(x)
        if isinstance(x, (np.bool_,)):
            return bool(x)
        try:
            missing = pd.isna(x)
            if isinstance(missing, (bool, np.bool_)) and missing:
                return ""
        except Exception:
            pass
        return x

    out = out.astype(object)
    for c in out.columns:
        out[c] = out[c].map(sheets_safe_cell)

    values = [list(out.columns)] + out.values.tolist()
    ws.resize(rows=max(100, len(values) + 10), cols=max(20, len(out.columns) + 3))
    ws.update(values, "A1", value_input_option="USER_ENTERED")
    ws.freeze(rows=1)


# ============================================================
# METADATA -> MARKET MAPPING
# ============================================================

def read_metadata_optional(sh):
    """
    Reads Security Metadata if available. The Phase-2 backtest can still run
    without it, but market mapping will rely more heavily on ticker suffixes.
    """
    try:
        df = worksheet_to_df(sh, SECURITY_METADATA_TAB, required=False)
    except Exception:
        return pd.DataFrame()

    if df.empty:
        return df

    # Find likely columns by normalized exact names.
    colmap = {norm_header(c): c for c in df.columns}
    symbol_col = colmap.get("symbol")
    yahoo_col = colmap.get("yahoo_symbol")
    country_col = colmap.get("country")

    rows = []
    for _, r in df.iterrows():
        sym = norm_symbol(r.get(symbol_col, "")) if symbol_col else ""
        yahoo = norm_symbol(r.get(yahoo_col, "")) if yahoo_col else ""
        country = norm_country(r.get(country_col, "")) if country_col else ""
        market = COUNTRY_TO_MARKET.get(country, "")
        for key in {sym, yahoo}:
            if key:
                rows.append((key, market, country))

    if not rows:
        return pd.DataFrame()

    return pd.DataFrame(rows, columns=["symbol_key", "metadata_market", "metadata_country"]).drop_duplicates(
        subset=["symbol_key"], keep="first"
    )


def infer_market_from_symbol(symbol, metadata_map):
    s = norm_symbol(symbol)

    if s in EXPLICIT_ASSET_SYMBOLS:
        return EXPLICIT_ASSET_SYMBOLS[s], "EXPLICIT_ASSET_SYMBOL"

    if s in metadata_map:
        m = metadata_map[s]
        if m:
            return m, "SECURITY_METADATA"

    # Conservative suffix fallbacks.
    if s.endswith(".AT"):
        return "GREECE", "SYMBOL_SUFFIX"
    if s.endswith(".L"):
        return "UK", "SYMBOL_SUFFIX"
    if s.endswith(".DE"):
        return "GERMANY", "SYMBOL_SUFFIX"
    if s.endswith(".PA"):
        return "FRANCE", "SYMBOL_SUFFIX"
    if s.endswith(".MI"):
        return "ITALY", "SYMBOL_SUFFIX"
    if s.endswith(".MC"):
        return "SPAIN", "SYMBOL_SUFFIX"
    if s.endswith(".AS"):
        return "NETHERLANDS", "SYMBOL_SUFFIX"
    if s.endswith(".SW"):
        return "SWITZERLAND", "SYMBOL_SUFFIX"
    if s.endswith(".T"):
        return "JAPAN", "SYMBOL_SUFFIX"
    if s.endswith(".HK"):
        return "HONG_KONG", "SYMBOL_SUFFIX"
    if s.endswith(".TO") or s.endswith(".V"):
        return "CANADA", "SYMBOL_SUFFIX"
    if s.endswith(".AX"):
        return "AUSTRALIA", "SYMBOL_SUFFIX"
    if s.endswith(".NS") or s.endswith(".BO"):
        return "INDIA", "SYMBOL_SUFFIX"

    # Unsuffixed equities in the current AutoTrader universe are mostly US.
    # This fallback is explicitly tagged so it can be audited.
    if re.fullmatch(r"[A-Z0-9.\-]+", s) and s:
        return "US", "UNSUFFIXED_US_FALLBACK"

    return "", "UNMAPPED"


# ============================================================
# TRADE OUTCOME DERIVATION
# ============================================================

def derive_outcomes(trades):
    """
    Adds normalized fields while preserving original trade columns.

    P/L precedence:
    1) explicit pnl_pct
    2) entry + exit price
    3) explicit pnl_cash + position_value
    4) entry + quantity + pnl_cash -> infer position_value

    Cash P/L precedence:
    1) explicit pnl_cash
    2) entry + exit + quantity
    3) pnl_pct + position_value
    """
    cols = {
        k: find_column(trades, k, required=(k in {"symbol", "entry_date"}))
        for k in ALIASES
    }

    out = trades.copy()
    out["_symbol"] = out[cols["symbol"]].map(norm_symbol)
    out["_entry_date"] = parse_datetime_series(out[cols["entry_date"]])

    if cols["close_date"]:
        out["_close_date"] = parse_datetime_series(out[cols["close_date"]])
    else:
        out["_close_date"] = pd.NaT

    numeric_fields = [
        "entry_price", "exit_price", "pnl_pct", "pnl_cash",
        "quantity", "position_value", "t1", "t2", "stop"
    ]
    for f in numeric_fields:
        if cols[f]:
            out[f"_{f}"] = out[cols[f]].map(safe_float)
        else:
            out[f"_{f}"] = np.nan

    for f in ["status", "exit_reason", "source_sheet"]:
        if cols[f]:
            out[f"_{f}"] = out[cols[f]].map(ntext)
        else:
            out[f"_{f}"] = ""

    # Event fields may be actual timestamps or simple flags.
    event_fields = [
        "t1_alerted_at", "t2_alerted_at", "stop_alerted_at",
        "take_profit_alerted_at", "runner_trail_alerted_at",
        "trail_stop_hit_alerted_at", "exit_weak_alerted_at",
        "max_hold_exit_alerted_at",
    ]
    for f in event_fields:
        if cols.get(f):
            out[f"_{f}_raw"] = out[cols[f]].map(ntext)
        else:
            out[f"_{f}_raw"] = ""

    # --------------------------------------------------------
    # Approximate realized outcome reconstruction agreed for this
    # Global Opportunity experiment.
    #
    # Precedence:
    #   STOP -> stop
    #   T2   -> t2
    #   T1   -> t1
    #   EXIT_WEAK -> entry (0%)
    #
    # STOP is checked first because a later stop event means the setup
    # ultimately failed under the simplified experiment. For trades with
    # T2/T1 but no stop, highest reached target wins.
    # Open/unresolved trades remain without an approximate exit.
    # --------------------------------------------------------
    has_stop = out["_stop_alerted_at_raw"].str.len() > 0
    has_t2 = out["_t2_alerted_at_raw"].str.len() > 0
    has_t1 = out["_t1_alerted_at_raw"].str.len() > 0
    has_exit_weak = out["_exit_weak_alerted_at_raw"].str.len() > 0

    # Also respect exit_reason when present.
    er = out["_exit_reason"].str.lower()
    has_stop |= er.str.contains(r"\bstop\b|stop_loss|stop loss|stopped", regex=True, na=False)
    has_t2 |= er.str.contains(r"\bt2\b|target.?2", regex=True, na=False)
    has_t1 |= er.str.contains(r"\bt1\b|target.?1|take_profit|take profit", regex=True, na=False)
    has_exit_weak |= er.str.contains(r"exit_weak|exit weak", regex=True, na=False)

    approx_exit = pd.Series(np.nan, index=out.index, dtype=float)
    approx_reason = pd.Series("", index=out.index, dtype=object)

    # Lowest precedence first; higher precedence overwrites below.
    m = has_exit_weak & out["_entry_price"].notna()
    approx_exit.loc[m] = out.loc[m, "_entry_price"]
    approx_reason.loc[m] = "EXIT_WEAK_AT_ENTRY"

    m = has_t1 & out["_t1"].notna()
    approx_exit.loc[m] = out.loc[m, "_t1"]
    approx_reason.loc[m] = "T1"

    m = has_t2 & out["_t2"].notna()
    approx_exit.loc[m] = out.loc[m, "_t2"]
    approx_reason.loc[m] = "T2"

    m = has_stop & out["_stop"].notna()
    approx_exit.loc[m] = out.loc[m, "_stop"]
    approx_reason.loc[m] = "STOP"

    out["_approx_exit_price"] = approx_exit
    out["_approx_exit_reason"] = approx_reason
    out["_approx_outcome_available"] = approx_exit.notna()

    # Derive P/L %. Explicit P/L remains highest authority if it ever
    # exists; otherwise use an actual exit price, then our agreed
    # approximate exit reconstruction.
    pnl_pct = out["_pnl_pct"].copy()

    effective_exit = out["_exit_price"].where(
        out["_exit_price"].notna(), out["_approx_exit_price"]
    )
    out["_effective_exit_price"] = effective_exit

    can_price = (
        pnl_pct.isna()
        & out["_entry_price"].notna()
        & effective_exit.notna()
        & (out["_entry_price"] != 0)
    )
    pnl_pct.loc[can_price] = (
        (effective_exit.loc[can_price] / out.loc[can_price, "_entry_price"]) - 1.0
    ) * 100.0

    can_cash_pos = (
        pnl_pct.isna()
        & out["_pnl_cash"].notna()
        & out["_position_value"].notna()
        & (out["_position_value"] != 0)
    )
    pnl_pct.loc[can_cash_pos] = (
        out.loc[can_cash_pos, "_pnl_cash"]
        / out.loc[can_cash_pos, "_position_value"]
    ) * 100.0

    inferred_pos = out["_entry_price"] * out["_quantity"]
    can_cash_inferred_pos = (
        pnl_pct.isna()
        & out["_pnl_cash"].notna()
        & inferred_pos.notna()
        & (inferred_pos != 0)
    )
    pnl_pct.loc[can_cash_inferred_pos] = (
        out.loc[can_cash_inferred_pos, "_pnl_cash"]
        / inferred_pos.loc[can_cash_inferred_pos]
    ) * 100.0

    out["_derived_pnl_pct"] = pnl_pct

    # Experimental cash P/L: fixed EUR notional per trade.
    # Actual Trade Amount is intentionally ignored.
    pnl_cash = pd.Series(np.nan, index=out.index, dtype=float)
    flat_mask = out["_derived_pnl_pct"].notna()
    pnl_cash.loc[flat_mask] = (
        FLAT_TRADE_EUR * out.loc[flat_mask, "_derived_pnl_pct"] / 100.0
    )

    # No historical sizing/quantity reconstruction here: fixed notional only.

    out["_derived_pnl_cash"] = pnl_cash

    # Closed/open determination.
    status_text = out["_status"].str.lower()
    reason_text = out["_exit_reason"].str.lower()
    closed_words = r"closed|close|exit|stopped|stop|t1|t2|take_profit|trail"
    open_words = r"open|active|holding|hold"

    out["_is_closed"] = (
        out["_close_date"].notna()
        | out["_exit_price"].notna()
        | reason_text.str.contains(closed_words, regex=True, na=False)
        | status_text.str.contains(r"closed|stopped|exited", regex=True, na=False)
        | out["_approx_outcome_available"]
    )
    out["_is_open"] = (
        status_text.str.contains(open_words, regex=True, na=False)
        & ~out["_is_closed"]
    )

    # T1 hit detection.
    t1_event = out["_t1_alerted_at_raw"].str.len() > 0
    t1_reason = reason_text.str.contains(
        r"\bt1\b|target.?1|take_profit|take profit", regex=True, na=False
    )
    t1_status = status_text.str.contains(
        r"\bt1\b|take_profit|take profit", regex=True, na=False
    )
    out["_t1_hit"] = t1_event | t1_reason | t1_status

    # T2 hit detection.
    t2_event = out["_t2_alerted_at_raw"].str.len() > 0
    t2_reason = reason_text.str.contains(
        r"\bt2\b|target.?2", regex=True, na=False
    )
    t2_status = status_text.str.contains(
        r"\bt2\b", regex=True, na=False
    )
    out["_t2_hit"] = t2_event | t2_reason | t2_status

    # STOP hit detection.
    stop_event = out["_stop_alerted_at_raw"].str.len() > 0
    stop_reason = reason_text.str.contains(
        r"\bstop\b|stop_loss|stop loss|stopped", regex=True, na=False
    )
    stop_status = status_text.str.contains(
        r"\bstop\b|stopped", regex=True, na=False
    )
    out["_stop_hit"] = stop_event | stop_reason | stop_status

    # Win/loss only where P/L is known.
    out["_is_win"] = out["_derived_pnl_pct"] > 0
    out["_is_loss"] = out["_derived_pnl_pct"] < 0

    # For scenario return calculations, unresolved/open trades are excluded
    # unless user explicitly enables them.
    out["_pnl_eligible"] = out["_derived_pnl_pct"].notna()
    if not INCLUDE_OPEN_TRADES_IN_PNL:
        out["_pnl_eligible"] &= ~out["_is_open"]

    return out, cols


# ============================================================
# GLOBAL OPPORTUNITY HISTORY
# ============================================================

def prepare_global_weekly(df):
    required = [
        "asof_date", "market", "status", "opportunity_score", "weekly_rank"
    ]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(
            f"{GLOBAL_WEEKLY_TAB} is missing required columns: {missing}"
        )

    g = df.copy()
    g["asof_date"] = parse_datetime_series(g["asof_date"])
    g["market"] = g["market"].map(lambda x: ntext(x).upper())
    g["status"] = g["status"].map(lambda x: ntext(x).upper())
    g["opportunity_score"] = g["opportunity_score"].map(safe_float)
    g["weekly_rank"] = g["weekly_rank"].map(safe_float)

    if "iso_week" not in g.columns:
        g["iso_week"] = g["asof_date"].map(
            lambda d: (
                f"{d.isocalendar().year}-W{d.isocalendar().week:02d}"
                if pd.notna(d) else ""
            )
        )
    else:
        g["iso_week"] = g["iso_week"].map(ntext)

    g = g[
        g["asof_date"].notna()
        & g["market"].ne("")
        & g["status"].ne("")
    ].copy()

    g = g.sort_values(["market", "asof_date", "weekly_rank"]).reset_index(drop=True)
    return g


def assign_market_snapshots(trades, global_weekly, metadata_df):
    metadata_map = {}
    if metadata_df is not None and not metadata_df.empty:
        for _, r in metadata_df.iterrows():
            metadata_map[norm_symbol(r["symbol_key"])] = ntext(r["metadata_market"]).upper()

    trades = trades.copy()

    market_info = trades["_symbol"].map(
        lambda s: infer_market_from_symbol(s, metadata_map)
    )
    trades["_market"] = market_info.map(lambda x: x[0])
    trades["_market_source"] = market_info.map(lambda x: x[1])

    # Build per-market date arrays for fast no-lookahead matching.
    by_market = {}
    for market, grp in global_weekly.groupby("market"):
        gg = grp.sort_values("asof_date").reset_index(drop=True)
        by_market[market] = gg

    matched_rows = []
    for idx, r in trades.iterrows():
        market = r["_market"]
        entry_dt = r["_entry_date"]

        result = {
            "_global_asof_date": pd.NaT,
            "_global_iso_week": "",
            "_global_status": "",
            "_global_score": np.nan,
            "_global_rank": np.nan,
            "_global_match": False,
            "_top_markets": "",
            "_is_top_n": False,
        }

        if not market or pd.isna(entry_dt) or market not in by_market:
            matched_rows.append(result)
            continue

        gg = by_market[market]

        if STRICTLY_PRIOR_SNAPSHOT:
            valid = gg[gg["asof_date"] < entry_dt.normalize()]
        else:
            valid = gg[gg["asof_date"] <= entry_dt.normalize()]

        if valid.empty:
            matched_rows.append(result)
            continue

        snap = valid.iloc[-1]
        asof = snap["asof_date"]

        # Top-N is determined from the exact same frozen weekly snapshot date.
        same_week = global_weekly[global_weekly["asof_date"] == asof].copy()
        same_week = same_week.sort_values(
            ["weekly_rank", "opportunity_score"],
            ascending=[True, False],
            na_position="last"
        )
        top_markets = same_week.head(TOP_N_MARKETS_SCENARIO_C)["market"].tolist()

        result.update({
            "_global_asof_date": asof,
            "_global_iso_week": ntext(snap["iso_week"]),
            "_global_status": ntext(snap["status"]).upper(),
            "_global_score": safe_float(snap["opportunity_score"]),
            "_global_rank": safe_float(snap["weekly_rank"]),
            "_global_match": True,
            "_top_markets": ", ".join(top_markets),
            "_is_top_n": market in top_markets,
        })
        matched_rows.append(result)

    matched = pd.DataFrame(matched_rows, index=trades.index)
    for c in matched.columns:
        trades[c] = matched[c]

    return trades


# ============================================================
# COUNTERFACTUAL SCENARIOS
# ============================================================

def scenario_weight(row, scenario):
    status = ntext(row["_global_status"]).upper()

    if scenario == "ACTUAL":
        return 1.0

    if not row["_global_match"]:
        # Missing market history cannot be silently interpreted as AVOID.
        return np.nan

    if scenario == "A":
        return 1.0 if status in {"PRIORITY", "ACTIVE"} else 0.0

    if scenario == "B":
        if status in {"PRIORITY", "ACTIVE"}:
            return 1.0
        if status == "SELECTIVE":
            return 0.5
        if status == "AVOID":
            return 0.0
        return np.nan

    if scenario == "C":
        return 1.0 if bool(row["_is_top_n"]) else 0.0

    raise ValueError(f"Unknown scenario: {scenario}")


def build_scenario_rows(trades):
    rows = []

    for scenario in ["ACTUAL", "A", "B", "C"]:
        for idx, r in trades.iterrows():
            w = scenario_weight(r, scenario)

            pnl_pct = r["_derived_pnl_pct"]
            pnl_cash = r["_derived_pnl_cash"]

            weighted_pct = np.nan
            weighted_cash = np.nan

            if not np.isnan(w) and r["_pnl_eligible"]:
                if pd.notna(pnl_pct):
                    weighted_pct = float(pnl_pct) * float(w)
                if pd.notna(pnl_cash):
                    weighted_cash = float(pnl_cash) * float(w)

            rows.append({
                "scenario": scenario,
                "trade_row": int(idx) + 2,
                "symbol": r["_symbol"],
                "entry_date": r["_entry_date"],
                "close_date": r["_close_date"],
                "market": r["_market"],
                "market_source": r["_market_source"],
                "global_asof_date": r["_global_asof_date"],
                "iso_week": r["_global_iso_week"],
                "global_status": r["_global_status"],
                "global_score": r["_global_score"],
                "global_rank": r["_global_rank"],
                "is_top_n": r["_is_top_n"],
                "allocation_weight": w,
                "pnl_eligible": bool(r["_pnl_eligible"]),
                "pnl_pct": pnl_pct,
                "weighted_pnl_pct": weighted_pct,
                "pnl_cash": pnl_cash,
                "weighted_pnl_cash": weighted_cash,
                "t1_hit": bool(r["_t1_hit"]),
                "stop_hit": bool(r["_stop_hit"]),
                "is_closed": bool(r["_is_closed"]),
                "is_open": bool(r["_is_open"]),
            })

    return pd.DataFrame(rows)


def max_drawdown_from_equity(equity):
    if len(equity) == 0:
        return np.nan
    arr = np.asarray(equity, dtype=float)
    running_max = np.maximum.accumulate(arr)
    dd = np.where(running_max != 0, (arr / running_max) - 1.0, 0.0)
    return float(np.nanmin(dd) * 100.0)


def build_scenario_curves(scenario_rows):
    """
    Two possible curves:
    - cash_incremental: cumulative weighted cash P/L where cash P/L exists
    - normalized_return: starting at NORMALIZED_START_CAPITAL and applying
      weighted trade P/L percentages sequentially.

    The normalized curve is a research proxy, not a simultaneous-position
    portfolio simulator.
    """
    all_curves = []

    for scenario, grp in scenario_rows.groupby("scenario"):
        g = grp.copy()
        # Use close date where available so realized results are ordered by exit;
        # fallback to entry date.
        g["event_date"] = g["close_date"].where(
            g["close_date"].notna(), g["entry_date"]
        )
        g = g.sort_values(["event_date", "trade_row"]).reset_index(drop=True)

        equity_norm = NORMALIZED_START_CAPITAL
        cum_cash = 0.0

        for _, r in g.iterrows():
            if not bool(r["pnl_eligible"]):
                continue
            w = r["allocation_weight"]
            if pd.isna(w):
                continue

            wpct = r["weighted_pnl_pct"]
            wcash = r["weighted_pnl_cash"]

            if pd.notna(wpct):
                equity_norm *= (1.0 + float(wpct) / 100.0)
            if pd.notna(wcash):
                cum_cash += float(wcash)

            all_curves.append({
                "scenario": scenario,
                "event_date": r["event_date"],
                "trade_row": r["trade_row"],
                "symbol": r["symbol"],
                "market": r["market"],
                "global_status": r["global_status"],
                "allocation_weight": w,
                "weighted_pnl_pct": wpct,
                "weighted_pnl_cash": wcash,
                "normalized_equity": equity_norm,
                "cumulative_cash_pnl": cum_cash,
            })

    # Keep a stable schema even when no trade has eligible P/L yet.
    # Without this, pd.DataFrame([]) has no "scenario" column and the
    # scenario summary crashes before diagnostics can be written.
    curve_columns = [
        "scenario", "event_date", "trade_row", "symbol", "market",
        "global_status", "allocation_weight", "weighted_pnl_pct",
        "weighted_pnl_cash", "normalized_equity", "cumulative_cash_pnl",
    ]
    return pd.DataFrame(all_curves, columns=curve_columns)


def summarize_scenarios(scenario_rows, curves):
    rows = []

    for scenario, grp in scenario_rows.groupby("scenario"):
        g = grp.copy()
        known = g[g["pnl_eligible"] & g["allocation_weight"].notna()].copy()
        taken = known[known["allocation_weight"] > 0].copy()

        # Weighted effective trade count is useful for scenario B.
        eff_trades = (
            taken["allocation_weight"].sum()
            if not taken.empty else 0.0
        )

        pnl_known = taken["pnl_pct"].dropna()
        weighted_pct = taken["weighted_pnl_pct"].dropna()
        weighted_cash = taken["weighted_pnl_cash"].dropna()

        # curves can legitimately be empty when the Trades sheet has no
        # derivable/eligible realized P/L. Treat that as "no curve", not an error.
        if curves is None or curves.empty or "scenario" not in curves.columns:
            c = pd.DataFrame()
        else:
            c = curves[curves["scenario"] == scenario].copy()

        norm_end = (
            c["normalized_equity"].iloc[-1]
            if not c.empty and c["normalized_equity"].notna().any()
            else np.nan
        )
        norm_mdd = (
            max_drawdown_from_equity(c["normalized_equity"].values)
            if not c.empty else np.nan
        )
        cash_total = (
            weighted_cash.sum() if not weighted_cash.empty else np.nan
        )

        # Additive EUR P/L curve under fixed €1,000-per-full-trade notional.
        euro_steps = taken["weighted_pnl_cash"].dropna().tolist()
        euro_equity = [0.0]
        for step in euro_steps:
            euro_equity.append(euro_equity[-1] + float(step))
        euro_peak = np.maximum.accumulate(np.asarray(euro_equity, dtype=float))
        euro_dd = np.asarray(euro_equity, dtype=float) - euro_peak
        max_dd_eur = float(euro_dd.min()) if len(euro_dd) else np.nan

        rows.append({
            "scenario": scenario,
            "rule": {
                "ACTUAL": "All trades, weight 1.0",
                "A": "PRIORITY/ACTIVE only",
                "B": "PRIORITY/ACTIVE 1.0; SELECTIVE 0.5; AVOID 0",
                "C": f"Only Top-{TOP_N_MARKETS_SCENARIO_C} market(s) of matched week",
            }[scenario],
            "trades_total": len(g),
            "trades_with_global_match": int(g["global_status"].ne("").sum()),
            "pnl_eligible_trades": len(known),
            "trades_taken": int((taken["allocation_weight"] > 0).sum()),
            "effective_trade_count": round(float(eff_trades), 3),
            "trades_rejected_or_zero_weight": int(
                (known["allocation_weight"] == 0).sum()
            ),
            "avg_trade_pnl_pct_unweighted": (
                float(pnl_known.mean()) if not pnl_known.empty else np.nan
            ),
            "median_trade_pnl_pct_unweighted": (
                float(pnl_known.median()) if not pnl_known.empty else np.nan
            ),
            "avg_weighted_pnl_pct_per_original_trade": (
                float(weighted_pct.sum() / len(known))
                if len(known) > 0 and not weighted_pct.empty else np.nan
            ),
            "sum_weighted_trade_pnl_pct": (
                float(weighted_pct.sum()) if not weighted_pct.empty else np.nan
            ),
            "win_rate_taken_pct": (
                float((pnl_known > 0).mean() * 100.0)
                if not pnl_known.empty else np.nan
            ),
            "stop_rate_taken_pct": (
                float(taken["stop_hit"].mean() * 100.0)
                if not taken.empty else np.nan
            ),
            "t1_rate_taken_pct": (
                float(taken["t1_hit"].mean() * 100.0)
                if not taken.empty else np.nan
            ),
            "flat_full_trade_eur": FLAT_TRADE_EUR,
            "weighted_cash_pnl": (
                float(cash_total) if pd.notna(cash_total) else np.nan
            ),
            "avg_eur_pnl_per_taken_trade": (
                float(cash_total / len(taken))
                if pd.notna(cash_total) and len(taken) else np.nan
            ),
            "avg_eur_pnl_per_effective_trade": (
                float(cash_total / eff_trades)
                if pd.notna(cash_total) and eff_trades else np.nan
            ),
            "max_drawdown_eur_additive": max_dd_eur,
            "normalized_start": NORMALIZED_START_CAPITAL,
            "normalized_end": (
                float(norm_end) if pd.notna(norm_end) else np.nan
            ),
            "normalized_total_return_pct": (
                float((norm_end / NORMALIZED_START_CAPITAL - 1.0) * 100.0)
                if pd.notna(norm_end) else np.nan
            ),
            "normalized_max_drawdown_pct": (
                float(norm_mdd) if pd.notna(norm_mdd) else np.nan
            ),
        })

    result = pd.DataFrame(rows)

    order = pd.Categorical(
        result["scenario"],
        categories=["ACTUAL", "A", "B", "C"],
        ordered=True
    )
    result = result.assign(_order=order).sort_values("_order").drop(columns="_order")
    return result


# ============================================================
# STATUS / MARKET BREAKDOWNS
# ============================================================

def aggregate_group(df, group_cols):
    rows = []

    for key, grp in df.groupby(group_cols, dropna=False):
        if not isinstance(key, tuple):
            key = (key,)

        base = {c: k for c, k in zip(group_cols, key)}
        pnl = grp.loc[grp["_pnl_eligible"], "_derived_pnl_pct"].dropna()

        base.update({
            "trades": len(grp),
            "closed_trades": int(grp["_is_closed"].sum()),
            "open_trades": int(grp["_is_open"].sum()),
            "pnl_known_trades": len(pnl),
            "wins": int((pnl > 0).sum()) if len(pnl) else 0,
            "losses": int((pnl < 0).sum()) if len(pnl) else 0,
            "win_rate_pct": (
                float((pnl > 0).mean() * 100.0) if len(pnl) else np.nan
            ),
            "avg_pnl_pct": float(pnl.mean()) if len(pnl) else np.nan,
            "median_pnl_pct": float(pnl.median()) if len(pnl) else np.nan,
            "sum_trade_pnl_pct": float(pnl.sum()) if len(pnl) else np.nan,
            "t1_hits": int(grp["_t1_hit"].sum()),
            "t1_rate_pct": float(grp["_t1_hit"].mean() * 100.0) if len(grp) else np.nan,
            "stop_hits": int(grp["_stop_hit"].sum()),
            "stop_rate_pct": float(grp["_stop_hit"].mean() * 100.0) if len(grp) else np.nan,
            "avg_global_score": float(grp["_global_score"].dropna().mean())
                if grp["_global_score"].notna().any() else np.nan,
        })
        rows.append(base)

    return pd.DataFrame(rows)


def build_score_buckets(trades):
    out = trades.copy()
    bins = [-np.inf, 5.5, 7.0, 8.0, np.inf]
    labels = ["<5.5", "5.5-6.99", "7.0-7.99", ">=8.0"]
    out["_score_bucket"] = pd.cut(
        out["_global_score"],
        bins=bins,
        labels=labels,
        right=False
    ).astype(str)
    out.loc[out["_global_score"].isna(), "_score_bucket"] = "UNMATCHED"
    return out


# ============================================================
# DIAGNOSTICS
# ============================================================

def build_diagnostics(trades, columns_found, global_weekly):
    rows = []

    def add(metric, value, note=""):
        rows.append({"metric": metric, "value": value, "note": note})

    add("script", "Global Opportunity Backtest Phase 2 v5")
    add("global_weekly_tab", GLOBAL_WEEKLY_TAB)
    add("trades_tab", TRADES_TAB)
    add("strictly_prior_snapshot", STRICTLY_PRIOR_SNAPSHOT)
    add("scenario_c_top_n", TOP_N_MARKETS_SCENARIO_C)
    add(
        "flat_trade_notional_eur",
        FLAT_TRADE_EUR,
        "Actual Trade Amount is deliberately ignored in this experiment."
    )
    add("trades_rows", len(trades))
    add("global_weekly_rows", len(global_weekly))
    add(
        "global_date_min",
        global_weekly["asof_date"].min().strftime("%Y-%m-%d")
        if len(global_weekly) else ""
    )
    add(
        "global_date_max",
        global_weekly["asof_date"].max().strftime("%Y-%m-%d")
        if len(global_weekly) else ""
    )
    add(
        "trades_with_valid_entry_date",
        int(trades["_entry_date"].notna().sum())
    )
    add(
        "trades_with_market_mapping",
        int(trades["_market"].ne("").sum())
    )
    add(
        "trades_with_global_match",
        int(trades["_global_match"].sum()),
        "Most recent frozen market snapshot strictly before entry."
    )
    add(
        "global_match_rate_pct",
        round(float(trades["_global_match"].mean() * 100.0), 2)
        if len(trades) else np.nan
    )
    add(
        "trades_with_approx_exit",
        int(trades["_approx_outcome_available"].sum()),
        "STOP->stop; T2->t2; T1->t1; EXIT_WEAK->entry."
    )
    for reason, n in trades["_approx_exit_reason"].value_counts().items():
        if reason:
            add(f"approx_exit_{reason}", int(n))
    add(
        "trades_with_pnl_pct",
        int(trades["_derived_pnl_pct"].notna().sum())
    )
    add(
        "trades_with_cash_pnl",
        int(trades["_derived_pnl_cash"].notna().sum())
    )
    add(
        "open_trades_included_in_pnl",
        INCLUDE_OPEN_TRADES_IN_PNL
    )

    for logical, actual in columns_found.items():
        add(f"column_{logical}", actual or "NOT FOUND")

    # Mapping source breakdown.
    for src, n in trades["_market_source"].value_counts(dropna=False).items():
        add(f"market_mapping_{src}", int(n))

    # Unmatched examples.
    unmatched = trades[~trades["_global_match"]]
    if not unmatched.empty:
        examples = ", ".join(
            f"{r['_symbol']}@{r['_entry_date'].date() if pd.notna(r['_entry_date']) else 'NO_DATE'}"
            for _, r in unmatched.head(15).iterrows()
        )
        add(
            "unmatched_examples",
            examples,
            "Usually means entry predates Phase-1 history or market mapping is unavailable."
        )

    return pd.DataFrame(rows)


# ============================================================
# OUTPUT TRADE AUDIT TABLE
# ============================================================

def build_trade_audit(trades):
    cols = [
        "_symbol", "_entry_date", "_close_date",
        "_market", "_market_source",
        "_global_asof_date", "_global_iso_week",
        "_global_status", "_global_score", "_global_rank",
        "_top_markets", "_is_top_n",
        "_status", "_exit_reason",
        "_entry_price", "_exit_price", "_approx_exit_price",
        "_effective_exit_price", "_approx_exit_reason",
        "_derived_pnl_pct", "_derived_pnl_cash",
        "_position_value", "_t1", "_t2", "_stop",
        "_t1_hit", "_t2_hit", "_stop_hit",
        "_is_closed", "_is_open", "_pnl_eligible",
        "_source_sheet",
    ]

    out = trades[[c for c in cols if c in trades.columns]].copy()
    rename = {
        c: c[1:] if c.startswith("_") else c
        for c in out.columns
    }
    out = out.rename(columns=rename)

    out.insert(0, "trade_row", np.arange(2, len(out) + 2))
    out.insert(1, "flat_trade_notional_eur", FLAT_TRADE_EUR)

    for scenario in ["ACTUAL", "A", "B", "C"]:
        out[f"scenario_{scenario}_weight"] = [
            scenario_weight(r, scenario)
            for _, r in trades.iterrows()
        ]

    return out


# ============================================================
# MAIN
# ============================================================

def main():
    print("=== AutoTrader Global Opportunity Backtest / Phase 2 v5 ===")
    print("GlobalOpportunityWeekly is treated as FROZEN.")
    print("No Yahoo/OpenAI calls are made.")
    print()

    sh = connect_workbook()

    print(f"Reading {GLOBAL_WEEKLY_TAB} ...")
    global_raw = worksheet_to_df(sh, GLOBAL_WEEKLY_TAB, required=True)
    global_weekly = prepare_global_weekly(global_raw)
    print(
        f"  {len(global_weekly)} market-week rows | "
        f"{global_weekly['asof_date'].min().date()} -> "
        f"{global_weekly['asof_date'].max().date()}"
    )

    print(f"Reading {TRADES_TAB} ...")
    trades_raw = worksheet_to_df(sh, TRADES_TAB, required=True)
    if trades_raw.empty:
        raise RuntimeError("Trades sheet is empty.")

    print(f"  {len(trades_raw)} Trades rows")
    print("Trades columns:")
    print("  " + " | ".join(str(c) for c in trades_raw.columns))

    metadata = read_metadata_optional(sh)
    if metadata.empty:
        print(
            f"WARNING: '{SECURITY_METADATA_TAB}' unavailable/empty. "
            "Ticker suffix fallback will be used."
        )
    else:
        print(f"  Security Metadata mapping keys: {len(metadata)}")

    trades, columns_found = derive_outcomes(trades_raw)

    print("Detected Trades fields:")
    for logical, actual in columns_found.items():
        print(f"  {logical:18s} -> {actual or 'NOT FOUND'}")

    bad_dates = int(trades["_entry_date"].isna().sum())
    if bad_dates:
        print(f"WARNING: {bad_dates} trade rows have no parseable entry date.")

    trades = assign_market_snapshots(trades, global_weekly, metadata)
    trades = build_score_buckets(trades)

    match_rate = float(trades["_global_match"].mean() * 100.0)
    print(f"Global snapshot match rate: {match_rate:.1f}%")

    if match_rate < 50:
        print(
            "WARNING: Global match rate is below 50%. "
            "Inspect GlobalOppBacktestDiagnostics before interpreting results."
        )

    pnl_pct_n = int(trades["_derived_pnl_pct"].notna().sum())
    cash_n = int(trades["_derived_pnl_cash"].notna().sum())
    print(f"P/L % available/derived for {pnl_pct_n}/{len(trades)} trades")
    print(f"Cash P/L available/derived for {cash_n}/{len(trades)} trades")

    status_summary = aggregate_group(
        trades[trades["_global_match"]],
        ["_global_status"]
    ).rename(columns={"_global_status": "global_status"})

    market_summary = aggregate_group(
        trades[trades["_global_match"]],
        ["_market", "_global_status"]
    ).rename(columns={
        "_market": "market",
        "_global_status": "global_status"
    })

    score_summary = aggregate_group(
        trades[trades["_global_match"]],
        ["_score_bucket"]
    ).rename(columns={"_score_bucket": "score_bucket"})

    # Put score-bucket diagnostics under status summary as an additional block
    # distinguished by summary_type.
    if not status_summary.empty:
        status_summary.insert(0, "summary_type", "STATUS")
    if not score_summary.empty:
        score_summary.insert(0, "summary_type", "SCORE_BUCKET")
        score_summary = score_summary.rename(
            columns={"score_bucket": "global_status"}
        )
        status_summary = pd.concat(
            [status_summary, score_summary],
            ignore_index=True,
            sort=False
        )

    scenario_rows = build_scenario_rows(trades)
    curves = build_scenario_curves(scenario_rows)
    if curves.empty:
        print(
            "WARNING: No eligible realized P/L rows were available for the "
            "equity curves. Classification diagnostics will still be written."
        )
    scenario_summary = summarize_scenarios(scenario_rows, curves)

    diagnostics = build_diagnostics(
        trades, columns_found, global_weekly
    )
    trade_audit = build_trade_audit(trades)

    print()
    print("Scenario summary:")
    print(
        scenario_summary[
            [
                "scenario", "trades_taken",
                "win_rate_taken_pct",
                "stop_rate_taken_pct",
                "t1_rate_taken_pct",
                "weighted_cash_pnl",
                "avg_eur_pnl_per_taken_trade",
                "max_drawdown_eur_additive",
            ]
        ].to_string(index=False)
    )

    print()
    print("Writing output tabs ...")

    upsert_dataframe(sh, OUT_TRADES_TAB, trade_audit)
    upsert_dataframe(sh, OUT_STATUS_TAB, status_summary)
    upsert_dataframe(sh, OUT_MARKETS_TAB, market_summary)
    upsert_dataframe(sh, OUT_SCENARIOS_TAB, scenario_summary)
    upsert_dataframe(sh, OUT_CURVE_TAB, curves)
    upsert_dataframe(sh, OUT_DIAGNOSTICS_TAB, diagnostics)

    print("Done.")
    print()
    print("Created/updated:")
    for x in [
        OUT_TRADES_TAB,
        OUT_STATUS_TAB,
        OUT_MARKETS_TAB,
        OUT_SCENARIOS_TAB,
        OUT_CURVE_TAB,
        OUT_DIAGNOSTICS_TAB,
    ]:
        print(f"  - {x}")

    print()
    print("Interpretation guardrail:")
    print(
        "Use the normalized equity curve only as a comparable research proxy "
        "unless cash P/L / position sizing is available for the Trades rows."
    )


if __name__ == "__main__":
    main()
