#!/usr/bin/env python3
"""
AutoTrader - Sector Opportunity Validation / Phase 4

Purpose
-------
Test the next V5 hypothesis WITHOUT changing production/preprod:

    Market Opportunity -> Sector Opportunity -> Trade Outcome

For every historical trade already matched to a frozen market snapshot in
GlobalOppBacktestTrades, this script reconstructs sector strength using ONLY
price information available before the trade entry.

It is deliberately simpler than a future production Sector Engine. The aim is
to prove/falsify whether sector context adds value before we design V5.

Sector score (0-10)
-------------------
1) Sector benchmark relative strength vs local market benchmark: 40%
2) Sector benchmark trend:                                    25%
3) Own-universe sector breadth:                               25%
4) Sector acceleration:                                      10%

The score is classified with the SAME research thresholds used in Phase 1:
    PRIORITY  >= 8.0
    ACTIVE    >= 7.0
    SELECTIVE >= 5.5
    AVOID     <  5.5

Important
---------
- No OpenAI calls.
- Yahoo data only.
- Uses Security Metadata for sector/sector_group/benchmarks.
- Uses frozen GlobalOppBacktestTrades for trade/market status.
- Never uses a trade's future result to calculate its sector score.
- Flat €1,000 outcome values are read from Phase 2 v5.
- Sector scores are research hypotheses, NOT production gates.

Outputs
-------
GlobalOppSectorTradeAudit
GlobalOppSectorStatus
GlobalOppMarketSectorMatrix
GlobalOppWeakMarketSector
GlobalOppSectorDiagnostics
"""

import os
import math
import time
from collections import defaultdict

import numpy as np
import pandas as pd
import yfinance as yf
import gspread
from google.oauth2.service_account import Credentials

SHEET_ID = os.getenv(
    "SHEET_ID_PROD",
    "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg"
)

SERVICE_ACCOUNT_JSON = os.getenv(
    "SERVICE_ACCOUNT_JSON_PROD",
    "bottrader-494519-30132dfab247.json"
)

TRADES_TAB = "GlobalOppBacktestTrades"
META_TAB = "Security Metadata"

OUT_AUDIT = "GlobalOppSectorTradeAudit"
OUT_STATUS = "GlobalOppSectorStatus"
OUT_MATRIX = "GlobalOppMarketSectorMatrix"
OUT_WEAK = "GlobalOppWeakMarketSector"
OUT_DIAG = "GlobalOppSectorDiagnostics"

MIN_BREADTH_STOCKS = int(os.getenv("SECTOR_MIN_BREADTH_STOCKS", "3"))
PRICE_HISTORY_DAYS = int(os.getenv("SECTOR_PRICE_HISTORY_DAYS", "420"))

# Fallbacks are used only when metadata does not contain a usable sector benchmark.
SECTOR_FALLBACK = {
    "COMMUNICATION SERVICES": "XLC",
    "CONSUMER DISCRETIONARY": "XLY",
    "CONSUMER CYCLICAL": "XLY",
    "CONSUMER STAPLES": "XLP",
    "CONSUMER DEFENSIVE": "XLP",
    "ENERGY": "XLE",
    "FINANCIALS": "XLF",
    "FINANCIAL SERVICES": "XLF",
    "HEALTH CARE": "XLV",
    "HEALTHCARE": "XLV",
    "INDUSTRIALS": "XLI",
    "MATERIALS": "XLB",
    "BASIC MATERIALS": "XLB",
    "REAL ESTATE": "XLRE",
    "TECHNOLOGY": "XLK",
    "INFORMATION TECHNOLOGY": "XLK",
    "UTILITIES": "XLU",
}

MARKET_BENCHMARK = {
    "GREECE": "GD.AT",
    "US": "SPY",
    "UK": "^FTSE",
    "GERMANY": "^GDAXI",
    "FRANCE": "^FCHI",
    "ITALY": "FTSEMIB.MI",
    "SPAIN": "^IBEX",
    "NETHERLANDS": "^AEX",
    "SWITZERLAND": "^SSMI",
    "JAPAN": "^N225",
    "INDIA": "^NSEI",
    "HONG KONG": "^HSI",
    "CANADA": "^GSPTSE",
    "AUSTRALIA": "^AXJO",
    # Asset sleeves: benchmark against broad world rather than pretending
    # they have an equity local market.
    "GOLD": "ACWI",
    "SILVER": "ACWI",
    "ENERGY": "ACWI",
    "INDUSTRIAL_METALS": "ACWI",
    "AGRICULTURE": "ACWI",
}

STATUS_ORDER = {"PRIORITY": 4, "ACTIVE": 3, "SELECTIVE": 2, "AVOID": 1}


def text(x):
    return str(x if x is not None else "").strip()


def norm(x):
    return " ".join(text(x).upper().replace("_", " ").replace("-", " ").split())


def fnum(x):
    s = text(x).replace("%", "").replace("€", "").replace(" ", "")
    if not s:
        return np.nan
    if "," in s and "." not in s:
        s = s.replace(",", ".")
    elif "," in s and "." in s:
        s = s.replace(",", "")
    try:
        v = float(s)
        return v if np.isfinite(v) else np.nan
    except Exception:
        return np.nan


def boolish(x):
    return text(x).lower() in {"true", "1", "yes", "y"}


def connect():
    creds = Credentials.from_service_account_file(
        SERVICE_ACCOUNT_JSON,
        scopes=["https://www.googleapis.com/auth/spreadsheets"]
    )
    return gspread.authorize(creds).open_by_key(SHEET_ID)


def read_df(sh, tab):
    vals = sh.worksheet(tab).get_all_values()
    if not vals:
        return pd.DataFrame()
    h = vals[0]
    rows = [(r + [""] * len(h))[:len(h)] for r in vals[1:]]
    return pd.DataFrame(rows, columns=h)


def safe_cell(x):
    if x is None:
        return ""
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating, float)):
        return "" if not np.isfinite(float(x)) else float(x)
    if isinstance(x, (np.bool_, bool)):
        return bool(x)
    if isinstance(x, pd.Timestamp):
        return x.strftime("%Y-%m-%d")
    try:
        if pd.isna(x):
            return ""
    except Exception:
        pass
    return x


def write_df(sh, tab, df):
    try:
        ws = sh.worksheet(tab)
        ws.clear()
    except gspread.exceptions.WorksheetNotFound:
        ws = sh.add_worksheet(
            title=tab, rows=max(100, len(df)+20), cols=max(20, len(df.columns)+5)
        )
    if df.empty:
        ws.update([["No rows"]], "A1")
        return
    out = df.astype(object).copy()
    for c in out.columns:
        out[c] = out[c].map(safe_cell)
    vals = [list(out.columns)] + out.values.tolist()
    ws.resize(rows=max(100, len(vals)+10), cols=max(20, len(out.columns)+3))
    ws.update(vals, "A1", value_input_option="USER_ENTERED")
    ws.freeze(rows=1)


def pick_col(df, candidates):
    cmap = {norm(c): c for c in df.columns}
    for c in candidates:
        if norm(c) in cmap:
            return cmap[norm(c)]
    return None


def prepare_metadata(meta):
    cols = {
        "symbol": pick_col(meta, ["symbol"]),
        "yahoo": pick_col(meta, ["yahoo_symbol", "yahoo symbol"]),
        "sector": pick_col(meta, ["sector"]),
        "sector_group": pick_col(meta, ["sector_group", "sector group"]),
        "sector_benchmark": pick_col(meta, ["sector_benchmark", "sector benchmark"]),
        "local_benchmark": pick_col(meta, ["local_benchmark", "local benchmark"]),
        "country": pick_col(meta, ["country"]),
        "status": pick_col(meta, ["status"]),
    }
    if not cols["symbol"]:
        raise RuntimeError("Security Metadata: symbol column not found.")

    rows = []
    for _, r in meta.iterrows():
        symbol = text(r[cols["symbol"]])
        if not symbol:
            continue
        yahoo = text(r[cols["yahoo"]]) if cols["yahoo"] else symbol
        sector = text(r[cols["sector"]]) if cols["sector"] else ""
        sector_group = text(r[cols["sector_group"]]) if cols["sector_group"] else ""
        sb = text(r[cols["sector_benchmark"]]) if cols["sector_benchmark"] else ""
        lb = text(r[cols["local_benchmark"]]) if cols["local_benchmark"] else ""
        country = text(r[cols["country"]]) if cols["country"] else ""
        status = text(r[cols["status"]]) if cols["status"] else ""
        if status and norm(status) not in {"ACTIVE", "OK", "ENABLED"}:
            continue
        rows.append({
            "symbol_meta": symbol,
            "yahoo_meta": yahoo or symbol,
            "sector_meta": sector,
            "sector_group_meta": sector_group,
            "sector_benchmark_meta": sb,
            "local_benchmark_meta": lb,
            "country_meta": country,
        })
    return pd.DataFrame(rows)


def build_meta_index(m):
    idx = {}
    for _, r in m.iterrows():
        for key in [r["symbol_meta"], r["yahoo_meta"]]:
            k = norm(key)
            if k:
                idx[k] = r.to_dict()
        # raw symbol before suffix helps e.g. ATHEX/Yahoo forms.
        for key in [r["symbol_meta"], r["yahoo_meta"]]:
            raw = text(key).split(".")[0]
            if raw:
                idx.setdefault(norm(raw), r.to_dict())
    return idx


def prepare_trades(t):
    required = ["symbol", "entry_date", "market", "global_status",
                "derived_pnl_pct", "derived_pnl_cash", "pnl_eligible"]
    missing = [c for c in required if c not in t.columns]
    if missing:
        raise RuntimeError(f"{TRADES_TAB} missing columns: {missing}")

    d = t.copy()
    d["entry_dt"] = pd.to_datetime(d["entry_date"], errors="coerce", format="mixed")
    d["market"] = d["market"].map(norm)
    d["global_status"] = d["global_status"].map(norm)
    d["pnl_pct"] = d["derived_pnl_pct"].map(fnum)
    d["pnl_eur"] = d["derived_pnl_cash"].map(fnum)
    d["eligible"] = d["pnl_eligible"].map(boolish)
    d = d[d["eligible"] & d["entry_dt"].notna() & d["pnl_pct"].notna()].copy()
    d["win"] = d["pnl_pct"] > 0
    d["loss"] = d["pnl_pct"] < 0
    return d


def download_prices(tickers, start, end):
    tickers = sorted({text(x) for x in tickers if text(x)})
    print(f"Downloading Yahoo history for {len(tickers)} tickers ...")
    cache = {}
    for i in range(0, len(tickers), 80):
        batch = tickers[i:i+80]
        try:
            raw = yf.download(
                batch, start=start, end=end, auto_adjust=False,
                progress=False, group_by="ticker", threads=True
            )
        except Exception as e:
            print("Yahoo batch error:", e)
            continue

        for ticker in batch:
            try:
                if len(batch) == 1:
                    x = raw.copy()
                else:
                    x = raw[ticker].copy()
                if x.empty:
                    continue
                col = "Adj Close" if "Adj Close" in x.columns else "Close"
                s = pd.to_numeric(x[col], errors="coerce").dropna()
                if not s.empty:
                    s.index = pd.to_datetime(s.index).tz_localize(None)
                    cache[ticker] = s.sort_index()
            except Exception:
                pass
    print(f"  usable price series: {len(cache)}/{len(tickers)}")
    return cache


def before(series, dt):
    if series is None or len(series) == 0:
        return pd.Series(dtype=float)
    # Strictly before entry date => no entry-day close lookahead.
    return series[series.index < pd.Timestamp(dt)].dropna()


def ret(s, n):
    if len(s) <= n:
        return np.nan
    return 100.0 * (s.iloc[-1] / s.iloc[-1-n] - 1.0)


def ema(s, n):
    if len(s) < n:
        return np.nan
    return float(s.ewm(span=n, adjust=False).mean().iloc[-1])


def slope_pct(s, n=13, lag=5):
    if len(s) < n + lag:
        return np.nan
    e = s.ewm(span=n, adjust=False).mean()
    a, b = float(e.iloc[-1]), float(e.iloc[-1-lag])
    return 100.0 * (a / b - 1.0) if b else np.nan


def clamp(v, lo=0.0, hi=10.0):
    return max(lo, min(hi, float(v)))


def trend_score(s):
    if len(s) < 55:
        return np.nan
    p = float(s.iloc[-1])
    e13, e34, e50 = ema(s, 13), ema(s, 34), ema(s, 50)
    r21 = ret(s, 21)
    sl13 = slope_pct(s, 13, 5)

    score = 5.0
    score += 1.5 if p > e13 else -1.5
    score += 1.0 if e13 > e34 else -1.0
    score += 0.75 if e34 > e50 else -0.75
    score += np.clip((r21 if pd.notna(r21) else 0) / 4.0, -1.0, 1.0)
    score += np.clip((sl13 if pd.notna(sl13) else 0) / 1.5, -0.75, 0.75)
    return clamp(score)


def relative_strength_score(sec, market):
    vals = []
    weights = []
    for n, w in [(5, .25), (21, .40), (63, .35)]:
        a, b = ret(sec, n), ret(market, n)
        if pd.notna(a) and pd.notna(b):
            vals.append((a-b) * w)
            weights.append(w)
    if not weights:
        return np.nan
    excess = sum(vals) / sum(weights)
    # 0 excess ~= neutral 5. +/-10 percentage points ~= extremes.
    return clamp(5.0 + excess / 2.0)


def acceleration_score(s, market):
    r5, r21 = ret(s, 5), ret(s, 21)
    m5, m21 = ret(market, 5), ret(market, 21)
    if any(pd.isna(x) for x in [r5, r21, m5, m21]):
        return np.nan
    recent_excess_daily = (r5-m5)/5.0
    medium_excess_daily = (r21-m21)/21.0
    accel = recent_excess_daily - medium_excess_daily
    return clamp(5.0 + accel * 4.0)


def breadth_score(constituents, prices, dt):
    flags = []
    for ticker in constituents:
        s = before(prices.get(ticker), dt)
        if len(s) < 55:
            continue
        p = float(s.iloc[-1])
        e13, e34, e50 = ema(s, 13), ema(s, 34), ema(s, 50)
        r21 = ret(s, 21)
        # Four simple breadth tests.
        tests = [
            p > e13,
            p > e34,
            p > e50,
            pd.notna(r21) and r21 > 0,
        ]
        flags.append(sum(bool(x) for x in tests) / 4.0)

    if len(flags) < MIN_BREADTH_STOCKS:
        return np.nan, len(flags)
    pct = 100.0 * float(np.mean(flags))
    return clamp(pct / 10.0), len(flags)


def classify(score):
    if pd.isna(score):
        return "UNKNOWN"
    if score >= 8.0:
        return "PRIORITY"
    if score >= 7.0:
        return "ACTIVE"
    if score >= 5.5:
        return "SELECTIVE"
    return "AVOID"


def summarize(g):
    return pd.Series({
        "trades": len(g),
        "wins": int(g["win"].sum()),
        "losses": int(g["loss"].sum()),
        "win_rate_pct": 100*g["win"].mean() if len(g) else np.nan,
        "t1_rate_pct": 100*g["t1_hit_bool"].mean() if len(g) else np.nan,
        "stop_rate_pct": 100*g["stop_hit_bool"].mean() if len(g) else np.nan,
        "avg_pnl_pct": g["pnl_pct"].mean(),
        "median_pnl_pct": g["pnl_pct"].median(),
        "total_pnl_eur": g["pnl_eur"].sum(),
        "expectancy_eur_per_trade": g["pnl_eur"].mean(),
        "avg_sector_score": g["sector_score"].mean(),
        "avg_market_score": g["global_score_num"].mean(),
    })


def main():
    print("=== AutoTrader Sector Opportunity Validation / Phase 4 ===")
    print("Hypothesis: Market -> Sector -> Trade outcome")
    print("No OpenAI calls. Sector score uses only pre-entry Yahoo history.")
    print()

    sh = connect()
    trades = prepare_trades(read_df(sh, TRADES_TAB))
    meta = prepare_metadata(read_df(sh, META_TAB))
    meta_idx = build_meta_index(meta)

    # Attach metadata.
    attached = []
    for _, r in trades.iterrows():
        sym = text(r["symbol"])
        md = meta_idx.get(norm(sym)) or meta_idx.get(norm(sym.split(".")[0])) or {}
        x = r.to_dict()
        x.update(md)
        attached.append(x)
    d = pd.DataFrame(attached)

    # Event flags are used only as outcomes, never in score calculation.
    d["t1_hit_bool"] = d["t1_hit"].map(boolish) if "t1_hit" in d.columns else False
    d["stop_hit_bool"] = d["stop_hit"].map(boolish) if "stop_hit" in d.columns else False
    d["global_score_num"] = d["global_score"].map(fnum) if "global_score" in d.columns else np.nan

    # Resolve sector benchmark and local benchmark.
    def sector_bm(r):
        sb = text(r.get("sector_benchmark_meta", ""))
        if sb:
            return sb
        key = norm(r.get("sector_group_meta", "")) or norm(r.get("sector_meta", ""))
        return SECTOR_FALLBACK.get(key, "")

    def local_bm(r):
        lb = text(r.get("local_benchmark_meta", ""))
        return lb or MARKET_BENCHMARK.get(norm(r.get("market", "")), "ACWI")

    d["sector_benchmark_used"] = d.apply(sector_bm, axis=1)
    d["market_benchmark_used"] = d.apply(local_bm, axis=1)
    d["sector_key"] = d.apply(
        lambda r: norm(r.get("sector_group_meta", "")) or norm(r.get("sector_meta", "")),
        axis=1
    )

    # Build own-universe sector constituent map from Security Metadata.
    sector_members = defaultdict(set)
    for _, r in meta.iterrows():
        key = norm(r["sector_group_meta"]) or norm(r["sector_meta"])
        y = text(r["yahoo_meta"])
        if key and y:
            sector_members[key].add(y)

    start = (d["entry_dt"].min() - pd.Timedelta(days=PRICE_HISTORY_DAYS)).strftime("%Y-%m-%d")
    end = (d["entry_dt"].max() + pd.Timedelta(days=2)).strftime("%Y-%m-%d")

    tickers = set(d["sector_benchmark_used"]) | set(d["market_benchmark_used"])
    for key in set(d["sector_key"]):
        tickers |= sector_members.get(key, set())

    prices = download_prices(tickers, start, end)

    audit = []
    for i, r in d.iterrows():
        dt = r["entry_dt"]
        sb = text(r["sector_benchmark_used"])
        mb = text(r["market_benchmark_used"])
        sk = text(r["sector_key"])

        sec = before(prices.get(sb), dt)
        mkt = before(prices.get(mb), dt)

        rs = relative_strength_score(sec, mkt) if len(sec) and len(mkt) else np.nan
        tr = trend_score(sec) if len(sec) else np.nan
        acc = acceleration_score(sec, mkt) if len(sec) and len(mkt) else np.nan
        br, br_n = breadth_score(sector_members.get(sk, set()), prices, dt)

        components = {
            "sector_rs_score": (rs, .40),
            "sector_trend_score": (tr, .25),
            "sector_breadth_score": (br, .25),
            "sector_acceleration_score": (acc, .10),
        }
        available = [(v, w) for v, w in components.values() if pd.notna(v)]
        if available:
            score = sum(v*w for v, w in available) / sum(w for _, w in available)
        else:
            score = np.nan

        x = r.to_dict()
        x.update({
            "sector_rs_score": rs,
            "sector_trend_score": tr,
            "sector_breadth_score": br,
            "sector_breadth_n": br_n,
            "sector_acceleration_score": acc,
            "sector_score": score,
            "sector_status": classify(score),
            "sector_score_components_available": len(available),
            "sector_data_quality": (
                "FULL" if len(available) == 4
                else "PARTIAL" if len(available) >= 2
                else "LOW"
            ),
        })
        audit.append(x)

    a = pd.DataFrame(audit)
    matched = a["sector_status"].ne("UNKNOWN").mean() * 100 if len(a) else 0
    print(f"Resolved trades: {len(a)}")
    print(f"Sector score coverage: {matched:.1f}%")

    # Main sector-status result.
    valid = a[a["sector_status"] != "UNKNOWN"].copy()
    status = valid.groupby("sector_status", dropna=False).apply(
        summarize, include_groups=False
    ).reset_index()
    status["status_order"] = status["sector_status"].map(STATUS_ORDER)
    status = status.sort_values("status_order", ascending=False)

    # Market x sector status matrix.
    matrix = valid.groupby(["global_status", "sector_status"], dropna=False).apply(
        summarize, include_groups=False
    ).reset_index()
    matrix["market_order"] = matrix["global_status"].map(STATUS_ORDER)
    matrix["sector_order"] = matrix["sector_status"].map(STATUS_ORDER)
    matrix = matrix.sort_values(["market_order", "sector_order"], ascending=False)

    # The key hypothesis: can strong sectors rescue weak broad markets?
    weak = valid[valid["global_status"].isin(["SELECTIVE", "AVOID"])].copy()
    weak["sector_strength_group"] = np.where(
        weak["sector_status"].isin(["PRIORITY", "ACTIVE"]),
        "STRONG_SECTOR_IN_WEAK_MARKET",
        "WEAK_SECTOR_IN_WEAK_MARKET"
    )
    weak_summary = weak.groupby(
        ["global_status", "sector_strength_group"], dropna=False
    ).apply(summarize, include_groups=False).reset_index()

    # Diagnostics.
    diag = pd.DataFrame([
        ["resolved_trades", len(a), ""],
        ["sector_score_coverage_pct", matched, ""],
        ["min_breadth_stocks", MIN_BREADTH_STOCKS, "research setting"],
        ["score_weights", "RS40 Trend25 Breadth25 Acceleration10",
         "frozen for this validation; not production"],
        ["lookahead_rule", "strictly before entry date",
         "entry-day close excluded"],
        ["purpose", "prove/falsify sector context",
         "do not use these thresholds as production gates yet"],
    ], columns=["metric", "value", "notes"])

    # Keep audit compact but traceable.
    wanted = [
        "symbol", "entry_date", "market", "global_status", "global_score_num",
        "sector_meta", "sector_group_meta", "sector_benchmark_used",
        "market_benchmark_used", "sector_key",
        "sector_rs_score", "sector_trend_score", "sector_breadth_score",
        "sector_breadth_n", "sector_acceleration_score", "sector_score",
        "sector_status", "sector_data_quality",
        "pnl_pct", "pnl_eur", "win", "t1_hit_bool", "stop_hit_bool"
    ]
    audit_out = a[[c for c in wanted if c in a.columns]].copy()

    print()
    print("Sector status test:")
    print(status[
        ["sector_status", "trades", "win_rate_pct", "t1_rate_pct",
         "stop_rate_pct", "expectancy_eur_per_trade", "total_pnl_eur"]
    ].to_string(index=False))

    print()
    print("Weak-market rescue test:")
    if weak_summary.empty:
        print("No eligible weak-market rows.")
    else:
        print(weak_summary[
            ["global_status", "sector_strength_group", "trades",
             "win_rate_pct", "t1_rate_pct", "stop_rate_pct",
             "expectancy_eur_per_trade", "total_pnl_eur"]
        ].to_string(index=False))

    print()
    print("Writing output tabs ...")
    write_df(sh, OUT_AUDIT, audit_out)
    write_df(sh, OUT_STATUS, status)
    write_df(sh, OUT_MATRIX, matrix)
    write_df(sh, OUT_WEAK, weak_summary)
    write_df(sh, OUT_DIAG, diag)
    print("Done.")
    for tab in [OUT_AUDIT, OUT_STATUS, OUT_MATRIX, OUT_WEAK, OUT_DIAG]:
        print(" -", tab)

    print()
    print("Primary decision test:")
    print("Do PRIORITY/ACTIVE sectors inside SELECTIVE/AVOID markets outperform")
    print("weak sectors inside the same weak-market states?")


if __name__ == "__main__":
    main()
