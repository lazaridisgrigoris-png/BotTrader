#!/usr/bin/env python3
"""
historical_trade_evaluator.py

Phase B backtest component for the trading-bot.

Purpose
-------
Consumes the Phase A output `backtest_ai_setups.csv` and evaluates what happened
after each historical setup.

It answers questions such as:
- Did entry trigger?
- Did stop/T1/T2 trigger?
- Was the stop too tight?
- Were targets too optimistic?
- Which setup archetypes performed best?
- Which exit methodology performed best?

Supported simulations
---------------------
1. STRUCTURE_FIXED
   Uses AI entry, AI stop, AI T1, AI T2.

2. FIXED_2PCT_STOP_T1_T2
   Uses AI entry, 2% stop, AI T1/T2.

3. ATR_STOP_T1_T2
   Uses AI entry, ATR-based stop, AI T1/T2.

4. TRAIL_AFTER_T1
   Uses AI entry/stop/T1, then trails after T1 is reached.

5. EMA10_EXIT
   Uses AI entry/stop, exits if daily close falls below EMA10.

6. TIME_EXIT
   Uses AI entry/stop, exits after N trading days if no target/stop.

Important simplification
------------------------
When high/low of the same daily candle touches both stop and target, this script
uses a conservative assumption: stop is hit first. This avoids overstating results.

Typical usage
-------------
python historical_trade_evaluator.py \
  --setups-csv backtest_ai_setups.csv \
  --output-results backtest_trade_results.csv \
  --output-summary backtest_summary.csv \
  --horizon-days 30

Dependencies
------------
pip install pandas numpy yfinance
"""

from __future__ import annotations

import argparse
import csv
import math
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

import numpy as np
import pandas as pd
import yfinance as yf


# -----------------------------
# Data models
# -----------------------------


@dataclass
class TradeOutcome:
    method: str
    week: str
    symbol: str
    snapshot_date: str
    decision: str
    setup_archetype: str
    bulkowski_pattern: str
    trend_stage: str
    grade_0_10: float
    market_dependency: str
    close_at_signal: float
    entry: float
    stop: float
    t1: Optional[float]
    t2: Optional[float]
    atr_pct_14d: Optional[float]
    triggered: bool
    trigger_date: str
    days_to_trigger: Optional[int]
    exit_date: str
    days_to_exit: Optional[int]
    exit_reason: str
    exit_price: Optional[float]
    pnl_pct: Optional[float]
    max_gain_pct: Optional[float]
    max_drawdown_pct: Optional[float]
    t1_hit: bool
    t1_hit_date: str
    t2_hit: bool
    t2_hit_date: str
    stop_hit: bool
    stop_hit_date: str
    final_close_pct: Optional[float]
    stop_then_recovered_flag: bool
    stop_too_tight_flag: bool
    target_too_optimistic_flag: bool
    notes: str


# -----------------------------
# CLI
# -----------------------------


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Evaluate historical AI setup outcomes")
    p.add_argument("--setups-csv", default="backtest_ai_setups.csv")
    p.add_argument("--output-results", default="backtest_trade_results.csv")
    p.add_argument("--output-summary", default="backtest_summary.csv")
    p.add_argument("--benchmark", default="SPY")
    p.add_argument("--horizon-days", type=int, default=30, help="Trading-day horizon after snapshot/entry")
    p.add_argument("--download-extra-calendar-days", type=int, default=80)
    p.add_argument("--atr-stop-multiple", type=float, default=1.5)
    p.add_argument("--fixed-stop-pct", type=float, default=2.0)
    p.add_argument("--trail-pct", type=float, default=3.0, help="Trailing stop after T1, percent from highest close/high")
    p.add_argument("--time-exit-days", type=int, default=20)
    p.add_argument("--include-future-setups", action="store_true", default=True)
    p.add_argument("--only-ai-selected", action="store_true", default=True)
    p.add_argument("--min-grade", type=float, default=0.0)
    p.add_argument("--max-symbols", type=int, default=0, help="Debug limit")
    return p.parse_args()


# -----------------------------
# Helpers
# -----------------------------


def safe_float(x: Any, default: Optional[float] = None) -> Optional[float]:
    try:
        if x is None or x == "" or (isinstance(x, float) and math.isnan(x)):
            return default
        v = float(x)
        if math.isnan(v):
            return default
        return v
    except Exception:
        return default


def safe_bool(x: Any) -> bool:
    if isinstance(x, bool):
        return x
    return str(x).strip().lower() in {"true", "1", "yes", "y"}


def normalize_yahoo_symbol(symbol: str) -> str:
    s = str(symbol).strip()
    if ":" in s:
        _exchange, rest = s.split(":", 1)
        return rest.strip()
    return s


def pct(a: Optional[float], b: Optional[float]) -> Optional[float]:
    if a is None or b is None or b == 0:
        return None
    return ((a / b) - 1.0) * 100.0


def pct_down(price: float, pct_value: float) -> float:
    return price * (1.0 - pct_value / 100.0)


def iso_date(x: Any) -> str:
    if x is None or x == "":
        return ""
    return pd.Timestamp(x).date().isoformat()


def trading_days_between(start: pd.Timestamp, end: pd.Timestamp, index: pd.DatetimeIndex) -> Optional[int]:
    try:
        sub = index[(index >= start) & (index <= end)]
        return max(0, len(sub) - 1)
    except Exception:
        return None


# -----------------------------
# Market data
# -----------------------------


def download_history(symbols: List[str], start: str, end: str) -> Dict[str, pd.DataFrame]:
    data: Dict[str, pd.DataFrame] = {}
    for original in symbols:
        yf_symbol = normalize_yahoo_symbol(original)
        try:
            df = yf.download(
                yf_symbol,
                start=start,
                end=(pd.Timestamp(end) + pd.Timedelta(days=1)).date().isoformat(),
                progress=False,
                auto_adjust=True,
                threads=False,
            )
            if isinstance(df.columns, pd.MultiIndex):
                df.columns = df.columns.get_level_values(0)
            df = df.rename(columns=str.title)
            needed = ["Open", "High", "Low", "Close", "Volume"]
            if df.empty or not all(c in df.columns for c in needed):
                data[original] = pd.DataFrame()
            else:
                data[original] = df[needed].dropna(subset=["Close"])
        except Exception as e:
            print(f"WARN: failed downloading {original}: {e}", file=sys.stderr)
            data[original] = pd.DataFrame()
    return data


def add_indicators(df: pd.DataFrame) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame()
    out = df.copy()
    out["EMA10"] = out["Close"].ewm(span=10, adjust=False).mean()
    out["MA50"] = out["Close"].rolling(50).mean()
    out["MA200"] = out["Close"].rolling(200).mean()
    high = out["High"]
    low = out["Low"]
    close = out["Close"]
    prev_close = close.shift(1)
    tr = pd.concat([(high - low), (high - prev_close).abs(), (low - prev_close).abs()], axis=1).max(axis=1)
    out["ATR14"] = tr.rolling(14).mean()
    out["ATR14_PCT"] = out["ATR14"] / out["Close"] * 100.0
    return out


# -----------------------------
# Setup loading
# -----------------------------


def load_setups(path: str, only_ai_selected: bool, include_future_setups: bool, min_grade: float, max_symbols: int) -> pd.DataFrame:
    df = pd.read_csv(path)
    if "ai_decision" not in df.columns:
        raise ValueError("Input CSV must be Phase A output and contain ai_decision")

    df["ai_grade_0_10"] = pd.to_numeric(df.get("ai_grade_0_10", 0), errors="coerce").fillna(0)

    allowed = ["TRADE"]
    if include_future_setups:
        allowed.append("FUTURE_SETUP")
    df = df[df["ai_decision"].astype(str).str.upper().isin(allowed)]
    df = df[df["ai_grade_0_10"] >= min_grade]

    if only_ai_selected and "ai_selected" in df.columns:
        df = df[df["ai_selected"].apply(safe_bool)]

    # Need numeric levels for simulation.
    for col in ["close", "ai_entry", "ai_stop", "ai_t1", "ai_t2", "atr_pct_14d"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    df = df.dropna(subset=["symbol", "snapshot_date", "close", "ai_entry"])

    if max_symbols and max_symbols > 0:
        keep_symbols = sorted(df["symbol"].unique())[:max_symbols]
        df = df[df["symbol"].isin(keep_symbols)]

    return df.reset_index(drop=True)


# -----------------------------
# Simulation core
# -----------------------------


def derive_method_levels(row: pd.Series, method: str, setup_df: pd.DataFrame, atr_stop_multiple: float, fixed_stop_pct: float) -> Tuple[Optional[float], Optional[float], Optional[float], Optional[float], str]:
    entry = safe_float(row.get("ai_entry"))
    close = safe_float(row.get("close"))
    ai_stop = safe_float(row.get("ai_stop"))
    t1 = safe_float(row.get("ai_t1"))
    t2 = safe_float(row.get("ai_t2"))

    if entry is None:
        return None, None, None, None, "missing_entry"

    # If no AI stop exists, use 2% fallback so method can still be evaluated.
    stop = ai_stop if ai_stop is not None else pct_down(entry, fixed_stop_pct)

    if method == "STRUCTURE_FIXED":
        pass
    elif method == "FIXED_2PCT_STOP_T1_T2":
        stop = pct_down(entry, fixed_stop_pct)
    elif method == "ATR_STOP_T1_T2":
        # Prefer ATR at snapshot from price series, fallback to Phase A percent ATR.
        atr_value = None
        if setup_df is not None and not setup_df.empty:
            snap = pd.Timestamp(row.get("snapshot_date"))
            hist = setup_df[setup_df.index <= snap]
            if not hist.empty and "ATR14" in hist.columns:
                atr_value = safe_float(hist["ATR14"].iloc[-1])
        if atr_value is not None:
            stop = entry - atr_stop_multiple * atr_value
        else:
            atr_pct = safe_float(row.get("atr_pct_14d"))
            if atr_pct is not None:
                stop = entry * (1.0 - (atr_pct * atr_stop_multiple) / 100.0)
            else:
                stop = pct_down(entry, fixed_stop_pct)
    elif method in {"TRAIL_AFTER_T1", "EMA10_EXIT", "TIME_EXIT"}:
        pass
    else:
        return None, None, None, None, f"unknown_method_{method}"

    return entry, stop, t1, t2, ""


def simulate_one_method(
    row: pd.Series,
    df_full: pd.DataFrame,
    method: str,
    horizon_days: int,
    atr_stop_multiple: float,
    fixed_stop_pct: float,
    trail_pct: float,
    time_exit_days: int,
) -> TradeOutcome:
    symbol = str(row.get("symbol"))
    week = str(row.get("week", ""))
    snapshot_date = pd.Timestamp(row.get("snapshot_date"))

    setup_archetype = str(row.get("ai_setup_archetype", ""))
    bulkowski_pattern = str(row.get("ai_bulkowski_pattern", ""))
    trend_stage = str(row.get("ai_trend_stage", ""))
    decision = str(row.get("ai_decision", ""))
    grade = safe_float(row.get("ai_grade_0_10"), 0.0) or 0.0
    market_dependency = str(row.get("ai_market_dependency", ""))
    close_at_signal = safe_float(row.get("close"), 0.0) or 0.0
    atr_pct_14d = safe_float(row.get("atr_pct_14d"))

    empty = TradeOutcome(
        method=method,
        week=week,
        symbol=symbol,
        snapshot_date=snapshot_date.date().isoformat(),
        decision=decision,
        setup_archetype=setup_archetype,
        bulkowski_pattern=bulkowski_pattern,
        trend_stage=trend_stage,
        grade_0_10=grade,
        market_dependency=market_dependency,
        close_at_signal=close_at_signal,
        entry=np.nan,
        stop=np.nan,
        t1=None,
        t2=None,
        atr_pct_14d=atr_pct_14d,
        triggered=False,
        trigger_date="",
        days_to_trigger=None,
        exit_date="",
        days_to_exit=None,
        exit_reason="NO_DATA",
        exit_price=None,
        pnl_pct=None,
        max_gain_pct=None,
        max_drawdown_pct=None,
        t1_hit=False,
        t1_hit_date="",
        t2_hit=False,
        t2_hit_date="",
        stop_hit=False,
        stop_hit_date="",
        final_close_pct=None,
        stop_then_recovered_flag=False,
        stop_too_tight_flag=False,
        target_too_optimistic_flag=False,
        notes="",
    )

    if df_full is None or df_full.empty or not isinstance(df_full.index, pd.DatetimeIndex):
        empty.notes = "no_price_data"
        return empty

    df = add_indicators(df_full)
    entry, stop, t1, t2, level_err = derive_method_levels(row, method, df, atr_stop_multiple, fixed_stop_pct)
    if entry is None or stop is None:
        empty.exit_reason = "INVALID_LEVELS"
        empty.notes = level_err or "missing_entry_or_stop"
        return empty

    empty.entry = entry
    empty.stop = stop
    empty.t1 = t1
    empty.t2 = t2

    future = df[df.index > snapshot_date].head(horizon_days).copy()
    if future.empty:
        empty.exit_reason = "NO_FUTURE_DATA"
        return empty

    triggered = False
    trigger_date: Optional[pd.Timestamp] = None
    t1_hit = False
    t2_hit = False
    stop_hit = False
    t1_date = ""
    t2_date = ""
    stop_date = ""
    exit_reason = "TIME_HORIZON"
    exit_price: Optional[float] = None
    exit_date: Optional[pd.Timestamp] = None
    max_high_after_entry: Optional[float] = None
    min_low_after_entry: Optional[float] = None
    highest_since_t1: Optional[float] = None
    trail_stop: Optional[float] = None

    for dt, bar in future.iterrows():
        high = float(bar["High"])
        low = float(bar["Low"])
        close = float(bar["Close"])
        ema10 = safe_float(bar.get("EMA10"))

        if not triggered:
            # Long setup. Entry triggers when daily high reaches entry.
            if high >= entry:
                triggered = True
                trigger_date = dt
                max_high_after_entry = high
                min_low_after_entry = low
            else:
                continue
        else:
            max_high_after_entry = max(max_high_after_entry or high, high)
            min_low_after_entry = min(min_low_after_entry or low, low)

        # Conservative same-day sequencing: stop first if touched.
        if low <= stop:
            stop_hit = True
            stop_date = dt.date().isoformat()
            exit_reason = "STOP"
            exit_price = stop
            exit_date = dt
            break

        if t1 is not None and not t1_hit and high >= t1:
            t1_hit = True
            t1_date = dt.date().isoformat()
            if method == "TRAIL_AFTER_T1":
                highest_since_t1 = high
                trail_stop = highest_since_t1 * (1.0 - trail_pct / 100.0)

        if t2 is not None and high >= t2:
            t2_hit = True
            t2_date = dt.date().isoformat()
            if method in {"STRUCTURE_FIXED", "FIXED_2PCT_STOP_T1_T2", "ATR_STOP_T1_T2"}:
                exit_reason = "T2"
                exit_price = t2
                exit_date = dt
                break

        if t1_hit and method in {"STRUCTURE_FIXED", "FIXED_2PCT_STOP_T1_T2", "ATR_STOP_T1_T2"} and t2 is None:
            exit_reason = "T1"
            exit_price = t1
            exit_date = dt
            break

        if method == "TRAIL_AFTER_T1" and t1_hit:
            highest_since_t1 = max(highest_since_t1 or high, high)
            trail_stop = highest_since_t1 * (1.0 - trail_pct / 100.0)
            if low <= trail_stop:
                exit_reason = "TRAIL_AFTER_T1"
                exit_price = trail_stop
                exit_date = dt
                break

        if method == "EMA10_EXIT" and triggered and ema10 is not None and close < ema10:
            exit_reason = "EMA10_EXIT"
            exit_price = close
            exit_date = dt
            break

        if method == "TIME_EXIT" and triggered and trigger_date is not None:
            days = trading_days_between(trigger_date, dt, df.index)
            if days is not None and days >= time_exit_days:
                exit_reason = "TIME_EXIT"
                exit_price = close
                exit_date = dt
                break

    if not triggered:
        final_close = float(future["Close"].iloc[-1])
        empty.exit_reason = "ENTRY_NOT_TRIGGERED"
        empty.final_close_pct = pct(final_close, close_at_signal)
        empty.entry = entry
        empty.stop = stop
        empty.t1 = t1
        empty.t2 = t2
        return empty

    if exit_date is None:
        exit_date = future.index[-1]
        exit_price = float(future["Close"].iloc[-1])
        exit_reason = "TIME_HORIZON"

    # If max/min were not updated after trigger, derive from post-trigger slice.
    post_trigger = df[(df.index >= trigger_date) & (df.index <= exit_date)] if trigger_date is not None else pd.DataFrame()
    if not post_trigger.empty:
        max_high_after_entry = float(post_trigger["High"].max())
        min_low_after_entry = float(post_trigger["Low"].min())

    pnl = pct(exit_price, entry)
    max_gain = pct(max_high_after_entry, entry) if max_high_after_entry is not None else None
    max_dd = pct(min_low_after_entry, entry) if min_low_after_entry is not None else None
    final_close = float(future["Close"].iloc[-1])
    final_close_pct = pct(final_close, entry)

    days_to_trigger = trading_days_between(snapshot_date, trigger_date, df.index) if trigger_date is not None else None
    days_to_exit = trading_days_between(trigger_date, exit_date, df.index) if trigger_date is not None else None

    # Methodology diagnostics.
    stop_pct = abs(pct(stop, entry) or 0.0)
    stop_too_tight = False
    if stop_hit and future[future.index > exit_date].head(10).empty is False:
        next_10 = future[future.index > exit_date].head(10)
        if not next_10.empty:
            rebound_from_entry = pct(float(next_10["High"].max()), entry)
            stop_then_recovered = bool(rebound_from_entry is not None and rebound_from_entry >= 3.0)
            stop_too_tight = bool(stop_then_recovered and stop_pct <= 2.0)
        else:
            stop_then_recovered = False
    else:
        stop_then_recovered = False

    t1_pct = pct(t1, entry) if t1 is not None else None
    target_too_optimistic = bool(t1_pct is not None and t1_pct >= 8.0 and not t1_hit and max_gain is not None and max_gain < t1_pct * 0.5)

    return TradeOutcome(
        method=method,
        week=week,
        symbol=symbol,
        snapshot_date=snapshot_date.date().isoformat(),
        decision=decision,
        setup_archetype=setup_archetype,
        bulkowski_pattern=bulkowski_pattern,
        trend_stage=trend_stage,
        grade_0_10=grade,
        market_dependency=market_dependency,
        close_at_signal=close_at_signal,
        entry=entry,
        stop=stop,
        t1=t1,
        t2=t2,
        atr_pct_14d=atr_pct_14d,
        triggered=True,
        trigger_date=trigger_date.date().isoformat() if trigger_date is not None else "",
        days_to_trigger=days_to_trigger,
        exit_date=exit_date.date().isoformat() if exit_date is not None else "",
        days_to_exit=days_to_exit,
        exit_reason=exit_reason,
        exit_price=exit_price,
        pnl_pct=pnl,
        max_gain_pct=max_gain,
        max_drawdown_pct=max_dd,
        t1_hit=t1_hit,
        t1_hit_date=t1_date,
        t2_hit=t2_hit,
        t2_hit_date=t2_date,
        stop_hit=stop_hit,
        stop_hit_date=stop_date,
        final_close_pct=final_close_pct,
        stop_then_recovered_flag=stop_then_recovered,
        stop_too_tight_flag=stop_too_tight,
        target_too_optimistic_flag=target_too_optimistic,
        notes="",
    )


# -----------------------------
# Summary generation
# -----------------------------


def summarize_results(results: pd.DataFrame) -> pd.DataFrame:
    if results.empty:
        return pd.DataFrame()

    df = results.copy()
    df["pnl_pct"] = pd.to_numeric(df["pnl_pct"], errors="coerce")
    df["max_gain_pct"] = pd.to_numeric(df["max_gain_pct"], errors="coerce")
    df["max_drawdown_pct"] = pd.to_numeric(df["max_drawdown_pct"], errors="coerce")

    groups = [
        ["method"],
        ["method", "setup_archetype"],
        ["method", "trend_stage"],
        ["method", "bulkowski_pattern"],
        ["method", "market_dependency"],
        ["method", "week"],
    ]

    rows: List[Dict[str, Any]] = []
    for group_cols in groups:
        for keys, g in df.groupby(group_cols, dropna=False):
            if not isinstance(keys, tuple):
                keys = (keys,)
            row: Dict[str, Any] = {"group_by": "+".join(group_cols)}
            for c, v in zip(group_cols, keys):
                row[c] = v

            triggered = g[g["triggered"] == True]
            row["signals"] = len(g)
            row["triggered"] = len(triggered)
            row["trigger_rate_pct"] = round(len(triggered) / len(g) * 100.0, 2) if len(g) else 0
            row["avg_pnl_pct"] = round(triggered["pnl_pct"].mean(), 3) if not triggered.empty else np.nan
            row["median_pnl_pct"] = round(triggered["pnl_pct"].median(), 3) if not triggered.empty else np.nan
            row["win_rate_pct"] = round((triggered["pnl_pct"] > 0).mean() * 100.0, 2) if not triggered.empty else np.nan
            row["avg_max_gain_pct"] = round(triggered["max_gain_pct"].mean(), 3) if not triggered.empty else np.nan
            row["avg_max_drawdown_pct"] = round(triggered["max_drawdown_pct"].mean(), 3) if not triggered.empty else np.nan
            row["t1_hit_rate_pct"] = round(triggered["t1_hit"].mean() * 100.0, 2) if not triggered.empty else np.nan
            row["t2_hit_rate_pct"] = round(triggered["t2_hit"].mean() * 100.0, 2) if not triggered.empty else np.nan
            row["stop_hit_rate_pct"] = round(triggered["stop_hit"].mean() * 100.0, 2) if not triggered.empty else np.nan
            row["stop_too_tight_rate_pct"] = round(triggered["stop_too_tight_flag"].mean() * 100.0, 2) if not triggered.empty else np.nan
            row["target_too_optimistic_rate_pct"] = round(triggered["target_too_optimistic_flag"].mean() * 100.0, 2) if not triggered.empty else np.nan
            rows.append(row)

    return pd.DataFrame(rows)


def write_csv(path: str, rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


# -----------------------------
# Main
# -----------------------------


def main() -> int:
    args = parse_args()
    setups = load_setups(
        args.setups_csv,
        only_ai_selected=args.only_ai_selected,
        include_future_setups=args.include_future_setups,
        min_grade=args.min_grade,
        max_symbols=args.max_symbols,
    )

    if setups.empty:
        print("No setups to evaluate after filters.")
        return 0

    min_date = pd.Timestamp(setups["snapshot_date"].min()) - pd.Timedelta(days=260)
    max_date = pd.Timestamp(setups["snapshot_date"].max()) + pd.Timedelta(days=args.download_extra_calendar_days)
    symbols = sorted(setups["symbol"].unique().tolist())
    print(f"Loaded setups: {len(setups)} rows, {len(symbols)} symbols")
    print(f"Downloading OHLCV from {min_date.date()} to {max_date.date()}")

    histories = download_history(symbols, min_date.date().isoformat(), max_date.date().isoformat())

    methods = [
        "STRUCTURE_FIXED",
        "FIXED_2PCT_STOP_T1_T2",
        "ATR_STOP_T1_T2",
        "TRAIL_AFTER_T1",
        "EMA10_EXIT",
        "TIME_EXIT",
    ]

    results: List[Dict[str, Any]] = []
    for idx, row in setups.iterrows():
        symbol = str(row["symbol"])
        df = histories.get(symbol, pd.DataFrame())
        for method in methods:
            outcome = simulate_one_method(
                row=row,
                df_full=df,
                method=method,
                horizon_days=args.horizon_days,
                atr_stop_multiple=args.atr_stop_multiple,
                fixed_stop_pct=args.fixed_stop_pct,
                trail_pct=args.trail_pct,
                time_exit_days=args.time_exit_days,
            )
            results.append(asdict(outcome))
        if (idx + 1) % 100 == 0:
            print(f"Evaluated {idx + 1}/{len(setups)} setup rows")

    results_df = pd.DataFrame(results)
    results_df.to_csv(args.output_results, index=False, encoding="utf-8")
    print(f"Wrote results: {args.output_results} rows={len(results_df)}")

    summary_df = summarize_results(results_df)
    summary_df.to_csv(args.output_summary, index=False, encoding="utf-8")
    print(f"Wrote summary: {args.output_summary} rows={len(summary_df)}")

    # Print concise top-level summary.
    top = summary_df[summary_df["group_by"] == "method"].copy()
    if not top.empty:
        cols = ["method", "signals", "triggered", "avg_pnl_pct", "win_rate_pct", "t1_hit_rate_pct", "stop_hit_rate_pct", "stop_too_tight_rate_pct"]
        print("\nMethod summary:")
        print(top[cols].to_string(index=False))

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
