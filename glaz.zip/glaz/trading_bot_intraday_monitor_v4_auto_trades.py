#!/usr/bin/env python3
"""
Intraday trade monitor for Google Sheets watchlists.

What it does
- Reads the current Watchlist sheet
- Reads the previous N weekly Watchlist snapshot sheets (if they exist)
- Reads the Trades sheet and monitors only rows with status OPEN
- Automatically creates/updates Trades rows when ENTRY/partial/full-exit events occur
- Pulls delayed intraday OHLC data from Yahoo Finance
- Triggers alerts when:
    high >= entry
    high >= t1
    high >= t2
    low  <= stop
- Prevents duplicate alerts across runs using dedicated alert timestamp columns
- Adds smart trade-management alerts with clear blind-executable actions
- Smart management alerts are generated only from Trades rows, not historical watchlist snapshots
- Updates source sheets and appends to DailySignals
- Sends Telegram alerts in HTML mode if configured, otherwise logs to stdout

Main patch in this version
- Supports previous weekly snapshot sheets like: Y26W11 Watchlist
- Supports a Trades sheet with status=open filtering
- Rounds current price / OHLC values to 2 decimals in Telegram messages
- Highlights the triggered level (ENTRY / STOP / T1 / T2) in bold
- Uses GOOGLE_APPLICATION_CREDENTIALS as a file path via:
    gspread.service_account(filename=GOOGLE_APPLICATION_CREDENTIALS)
"""

import os
import json
import time
import traceback
from datetime import datetime, timedelta
from html import escape
from typing import Any, Dict, List, Optional, Tuple

import requests
import pandas as pd
import yfinance as yf
import gspread


SHEET_ID = os.getenv("SHEET_ID", "").strip()
WATCHLIST_TAB = os.getenv("WATCHLIST_TAB", "Watchlist").strip()
SIGNALS_TAB = os.getenv("SIGNALS_TAB", "DailySignals").strip()
TRADES_TAB = os.getenv("TRADES_TAB", "Trades").strip()
TRADES_STATUS_COLUMN = os.getenv("TRADES_STATUS_COLUMN", "status").strip().lower()
TRADES_OPEN_STATUS = os.getenv("TRADES_OPEN_STATUS", "open").strip().lower()
TRADES_CLOSED_STATUS = os.getenv("TRADES_CLOSED_STATUS", "closed").strip().lower()
AUTO_CREATE_TRADES = os.getenv("AUTO_CREATE_TRADES", "true").strip().lower() in ("1", "true", "yes", "y")

GOOGLE_APPLICATION_CREDENTIALS = os.getenv("GOOGLE_APPLICATION_CREDENTIALS", "").strip()

MONITOR_INTERVAL = os.getenv("MONITOR_INTERVAL", "15m").strip()
YF_PERIOD = os.getenv("YF_PERIOD", "2d").strip()
ALERTS_REQUIRE_TRADE = os.getenv("ALERTS_REQUIRE_TRADE", "true").strip().lower() in ("1", "true", "yes", "y")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "").strip()

SYMBOL_OVERRIDES_JSON = os.getenv("SYMBOL_OVERRIDES_JSON", "").strip()
MONITOR_NAME = os.getenv("MONITOR_NAME", "intraday-monitor").strip()
HISTORY_SHEETS_LOOKBACK_WEEKS = int(os.getenv("HISTORY_SHEETS_LOOKBACK_WEEKS", "4").strip())
SNAPSHOT_SUFFIX = os.getenv("SNAPSHOT_SUFFIX", "Watchlist").strip()

# Smart trade-management settings. Tune from env if needed.
WEAK_EXIT_DAYS = int(os.getenv("WEAK_EXIT_DAYS", "10").strip())
WEAK_EXIT_MIN_GAIN_PCT = float(os.getenv("WEAK_EXIT_MIN_GAIN_PCT", "1.0").strip())
MAX_HOLD_DAYS = int(os.getenv("MAX_HOLD_DAYS", "30").strip())
TAKE_PROFIT_GAIN_PCT = float(os.getenv("TAKE_PROFIT_GAIN_PCT", "5.0").strip())
EMA_EXIT_PERIOD = int(os.getenv("EMA_EXIT_PERIOD", "10").strip())
RUNNER_START_GAIN_PCT = float(os.getenv("RUNNER_START_GAIN_PCT", "8.0").strip())
RUNNER_TRAIL_PCT = float(os.getenv("RUNNER_TRAIL_PCT", "3.0").strip())
DAILY_HISTORY_PERIOD = os.getenv("DAILY_HISTORY_PERIOD", "60d").strip()

WATCHLIST_HEADERS = [
    "symbol", "decision", "entry", "stop", "t1", "t2",
    "last_run", "last_close", "last_status", "last_signal_ts", "notes",
    "entry_alerted_at", "t1_alerted_at", "t2_alerted_at", "stop_alerted_at",
    "take_profit_alerted_at", "runner_trail_alerted_at", "trail_stop_hit_alerted_at",
    "exit_weak_alerted_at", "max_hold_exit_alerted_at",
]

TRADES_HEADERS = [
    "symbol", "status", "entry", "stop", "t1", "t2",
    "entry_date", "open_date", "source_sheet",
    "position_pct_remaining", "closed_at", "exit_reason",
    "last_run", "last_close", "last_status", "last_signal_ts", "notes",
    "entry_alerted_at", "t1_alerted_at", "t2_alerted_at", "stop_alerted_at",
    "take_profit_alerted_at", "runner_trail_alerted_at", "trail_stop_hit_alerted_at",
    "exit_weak_alerted_at", "max_hold_exit_alerted_at",
]

SIGNALS_HEADERS = [
    "ts", "week_id", "symbol", "event", "action", "price", "entry", "stop", "t1", "t2",
    "bar_ts", "source", "notes",
]


def now_str_local() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def log(msg: str) -> None:
    print(f"[{now_str_local()}] {msg}", flush=True)


def to_float(v: Any) -> Optional[float]:
    if v is None:
        return None
    if isinstance(v, (int, float)):
        return float(v)
    s = str(v).strip().replace(",", "")
    if not s:
        return None
    try:
        return float(s)
    except Exception:
        return None


def fmt2(v: Any) -> str:
    x = to_float(v)
    return f"{x:.2f}" if x is not None else ""


def parse_symbol_overrides() -> Dict[str, str]:
    if not SYMBOL_OVERRIDES_JSON:
        return {}
    try:
        data = json.loads(SYMBOL_OVERRIDES_JSON)
        if isinstance(data, dict):
            return {str(k).strip(): str(v).strip() for k, v in data.items()}
    except Exception as e:
        log(f"WARNING: invalid SYMBOL_OVERRIDES_JSON -> {e}")
    return {}


SYMBOL_OVERRIDES = parse_symbol_overrides()


def previous_snapshot_titles(lookback_weeks: int, suffix: str) -> List[str]:
    titles: List[str] = []
    now = datetime.now()
    for i in range(1, lookback_weeks + 1):
        d = now - timedelta(weeks=i)
        iso = d.isocalendar()
        yy = iso.year % 100
        ww = iso.week
        titles.append(f"Y{yy:02d}W{ww:02d} {suffix}")
    return titles


def get_optional_worksheet(sh: gspread.Spreadsheet, title: str) -> Optional[gspread.Worksheet]:
    try:
        return sh.worksheet(title)
    except gspread.WorksheetNotFound:
        log(f"Sheet not found, skipping: {title}")
        return None


def tv_to_yahoo_symbol(symbol: str) -> str:
    """
    Converts 'NASDAQ:AAPL' -> 'AAPL'.
    Keeps already-Yahoo-style tickers as-is.
    """
    s = (symbol or "").strip()
    if not s:
        return s
    if s in SYMBOL_OVERRIDES:
        return SYMBOL_OVERRIDES[s]
    if ":" in s:
        return s.split(":")[-1].strip()
    return s


def sheet_col_map(headers: List[str]) -> Dict[str, int]:
    out: Dict[str, int] = {}
    for i, h in enumerate(headers, start=1):
        key = (h or "").strip().lower()
        if not key:
            continue
        out[key] = i
        out[key.replace(" ", "_")] = i
        out[key.replace("_", " ")] = i
    return out


def ensure_headers(ws: gspread.Worksheet, required_headers: List[str]) -> Dict[str, int]:
    values = ws.get_all_values()
    header_row = values[0] if values else []
    existing = [str(x).strip() for x in header_row]
    existing_lc = {x.strip().lower(): idx + 1 for idx, x in enumerate(existing) if str(x).strip()}
    next_col = len(existing) + 1
    updates = []
    missing = 0
    for h in required_headers:
        if h.lower() not in existing_lc:
            updates.append({
                "range": gspread.utils.rowcol_to_a1(1, next_col),
                "values": [[h]],
            })
            existing_lc[h.lower()] = next_col
            existing.append(h)
            next_col += 1
            missing += 1

    if missing > 0:
        current_cols = getattr(ws, "col_count", len(header_row) or 1)
        needed_cols = len(existing)
        if needed_cols > current_cols:
            ws.add_cols(needed_cols - current_cols)

    if updates:
        ws.batch_update(updates)
    return sheet_col_map(existing)


def get_cell(row: List[str], col_map: Dict[str, int], key: str) -> str:
    idx = col_map.get(key.lower()) or col_map.get(key.replace("_", " ").lower())
    if not idx:
        return ""
    j = idx - 1
    return row[j] if 0 <= j < len(row) else ""


def batch_update_cells(ws: gspread.Worksheet, row_index: int, updates: List[Tuple[int, Any]]) -> None:
    if not updates:
        return
    payload = []
    for col_idx, val in updates:
        payload.append({
            "range": gspread.utils.rowcol_to_a1(row_index, col_idx),
            "values": [["" if val is None else str(val)]],
        })
    ws.batch_update(payload)


def append_row(ws: gspread.Worksheet, values_by_header: Dict[str, Any], col_map: Dict[str, int]) -> None:
    max_col = max(col_map.values()) if col_map else 1
    row = [""] * max_col
    for k, v in values_by_header.items():
        col_idx = col_map.get(k.lower()) or col_map.get(k.replace("_", " ").lower())
        if col_idx:
            row[col_idx - 1] = "" if v is None else str(v)
    ws.append_row(row, value_input_option="USER_ENTERED")




def append_trade_row(ws_trades: gspread.Worksheet, values_by_header: Dict[str, Any]) -> None:
    col_map = ensure_headers(ws_trades, TRADES_HEADERS)
    append_row(ws_trades, values_by_header, col_map)


def find_open_trade_row(ws_trades: gspread.Worksheet, symbol: str) -> Tuple[Optional[int], Optional[List[str]], Dict[str, int]]:
    """Return row index, row values, col_map for an open trade matching symbol. Manual columns are ignored."""
    col_map = ensure_headers(ws_trades, TRADES_HEADERS)
    values = ws_trades.get_all_values()
    target = (symbol or "").strip().upper()
    for row_index, row in enumerate(values[1:], start=2):
        row_symbol = (get_cell(row, col_map, "symbol") or "").strip().upper()
        row_status = (get_cell(row, col_map, TRADES_STATUS_COLUMN) or "").strip().lower()
        if row_symbol == target and row_status == TRADES_OPEN_STATUS:
            return row_index, row, col_map
    return None, None, col_map


def get_remaining_pct(row: List[str], col_map: Dict[str, int]) -> float:
    current = to_float(get_cell(row, col_map, "position_pct_remaining"))
    if current is None or current <= 0:
        return 100.0
    return max(0.0, min(100.0, current))


def trade_ledger_updates_for_event(
    event: str,
    row: List[str],
    col_map: Dict[str, int],
    bar: Dict[str, Any],
    source_name: str,
    ts_now: str,
) -> List[Tuple[int, Any]]:
    """Updates only official bot columns. Any user/manual columns are ignored."""
    event = event.upper().strip()
    updates: List[Tuple[int, Any]] = []
    remaining = get_remaining_pct(row, col_map)

    def add(key: str, value: Any) -> None:
        if key in col_map:
            updates.append((col_map[key], value))

    add("last_run", ts_now)
    add("last_close", bar.get("close"))
    add("last_status", event)
    add("last_signal_ts", ts_now)

    if event == "ENTRY":
        add("status", TRADES_OPEN_STATUS)
        add("entry_date", ts_now.split(" ")[0])
        add("open_date", ts_now)
        add("position_pct_remaining", 100)
        add("source_sheet", source_name)
        add("entry_alerted_at", ts_now)
        return updates

    if event in ("T1", "TAKE_PROFIT"):
        # Blind-execution rule: sell 50% of CURRENT position, keep the rest open.
        new_remaining = round(remaining * 0.5, 2)
        add("position_pct_remaining", new_remaining)
        add("status", TRADES_OPEN_STATUS if new_remaining > 0 else TRADES_CLOSED_STATUS)
        if event == "T1":
            add("t1_alerted_at", ts_now)
        else:
            add("take_profit_alerted_at", ts_now)
        return updates

    if event == "RUNNER_TRAIL":
        add("runner_trail_alerted_at", ts_now)
        return updates

    if event in ("STOP", "T2", "TRAIL_STOP_HIT", "EXIT_WEAK", "MAX_HOLD_EXIT"):
        add("status", TRADES_CLOSED_STATUS)
        add("position_pct_remaining", 0)
        add("closed_at", ts_now)
        add("exit_reason", event)
        if event == "STOP":
            add("stop_alerted_at", ts_now)
        elif event == "T2":
            add("t2_alerted_at", ts_now)
        elif event == "TRAIL_STOP_HIT":
            add("trail_stop_hit_alerted_at", ts_now)
        elif event == "EXIT_WEAK":
            add("exit_weak_alerted_at", ts_now)
        elif event == "MAX_HOLD_EXIT":
            add("max_hold_exit_alerted_at", ts_now)
        return updates

    return updates


def sync_trades_sheet_from_event(
    ws_trades: Optional[gspread.Worksheet],
    symbol: str,
    event: str,
    source_row: List[str],
    source_col_map: Dict[str, int],
    bar: Dict[str, Any],
    source_name: str,
    note: str,
    ts_now: str,
) -> None:
    """Auto-ledger sync. ENTRY creates an OPEN trade. Partial/full exits update the open trade.

    Important: the script deliberately ignores any manual/user column in Trades.
    """
    if ws_trades is None or not AUTO_CREATE_TRADES:
        return

    event = event.upper().strip()
    if event not in ("ENTRY", "T1", "T2", "STOP", "TAKE_PROFIT", "RUNNER_TRAIL", "TRAIL_STOP_HIT", "EXIT_WEAK", "MAX_HOLD_EXIT"):
        return

    row_index, trade_row, trade_col_map = find_open_trade_row(ws_trades, symbol)

    if event == "ENTRY":
        if row_index is not None:
            # Already open; do not duplicate. Add a note only.
            existing_notes = get_cell(trade_row or [], trade_col_map, "notes")
            updates = []
            if "notes" in trade_col_map:
                updates.append((trade_col_map["notes"], append_note(existing_notes, f"[AUTO_TRADES_DUPLICATE_ENTRY_IGNORED] {note}")))
            if "last_run" in trade_col_map:
                updates.append((trade_col_map["last_run"], ts_now))
            if updates:
                batch_update_cells(ws_trades, row_index, updates)
            return

        append_trade_row(ws_trades, {
            "symbol": symbol,
            "status": TRADES_OPEN_STATUS,
            "entry": get_cell(source_row, source_col_map, "entry"),
            "stop": get_cell(source_row, source_col_map, "stop"),
            "t1": get_cell(source_row, source_col_map, "t1"),
            "t2": get_cell(source_row, source_col_map, "t2"),
            "entry_date": ts_now.split(" ")[0],
            "open_date": ts_now,
            "source_sheet": source_name,
            "position_pct_remaining": 100,
            "last_run": ts_now,
            "last_close": bar.get("close"),
            "last_status": "ENTRY",
            "last_signal_ts": ts_now,
            "entry_alerted_at": ts_now,
            "notes": f"[AUTO_TRADES_OPENED] {note}",
        })
        log(f"Trades | {symbol}: auto-created OPEN trade from {source_name}")
        return

    # For exits/management, only update if a real open trade exists.
    if row_index is None or trade_row is None:
        log(f"Trades | {symbol}: {event} ignored for ledger; no OPEN trade found")
        return

    updates = trade_ledger_updates_for_event(event, trade_row, trade_col_map, bar, source_name, ts_now)
    existing_notes = get_cell(trade_row, trade_col_map, "notes")
    if "notes" in trade_col_map:
        updates.append((trade_col_map["notes"], append_note(existing_notes, f"[AUTO_TRADES_{event}] {note}")))
    batch_update_cells(ws_trades, row_index, updates)
    log(f"Trades | {symbol}: auto-updated ledger for {event}")

def iso_week_id(dt_val: Optional[datetime] = None) -> str:
    dt_val = dt_val or datetime.now()
    y, w, _ = dt_val.isocalendar()
    return f"{y}-W{w:02d}"


def send_telegram_message(text: str) -> None:
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        log("Telegram not configured; message below:")
        print(text, flush=True)
        return
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "disable_web_page_preview": True,
        "parse_mode": "HTML",
    }
    r = requests.post(url, json=payload, timeout=20)
    r.raise_for_status()


def append_note(existing: str, new_note: str) -> str:
    existing = (existing or "").strip()
    new_note = (new_note or "").strip()
    if not new_note:
        return existing
    if not existing:
        return new_note
    if new_note in existing:
        return existing
    return existing + "\n" + new_note


def fetch_latest_bar(yahoo_symbol: str, interval: str, period: str) -> Optional[Dict[str, Any]]:
    try:
        df = yf.download(
            tickers=yahoo_symbol,
            interval=interval,
            period=period,
            progress=False,
            auto_adjust=False,
            threads=False,
            prepost=False,
            group_by="column",
        )
    except Exception as e:
        log(f"{yahoo_symbol}: yfinance error -> {e}")
        return None

    if df is None or df.empty:
        return None

    try:
        if hasattr(df.columns, "nlevels") and df.columns.nlevels > 1:
            df = df.copy()
            df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]

        last = df.iloc[-1]
        idx = df.index[-1]

        return {
            "bar_ts": str(idx),
            "open": to_float(last["Open"]) if "Open" in last.index else None,
            "high": to_float(last["High"]) if "High" in last.index else None,
            "low": to_float(last["Low"]) if "Low" in last.index else None,
            "close": to_float(last["Close"]) if "Close" in last.index else None,
            "volume": to_float(last["Volume"]) if "Volume" in last.index else None,
        }
    except Exception as e:
        log(f"{yahoo_symbol}: could not parse latest bar -> {e}")
        return None




def parse_datetime_any(value: Any) -> Optional[datetime]:
    s = (str(value).strip() if value is not None else "")
    if not s:
        return None
    try:
        dt = pd.to_datetime(s, errors="coerce")
        if not pd.isna(dt):
            return dt.to_pydatetime()
    except Exception:
        pass
    for fmt in ("%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%d/%m/%Y", "%d/%m/%Y %H:%M:%S"):
        try:
            return datetime.strptime(s, fmt)
        except Exception:
            continue
    return None


def infer_entry_datetime(row: List[str], col_map: Dict[str, int]) -> Optional[datetime]:
    for key in ("entry_date", "open_date", "entry_alerted_at", "last_signal_ts", "last_run"):
        dt = parse_datetime_any(get_cell(row, col_map, key))
        if dt is not None:
            return dt
    return None


def fetch_daily_history(yahoo_symbol: str, period: str = DAILY_HISTORY_PERIOD) -> Optional[pd.DataFrame]:
    try:
        df = yf.download(
            tickers=yahoo_symbol,
            interval="1d",
            period=period,
            progress=False,
            auto_adjust=False,
            threads=False,
            prepost=False,
            group_by="column",
        )
    except Exception as e:
        log(f"{yahoo_symbol}: yfinance daily history error -> {e}")
        return None
    if df is None or df.empty:
        return None
    if hasattr(df.columns, "nlevels") and df.columns.nlevels > 1:
        df = df.copy()
        df.columns = [c[0] if isinstance(c, tuple) else c for c in df.columns]
    return df.dropna(how="all")


def get_action_for_event(event: str, row: Optional[List[str]] = None, col_map: Optional[Dict[str, int]] = None) -> str:
    event = event.upper().strip()
    if event == "ENTRY":
        return "BUY 100% of planned position"
    if event == "STOP":
        return "SELL 100% of current/remaining position immediately"
    if event == "T1":
        return "SELL 50% of current position"
    if event == "T2":
        return "SELL 100% of remaining position"
    if event == "TAKE_PROFIT":
        return "SELL 50% of current position"
    if event == "RUNNER_TRAIL":
        return f"HOLD, set/raise trailing stop {RUNNER_TRAIL_PCT:.1f}% below highest close since entry"
    if event == "TRAIL_STOP_HIT":
        return "SELL 100% of remaining position"
    if event == "EXIT_WEAK":
        return "SELL 100% of current position"
    if event == "MAX_HOLD_EXIT":
        return "SELL 100% of current position"
    return "HOLD / no manual action"


def evaluate_management_events(row: List[str], col_map: Dict[str, int], bar: Dict[str, Any], daily_df: Optional[pd.DataFrame]) -> List[Dict[str, Any]]:
    entry = to_float(get_cell(row, col_map, "entry"))
    close_v = to_float(bar.get("close"))
    if entry is None or close_v is None or entry <= 0:
        return []
    active_dt = infer_entry_datetime(row, col_map)
    if active_dt is None:
        return []
    days_open = max(0, (datetime.now().date() - active_dt.date()).days)
    pnl_pct = ((close_v / entry) - 1.0) * 100.0

    highest_close = close_v
    ema_value = None
    max_gain_pct = pnl_pct
    trail_stop_price = None

    if daily_df is not None and not daily_df.empty and "Close" in daily_df.columns:
        try:
            hist = daily_df.copy()
            try:
                hist = hist[hist.index.date >= active_dt.date()]
            except Exception:
                pass
            closes = hist["Close"].dropna()
            if not closes.empty:
                highest_close = float(closes.max())
                max_gain_pct = ((highest_close / entry) - 1.0) * 100.0
                ema_value = float(closes.ewm(span=EMA_EXIT_PERIOD, adjust=False).mean().iloc[-1])
                trail_stop_price = highest_close * (1.0 - RUNNER_TRAIL_PCT / 100.0)
        except Exception as e:
            log(f"WARNING: management history calculation failed -> {e}")

    if days_open >= MAX_HOLD_DAYS and not get_cell(row, col_map, "max_hold_exit_alerted_at"):
        return [{"event": "MAX_HOLD_EXIT", "trigger_price": close_v, "level": close_v, "action": get_action_for_event("MAX_HOLD_EXIT"), "reason": f"days_open={days_open} >= {MAX_HOLD_DAYS}; max holding period reached"}]
    if days_open >= WEAK_EXIT_DAYS and pnl_pct < WEAK_EXIT_MIN_GAIN_PCT and not get_cell(row, col_map, "exit_weak_alerted_at"):
        return [{"event": "EXIT_WEAK", "trigger_price": close_v, "level": close_v, "action": get_action_for_event("EXIT_WEAK"), "reason": f"days_open={days_open} >= {WEAK_EXIT_DAYS} and pnl={pnl_pct:.2f}% < {WEAK_EXIT_MIN_GAIN_PCT:.2f}%"}]
    if max_gain_pct >= RUNNER_START_GAIN_PCT and trail_stop_price is not None:
        if close_v <= trail_stop_price and not get_cell(row, col_map, "trail_stop_hit_alerted_at"):
            return [{"event": "TRAIL_STOP_HIT", "trigger_price": close_v, "level": trail_stop_price, "action": get_action_for_event("TRAIL_STOP_HIT"), "reason": f"max_gain={max_gain_pct:.2f}% and close={close_v:.2f} <= trail_stop={trail_stop_price:.2f}"}]
        if not get_cell(row, col_map, "runner_trail_alerted_at"):
            return [{"event": "RUNNER_TRAIL", "trigger_price": close_v, "level": trail_stop_price, "action": get_action_for_event("RUNNER_TRAIL"), "reason": f"max_gain={max_gain_pct:.2f}% >= {RUNNER_START_GAIN_PCT:.2f}%; suggested trailing stop={trail_stop_price:.2f}"}]
    if pnl_pct >= TAKE_PROFIT_GAIN_PCT and ema_value is not None and close_v < ema_value and not get_cell(row, col_map, "take_profit_alerted_at"):
        return [{"event": "TAKE_PROFIT", "trigger_price": close_v, "level": ema_value, "action": get_action_for_event("TAKE_PROFIT"), "reason": f"pnl={pnl_pct:.2f}% >= {TAKE_PROFIT_GAIN_PCT:.2f}% and close={close_v:.2f} < EMA{EMA_EXIT_PERIOD}={ema_value:.2f}"}]
    return []

def connect_sheets() -> Tuple[gspread.Spreadsheet, gspread.Worksheet, gspread.Worksheet, Optional[gspread.Worksheet]]:
    if not SHEET_ID:
        raise RuntimeError("SHEET_ID is required")
    if not GOOGLE_APPLICATION_CREDENTIALS:
        raise RuntimeError("GOOGLE_APPLICATION_CREDENTIALS is required")

    gc = gspread.service_account(filename=GOOGLE_APPLICATION_CREDENTIALS)
    sh = gc.open_by_key(SHEET_ID)

    ws_watch = sh.worksheet(WATCHLIST_TAB)
    try:
        ws_signals = sh.worksheet(SIGNALS_TAB)
    except gspread.WorksheetNotFound:
        ws_signals = sh.add_worksheet(title=SIGNALS_TAB, rows=1000, cols=20)

    ws_trades = get_optional_worksheet(sh, TRADES_TAB)
    if ws_trades is None:
        ws_trades = sh.add_worksheet(title=TRADES_TAB, rows=1000, cols=max(30, len(TRADES_HEADERS)))

    ensure_headers(ws_watch, WATCHLIST_HEADERS)
    ensure_headers(ws_signals, SIGNALS_HEADERS)
    ensure_headers(ws_trades, TRADES_HEADERS)

    return sh, ws_watch, ws_signals, ws_trades


def is_open_trade_row(row: List[str], col_map: Dict[str, int]) -> bool:
    status = (get_cell(row, col_map, TRADES_STATUS_COLUMN) or "").strip().lower()
    return status == TRADES_OPEN_STATUS


def is_trade_watchlist_row(row: List[str], col_map: Dict[str, int]) -> bool:
    decision = (get_cell(row, col_map, "decision") or "").strip().upper()
    if ALERTS_REQUIRE_TRADE:
        return decision == "TRADE"
    return True


def evaluate_events(row: List[str], col_map: Dict[str, int], bar: Dict[str, Any]) -> List[Dict[str, Any]]:
    entry = to_float(get_cell(row, col_map, "entry"))
    stop = to_float(get_cell(row, col_map, "stop"))
    t1 = to_float(get_cell(row, col_map, "t1"))
    t2 = to_float(get_cell(row, col_map, "t2"))

    high_v = to_float(bar.get("high"))
    low_v = to_float(bar.get("low"))
    close_v = to_float(bar.get("close"))

    events: List[Dict[str, Any]] = []

    if entry is not None and high_v is not None and not get_cell(row, col_map, "entry_alerted_at") and high_v >= entry:
        events.append({"event": "ENTRY", "trigger_price": close_v, "level": entry})

    if t1 is not None and high_v is not None and not get_cell(row, col_map, "t1_alerted_at") and high_v >= t1:
        events.append({"event": "T1", "trigger_price": close_v, "level": t1})

    if t2 is not None and high_v is not None and not get_cell(row, col_map, "t2_alerted_at") and high_v >= t2:
        events.append({"event": "T2", "trigger_price": close_v, "level": t2})

    if stop is not None and low_v is not None and not get_cell(row, col_map, "stop_alerted_at") and low_v <= stop:
        events.append({"event": "STOP", "trigger_price": close_v, "level": stop})

    return events


def build_alert_message(
    symbol: str,
    source_sheet: str,
    bar: Dict[str, Any],
    event: str,
    row: List[str],
    col_map: Dict[str, int],
) -> str:
    entry = get_cell(row, col_map, "entry")
    stop = get_cell(row, col_map, "stop")
    t1 = get_cell(row, col_map, "t1")
    t2 = get_cell(row, col_map, "t2")
    notes = get_cell(row, col_map, "notes")

    def level_line(name: str, value: str) -> str:
        rendered_value = fmt2(value) or value
        text = f"{name}: {rendered_value}"
        return f"<b>{escape(text)}</b>" if event.upper() == name.upper() else escape(text)

    action = get_action_for_event(event, row, col_map)

    return (
        f"{escape(MONITOR_NAME)}\n"
        f"Source: {escape(source_sheet)}\n"
        f"Symbol: {escape(symbol)}\n"
        f"Event: <b>{escape(event.upper())}</b>\n"
        f"Action: <b>{escape(action)}</b>\n"
        f"Bar time: {escape(str(bar.get('bar_ts') or ''))}\n"
        f"Current price: {fmt2(bar.get('close'))}\n"
        f"High: {fmt2(bar.get('high'))}\n"
        f"Low: {fmt2(bar.get('low'))}\n"
        f"{level_line('ENTRY', entry)}\n"
        f"{level_line('STOP', stop)}\n"
        f"{level_line('T1', t1)}\n"
        f"{level_line('T2', t2)}\n\n"
        f"Notes:\n{escape(notes or '')}"
    )


def status_for_event(event: str) -> str:
    event = event.upper().strip()
    known = ("ENTRY", "T1", "T2", "STOP", "TAKE_PROFIT", "RUNNER_TRAIL", "TRAIL_STOP_HIT", "EXIT_WEAK", "MAX_HOLD_EXIT")
    return event if event in known else "SIGNAL"


def process_source_sheet(
    ws: gspread.Worksheet,
    ws_signals: gspread.Worksheet,
    required_headers: List[str],
    row_filter_fn,
    source_name: str,
    bar_cache: Dict[str, Optional[Dict[str, Any]]],
    daily_cache: Optional[Dict[str, Optional[pd.DataFrame]]] = None,
    ws_trades_for_sync: Optional[gspread.Worksheet] = None,
    allow_management_events: bool = False,
) -> Tuple[int, int, int]:
    ensure_headers(ws, required_headers)
    values = ws.get_all_values()
    if not values or len(values) < 2:
        log(f"{source_name}: empty sheet")
        return 0, 0, 0

    col_map = sheet_col_map(values[0])
    signals_col_map = ensure_headers(ws_signals, SIGNALS_HEADERS)

    total_rows = 0
    monitored_rows = 0
    alerts_sent = 0

    for row_index, row in enumerate(values[1:], start=2):
        total_rows += 1

        symbol = (get_cell(row, col_map, "symbol") or "").strip()
        if not symbol:
            continue

        if not row_filter_fn(row, col_map):
            continue

        monitored_rows += 1
        yahoo_symbol = tv_to_yahoo_symbol(symbol)

        if yahoo_symbol in bar_cache:
            bar = bar_cache[yahoo_symbol]
        else:
            bar = fetch_latest_bar(yahoo_symbol, MONITOR_INTERVAL, YF_PERIOD)
            bar_cache[yahoo_symbol] = bar

        updates: List[Tuple[int, Any]] = []
        if "last_run" in col_map:
            updates.append((col_map["last_run"], now_str_local()))

        if not bar:
            log(f"{source_name} | {symbol} ({yahoo_symbol}): no intraday data")
            batch_update_cells(ws, row_index, updates)
            continue

        if "last_close" in col_map:
            updates.append((col_map["last_close"], bar.get("close")))

        events = evaluate_events(row, col_map, bar)

        hard_events = {ev.get("event", "").upper() for ev in events}
        if allow_management_events and not hard_events.intersection({"STOP", "T2", "T1", "ENTRY"}):
            daily_df = None
            if daily_cache is not None:
                if yahoo_symbol in daily_cache:
                    daily_df = daily_cache[yahoo_symbol]
                else:
                    daily_df = fetch_daily_history(yahoo_symbol)
                    daily_cache[yahoo_symbol] = daily_df
            events.extend(evaluate_management_events(row, col_map, bar, daily_df))

        if not events:
            batch_update_cells(ws, row_index, updates)
            log(f"{source_name} | {symbol} ({yahoo_symbol}): no new events | close={fmt2(bar.get('close'))}")
            continue

        week_id = iso_week_id()
        existing_notes = get_cell(row, col_map, "notes")

        for ev in events:
            event = ev["event"].upper().strip()
            ts_now = now_str_local()

            if event == "ENTRY" and "entry_alerted_at" in col_map:
                updates.append((col_map["entry_alerted_at"], ts_now))
            elif event == "T1" and "t1_alerted_at" in col_map:
                updates.append((col_map["t1_alerted_at"], ts_now))
            elif event == "T2" and "t2_alerted_at" in col_map:
                updates.append((col_map["t2_alerted_at"], ts_now))
            elif event == "STOP" and "stop_alerted_at" in col_map:
                updates.append((col_map["stop_alerted_at"], ts_now))
            elif event == "TAKE_PROFIT" and "take_profit_alerted_at" in col_map:
                updates.append((col_map["take_profit_alerted_at"], ts_now))
            elif event == "RUNNER_TRAIL" and "runner_trail_alerted_at" in col_map:
                updates.append((col_map["runner_trail_alerted_at"], ts_now))
            elif event == "TRAIL_STOP_HIT" and "trail_stop_hit_alerted_at" in col_map:
                updates.append((col_map["trail_stop_hit_alerted_at"], ts_now))
            elif event == "EXIT_WEAK" and "exit_weak_alerted_at" in col_map:
                updates.append((col_map["exit_weak_alerted_at"], ts_now))
            elif event == "MAX_HOLD_EXIT" and "max_hold_exit_alerted_at" in col_map:
                updates.append((col_map["max_hold_exit_alerted_at"], ts_now))

            if "last_status" in col_map:
                updates.append((col_map["last_status"], status_for_event(event)))
            if "last_signal_ts" in col_map:
                updates.append((col_map["last_signal_ts"], ts_now))

            action = ev.get("action") or get_action_for_event(event, row, col_map)
            reason = ev.get("reason") or ""
            note = (
                f"[INTRADAY_{event}] {ts_now} | action={action} | source={source_name} | "
                f"bar={bar.get('bar_ts')} | close={fmt2(bar.get('close'))} | "
                f"high={fmt2(bar.get('high'))} | low={fmt2(bar.get('low'))}"
                + (f" | reason={reason}" if reason else "")
            )
            existing_notes = append_note(existing_notes, note)

            # Auto-sync Trades ledger from Watchlist / snapshot events.
            # For the Trades sheet itself, update ledger fields directly on the same row.
            if source_name == TRADES_TAB:
                updates.extend(trade_ledger_updates_for_event(event, row, col_map, bar, source_name, ts_now))
            else:
                sync_trades_sheet_from_event(
                    ws_trades=ws_trades_for_sync,
                    symbol=symbol,
                    event=event,
                    source_row=row,
                    source_col_map=col_map,
                    bar=bar,
                    source_name=source_name,
                    note=note,
                    ts_now=ts_now,
                )

            msg = build_alert_message(symbol, source_name, bar, event, row, col_map)
            try:
                send_telegram_message(msg)
                alerts_sent += 1
            except Exception as e:
                log(f"{source_name} | {symbol}: failed to send alert -> {e}")

            append_row(ws_signals, {
                "ts": ts_now,
                "week_id": week_id,
                "symbol": symbol,
                "event": event,
                "action": action,
                "price": fmt2(bar.get("close")),
                "entry": get_cell(row, col_map, "entry"),
                "stop": get_cell(row, col_map, "stop"),
                "t1": get_cell(row, col_map, "t1"),
                "t2": get_cell(row, col_map, "t2"),
                "bar_ts": bar.get("bar_ts"),
                "source": f"{source_name}|YAHOO_{MONITOR_INTERVAL}",
                "notes": note,
            }, signals_col_map)

            log(
                f"{source_name} | {symbol}: {event} triggered | action={action} | "
                f"close={fmt2(bar.get('close'))} high={fmt2(bar.get('high'))} low={fmt2(bar.get('low'))}"
            )

        if "notes" in col_map:
            updates.append((col_map["notes"], existing_notes))

        batch_update_cells(ws, row_index, updates)
        time.sleep(0.5)

    return total_rows, monitored_rows, alerts_sent


def main() -> int:
    sh, ws_watch, ws_signals, ws_trades = connect_sheets()

    total_rows = 0
    monitored_rows = 0
    alerts_sent = 0
    bar_cache: Dict[str, Optional[Dict[str, Any]]] = {}
    daily_cache: Dict[str, Optional[pd.DataFrame]] = {}

    t, m, a = process_source_sheet(
        ws=ws_watch,
        ws_signals=ws_signals,
        required_headers=WATCHLIST_HEADERS,
        row_filter_fn=is_trade_watchlist_row,
        source_name=WATCHLIST_TAB,
        bar_cache=bar_cache,
        daily_cache=daily_cache,
        ws_trades_for_sync=ws_trades,
        allow_management_events=False,
    )
    total_rows += t
    monitored_rows += m
    alerts_sent += a

    for title in previous_snapshot_titles(HISTORY_SHEETS_LOOKBACK_WEEKS, SNAPSHOT_SUFFIX):
        ws_prev = get_optional_worksheet(sh, title)
        if ws_prev is None:
            continue

        t, m, a = process_source_sheet(
            ws=ws_prev,
            ws_signals=ws_signals,
            required_headers=WATCHLIST_HEADERS,
            row_filter_fn=is_trade_watchlist_row,
            source_name=title,
            bar_cache=bar_cache,
            daily_cache=daily_cache,
            ws_trades_for_sync=ws_trades,
            allow_management_events=False,
        )
        total_rows += t
        monitored_rows += m
        alerts_sent += a

    if ws_trades is not None:
        t, m, a = process_source_sheet(
            ws=ws_trades,
            ws_signals=ws_signals,
            required_headers=TRADES_HEADERS,
            row_filter_fn=is_open_trade_row,
            source_name=TRADES_TAB,
            bar_cache=bar_cache,
            daily_cache=daily_cache,
            ws_trades_for_sync=None,
            allow_management_events=True,
        )
        total_rows += t
        monitored_rows += m
        alerts_sent += a

    log(f"Done. total_rows={total_rows} monitored_rows={monitored_rows} alerts_sent={alerts_sent}")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as e:
        log(f"FATAL: {type(e).__name__}: {e}")
        traceback.print_exc()
        raise
