import pandas as pd
import yfinance as yf
from datetime import timedelta
import time

INPUT_FILE = "trade_evaluation.csv"

OUTPUT_ALL_TRADES = "trade_evaluation_with_market_regime.csv"
OUTPUT_STOPPED = "stopped_post_stop_analysis.csv"

VIX_SYMBOL = "^VIX"


# --------------------------------------------------
# Symbol conversion
# --------------------------------------------------
def normalize_symbol(symbol: str) -> str:
    symbol = str(symbol).strip()

    if symbol.startswith("NASDAQ:"):
        return symbol.replace("NASDAQ:", "")

    if symbol.startswith("NYSE:"):
        return symbol.replace("NYSE:", "")

    if symbol.startswith("ATHEX:"):
        return symbol.replace("ATHEX:", "")

    return symbol


# --------------------------------------------------
# Market benchmark mapping
# --------------------------------------------------
def get_market_benchmark(symbol: str):
    symbol = str(symbol).strip().upper()

    if symbol.startswith("NASDAQ:"):
        return "QQQ", "US_NASDAQ"

    if symbol.startswith("NYSE:"):
        return "SPY", "US_NYSE"

    if symbol.startswith("ATHEX:"):
        # Yahoo symbol for Athens General Index is often GD.AT
        return "GD.AT", "GREECE_ATHEX"

    if symbol.endswith(".DE"):
        return "VGK", "EUROPE"

    if symbol.endswith(".PA"):
        return "VGK", "EUROPE"

    if symbol.endswith(".MI"):
        return "VGK", "EUROPE"

    if symbol.endswith(".L"):
        return "VGK", "UK_EUROPE"

    # ETFs / unknown global symbols
    return "SPY", "GLOBAL_DEFAULT"


# --------------------------------------------------
# Safe yfinance helpers
# --------------------------------------------------
def flatten_columns(df: pd.DataFrame) -> pd.DataFrame:
    if isinstance(df.columns, pd.MultiIndex):
        df.columns = df.columns.get_level_values(0)
    return df


def get_column_as_series(df: pd.DataFrame, col_name: str) -> pd.Series:
    col = df[col_name]
    if isinstance(col, pd.DataFrame):
        col = col.iloc[:, 0]
    return col.dropna()


def download_history(symbol: str, start, end):
    hist = yf.download(
        symbol,
        start=start.strftime("%Y-%m-%d"),
        end=end.strftime("%Y-%m-%d"),
        progress=False,
        auto_adjust=False,
        group_by="column",
        threads=False
    )

    if hist is None or hist.empty:
        return pd.DataFrame()

    hist = flatten_columns(hist)
    hist = hist.dropna(how="all")
    return hist


# --------------------------------------------------
# Market regime calculation
# --------------------------------------------------
def calculate_market_regime(symbol: str, entry_date):
    benchmark, market_region = get_market_benchmark(symbol)

    entry_date = pd.to_datetime(entry_date)

    start = entry_date - timedelta(days=320)
    end = entry_date + timedelta(days=5)

    result = {
        "market_region": market_region,
        "market_benchmark": benchmark,
        "market_entry_date_used": "",
        "benchmark_close": None,
        "benchmark_sma21": None,
        "benchmark_sma50": None,
        "benchmark_trend": "UNKNOWN",
        "vix_value": None,
        "vix_status": "UNKNOWN",
        "market_score": None,
        "market_regime": "UNKNOWN"
    }

    try:
        bench_hist = download_history(benchmark, start, end)

        if bench_hist.empty or "Close" not in bench_hist.columns:
            return result

        close = get_column_as_series(bench_hist, "Close")
        close = close.sort_index()

        close = close[close.index <= entry_date + timedelta(days=1)]

        if close.empty:
            return result

        bench_df = pd.DataFrame({"Close": close})
        bench_df["SMA21"] = bench_df["Close"].rolling(21).mean()
        bench_df["SMA50"] = bench_df["Close"].rolling(50).mean()

        entry_row = bench_df.dropna(subset=["Close"]).iloc[-1]

        benchmark_close = float(entry_row["Close"])
        sma21 = float(entry_row["SMA21"]) if pd.notna(entry_row["SMA21"]) else None
        sma50 = float(entry_row["SMA50"]) if pd.notna(entry_row["SMA50"]) else None
        date_used = entry_row.name.date()

        score = 0

        # Short-term swing regime logic, aligned with weekly entries / 2-4 week horizon.
        # BULL requires price above the 1-month average and 1-month trend above the 2.5-month trend.
        # BEAR now requires BOTH price below SMA21 AND SMA21 below SMA50.
        # This avoids falsely labeling a normal pullback inside an uptrend as BEAR.
        if sma21 is not None and sma50 is not None:
            if benchmark_close > sma21 and sma21 > sma50:
                trend = "BULLISH"
                score += 2
            elif benchmark_close < sma21 and sma21 < sma50:
                trend = "BEARISH"
                score -= 2
            elif benchmark_close > sma21:
                trend = "RECOVERING"
                score += 1
            else:
                trend = "WEAK_OR_MIXED"
                score -= 1
        else:
            trend = "INSUFFICIENT_SMA_DATA"

        # VIX risk filter
        vix_start = entry_date - timedelta(days=10)
        vix_end = entry_date + timedelta(days=5)

        vix_hist = download_history(VIX_SYMBOL, vix_start, vix_end)

        vix_value = None
        vix_status = "UNKNOWN"

        if not vix_hist.empty and "Close" in vix_hist.columns:
            vix_close = get_column_as_series(vix_hist, "Close")
            vix_close = vix_close[vix_close.index <= entry_date + timedelta(days=1)]

            if not vix_close.empty:
                vix_value = float(vix_close.iloc[-1])

                if vix_value < 18:
                    vix_status = "LOW_VOL_SUPPORTIVE"
                    score += 1
                elif vix_value <= 25:
                    vix_status = "NORMAL_CAUTION"
                else:
                    vix_status = "HIGH_VOL_RISK_OFF"
                    score -= 1

        if score >= 2:
            regime = "BULL"
        elif score <= -2:
            regime = "BEAR"
        else:
            regime = "MIXED"

        result.update({
            "market_entry_date_used": date_used,
            "benchmark_close": round(benchmark_close, 4),
            "benchmark_sma21": round(sma21, 4) if sma21 is not None else None,
            "benchmark_sma50": round(sma50, 4) if sma50 is not None else None,
            "benchmark_trend": trend,
            "vix_value": round(vix_value, 2) if vix_value is not None else None,
            "vix_status": vix_status,
            "market_score": score,
            "market_regime": regime
        })

        return result

    except Exception as e:
        result["market_regime"] = "ERROR"
        result["market_error"] = str(e)
        return result


# --------------------------------------------------
# Load trades
# --------------------------------------------------
df = pd.read_csv(INPUT_FILE)

df["status"] = df["status"].astype(str).str.upper().str.strip()
df["symbol"] = df["symbol"].astype(str).str.strip()

print(f"Loaded {len(df)} trades")

# --------------------------------------------------
# Add market regime to all trades with entry_date
# --------------------------------------------------
market_rows = []

for idx, r in df.iterrows():
    symbol = r["symbol"]
    entry_date = pd.to_datetime(r.get("entry_date", None), errors="coerce")

    if pd.isna(entry_date):
        market_rows.append({
            "market_region": "",
            "market_benchmark": "",
            "market_entry_date_used": "",
            "benchmark_close": None,
            "benchmark_sma21": None,
            "benchmark_sma50": None,
            "benchmark_trend": "NO_ENTRY",
            "vix_value": None,
            "vix_status": "NO_ENTRY",
            "market_score": None,
            "market_regime": "NO_ENTRY"
        })
        continue

    print(f"Market regime for {symbol} at {entry_date.date()}")

    regime = calculate_market_regime(symbol, entry_date)
    market_rows.append(regime)

    time.sleep(0.2)

market_df = pd.DataFrame(market_rows)
df_with_market = pd.concat([df.reset_index(drop=True), market_df.reset_index(drop=True)], axis=1)

df_with_market.to_csv(OUTPUT_ALL_TRADES, index=False, encoding="utf-8-sig")

print("\nSaved:", OUTPUT_ALL_TRADES)


# --------------------------------------------------
# Stopped-trade post-stop analysis
# --------------------------------------------------
stopped = df_with_market[df_with_market["status"].eq("STOPPED")].copy()

print(f"\nFound {len(stopped)} stopped trades")

results = []

for idx, r in stopped.iterrows():
    original_symbol = r["symbol"]
    yf_symbol = normalize_symbol(original_symbol)

    try:
        entry_date = pd.to_datetime(r["entry_date"], errors="coerce")
        stop_date = pd.to_datetime(r["exit_date"], errors="coerce")
        pnl_pct = float(r["pnl_pct"])

        if pd.isna(entry_date) or pd.isna(stop_date):
            results.append({
                "week": r.get("week", ""),
                "symbol": original_symbol,
                "yf_symbol": yf_symbol,
                "status": "INVALID_DATES"
            })
            continue

        start = stop_date
        end = pd.Timestamp.today() + timedelta(days=1)

        print(f"Fetching stopped trade {original_symbol} -> {yf_symbol} from {start.date()}")

        hist = download_history(yf_symbol, start, end)

        if hist.empty:
            results.append({
                "week": r.get("week", ""),
                "symbol": original_symbol,
                "yf_symbol": yf_symbol,
                "entry_date": entry_date.date(),
                "stop_date": stop_date.date(),
                "stopped_pct": pnl_pct,
                "status": "NO_DATA"
            })
            continue

        if "Low" not in hist.columns or "Close" not in hist.columns:
            results.append({
                "week": r.get("week", ""),
                "symbol": original_symbol,
                "yf_symbol": yf_symbol,
                "entry_date": entry_date.date(),
                "stop_date": stop_date.date(),
                "stopped_pct": pnl_pct,
                "status": "MISSING_LOW_OR_CLOSE"
            })
            continue

        close_series = get_column_as_series(hist, "Close")
        low_series = get_column_as_series(hist, "Low")

        if close_series.empty or low_series.empty:
            results.append({
                "week": r.get("week", ""),
                "symbol": original_symbol,
                "yf_symbol": yf_symbol,
                "entry_date": entry_date.date(),
                "stop_date": stop_date.date(),
                "stopped_pct": pnl_pct,
                "status": "EMPTY_PRICE_SERIES"
            })
            continue

        stop_close = float(close_series.iloc[0])
        inferred_entry = stop_close / (1 + pnl_pct / 100)

        lowest_date_ts = low_series.idxmin()
        lowest_price = float(low_series.loc[lowest_date_ts])
        lowest_date = pd.to_datetime(lowest_date_ts).date()

        lowest_pct_from_entry = (lowest_price / inferred_entry - 1) * 100
        extra_drawdown_after_stop = lowest_pct_from_entry - pnl_pct

        results.append({
            "week": r.get("week", ""),
            "symbol": original_symbol,
            "yf_symbol": yf_symbol,
            "entry_date": entry_date.date(),
            "stop_date": stop_date.date(),
            "stopped_pct": round(pnl_pct, 2),
            "inferred_entry": round(inferred_entry, 4),
            "stop_close": round(stop_close, 4),
            "lowest_after_stop_price": round(lowest_price, 4),
            "lowest_after_stop_date": lowest_date,
            "lowest_pct_from_entry": round(lowest_pct_from_entry, 2),
            "extra_drawdown_after_stop_pct": round(extra_drawdown_after_stop, 2),
            "would_survive_2_5_stop": lowest_pct_from_entry > -2.5,
            "would_survive_3_0_stop": lowest_pct_from_entry > -3.0,
            "would_survive_3_5_stop": lowest_pct_from_entry > -3.5,
            "t1_hit": r.get("t1_hit", ""),
            "market_region": r.get("market_region", ""),
            "market_benchmark": r.get("market_benchmark", ""),
            "benchmark_trend": r.get("benchmark_trend", ""),
            "vix_value": r.get("vix_value", ""),
            "vix_status": r.get("vix_status", ""),
            "market_score": r.get("market_score", ""),
            "market_regime": r.get("market_regime", ""),
            "status": "OK"
        })

        time.sleep(0.3)

    except Exception as e:
        results.append({
            "week": r.get("week", ""),
            "symbol": original_symbol,
            "yf_symbol": yf_symbol,
            "status": "ERROR",
            "error": str(e)
        })


# --------------------------------------------------
# Output stopped analysis
# --------------------------------------------------
out = pd.DataFrame(results)
out.to_csv(OUTPUT_STOPPED, index=False, encoding="utf-8-sig")

print("\nSaved:", OUTPUT_STOPPED)

ok = out[out["status"].eq("OK")].copy()

if not ok.empty:
    print("\n================ STOPPED TRADE SUMMARY ================")
    print("Stopped trades analyzed:", len(ok))
    print("Would survive 2.5% stop:", int(ok["would_survive_2_5_stop"].sum()))
    print("Would survive 3.0% stop:", int(ok["would_survive_3_0_stop"].sum()))
    print("Would survive 3.5% stop:", int(ok["would_survive_3_5_stop"].sum()))
    print("Median lowest % from entry:", round(ok["lowest_pct_from_entry"].median(), 2))
    print("Median extra drawdown after stop:", round(ok["extra_drawdown_after_stop_pct"].median(), 2))
    print("Worst post-stop drawdown:", round(ok["lowest_pct_from_entry"].min(), 2))

    print("\nStopped trades by market regime:")
    print(ok.groupby("market_regime")["symbol"].count())

    print("\nAverage post-stop drawdown by market regime:")
    print(ok.groupby("market_regime")["lowest_pct_from_entry"].mean().round(2))

    print("\nStopped but T1 later hit:")
    print(ok[ok["t1_hit"].astype(str).str.upper().eq("TRUE")][[
        "symbol",
        "stopped_pct",
        "lowest_pct_from_entry",
        "extra_drawdown_after_stop_pct",
        "lowest_after_stop_date",
        "market_regime",
        "benchmark_trend",
        "vix_value"
    ]])
else:
    print("\nNo valid stopped trades analyzed.")


# --------------------------------------------------
# Full trade regime performance summary
# --------------------------------------------------
print("\n================ ALL TRADES MARKET REGIME SUMMARY ================")

valid_regime = df_with_market[
    ~df_with_market["market_regime"].isin(["NO_ENTRY", "UNKNOWN", "ERROR"])
].copy()

if not valid_regime.empty and "pnl_pct" in valid_regime.columns:
    valid_regime["pnl_pct_numeric"] = pd.to_numeric(valid_regime["pnl_pct"], errors="coerce")

    print("\nTrades by market regime:")
    print(valid_regime.groupby("market_regime")["symbol"].count())

    print("\nAverage pnl_pct by market regime:")
    print(valid_regime.groupby("market_regime")["pnl_pct_numeric"].mean().round(2))

    print("\nMedian pnl_pct by market regime:")
    print(valid_regime.groupby("market_regime")["pnl_pct_numeric"].median().round(2))

    print("\nT1 hit rate by market regime:")
    tmp = valid_regime.copy()
    tmp["t1_hit_bool"] = tmp["t1_hit"].astype(str).str.upper().eq("TRUE")
    print(tmp.groupby("market_regime")["t1_hit_bool"].mean().mul(100).round(1))