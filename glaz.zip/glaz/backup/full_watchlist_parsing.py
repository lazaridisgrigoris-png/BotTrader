#!/usr/bin/env python3
"""
run_daily.py (updated)

Adds:
- Daily vs Weekly mode
- Per-row min_grade + only_alert_if_trade + update_only_on_change + status fields
- Only write back to Watchlist when status changes (optional)
- Produces a single summary text file per run (top picks)

Google Sheet:
Tab: Watchlist (headers in row 1). This script will add missing headers automatically.

Minimum columns needed:
- symbol
- enabled

Recommended columns (will be auto-added if missing):
- min_grade (default 7)
- only_alert_if_trade (default TRUE)
- update_only_on_change (default TRUE)
- last_status (stores last decision, e.g. TRADE/NO_TRADE/ERROR)
- last_grade (stores last grade)
- last_pattern
- last_signal_ts (timestamp of last TRADE signal)
- last_change_ts (timestamp of last status change)
- ...plus your previous columns like decision/grade/pattern/entry/stop/t1/t2/notes/raw_json, etc.

History tab:
- DailySignals (auto-created) always appends every run (unless you disable)

Install:
  python -m pip install gspread google-auth requests openai requests

Env vars:
  OPENAI_API_KEY=...
  CHARTIMG_KEY=...
  SHEET_ID=...
Optional:
  SERVICE_ACCOUNT_JSON=service_account.json
  OPENAI_MODEL=gpt-5
"""

from __future__ import annotations

import base64
import datetime as dt
import json
import os
import re
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import requests
import gspread
from google.oauth2.service_account import Credentials
from openai import OpenAI


# =========================
# CONFIG
# =========================

# ---- Google Sheets
SHEET_ID = os.getenv("SHEET_ID", "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg")


SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "auto-trading-481921-980bcad6baf5.json")



WATCHLIST_TAB = "Watchlist"
HISTORY_TAB = "DailySignals"

# ---- Chart-IMG (v1 GET - confirmed working in your environment)
CHARTIMG_KEY = os.getenv("CHARTIMG_KEY", "0nG77A6Hc6ajztBP6lfXN7HJpwQJUsIHaArnOMnW")
CHARTIMG_BASE_URL = "https://api.chart-img.com/v1/tradingview/advanced-chart"

CHART_THEME = "dark"
CHART_WIDTH = 800
CHART_HEIGHT = 600
CHART_INTERVAL = "1D"

# ---- OpenAI
#OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-5")
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
OPENAI_TIMEOUT_SEC = 90

# ---- Runtime
OUTPUT_DIR = Path("output")
SAVE_CHARTS = True
SLEEP_BETWEEN_SYMBOLS_SEC = 1.0

# ---- Strategy constraints (hard filters)
MAX_STOP_PCT = 0.02     # 2%
MIN_TARGET1_PCT = 0.05  # 5%
MAX_HOLD_DAYS = 20      # ~1 month trading days

# ---- Run mode
# daily: full analysis
# weekly: only "setup forming / near trigger" scanning (slightly looser language), still returns TRADE/NO_TRADE
RUN_MODE = os.getenv("RUN_MODE", "daily").strip().lower()
if RUN_MODE not in ("daily", "weekly"):
    RUN_MODE = "daily"

# ---- Watchlist headers (auto-added if missing)
WATCHLIST_HEADERS = [
    # input controls
    "symbol",
    "enabled",
    "min_grade",
    "only_alert_if_trade",
    "update_only_on_change",

    # primary outputs
    "last_run",
    "decision",
    "grade_0_10",
    "pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",

    # status tracking
    "last_status",
    "last_grade",
    "last_pattern",
    "last_signal_ts",
    "last_change_ts",
]

HISTORY_HEADERS = [
    "run_ts",
    "mode",
    "symbol",
    "decision",
    "grade_0_10",
    "best_pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",
]


# =========================
# PROMPTS
# =========================

BASE_PROMPT = f"""
You evaluate daily stock charts using Bulkowski-style chart patterns with highest probability of success.
LONG trades only.

Constraints:
- Timeframe: Daily
- Lookback: Year-to-date (as shown in the chart image)
- Max holding time: 1 month (about {MAX_HOLD_DAYS} trading days)
- Target: +5% to +10%
- Stop loss: -1% to -2% (flag NO_TRADE if unrealistic given volatility/structure)

Return STRICT JSON only with exactly this schema:
{{
  "symbol": "EXCHANGE:TICKER",
  "pattern_candidates": [
    {{"name": "string", "confidence_0_100": 0, "breakout_level": 0.0, "invalidation_level": 0.0}}
  ],
  "entry_plan": {{
    "decision": "TRADE" or "NO_TRADE",
    "trigger": "string",
    "entry_price": 0.0,
    "stop_price": 0.0,
    "target_price_1": 0.0,
    "target_price_2": 0.0,
    "time_stop_days": {MAX_HOLD_DAYS}
  }},
  "risk_notes": ["string"],
  "grade_0_10": 0,
  "no_trade_if": ["string"]
}}
""".strip()

DAILY_INSTRUCTIONS = """
Mode: DAILY EXECUTION SCAN
- Be strict: Only set decision=TRADE if breakout/trigger is actionable now or next 1–2 sessions.
- Require stop to be structurally valid and within 1–2% (otherwise NO_TRADE).
- Prefer patterns that can plausibly deliver +5% within 1 month before major resistance.
""".strip()

WEEKLY_INSTRUCTIONS = """
Mode: WEEKLY SETUP SCAN
- Identify if a high-quality Bulkowski-style setup is forming or close to a valid trigger.
- It's OK if entry isn't today, but only mark TRADE if trigger is very close (near breakout level).
- Still respect the stop realism: if 1–2% stop is not realistic, prefer NO_TRADE and explain.
""".strip()

PROMPT_BY_MODE = {
    "daily": BASE_PROMPT + "\n\n" + DAILY_INSTRUCTIONS,
    "weekly": BASE_PROMPT + "\n\n" + WEEKLY_INSTRUCTIONS,
}


# =========================
# HELPERS
# =========================

def now_str_local() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def today_iso() -> str:
    return dt.date.today().isoformat()

def safe_filename(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
    return s.strip("_") or "item"

def png_bytes_to_data_url(png_bytes: bytes) -> str:
    b64 = base64.b64encode(png_bytes).decode("ascii")
    return f"data:image/png;base64,{b64}"

def to_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        if isinstance(x, (int, float)):
            return float(x)
        s = str(x).strip()
        if s == "":
            return None
        return float(s)
    except Exception:
        return None

def truthy(x: Any, default: bool = False) -> bool:
    if x is None:
        return default
    s = str(x).strip().upper()
    if s == "":
        return default
    return s in ("TRUE", "YES", "1", "Y")

def to_int(x: Any, default: int) -> int:
    try:
        if x is None:
            return default
        s = str(x).strip()
        if s == "":
            return default
        return int(float(s))
    except Exception:
        return default


# =========================
# GOOGLE SHEETS
# =========================

def connect_sheets() -> Tuple[gspread.Worksheet, gspread.Worksheet]:
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON, scopes=scopes)
    gc = gspread.authorize(creds)
    sh = gc.open_by_key(SHEET_ID)

    ws_watch = sh.worksheet(WATCHLIST_TAB)

    try:
        ws_hist = sh.worksheet(HISTORY_TAB)
    except gspread.WorksheetNotFound:
        ws_hist = sh.add_worksheet(title=HISTORY_TAB, rows=2000, cols=30)
        ws_hist.append_row(HISTORY_HEADERS)

    return ws_watch, ws_hist

def ensure_headers(ws: gspread.Worksheet, required_headers: List[str]) -> Dict[str, int]:
    values = ws.get_all_values()
    if not values:
        ws.append_row(required_headers)
        header_row = required_headers
    else:
        header_row = values[0]

    col_map = {h.strip().lower(): i for i, h in enumerate(header_row, start=1)}

    missing = [h for h in required_headers if h.lower() not in col_map]
    if missing:
        new_headers = header_row + missing
        ws.update("1:1", [new_headers])
        col_map = {h.strip().lower(): i for i, h in enumerate(new_headers, start=1)}

    return col_map

def get_cell(ws: gspread.Worksheet, row: List[str], col_map: Dict[str, int], name: str) -> str:
    c = col_map[name.lower()]
    return row[c - 1].strip() if c - 1 < len(row) else ""

def set_cell(ws: gspread.Worksheet, row_index: int, col: int, val: Any) -> None:
    ws.update_cell(row_index, col, "" if val is None else str(val))

def batch_update_cells(ws: gspread.Worksheet, row_index: int, updates: List[Tuple[int, Any]]) -> None:
    for col, val in updates:
        set_cell(ws, row_index, col, val)


# =========================
# CHART-IMG
# =========================

def chartimg_params(symbol: str) -> Dict[str, Any]:
    return {
        "key": CHARTIMG_KEY,
        "symbol": symbol,
        "interval": CHART_INTERVAL,
        "theme": CHART_THEME,
        "width": CHART_WIDTH,
        "height": CHART_HEIGHT,
    }

def fetch_chart_png(symbol: str) -> bytes:
    if not CHARTIMG_KEY:
        raise RuntimeError("CHARTIMG_KEY is empty. Set env var CHARTIMG_KEY.")

    r = requests.get(CHARTIMG_BASE_URL, params=chartimg_params(symbol), timeout=60)
    ctype = (r.headers.get("content-type") or "").lower()

    if r.status_code != 200:
        raise RuntimeError(f"Chart-IMG HTTP {r.status_code}: {r.text[:500]}")
    if "application/json" in ctype or r.content[:1] == b"{":
        raise RuntimeError(f"Chart-IMG returned JSON instead of PNG: {r.text[:500]}")

    return r.content


# =========================
# OPENAI
# =========================

def openai_client() -> OpenAI:
    return OpenAI()

def analyze_chart(symbol: str, png_bytes: bytes, client: OpenAI) -> Dict[str, Any]:
    img_url = png_bytes_to_data_url(png_bytes)
    prompt = PROMPT_BY_MODE[RUN_MODE]

    resp = client.responses.create(
        model=OPENAI_MODEL,
        input=[{
            "role": "user",
            "content": [
                {"type": "input_text", "text": f"Symbol: {symbol}\n\n{prompt}"},
                {"type": "input_image", "image_url": img_url},
            ],
        }],
        timeout=OPENAI_TIMEOUT_SEC,
    )

    text = (resp.output_text or "").strip()
    if not text:
        raise RuntimeError("OpenAI returned empty output_text.")

    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, flags=re.DOTALL)
        if not m:
            raise RuntimeError(f"OpenAI output not JSON:\n{text[:1200]}")
        return json.loads(m.group(0))


# =========================
# POST-FILTERS (enforce your plan)
# =========================

def enforce_plan_filters(result: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    notes: List[str] = []
    entry_plan = result.get("entry_plan") or {}
    decision = str(entry_plan.get("decision", "")).upper().strip()

    entry = to_float(entry_plan.get("entry_price"))
    stop = to_float(entry_plan.get("stop_price"))
    t1 = to_float(entry_plan.get("target_price_1"))
    t2 = to_float(entry_plan.get("target_price_2"))

    if decision == "TRADE":
        if entry is None or stop is None or t1 is None or t2 is None:
            notes.append("Missing prices in entry_plan; forcing NO_TRADE.")
            decision = "NO_TRADE"

    if decision == "TRADE" and entry and stop:
        stop_pct = (entry - stop) / entry
        if stop_pct <= 0:
            notes.append("Stop is not below entry for LONG; forcing NO_TRADE.")
            decision = "NO_TRADE"
        elif stop_pct > MAX_STOP_PCT:
            notes.append(f"Stop distance {stop_pct*100:.2f}% > {MAX_STOP_PCT*100:.2f}% max; forcing NO_TRADE.")
            decision = "NO_TRADE"

    if decision == "TRADE" and entry and t1:
        t1_pct = (t1 - entry) / entry
        if t1_pct < MIN_TARGET1_PCT:
            notes.append(f"Target1 gain {t1_pct*100:.2f}% < {MIN_TARGET1_PCT*100:.2f}% min; forcing NO_TRADE.")
            decision = "NO_TRADE"

    entry_plan["decision"] = "TRADE" if decision == "TRADE" else "NO_TRADE"
    result["entry_plan"] = entry_plan

    if notes:
        rn = list(result.get("risk_notes") or [])
        rn += [f"[PLAN_FILTER] {n}" for n in notes]
        result["risk_notes"] = rn

        nt = list(result.get("no_trade_if") or [])
        nt += [f"[PLAN_FILTER] {n}" for n in notes]
        result["no_trade_if"] = nt

    return result, notes


# =========================
# EXTRA POLICY: alert threshold + status change logic
# =========================

def best_pattern(result: Dict[str, Any]) -> str:
    pats = result.get("pattern_candidates") or []
    if not pats:
        return ""
    return str((pats[0] or {}).get("name", "")).strip()

def entry_fields(result: Dict[str, Any]) -> Tuple[Any, Any, Any, Any]:
    ep = result.get("entry_plan") or {}
    return ep.get("entry_price", ""), ep.get("stop_price", ""), ep.get("target_price_1", ""), ep.get("target_price_2", "")

def normalize_decision(result: Dict[str, Any]) -> str:
    ep = result.get("entry_plan") or {}
    return str(ep.get("decision", "")).upper().strip() or "NO_TRADE"

def grade_val(result: Dict[str, Any]) -> int:
    g = result.get("grade_0_10", 0)
    try:
        return int(float(g))
    except Exception:
        return 0

def passes_user_thresholds(result: Dict[str, Any], min_grade: int, only_alert_if_trade: bool) -> bool:
    d = normalize_decision(result)
    g = grade_val(result)
    if g < min_grade:
        return False
    if only_alert_if_trade and d != "TRADE":
        return False
    return True

def status_changed(old_status: str, new_status: str) -> bool:
    return (old_status or "").strip().upper() != (new_status or "").strip().upper()


# =========================
# WATCHLIST WRITEBACK + HISTORY
# =========================

def build_watchlist_writeback(result: Dict[str, Any]) -> Dict[str, Any]:
    ep = result.get("entry_plan") or {}
    decision = normalize_decision(result)
    grade = result.get("grade_0_10", "")

    entry, stop, t1, t2 = entry_fields(result)

    rn = result.get("risk_notes") or []
    nt = result.get("no_trade_if") or []
    notes_parts: List[str] = []
    if isinstance(rn, list) and rn:
        notes_parts.append("Risk: " + " | ".join(map(str, rn[:6])))
    if decision == "NO_TRADE" and isinstance(nt, list) and nt:
        notes_parts.append("NoTradeIf: " + " | ".join(map(str, nt[:6])))

    wb = {
        "last_run": now_str_local(),
        "decision": decision,
        "grade_0_10": grade,
        "pattern": best_pattern(result),
        "entry": entry,
        "stop": stop,
        "t1": t1,
        "t2": t2,
        "notes": " || ".join(notes_parts),
        "raw_json": json.dumps(result, ensure_ascii=False),
    }
    return wb

def update_watchlist_row(
    ws_watch: gspread.Worksheet,
    col_map: Dict[str, int],
    row_index: int,
    wb: Dict[str, Any],
    status_fields: Dict[str, Any],
    do_update: bool
) -> None:
    if not do_update:
        return

    updates: List[Tuple[int, Any]] = []
    for k, v in {**wb, **status_fields}.items():
        ck = k.lower()
        if ck in col_map:
            updates.append((col_map[ck], v))
    batch_update_cells(ws_watch, row_index, updates)

def append_history(ws_hist: gspread.Worksheet, result: Dict[str, Any]) -> None:
    ep = result.get("entry_plan") or {}
    decision = normalize_decision(result)
    grade = result.get("grade_0_10", "")
    pat = best_pattern(result)
    entry, stop, t1, t2 = entry_fields(result)

    rn = result.get("risk_notes") or []
    nt = result.get("no_trade_if") or []
    notes_parts: List[str] = []
    if isinstance(rn, list) and rn:
        notes_parts.append("Risk: " + " | ".join(map(str, rn[:6])))
    if decision == "NO_TRADE" and isinstance(nt, list) and nt:
        notes_parts.append("NoTradeIf: " + " | ".join(map(str, nt[:6])))

    ws_hist.append_row([
        now_str_local(),
        RUN_MODE,
        result.get("symbol", ""),
        decision,
        grade,
        pat,
        entry,
        stop,
        t1,
        t2,
        " || ".join(notes_parts),
        json.dumps(result, ensure_ascii=False),
    ])


# =========================
# MAIN
# =========================

def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logs_dir = OUTPUT_DIR / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    charts_dir = OUTPUT_DIR / "charts" / today_iso()
    if SAVE_CHARTS:
        charts_dir.mkdir(parents=True, exist_ok=True)

    log_path = logs_dir / f"run_{today_iso()}_{RUN_MODE}.log"
    summary_path = OUTPUT_DIR / f"summary_{today_iso()}_{RUN_MODE}.txt"

    def log(msg: str) -> None:
        line = f"[{now_str_local()}] {msg}"
        print(line)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")

    if not CHARTIMG_KEY:
        raise RuntimeError("CHARTIMG_KEY not set.")
    if not SHEET_ID or SHEET_ID.startswith("PUT_YOUR"):
        raise RuntimeError("SHEET_ID not set (env SHEET_ID or edit script).")

    ws_watch, ws_hist = connect_sheets()
    col_map = ensure_headers(ws_watch, WATCHLIST_HEADERS)
    ensure_headers(ws_hist, HISTORY_HEADERS)

    rows = ws_watch.get_all_values()
    if len(rows) < 2:
        log("Watchlist has no rows.")
        return

    client = openai_client()

    # Collect “alerts” (candidates) for the summary file
    alerts: List[Dict[str, Any]] = []
    status_changes: List[Dict[str, Any]] = []

    log(f"Run start: mode={RUN_MODE} symbols_rows={len(rows)-1} model={OPENAI_MODEL}")
   
    for r_idx in range(2, len(rows) + 1):
        row = rows[r_idx - 1]
        
        symbol = get_cell(ws_watch, row, col_map, "symbol")
        enabled = get_cell(ws_watch, row, col_map, "enabled")
        if not symbol or not truthy(enabled, default=False):
            continue
        log(symbol)
        # Per-row controls
        min_grade = to_int(get_cell(ws_watch, row, col_map, "min_grade"), default=7)
        only_alert_if_trade = truthy(get_cell(ws_watch, row, col_map, "only_alert_if_trade"), default=True)
        update_only_on_change = truthy(get_cell(ws_watch, row, col_map, "update_only_on_change"), default=True)

        old_status = get_cell(ws_watch, row, col_map, "last_status")
        old_grade = get_cell(ws_watch, row, col_map, "last_grade")
        old_pattern = get_cell(ws_watch, row, col_map, "last_pattern")

        safe_sym = safe_filename(symbol)

        try:
            log(f"{symbol}: fetching chart...")
            png = fetch_chart_png(symbol)

            if SAVE_CHARTS:
                chart_path = charts_dir / f"{safe_sym}.png"
                chart_path.write_bytes(png)

            log(f"{symbol}: analyzing...")
            result = analyze_chart(symbol, png, client)

            # Enforce your plan constraints
            result, filter_notes = enforce_plan_filters(result)
            if filter_notes:
                log(f"{symbol}: plan filters -> {filter_notes}")

            decision = normalize_decision(result)
            g = grade_val(result)
            pat = best_pattern(result)

            wb = build_watchlist_writeback(result)

            # Status tracking fields
            changed = status_changed(old_status, decision)
            status_fields: Dict[str, Any] = {
                "last_status": decision,
                "last_grade": g,
                "last_pattern": pat,
            }
            if changed:
                status_fields["last_change_ts"] = now_str_local()
                status_changes.append({
                    "symbol": symbol,
                    "old": old_status,
                    "new": decision,
                    "grade": g,
                    "pattern": pat
                })
            if decision == "TRADE":
                status_fields["last_signal_ts"] = now_str_local()

            # Decide whether to write back
            do_update = True
            if update_only_on_change and not changed:
                # still update last_run, but skip overwriting the row if unchanged
                # (helps reduce noise + avoids burning Sheets quota)
                do_update = False
                # but always update last_run so you know it was checked
                # (update_only_on_change applies to the bulk fields, not last_run)
                set_cell(ws_watch, r_idx, col_map["last_run"], now_str_local())

            if not do_update:
                log(f"{symbol}: unchanged ({decision}); skipped writeback (except last_run).")
            else:
                update_watchlist_row(ws_watch, col_map, r_idx, wb, status_fields, do_update=True)
                log(f"{symbol}: updated. decision={decision} grade={g} pattern={pat}")

            # Alerting logic (for summary)
            if passes_user_thresholds(result, min_grade=min_grade, only_alert_if_trade=only_alert_if_trade):
                entry, stop, t1, t2 = entry_fields(result)
                alerts.append({
                    "symbol": symbol,
                    "decision": decision,
                    "grade": g,
                    "pattern": pat,
                    "entry": entry,
                    "stop": stop,
                    "t1": t1,
                    "t2": t2,
                })

            # Always append to history (so you can analyze later)
            append_history(ws_hist, result)

        except Exception as e:
            err = f"{type(e).__name__}: {e}"
            log(f"{symbol}: ERROR -> {err}")

            # Update row (even in change-only mode) with last_run + decision ERROR + notes
            fail_updates = {
                "last_run": now_str_local(),
                "decision": "ERROR",
                "notes": err,
                "last_status": "ERROR",
                "last_change_ts": now_str_local(),
            }
            update_watchlist_row(ws_watch, col_map, r_idx, fail_updates, {}, do_update=True)

        time.sleep(SLEEP_BETWEEN_SYMBOLS_SEC)

    # Write summary file
    alerts_sorted = sorted(alerts, key=lambda x: (x["decision"] != "TRADE", -int(x["grade"])))
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"Run summary ({RUN_MODE}) @ {now_str_local()}\n")
        f.write(f"Alerts (after min_grade + only_alert_if_trade filters): {len(alerts_sorted)}\n\n")
        for a in alerts_sorted[:25]:
            f.write(
                f"- {a['symbol']} | {a['decision']} | grade={a['grade']} | {a['pattern']} "
                f"| entry={a['entry']} stop={a['stop']} t1={a['t1']} t2={a['t2']}\n"
            )

        f.write("\nStatus changes:\n")
        if not status_changes:
            f.write("- none\n")
        else:
            for sc in status_changes:
                f.write(f"- {sc['symbol']}: {sc['old']} -> {sc['new']} (grade={sc['grade']} pattern={sc['pattern']})\n")

    log(f"Run complete. Summary written to: {summary_path}")
    log("Tip: open the summary file to see top picks quickly.")


if __name__ == "__main__":
    main()
