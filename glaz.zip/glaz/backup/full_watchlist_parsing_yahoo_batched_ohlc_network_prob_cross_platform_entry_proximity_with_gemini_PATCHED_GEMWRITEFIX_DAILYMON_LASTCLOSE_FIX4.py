#!/usr/bin/env python3
"""
full_watchlist_parsing.py (Yahoo Finance + mplfinance version)

Replaces Chart-IMG with:
- yfinance: download 1y daily OHLCV
- mplfinance: render candlestick+volume chart to PNG bytes
Then sends PNG to OpenAI Vision exactly like before.

Dependencies:
  python -m pip install openai gspread google-auth yfinance mplfinance pandas matplotlib httpx

Env vars (recommended):
  OPENAI_API_KEY=...
  SHEET_ID=...
Optional:
  SERVICE_ACCOUNT_JSON=...
  OPENAI_MODEL=...
  RUN_MODE=daily|weekly
"""

from __future__ import annotations

import base64
import datetime as dt
import io
import json
import os
import re
import time
import random
import httpx
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import gspread
import gspread.utils
import pandas as pd
import yfinance as yf
import mplfinance as mpf
from google.oauth2.service_account import Credentials
from openai import OpenAI, APIConnectionError, APITimeoutError, RateLimitError, APIError

# Gemini (optional)

def strip_json_fence(text: str) -> str:
    """Remove common markdown code fences around JSON and return the raw JSON string."""
    if text is None:
        return ""
    s = str(text).strip()
    # Remove ```json ... ``` or ``` ... ``` fences
    if s.startswith("```"):
        # Drop the opening fence line
        s = re.sub(r"^```(?:json)?\s*\n", "", s, flags=re.IGNORECASE)
        # Drop the trailing fence
        s = re.sub(r"\n```\s*$", "", s)
    # Some models wrap in single backticks
    if s.startswith("`") and s.endswith("`") and len(s) >= 2:
        s = s[1:-1].strip()
    return s

try:
    from google import genai as google_genai
    from google.genai import types as genai_types
except ImportError:  # pragma: no cover
    google_genai = None
    genai_types = None

import socket
import requests
# =========================
# CONFIG
# =========================

# ---- Google Sheets
SHEET_ID = os.getenv("SHEET_ID", "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg")
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "auto-trading-481921-980bcad6baf5.json")
WATCHLIST_TAB = "Watchlist"
HISTORY_TAB = "DailySignals"
GEM_OUTPUT_TAB = "Output_Gem"

# ---- Chart rendering (local)
LOOKBACK_PERIOD = os.getenv("LOOKBACK_PERIOD", "1y")  # e.g. 6mo, 1y, 2y
INTERVAL = "1d"

# mplfinance render settings (affect readability + OpenAI image tokens)
FIGSIZE = (8, 6)   # inches
DPI = 150          # 120–180 is a good range

# ---- OpenAI
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
OPENAI_TIMEOUT_SEC = 180


# ---- Provider selection
# openai | gemini | both
ANALYSIS_PROVIDER = os.getenv("ANALYSIS_PROVIDER", "openai").strip().lower()
if ANALYSIS_PROVIDER not in ("openai", "gemini", "both"):
    ANALYSIS_PROVIDER = "openai"

# ---- Gemini
GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash-lite")
GEMINI_TIMEOUT_SEC = int(os.getenv("GEMINI_TIMEOUT_SEC", "180"))

# ---- Runtime
OUTPUT_DIR = Path("output")
SAVE_CHARTS = True
SLEEP_BETWEEN_SYMBOLS_SEC = 0.5

# ---- Strategy constraints (hard filters)
MAX_STOP_PCT = 0.02     # 2%
MIN_TARGET1_PCT = 0.05  # 5%
MAX_HOLD_DAYS = 20      # ~1 month trading days

# Entry must be close to current price to be actionable in DAILY scans
ENTRY_MAX_GAP_PCT = float(os.getenv("ENTRY_MAX_GAP_PCT", "0.02"))  # 2% default
STOP_MAX_PCT = float(os.getenv("STOP_MAX_PCT", "0.02"))        # 2% max stop
MIN_TARGET2_PCT = float(os.getenv("MIN_TARGET2_PCT", "0.10")) # 10% target2
# If TRADE, entry_price should align with the detected breakout_level (prevents "loose" entries)
ENTRY_BREAKOUT_ALIGN_PCT = float(os.getenv("ENTRY_BREAKOUT_ALIGN_PCT", "0.005"))  # 0.5% default

# ---- Run mode
# weekly: full analysis (OpenAI/Gemini) + writebacks
# daily : monitoring run (no AI calls; just refresh prices + last_run)
RUN_MODE = os.getenv("RUN_MODE", "weekly").strip().lower()
if RUN_MODE not in ("daily", "weekly"):
    RUN_MODE = "weekly"

# ---- Watchlist headers (auto-added if missing)
WATCHLIST_HEADERS = [
    # input controls
    "symbol",
    "enabled",
    "min_grade",
    "only_alert_if_trade",
    "update_only_on_change",

    # primary outputs
    "last_run",
    "last_close",
    "decision",
    "grade_0_10",
    "pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",

    # status tracking
    "last_status",
    "last_grade",
    "last_pattern",
    "last_signal_ts",
    "last_change_ts",
]

HISTORY_HEADERS = [
    "run_ts",
    "mode",
    "symbol",
    "decision",
    "grade_0_10",
    "best_pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",
]

# Output_Gem: symbol + primary outputs (to compare Gemini results with Watchlist/OpenAI)
GEM_OUTPUT_HEADERS = [
    "symbol",
    "last_run",
    "last_close",
    "decision",
    "grade_0_10",
    "pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",
]

# =========================
# PROMPTS
# =========================

BASE_PROMPT = f"""
You evaluate daily stock charts using Bulkowski-style chart patterns with highest probability of success.
LONG trades only.

Constraints:
- Timeframe: Daily
- Lookback: last {LOOKBACK_PERIOD} (as shown in the chart image)
- Max holding time: 1 month (about {MAX_HOLD_DAYS} trading days)
- Target: +5% to +10%
- Stop loss: -1% to -2% (flag NO_TRADE if unrealistic given volatility/structure)

Return STRICT JSON only with exactly this schema:
{{
  "symbol": "EXCHANGE:TICKER",
  "pattern_candidates": [
    {{"name": "string", "confidence_0_100": 0, "breakout_level": 0.0, "invalidation_level": 0.0}}
  ],
  "entry_plan": {{
    "decision": "TRADE" or "NO_TRADE",
    "trigger": "string",
    "entry_price": 0.0,
    "stop_price": 0.0,
    "target_price_1": 0.0,
    "target_price_2": 0.0,
    "time_stop_days": {MAX_HOLD_DAYS}
  }},
  "risk_notes": ["string"],
  "grade_0_10": 0,
  "no_trade_if": ["string"]
}}
""".strip()

DAILY_INSTRUCTIONS = """
Mode: DAILY EXECUTION SCAN
- Be strict: Only set decision=TRADE if breakout/trigger is actionable now or next 1–2 sessions.
- Require stop to be structurally valid and within 1–2% (otherwise NO_TRADE).
- Prefer patterns that can plausibly deliver +5% within 1 month before major resistance.

- IMPORTANT: DAILY scan rule: Only set decision=TRADE if entry_price is within ~2% of the latest close (current price proxy).
- If entry_price is farther away (waiting for breakout/pullback), set decision=NO_TRADE and note it as FUTURE_SETUP.
""".strip()

WEEKLY_INSTRUCTIONS = """
Mode: WEEKLY SETUP SCAN
- Identify if a high-quality Bulkowski-style setup is forming or close to a valid trigger.
- It's OK if entry isn't today, but only mark TRADE if trigger is very close (near breakout level).
- Still respect the stop realism: if 1–2% stop is not realistic, prefer NO_TRADE and explain.
""".strip()

PROMPT_BY_MODE = {
    "daily": BASE_PROMPT + "\n\n" + DAILY_INSTRUCTIONS,
    "weekly": BASE_PROMPT + "\n\n" + WEEKLY_INSTRUCTIONS,
}


# =========================
# HELPERS
# =========================

def now_str_local() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def today_iso() -> str:
    return dt.date.today().isoformat()

def safe_filename(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
    return s.strip("_") or "item"

def png_bytes_to_data_url(png_bytes: bytes) -> str:
    b64 = base64.b64encode(png_bytes).decode("ascii")
    return f"data:image/png;base64,{b64}"

def to_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        if isinstance(x, (int, float)):
            return float(x)
        s = str(x).strip()
        if s == "":
            return None
        return float(s)
    except Exception:
        return None

def truthy(x: Any, default: bool = False) -> bool:
    if x is None:
        return default
    s = str(x).strip().upper()
    if s == "":
        return default
    return s in ("TRUE", "YES", "1", "Y")

def to_int(x: Any, default: int) -> int:
    try:
        if x is None:
            return default
        s = str(x).strip()
        if s == "":
            return default
        return int(float(s))
    except Exception:
        return default


# =========================
# GOOGLE SHEETS
# =========================

def connect_sheets() -> Tuple[gspread.Worksheet, gspread.Worksheet, gspread.Worksheet]:
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON, scopes=scopes)
    gc = gspread.authorize(creds)
    sh = gc.open_by_key(SHEET_ID)

    ws_watch = sh.worksheet(WATCHLIST_TAB)

    try:
        ws_hist = sh.worksheet(HISTORY_TAB)
    except gspread.WorksheetNotFound:
        ws_hist = sh.add_worksheet(title=HISTORY_TAB, rows=2000, cols=30)
        ws_hist.append_row(HISTORY_HEADERS)

    try:
        ws_gem = sh.worksheet(GEM_OUTPUT_TAB)
    except gspread.WorksheetNotFound:
        ws_gem = sh.add_worksheet(title=GEM_OUTPUT_TAB, rows=2000, cols=30)
        ws_gem.append_row(GEM_OUTPUT_HEADERS)

    return ws_watch, ws_hist, ws_gem

def ensure_headers(ws: gspread.Worksheet, required_headers: List[str]) -> Dict[str, int]:
    values = ws.get_all_values()
    if not values:
        ws.append_row(required_headers)
        header_row = required_headers
    else:
        header_row = values[0]

    col_map = {}
    for i, h in enumerate(header_row, start=1):
        key = h.strip().lower()
        if not key:
            continue
        col_map[key] = i
        col_map[key.replace(" ", "_")] = i
    missing = [h for h in required_headers if h.lower() not in col_map]
    if missing:
        new_headers = header_row + missing
        ws.update("1:1", [new_headers])
        col_map = {}
        for i, h in enumerate(new_headers, start=1):
            key = h.strip().lower()
            if not key:
                continue
            col_map[key] = i
            col_map[key.replace(" ", "_")] = i
    return col_map


def build_symbol_row_map(ws: gspread.Worksheet, symbol_col_name: str = "symbol") -> Dict[str, int]:
    """Return mapping from symbol -> row index for a sheet with headers on row 1."""
    values = ws.get_all_values()
    if not values or len(values) < 2:
        return {}
    header = [h.strip().lower() for h in values[0]]
    try:
        sym_idx = header.index(symbol_col_name.lower())
    except ValueError:
        return {}
    out: Dict[str, int] = {}
    for i in range(2, len(values) + 1):
        row = values[i - 1]
        if sym_idx < len(row):
            s = row[sym_idx].strip()
            if s:
                out[s] = i
    return out


def upsert_row_by_symbol(
    ws: gspread.Worksheet,
    col_map: Dict[str, int],
    symbol_to_row: Dict[str, int],
    symbol: str,
    values_by_col: Dict[str, Any],
) -> None:
    """Upsert a row by symbol (update if exists, append otherwise)."""
    s = (symbol or "").strip()
    if not s:
        return

    if s not in symbol_to_row:
        # Append a full-width row matching existing header width.
        max_col = max(col_map.values()) if col_map else 1
        row_vals = [""] * max_col
        if "symbol" in col_map:
            row_vals[col_map["symbol"] - 1] = s
        for k, v in values_by_col.items():
            ck = str(k).strip().lower()
            if ck in col_map:
                row_vals[col_map[ck] - 1] = "" if v is None else str(v)
        ws.append_row(row_vals, value_input_option="RAW")
        # Refresh map for appended row
        symbol_to_row[s] = len(ws.get_all_values())
        return

    row_index = symbol_to_row[s]
    updates: List[Tuple[int, Any]] = []
    for k, v in values_by_col.items():
        ck = str(k).strip().lower()
        if ck in col_map:
            updates.append((col_map[ck], v))
    batch_update_cells(ws, row_index, updates)


def get_cell(row: List[str], col_map: Dict[str, int], name: str) -> str:
    c = col_map[name.lower()]
    return row[c - 1].strip() if c - 1 < len(row) else ""

def set_cell(ws: gspread.Worksheet, row_index: int, col: int, val: Any) -> None:
    """Single-cell write (kept for rare cases). Prefer batch_update_cells()."""
    ws.update_cell(row_index, col, "" if val is None else str(val))

def batch_update_cells(ws: gspread.Worksheet, row_index: int, updates: List[Tuple[int, Any]]) -> None:
    """Batch update many cells in ONE Sheets API write request."""
    if not updates:
        return
    payload = []
    for col, val in updates:
        a1 = gspread.utils.rowcol_to_a1(row_index, col)
        payload.append({"range": a1, "values": [["" if val is None else str(val)]]})
    ws.batch_update(payload)


def merge_notes(existing: str, new: str) -> str:
    """Append new notes while keeping existing notes for reference."""
    existing = (existing or "").strip()
    new = (new or "").strip()
    if not existing:
        return new
    if not new:
        return existing
    if new in existing:
        return existing
    return existing + "\n\n---\n\n" + new


# =========================
# YFINANCE + MPLFINANCE (replaces Chart-IMG)
# =========================

def symbol_to_yf_ticker(symbol: str) -> str:
    """
    Converts 'NASDAQ:AAPL' -> 'AAPL'
    Keeps already-Yahoo-style tickers as-is.
    """
    s = symbol.strip()
    if ":" in s:
        return s.split(":")[-1].strip()
    return s

def yf_download_ohlcv(yf_ticker: str) -> pd.DataFrame:
    df = yf.download(
        tickers=yf_ticker,
        period=LOOKBACK_PERIOD,
        interval=INTERVAL,
        auto_adjust=False,
        group_by="column",
        progress=False,
        threads=False,
    )
    if df is None or df.empty:
        raise RuntimeError(f"No Yahoo Finance data returned for ticker={yf_ticker}")

    # If MultiIndex columns exist, flatten them (robust handling)
    if isinstance(df.columns, pd.MultiIndex):
        levels0 = set(map(str, df.columns.get_level_values(0)))
        levels1 = set(map(str, df.columns.get_level_values(-1)))
        ohlcv = {"Open", "High", "Low", "Close", "Volume", "Adj Close"}

        if len(levels0 & ohlcv) >= 3:
            df.columns = df.columns.get_level_values(0)
        elif len(levels1 & ohlcv) >= 3:
            df.columns = df.columns.get_level_values(-1)
        else:
            df.columns = ["_".join(map(str, c)) for c in df.columns.to_list()]

    df = df.rename(columns={c: str(c).strip() for c in df.columns})

    required = ["Open", "High", "Low", "Close", "Volume"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"Missing OHLCV columns {missing}. Got columns: {list(df.columns)}")

    df = df[required].copy()

    # Force numeric
    for col in required:
        s = df[col]
        if not isinstance(s, pd.Series):
            s = s.squeeze()
        df[col] = pd.to_numeric(s, errors="coerce")

    df = df.dropna()
    df.index = pd.to_datetime(df.index)
    return df

def render_chart_png_bytes(ohlcv: pd.DataFrame, title: str = "") -> bytes:
    # Return matplotlib figure so we can save into bytes.
    fig, _axes = mpf.plot(
        ohlcv,
        type="candle",
        style="yahoo",
        volume=True,
        figsize=FIGSIZE,
        title=title or None,
        returnfig=True,
    )

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=DPI, bbox_inches="tight")
    # Avoid memory leak when looping many tickers
    try:
        import matplotlib.pyplot as plt
        plt.close(fig)
    except Exception:
        pass

    return buf.getvalue()

def fetch_chart_png(symbol: str) -> bytes:
    yf_ticker = symbol_to_yf_ticker(symbol)
    df = yf_download_ohlcv(yf_ticker)
    return render_chart_png_bytes(df, title=symbol)



def ohlcv_to_compact_json(df: pd.DataFrame, max_rows: int = 260) -> str:
    """Serialize the last max_rows OHLCV bars into compact JSON to keep payload small."""
    d = df.tail(max_rows).copy()
    # Round prices to reduce token size while keeping precision for pattern logic
    for col in ["Open", "High", "Low", "Close"]:
        d[col] = d[col].round(2)
    # Ensure int volume
    d["Volume"] = d["Volume"].astype("int64")

    rows = []
    for idx, r in d.iterrows():
        rows.append({
            "date": idx.strftime("%Y-%m-%d"),
            "o": float(r["Open"]),
            "h": float(r["High"]),
            "l": float(r["Low"]),
            "c": float(r["Close"]),
            "v": int(r["Volume"]),
        })
    return json.dumps(rows, separators=(",", ":"))


# =========================
# OPENAI
# =========================

import os
import platform
import httpx
from openai import OpenAI

def openai_client() -> OpenAI:
    """Working OpenAI client for both Windows local and Cloud Run Linux."""
    api_key = os.getenv("OPENAI_API_KEY", "").strip()
    
    # These were the critical missing pieces!
    org_id = os.getenv("OPENAI_ORG_ID", "org-9EwgB06MNEoPblcvOM37AaQU")
    project_id = os.getenv("OPENAI_PROJECT_ID", "proj_tarlZtrcFzsRr4BsFvw640H7")

    client_args = {
        "api_key": api_key,
        "organization": org_id,
        "project": project_id,
        "max_retries": 3,
    }

    # Apply Cloud Run specific networking logic
    if platform.system() == "Linux":
        cert_path = "/etc/ssl/certs/ca-certificates.crt"
        # Force HTTP/1.1 and explicit SSL verification for GCP stability
        client_args["http_client"] = httpx.Client(
            http2=False, 
            verify=cert_path if os.path.exists(cert_path) else True,
            timeout=httpx.Timeout(180.0, connect=30.0),
            headers={"Connection": "close"}
        )
        print(f"DEBUG: Linux detected. Client configured with Org: {org_id[:8]}...")
    else:
        print(f"DEBUG: {platform.system()} detected. Using default local stack.")

    return OpenAI(**client_args)


def gemini_client():
    """Create a Gemini client (Developer API key flow)."""
    if google_genai is None:
        raise RuntimeError("Gemini SDK not installed. Add 'google-genai' to requirements.txt.")
    api_key = os.getenv("GEMINI_API_KEY", "").strip()
    if not api_key:
        raise RuntimeError("GEMINI_API_KEY is not set.")
    return google_genai.Client(api_key=api_key)


def analyze_ohlcv_gemini(symbol: str, ohlcv_df: pd.DataFrame, client) -> Dict[str, Any]:
    """Text-only analysis (no image): send compact OHLCV JSON to Gemini and parse strict JSON."""
    if genai_types is None:
        raise RuntimeError("Gemini SDK not available (google-genai).")
    
    
    prompt = PROMPT_BY_MODE[RUN_MODE]
    ohlcv_json = ohlcv_to_compact_json(ohlcv_df, max_rows=260)

    latest_close = float(ohlcv_df["Close"].iloc[-1]) if not ohlcv_df.empty else 0.0

    data_prompt = (
        f"Symbol: {symbol}\n\n"
        f"You are given DAILY OHLCV bars as a JSON array of objects with keys: date,o,h,l,c,v.\n"
        f"Use ONLY this OHLCV (no images) to detect Bulkowski-style chart patterns and propose a LONG trade plan.\n\n"
        f"Latest close: {latest_close}\n\n"
        f"OHLCV_JSON:\n{ohlcv_json}\n\n"
        f"{prompt}\n\n"
        f"Return STRICT JSON only. No markdown. No prose outside JSON."
    )

    max_attempts = 2
    base_sleep = 1.5
    for attempt in range(1, max_attempts + 1):
        try:
            resp = client.models.generate_content(
                model=GEMINI_MODEL,
                contents=data_prompt,
                config=genai_types.GenerateContentConfig(
                    temperature=0.2,
                    max_output_tokens=8192,
                    response_mime_type="application/json",
                ),
            )
            text = (resp.text or "").strip()
            if not text:
                raise RuntimeError("Gemini returned empty response text.")
            try:
                return json.loads(text)
            except json.JSONDecodeError:
                m = re.search(r"\{.*\}", text, flags=re.DOTALL)
                if not m:
                    raise RuntimeError(f"Gemini output not JSON: {text[:1200]}")
                return json.loads(m.group(0))
            if text.startswith("```"):
                text = text.strip("`")
                text = text.replace("json", "", 1).strip()
            # --- output_gem writeback (Gemini text/vision result) ---
            try:
                gem_decision = normalize_decision(gem_result) if gem_result else "NO_TRADE"
                gem_g = grade_val(gem_result) if gem_result else None
                gem_pat = best_pattern(gem_result) if gem_result else None

                # The update_only_on_change flag lives on watchlist; apply the same rule to output_gem.
                update_only_on_change = False
                wrow = watch_row_by_symbol.get(symbol, [])
                if wrow and "update_only_on_change" in col_map:
                    u_idx = col_map["update_only_on_change"] - 1
                    if 0 <= u_idx < len(wrow):
                        update_only_on_change = parse_bool(wrow[u_idx])

                old_gem_row = gem_row_by_symbol.get(symbol, [])
                old_gem_status = ""
                if old_gem_row:
                    st_col = col_map_gem.get("last_status") or col_map_gem.get("decision")
                    if st_col:
                        s_idx = st_col - 1
                        if 0 <= s_idx < len(old_gem_row):
                            old_gem_status = (old_gem_row[s_idx] or "").strip()

                gem_changed = status_changed(old_gem_status, gem_decision)
                do_update_gem = (not update_only_on_change) or gem_changed

                # Ensure row exists in output_gem
                if symbol not in symbol_to_row_gem:
                    upsert_row_by_symbol(ws_gem, col_map_gem, symbol_to_row_gem, symbol, {"symbol": symbol}, logger=log, cache_row_by_symbol=gem_row_by_symbol)
                    # Refresh maps for this symbol
                    _gem_rows_refresh = ws_gem.get_all_values()
                    gem_row_by_symbol.clear()
                    for _r in _gem_rows_refresh[1:]:
                        if _r and len(_r) > 0:
                            _sym = (_r[0] or "").strip()
                            if _sym:
                                gem_row_by_symbol[_sym] = _r
                    symbol_to_row_gem = build_symbol_row_map(ws_gem)

                grow_idx = symbol_to_row_gem.get(symbol)
                if grow_idx:
                    gem_wb = build_watchlist_writeback(gem_result) if gem_result else {}
                    # Merge notes to keep existing notes for reference
                    old_gem_notes = ""
                    if old_gem_row and "notes" in col_map_gem:
                        n_idx = col_map_gem["notes"] - 1
                        if 0 <= n_idx < len(old_gem_row):
                            old_gem_notes = old_gem_row[n_idx]
                    if isinstance(gem_wb, dict) and "notes" in gem_wb:
                        gem_wb["notes"] = merge_notes(old_gem_notes, gem_wb.get("notes") or "")

                    gem_status_fields: Dict[str, Any] = {
                        "last_status": gem_decision,
                        "last_grade": gem_g,
                        "last_pattern": gem_pat,
                    }
                    if gem_changed:
                        gem_status_fields["last_change_ts"] = now_str_local()
                    if gem_decision == "TRADE":
                        gem_status_fields["last_signal_ts"] = now_str_local()

                    update_watchlist_row(ws_gem, col_map_gem, grow_idx, gem_wb, gem_status_fields, do_update_gem)

                    # Always refresh last_run on output_gem to mirror watchlist behavior
                    lr_col = col_map_gem.get("last_run")
                    if lr_col:
                        last_run_payload_gem.append({
                            "range": gspread.utils.rowcol_to_a1(grow_idx, lr_col),
                            "values": [[now_str_local()]],
                        })
            except Exception as _gem_wb_e:
                log(f"{symbol}: output_gem writeback error -> {_gem_wb_e}")

            # If vision ran, re-write watchlist with FINAL decision/notes (respecting update_only_on_change)
            if vision:
                try:
                    final_decision = normalize_decision(result)
                    final_g = grade_val(result)
                    final_pat = best_pattern(result)
                    old_row = watch_row_by_symbol.get(symbol, [])
                    old_status = ""
                    if old_row:
                        st_col = col_map.get("last_status") or col_map.get("decision")
                        if st_col:
                            s_idx = st_col - 1
                            if 0 <= s_idx < len(old_row):
                                old_status = (old_row[s_idx] or "").strip()
                    changed2 = status_changed(old_status, final_decision)
                    update_only_on_change = False
                    if old_row and "update_only_on_change" in col_map:
                        u_idx = col_map["update_only_on_change"] - 1
                        if 0 <= u_idx < len(old_row):
                            update_only_on_change = parse_bool(old_row[u_idx])
                    do_update2 = (not update_only_on_change) or changed2

                    final_wb = build_watchlist_writeback(result)
                    old_notes = ""
                    if old_row and "notes" in col_map:
                        n_idx = col_map["notes"] - 1
                        if 0 <= n_idx < len(old_row):
                            old_notes = old_row[n_idx]
                    if isinstance(final_wb, dict) and "notes" in final_wb:
                        final_wb["notes"] = merge_notes(old_notes, final_wb.get("notes") or "")

                    status_fields2: Dict[str, Any] = {
                        "last_status": final_decision,
                        "last_grade": final_g,
                        "last_pattern": final_pat,
                    }
                    if changed2:
                        status_fields2["last_change_ts"] = now_str_local()
                    if final_decision == "TRADE":
                        status_fields2["last_signal_ts"] = now_str_local()

                    update_watchlist_row(ws_watch, col_map, row_index, final_wb, status_fields2, do_update2)
                except Exception as _vision_wb_e:
                    log(f"{symbol}: watchlist vision writeback error -> {_vision_wb_e}")

        except Exception as e:
            if attempt == max_attempts:
                raise
            sleep_s = base_sleep * (2 ** (attempt - 1)) + random.uniform(0, 0.5)
            print(f"[{now_str_local()}] {symbol}: Gemini error ({type(e).__name__}); retry {attempt}/{max_attempts} in {sleep_s:.1f}s")
            time.sleep(sleep_s)




def analyze_trade_confirmation_gemini_image(
    symbol: str,
    chart_png_bytes: bytes,
    last_close: float,
    openai_result: dict | None,
    gemini_text_result: dict | None,
    gemini_client: "google_genai.Client",
    logger: logging.Logger,
) -> dict:
    # Defensive: callers may accidentally pass the gemini_client() factory instead of an instantiated Client.
    if callable(gemini_client):
        gemini_client = gemini_client()

    """Second-pass confirmation using Gemini with the rendered chart image.

    Only run this when *either* OpenAI or Gemini-text suggested TRADE.
    Returns a small JSON payload with a TRADE/NO_TRADE decision and a short rationale.
    """
    vision_model = os.getenv("GEMINI_VISION_MODEL", os.getenv("GEMINI_MODEL", "gemini-2.0-flash"))
    temperature = float(os.getenv("GEMINI_VISION_TEMPERATURE", os.getenv("GEMINI_TEMPERATURE", "0.2")))

    constraints = {
        "entry_max_gap_pct": ENTRY_MAX_GAP_PCT,
        "stop_max_pct": STOP_MAX_PCT,
        "min_target1_pct": MIN_TARGET1_PCT,
        "min_target2_pct": MIN_TARGET2_PCT,
        "mode": os.getenv("MODE", "daily"),
    }

    def _compact_plan(r: dict | None) -> dict | None:
        if not isinstance(r, dict):
            return None
        ep = r.get("entry_plan")
        if not isinstance(ep, dict):
            ep = {}
        return {
            "decision": ep.get("decision"),
            "entry_price": ep.get("entry_price"),
            "stop_price": ep.get("stop_price"),
            "target_price_1": ep.get("target_price_1"),
            "target_price_2": ep.get("target_price_2"),
            "trigger": ep.get("trigger"),
        }

    payload = {
        "symbol": symbol,
        "last_close": last_close,
        "constraints": constraints,
        "openai_plan": _compact_plan(openai_result),
        "gemini_text_plan": _compact_plan(gemini_text_result),
    }

    prompt = (
        "You are a strict technical-analysis validator. You will be given a candlestick chart image rendered from OHLCV. "
        "Your job: CONFIRM or REJECT a previously-proposed LONG trade setup based ONLY on what you see in the chart.\n\n"
        "Rules (must follow):\n"
        "- Only LONG trades.\n"
        "- If a trade is not actionable near the current price, return NO_TRADE.\n"
        f"- Entry must be within {ENTRY_MAX_GAP_PCT:.4f} (ENTRY_MAX_GAP_PCT) of last_close.\n"
        f"- Stop distance (entry->stop) must be <= {STOP_MAX_PCT:.4f} (STOP_MAX_PCT).\n"
        f"- Target1 must be >= {MIN_TARGET1_PCT:.4f} and Target2 >= {MIN_TARGET2_PCT:.4f} above entry.\n"
        "If the chart does not clearly support the setup/pattern, return NO_TRADE.\n\n"
        "Return STRICT JSON ONLY in this schema:\n"
        "{\n"
        "  "symbol": string,\n"
        "  "decision": "TRADE" | "NO_TRADE",\n"
        "  "confidence_0_100": number,\n"
        "  "reason": string,\n"
        "  "suggested_entry_plan": {\n"
        "     "entry_price": number|null,\n"
        "     "stop_price": number|null,\n"
        "     "target_price_1": number|null,\n"
        "     "target_price_2": number|null\n"
        "  }\n"
        "}\n\n"
        "Context (JSON):\n"
        + json.dumps(payload, ensure_ascii=False)
    )

    # Build multimodal content for the google-genai SDK (works across versions by using dict fallback).
    raw_text = None
    try:
        content = [
            genai_types.Content(
                role="user",
                parts=[
                    genai_types.Part.from_bytes(data=chart_png_bytes, mime_type="image/png"),
                    genai_types.Part.from_text(text=prompt),
                ],
            )
        ]
        resp = gemini_client.models.generate_content(
            model=vision_model,
            contents=content,
            config=genai_types.GenerateContentConfig(temperature=temperature),
        )
        raw_text = getattr(resp, "text", None)
    except Exception:
        content = [
            {
                "role": "user",
                "parts": [
                    {
                        "inline_data": {
                            "mime_type": "image/png",
                            "data": base64.b64encode(chart_png_bytes).decode("utf-8"),
                        }
                    },
                    {"text": prompt},
                ],
            }
        ]
        resp = gemini_client.models.generate_content(
            model=vision_model,
            contents=content,
            config={"temperature": temperature},
        )
        raw_text = getattr(resp, "text", None)

    raw_text = (raw_text or "").strip()
    if not raw_text:
        raise ValueError("Gemini vision returned empty response")

    raw_text = strip_json_fence(raw_text)
    out = json.loads(raw_text)

    out.setdefault("symbol", symbol)
    out.setdefault("decision", "NO_TRADE")
    out.setdefault("confidence_0_100", 50)
    out.setdefault("reason", "")
    out.setdefault("suggested_entry_plan", {"entry_price": None, "stop_price": None, "target_price_1": None, "target_price_2": None})
    return out

def analyze_ohlcv(symbol: str, ohlcv_df: pd.DataFrame, client: OpenAI) -> Dict[str, Any]:
    """Text-only analysis (no image): send compact OHLCV JSON to the model."""
    prompt = PROMPT_BY_MODE[RUN_MODE]
    ohlcv_json = ohlcv_to_compact_json(ohlcv_df, max_rows=260)

    # Current price proxy (latest close)
    latest_close = float(ohlcv_df["Close"].iloc[-1]) if not ohlcv_df.empty else 0.0

    data_prompt = (
        f"Symbol: {symbol}\n\n"
        f"You are given DAILY OHLCV bars as a JSON array of objects with keys: "
        f"date,o,h,l,c,v (open/high/low/close/volume).\n"
        f"Use this OHLCV data (not an image) to detect Bulkowski-style chart patterns "
        f"and propose a LONG trade plan that follows the constraints.\n\n"
        f"OHLCV_JSON:\n{ohlcv_json}"
    )

    max_attempts = 5
    base_sleep = 1.5

    for attempt in range(1, max_attempts + 1):
        try:
            resp = client.responses.create(
                model=OPENAI_MODEL,
                input=[{
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": data_prompt + "\n\n" + prompt},
                    ],
                }],
                timeout=OPENAI_TIMEOUT_SEC,
            )

            text = (resp.output_text or "").strip()
            if not text:
                raise RuntimeError("OpenAI returned empty output_text.")

            try:
                return json.loads(text)
            except json.JSONDecodeError:
                m = re.search(r"\{.*\}", text, flags=re.DOTALL)
                if not m:
                    raise RuntimeError(f"OpenAI output not JSON:\n{text[:1200]}")
                return json.loads(m.group(0))

        except (APIConnectionError, APITimeoutError, RateLimitError, APIError) as e:
            if attempt == max_attempts:
                raise
            sleep_s = base_sleep * (2 ** (attempt - 1)) + random.uniform(0, 0.5)
            print(
                f"[{now_str_local()}] {symbol}: OpenAI transient error ({type(e).__name__}). "
                f"Retry {attempt}/{max_attempts} in {sleep_s:.1f}s"
            )
            time.sleep(sleep_s)


# =========================
# POST-FILTERS (enforce your plan)
# =========================

def enforce_plan_filters(result: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    notes: List[str] = []
    entry_plan = result.get("entry_plan") or {}
    decision = str(entry_plan.get("decision", "")).upper().strip()

    entry = to_float(entry_plan.get("entry_price"))
    stop = to_float(entry_plan.get("stop_price"))
    t1 = to_float(entry_plan.get("target_price_1"))
    t2 = to_float(entry_plan.get("target_price_2"))

    if decision == "TRADE":
        if entry is None or stop is None or t1 is None or t2 is None:
            notes.append("Missing prices in entry_plan; forcing NO_TRADE.")
            decision = "NO_TRADE"

    if decision == "TRADE" and entry and stop:
        stop_pct = (entry - stop) / entry
        if stop_pct <= 0:
            notes.append("Stop is not below entry for LONG; forcing NO_TRADE.")
            decision = "NO_TRADE"
        elif stop_pct > MAX_STOP_PCT:
            notes.append(f"Stop distance {stop_pct*100:.2f}% > {MAX_STOP_PCT*100:.2f}% max; forcing NO_TRADE.")
            decision = "NO_TRADE"

    if decision == "TRADE" and entry and t1:
        t1_pct = (t1 - entry) / entry
        if t1_pct < MIN_TARGET1_PCT:
            notes.append(f"Target1 gain {t1_pct*100:.2f}% < {MIN_TARGET1_PCT*100:.2f}% min; forcing NO_TRADE.")
            decision = "NO_TRADE"

    entry_plan["decision"] = "TRADE" if decision == "TRADE" else "NO_TRADE"
    result["entry_plan"] = entry_plan

    if notes:
        rn = list(result.get("risk_notes") or [])
        rn += [f"[PLAN_FILTER] {n}" for n in notes]
        result["risk_notes"] = rn

        nt = list(result.get("no_trade_if") or [])
        nt += [f"[PLAN_FILTER] {n}" for n in notes]
        result["no_trade_if"] = nt

    return result, notes



def enforce_entry_proximity(result: Dict[str, Any], last_close: float) -> Tuple[Dict[str, Any], List[str]]:
    """If decision=TRADE but entry is far from current price, downgrade to NO_TRADE and mark as FUTURE_SETUP."""
    notes: List[str] = []
    ep = result.get("entry_plan") or {}
    decision = str(ep.get("decision", "")).upper().strip()

    entry = to_float(ep.get("entry_price"))

    if decision == "TRADE" and entry is not None and last_close and last_close > 0:
        gap = abs(entry - last_close) / last_close
        if gap > ENTRY_MAX_GAP_PCT:
            notes.append(
                f"Entry {entry:.2f} is {gap*100:.2f}% away from last close {last_close:.2f}. "
                f"Treat as FUTURE_SETUP; forcing NO_TRADE for this run."
            )
            ep["decision"] = "NO_TRADE"
            result["entry_plan"] = ep

    if notes:
        rn = list(result.get("risk_notes") or [])
        rn += [f"[FUTURE_SETUP] {n}" for n in notes]
        result["risk_notes"] = rn

        nt = list(result.get("no_trade_if") or [])
        nt += [f"[FUTURE_SETUP] {n}" for n in notes]
        result["no_trade_if"] = nt

    return result, notes


# =========================
# EXTRA POLICY: alert threshold + status change logic
# =========================

def best_pattern(result: Dict[str, Any]) -> str:
    pats = result.get("pattern_candidates") or []
    if not pats:
        return ""
    return str((pats[0] or {}).get("name", "")).strip()

def entry_fields(result: Dict[str, Any]) -> Tuple[Any, Any, Any, Any]:
    ep = result.get("entry_plan") or {}
    return ep.get("entry_price", ""), ep.get("stop_price", ""), ep.get("target_price_1", ""), ep.get("target_price_2", "")

def normalize_decision(result: Dict[str, Any]) -> str:
    ep = result.get("entry_plan") or {}
    return str(ep.get("decision", "")).upper().strip() or "NO_TRADE"

def grade_val(result: Dict[str, Any]) -> int:
    g = result.get("grade_0_10", 0)
    try:
        return int(float(g))
    except Exception:
        return 0

def passes_user_thresholds(result: Dict[str, Any], min_grade: int, only_alert_if_trade: bool) -> bool:
    d = normalize_decision(result)
    g = grade_val(result)
    if g < min_grade:
        return False
    if only_alert_if_trade and d != "TRADE":
        return False
    return True

def status_changed(old_status: str, new_status: str) -> bool:
    return (old_status or "").strip().upper() != (new_status or "").strip().upper()


# =========================
# WATCHLIST WRITEBACK + HISTORY
# =========================

def build_watchlist_writeback(result: Dict[str, Any]) -> Dict[str, Any]:
    decision = normalize_decision(result)
    grade = result.get("grade_0_10", "")
    entry, stop, t1, t2 = entry_fields(result)

    rn = result.get("risk_notes") or []
    nt = result.get("no_trade_if") or []
    notes_parts: List[str] = []
    if isinstance(rn, list) and rn:
        notes_parts.append("Risk: " + " | ".join(map(str, rn[:6])))
    if decision == "NO_TRADE" and isinstance(nt, list) and nt:
        notes_parts.append("NoTradeIf: " + " | ".join(map(str, nt[:6])))

    return {
        "last_run": now_str_local(),
        "last_close": (round(to_float(result.get("last_close")) or 0.0, 4) if to_float(result.get("last_close")) is not None else ""),
        "decision": decision,
        "grade_0_10": grade,
        "pattern": best_pattern(result),
        "entry": entry,
        "stop": stop,
        "t1": t1,
        "t2": t2,
        "notes": " || ".join(notes_parts),
        "raw_json": json.dumps(result, ensure_ascii=False),
    }

def update_watchlist_row(
    ws_watch: gspread.Worksheet,
    col_map: Dict[str, int],
    row_index: int,
    wb: Dict[str, Any],
    status_fields: Dict[str, Any],
    do_update: bool
) -> None:
    if not do_update:
        return

    updates: List[Tuple[int, Any]] = []
    for k, v in {**wb, **status_fields}.items():
        ck = k.lower()
        if ck in col_map:
            updates.append((col_map[ck], v))
    batch_update_cells(ws_watch, row_index, updates)

def build_history_row(result: Dict[str, Any]) -> List[Any]:
    """Build one history row to later append in a single batch."""
    decision = normalize_decision(result)
    grade = result.get("grade_0_10", "")
    pat = best_pattern(result)
    entry, stop, t1, t2 = entry_fields(result)

    rn = result.get("risk_notes") or []
    nt = result.get("no_trade_if") or []
    notes_parts: List[str] = []
    if isinstance(rn, list) and rn:
        notes_parts.append("Risk: " + " | ".join(map(str, rn[:6])))
    if decision == "NO_TRADE" and isinstance(nt, list) and nt:
        notes_parts.append("NoTradeIf: " + " | ".join(map(str, nt[:6])))

    return [
        now_str_local(),
        RUN_MODE,
        result.get("symbol", ""),
        decision,
        grade,
        pat,
        entry,
        stop,
        t1,
        t2,
        " || ".join(notes_parts),
        json.dumps(result, ensure_ascii=False),
    ]


# =========================
# NETWORK PROBE
# =========================



def network_probe():
    print("--- STARTING NETWORK PROBE ---")
    # Test 1: DNS Lookup
    try:
        ip = socket.gethostbyname("api.openai.com")
        print(f"DNS Check: api.openai.com resolved to {ip}")
    except Exception as e:
        print(f"DNS Check FAILED: Could not resolve OpenAI domain. {e}")

    # Test 2: Basic HTTP Reachability
    try:
        r = requests.get("https://api.openai.com/v1/models", timeout=5)
        print(f"HTTP Check: OpenAI reached. Status: {r.status_code}")
    except Exception as e:
        print(f"HTTP Check FAILED: {e}")
    print("--- END NETWORK PROBE ---")

def enforce_entry_breakout_alignment(result: Dict[str, Any], tol_pct: float = ENTRY_BREAKOUT_ALIGN_PCT) -> Tuple[Dict[str, Any], List[str]]:
    """Ensure entry_price is close to the chosen breakout_level (apples-to-apples between providers).

    If the model proposes a TRADE but the entry is far from the breakout level, we force NO_TRADE.
    This prevents 'loose' Gemini plans where entry is materially away from the technical trigger.
    """
    notes: List[str] = []
    if not isinstance(result, dict):
        return result, notes

    entry_plan = result.get("entry_plan") or {}
    if not isinstance(entry_plan, dict):
        return result, notes

    decision = (entry_plan.get("decision") or "").upper()
    if decision != "TRADE":
        return result, notes

    entry = entry_plan.get("entry_price")
    if not isinstance(entry, (int, float)) or entry <= 0:
        return result, notes

    breakout_level = None
    pcs = result.get("pattern_candidates") or []
    if isinstance(pcs, list) and pcs:
        first = pcs[0]
        if isinstance(first, dict):
            breakout_level = first.get("breakout_level")

    if not isinstance(breakout_level, (int, float)) or breakout_level <= 0:
        return result, notes

    gap = abs(float(entry) - float(breakout_level)) / float(breakout_level)
    if gap > float(tol_pct):
        note = f"[ALIGN_FILTER] entry_price ({entry}) is {gap*100:.2f}% away from breakout_level ({breakout_level}); forcing NO_TRADE."
        notes.append(note)

        entry_plan["decision"] = "NO_TRADE"
        entry_plan["trigger"] = (entry_plan.get("trigger") or "") + " | Forced NO_TRADE by ALIGN_FILTER."
        result["entry_plan"] = entry_plan

        rn = result.get("risk_notes")
        if not isinstance(rn, list):
            rn = []
        rn.append(note)
        result["risk_notes"] = rn

        nti = result.get("no_trade_if")
        if not isinstance(nti, list):
            nti = []
        nti.append(note)
        result["no_trade_if"] = nti

    return result, notes


def compute_daily_signal(
    prev_close: Optional[float],
    last_close: Optional[float],
    entry: Optional[float],
    stop: Optional[float],
    t1: Optional[float],
    t2: Optional[float],
    last_status: str = "",
    decision: str = "",
) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """Compute DAILY monitoring signal from price crosses.

    Returns: (signal_type, new_status, note)
      signal_type in {"BREAKOUT","T1","T2","STOP"} or None
      new_status mirrors signal_type when present; otherwise keeps last_status.
    """
    if last_close is None:
        return None, (last_status or None), None

    ls = (last_status or "").upper().strip()
    dec = (decision or "").upper().strip()

    # If already terminal, do nothing
    if ls in ("T2", "STOP", "STOP_HIT", "T2_HIT"):
        return None, ls, None

    def crossed_up(level: Optional[float]) -> bool:
        if level is None:
            return False
        if prev_close is None:
            return last_close >= level
        return prev_close < level <= last_close

    def crossed_down(level: Optional[float]) -> bool:
        if level is None:
            return False
        if prev_close is None:
            return last_close <= level
        return prev_close > level >= last_close

    # Stop logic: only meaningful when we consider the setup active-ish
    activeish = dec in ("TRADE", "FUTURE_SETUP") or ls in ("BREAKOUT", "T1")
    if activeish and stop is not None and crossed_down(stop):
        note = f"STOP hit: close {last_close:.2f} crossed below/at stop {stop:.2f}"
        return "STOP", "STOP", note

    # Progression logic by status
    if ls in ("T1", "T1_HIT"):
        if t2 is not None and crossed_up(t2):
            note = f"T2 hit: close {last_close:.2f} crossed above/at t2 {t2:.2f}"
            return "T2", "T2", note
        return None, ls, None

    if ls in ("BREAKOUT", "ENTRY", "ENTRY_HIT"):
        if t2 is not None and crossed_up(t2):
            note = f"T2 hit: close {last_close:.2f} crossed above/at t2 {t2:.2f}"
            return "T2", "T2", note
        if t1 is not None and crossed_up(t1):
            note = f"T1 hit: close {last_close:.2f} crossed above/at t1 {t1:.2f}"
            return "T1", "T1", note
        return None, ls, None

    # Pre-entry: check breakout
    if entry is not None and crossed_up(entry):
        note = f"BREAKOUT: close {last_close:.2f} crossed above/at entry {entry:.2f}"
        return "BREAKOUT", "BREAKOUT", note

    return None, (ls or None), None

def main() -> None:

    network_probe()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logs_dir = OUTPUT_DIR / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    charts_dir = OUTPUT_DIR / "charts" / today_iso()
    if SAVE_CHARTS:
        charts_dir.mkdir(parents=True, exist_ok=True)

    log_path = logs_dir / f"run_{today_iso()}_{RUN_MODE}.log"
    summary_path = OUTPUT_DIR / f"summary_{today_iso()}_{RUN_MODE}.txt"

    def log(msg: str) -> None:
        line = f"[{now_str_local()}] {msg}"
        print(line)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")

    if not SHEET_ID or SHEET_ID.startswith("PUT_YOUR"):
        raise RuntimeError("SHEET_ID not set (env SHEET_ID or edit script).")

    ws_watch, ws_hist, ws_gem = connect_sheets()
    col_map = ensure_headers(ws_watch, WATCHLIST_HEADERS)
    gem_col_map = ensure_headers(ws_gem, GEM_OUTPUT_HEADERS)
    ensure_headers(ws_hist, HISTORY_HEADERS)
    gem_col_map = ensure_headers(ws_gem, GEM_OUTPUT_HEADERS)
    gem_symbol_to_row = build_symbol_row_map(ws_gem, "symbol")

    rows = ws_watch.get_all_values()
    if len(rows) < 2:
        log("Watchlist has no rows.")
        return


    # Build caches for existing values (notes merging + status-change detection)
    watch_row_by_symbol: Dict[str, List[str]] = {}
    for r in rows[1:]:
        if r and len(r) > 0:
            sym = (r[0] or "").strip()
            if sym:
                watch_row_by_symbol[sym] = r

    gem_rows = ws_gem.get_all_values()
    gem_row_by_symbol: Dict[str, List[str]] = {}
    if gem_rows and len(gem_rows) >= 2:
        for r in gem_rows[1:]:
            if r and len(r) > 0:
                sym = (r[0] or "").strip()
                if sym:
                    gem_row_by_symbol[sym] = r

    # IMPORTANT: Daily mode is a monitoring run (no AI calls).
    openai_cli = openai_client() if (RUN_MODE == "weekly" and ANALYSIS_PROVIDER in ("openai", "both")) else None
    gemini_cli = gemini_client() if (RUN_MODE == "weekly" and ANALYSIS_PROVIDER in ("gemini", "both")) else None

    alerts: List[Dict[str, Any]] = []
    status_changes: List[Dict[str, Any]] = []
    history_buffer: List[List[Any]] = []
    last_run_payload: List[Dict[str, Any]] = []
    last_run_payload_gem: List[Dict[str, Any]] = []

    log(f"Run start: mode={RUN_MODE} symbols_rows={len(rows)-1} model={OPENAI_MODEL}")
    log(f"Run start: mode={RUN_MODE} symbols_rows={len(rows)-1} model={GEMINI_MODEL}")
 
    for r_idx in range(2, len(rows) + 1):
        row = rows[r_idx - 1]

        symbol = get_cell(row, col_map, "symbol")
        enabled = get_cell(row, col_map, "enabled")
        if not symbol or not truthy(enabled, default=False):
            continue

        min_grade = to_int(get_cell(row, col_map, "min_grade"), default=7)
        only_alert_if_trade = truthy(get_cell(row, col_map, "only_alert_if_trade"), default=True)
        update_only_on_change = truthy(get_cell(row, col_map, "update_only_on_change"), default=True)

        old_status = get_cell(row, col_map, "last_status")
        safe_sym = safe_filename(symbol)

        try:
            log(f"{symbol}: downloading OHLCV from Yahoo Finance...")
            yf_ticker = symbol_to_yf_ticker(symbol)
            df = yf_download_ohlcv(yf_ticker)

            # Compute closes for both modes (used for last_close column and entry proximity checks)
            last_close = float(df["Close"].iloc[-1]) if not df.empty else None
            prev_close = float(df["Close"].iloc[-2]) if len(df) >= 2 else None

            # Always refresh last_run/last_close columns (even if update_only_on_change skips other fields)
            if RUN_MODE != "daily":
                if "last_run" in col_map:
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_run"]),
                        "values": [[now_str_local()]],
                    })
                if "last_close" in col_map:
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_close"]),
                        "values": [[last_close if last_close is not None else ""]],
                    })

            if SAVE_CHARTS:
                png = render_chart_png_bytes(df, title=symbol)
                chart_path = charts_dir / f"{safe_sym}.png"
                chart_path.write_bytes(png)

            # Daily mode: no AI. Monitor existing levels (entry/stop/t1/t2) and log signals.
            if RUN_MODE != "weekly":
                # (last_close/prev_close already computed above)

                # Read existing plan from the sheet row (produced by weekly runs)
                decision_cell = get_cell(row, col_map, "decision")
                entry_cell = to_float(get_cell(row, col_map, "entry"))
                stop_cell = to_float(get_cell(row, col_map, "stop"))
                t1_cell = to_float(get_cell(row, col_map, "t1"))
                t2_cell = to_float(get_cell(row, col_map, "t2"))

                signal, new_status, sig_note = compute_daily_signal(
                    prev_close=prev_close,
                    last_close=last_close,
                    entry=entry_cell,
                    stop=stop_cell,
                    t1=t1_cell,
                    t2=t2_cell,
                    last_status=old_status or "",
                    decision=decision_cell or "",
                )

                # Always refresh last_run
                if "last_run" in col_map:
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_run"]),
                        "values": [[now_str_local()]],
                    })
                # Always refresh last_close
                if "last_close" in col_map:
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_close"]),
                        "values": [[last_close if last_close is not None else ""]],
                    })

                status_fields: Dict[str, Any] = {}
                if signal and new_status:
                    status_fields["last_status"] = new_status
                    status_fields["last_signal_ts"] = now_str_local()
                    if (old_status or "").strip().upper() != new_status.upper():
                        status_fields["last_change_ts"] = now_str_local()
                        status_changes.append({
                            "symbol": symbol,
                            "old": old_status,
                            "new": new_status,
                            "grade": to_int(get_cell(row, col_map, "grade_0_10"), default=None),
                            "pattern": get_cell(row, col_map, "pattern"),
                        })

                    # Append signal note to notes (preserve history)
                    if "notes" in col_map and sig_note:
                        old_notes = get_cell(row, col_map, "notes") or ""
                        new_notes = merge_notes(old_notes, f"[DAILY_SIGNAL] {sig_note}")
                        ws_watch.update(
                            gspread.utils.rowcol_to_a1(r_idx, col_map["notes"]),
                            [[new_notes]],
                        )

                    # Write to DailySignals history tab (lightweight row)
                    hist_row = [
                        now_str_local(),
                        RUN_MODE,
                        symbol,
                        decision_cell,
                        get_cell(row, col_map, "grade_0_10"),
                        get_cell(row, col_map, "pattern"),
                        entry_cell,
                        stop_cell,
                        t1_cell,
                        t2_cell,
                        f"[DAILY_SIGNAL] {sig_note}" if sig_note else "",
                        "",  # raw_json not recomputed in daily mode
                    ]
                    history_buffer.append(hist_row)

                    # Daily alerts list (optional, used in summary)
                    dec_norm = str(decision_cell or "").upper().strip()
                    if only_alert_if_trade:
                        if dec_norm != "NO_TRADE":
                            alerts.append({
                                "symbol": symbol,
                                "decision": decision_cell,
                                "grade": to_int(get_cell(row, col_map, "grade_0_10"), default=None),
                                "pattern": get_cell(row, col_map, "pattern"),
                                "entry": entry_cell,
                                "stop": stop_cell,
                                "t1": t1_cell,
                                "t2": t2_cell,
                                "signal": signal,
                            })
                    else:
                        alerts.append({
                            "symbol": symbol,
                            "decision": decision_cell,
                            "grade": to_int(get_cell(row, col_map, "grade_0_10"), default=None),
                            "pattern": get_cell(row, col_map, "pattern"),
                            "entry": entry_cell,
                            "stop": stop_cell,
                            "t1": t1_cell,
                            "t2": t2_cell,
                            "signal": signal,
                        })

                    log(f"{symbol}: DAILY signal -> {signal} ({sig_note})")

                    # Persist status fields in Watchlist row
                    update_watchlist_row(ws_watch, col_map, r_idx, {}, status_fields, do_update=True)
                else:
                    log(f"{symbol}: DAILY mode -> no signal (close={last_close})")

                time.sleep(SLEEP_BETWEEN_SYMBOLS_SEC)
                continue


            result = None
            gem_result = None

            if ANALYSIS_PROVIDER in ("openai", "both"):
                log(f"{symbol}: OpenAI analysis")
                result = analyze_ohlcv(symbol, df, openai_cli)
                if isinstance(result, dict):
                    result["last_close"] = last_close
                    result["prev_close"] = prev_close

            if ANALYSIS_PROVIDER in ("gemini", "both"):
                log(f"{symbol}: Gemini analysis")
                gem_result = analyze_ohlcv_gemini(symbol, df, gemini_cli)
                if isinstance(gem_result, dict):
                    gem_result["last_close"] = last_close
                    gem_result["prev_close"] = prev_close
                
            # =========================
            # OPENAI POST-PROCESSING
            # =========================
            if result is not None:
                result, filter_notes = enforce_plan_filters(result)
                result.setdefault("post_filter_notes", []).extend(filter_notes)
                if filter_notes:
                    log(f"{symbol}: plan filters -> {filter_notes}")

                last_close = float(df["Close"].iloc[-1]) if not df.empty else 0.0
                result, proximity_notes = enforce_entry_proximity(result, last_close)
                result.setdefault("post_filter_notes", []).extend(proximity_notes)
                if proximity_notes:
                    log(f"{symbol}: entry proximity -> {proximity_notes}")

                result, align_notes = enforce_entry_breakout_alignment(result)
                result.setdefault("post_filter_notes", []).extend(align_notes)
                if align_notes:
                    log(f"{symbol}: entry/breakout alignment -> {align_notes}")

                decision = normalize_decision(result)
                g = grade_val(result)
                pat = best_pattern(result)

                wb = build_watchlist_writeback(result)

                # Merge notes so previous context is kept
                try:
                    old_notes = ""
                    old_row = watch_row_by_symbol.get(symbol, [])
                    if old_row and "notes" in col_map:
                        n_idx = col_map["notes"] - 1
                        if 0 <= n_idx < len(old_row):
                            old_notes = old_row[n_idx]
                    if isinstance(wb, dict) and "notes" in wb:
                        wb["notes"] = merge_notes(old_notes, wb.get("notes") or "")
                except Exception:
                    pass

                changed = status_changed(old_status, decision)
                status_fields: Dict[str, Any] = {
                    "last_status": decision,
                    "last_grade": g,
                    "last_pattern": pat,
                }

                if changed:
                    status_fields["last_change_ts"] = now_str_local()
                    status_changes.append({
                        "symbol": symbol,
                        "old": old_status,
                        "new": decision,
                        "grade": g,
                        "pattern": pat,
                    })

                if decision == "TRADE":
                    status_fields["last_signal_ts"] = now_str_local()

                do_update = True
                if update_only_on_change and not changed:
                    do_update = False
                    last_run_payload.append({
                        "range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_run"]),
                        "values": [[now_str_local()]],
                    })

                if not do_update:
                    log(f"{symbol}: unchanged ({decision}); skipped writeback")
                else:
                    update_watchlist_row(ws_watch, col_map, r_idx, wb, status_fields, do_update=True)
                    log(f"{symbol}: updated. decision={decision} grade={g} pattern={pat}")

                if passes_user_thresholds(result, min_grade=min_grade, only_alert_if_trade=only_alert_if_trade):
                    entry, stop, t1, t2 = entry_fields(result)
                    alerts.append({
                        "symbol": symbol,
                        "decision": decision,
                        "grade": g,
                        "pattern": pat,
                        "entry": entry,
                        "stop": stop,
                        "t1": t1,
                        "t2": t2,
                    })

                history_buffer.append(build_history_row(result))

            # =========================
            # GEMINI POST-PROCESSING
            # =========================
            if gem_result is not None:
                try:
                    # Unified post-filters (same as OpenAI) to make results apples-to-apples
                    gem_result, _plan_notes = enforce_plan_filters(gem_result)
                    gem_result, _prox_notes = enforce_entry_proximity(gem_result, last_close=last_close)
                    gem_result, _align_notes = enforce_entry_breakout_alignment(gem_result)

                    # Surface filter notes in risk_notes for easier debugging (optional but handy)
                    _all_notes = []
                    _all_notes.extend(_plan_notes or [])
                    _all_notes.extend(_prox_notes or [])
                    _all_notes.extend(_align_notes or [])
                    if _all_notes:
                        rn = gem_result.get("risk_notes")
                        if not isinstance(rn, list):
                            rn = []
                        rn.extend(_all_notes)
                        gem_result["risk_notes"] = rn

                except Exception as _pp_e:
                    log(f"{symbol}: Gemini post-processing error -> {_pp_e}")

                # ---- GEMINI VISION CONFIRMATION (image-based) ----
                # Run ONLY if either model suggested TRADE (after unified post-filters).
                vision = None
                try:
                    openai_dec = ((result or {}).get("entry_plan") or {}).get("decision")
                    gemini_text_dec = ((gem_result or {}).get("entry_plan") or {}).get("decision")
                    if str(openai_dec).upper() == "TRADE" or str(gemini_text_dec).upper() == "TRADE":
                        log(f"{symbol}: Gemini vision confirmation (chart image)")
                        chart_png = render_chart_png_bytes(df, symbol)
                        vision = analyze_trade_confirmation_gemini_image(
                            symbol=symbol,
                            chart_png_bytes=chart_png,
                            last_close=float(last_close),
                            openai_result=result,
                            gemini_text_result=gem_result,
                            gemini_client=gemini_cli,
                            logger=log,
                        )
                        v_dec = str(vision.get("decision", "NO_TRADE")).upper()
                        # Attach vision payload for audit/debugging
                        if isinstance(gem_result, dict):
                            gem_result["vision_confirmation"] = vision
                        if isinstance(result, dict):
                            result["vision_confirmation"] = vision

                        if v_dec != "TRADE":
                            # Downgrade both model decisions to NO_TRADE (keep original numbers in notes)
                            for _r in (result, gem_result):
                                if isinstance(_r, dict):
                                    ep = _r.get("entry_plan")
                                    if isinstance(ep, dict):
                                        ep["decision"] = "NO_TRADE"
                                    rn = _r.get("risk_notes")
                                    if rn is None:
                                        rn = []
                                        _r["risk_notes"] = rn
                                    if isinstance(rn, list):
                                        rn.append(f"VISION_REJECTED: {vision.get('reason','').strip()[:180]}")
                            log(f"{symbol}: Vision rejected trade -> NO_TRADE")
                        else:
                            for _r in (result, gem_result):
                                if isinstance(_r, dict):
                                    rn = _r.get("risk_notes")
                                    if rn is None:
                                        rn = []
                                        _r["risk_notes"] = rn
                                    if isinstance(rn, list):
                                        rn.append(f"VISION_CONFIRMED ({vision.get('confidence_0_100', '')})")
                except Exception as _vision_e:
                    log(f"{symbol}: Gemini vision confirmation error -> {_vision_e}")

                # =========================
                # GEMINI WRITEBACK (output_gem) + FINAL WATCHLIST SYNC
                # =========================
                try:
                    # Final (post-filter, post-vision) Gemini decision snapshot
                    g_decision = normalize_decision(gem_result)
                    g_grade = grade_val(gem_result)
                    g_pat = best_pattern(gem_result)
                    g_entry, g_stop, g_t1, g_t2 = entry_fields(gem_result)
                    g_time_stop = ((gem_result.get("entry_plan") or {}).get("time_stop_days")) if isinstance(gem_result, dict) else None

                    # Merge notes (keep existing notes for reference)
                    g_old_row = gem_row_by_symbol.get(symbol, [])
                    g_old_notes = ""
                    if g_old_row and "notes" in gem_col_map:
                        _ni = gem_col_map["notes"] - 1
                        if 0 <= _ni < len(g_old_row):
                            g_old_notes = g_old_row[_ni] or ""

                    g_wb = build_watchlist_writeback(gem_result)  # reuse existing helper to format notes
                    g_new_notes = g_wb.get("notes") if isinstance(g_wb, dict) else ""
                    g_notes = merge_notes(g_old_notes, g_new_notes or "")

                    # Respect update_only_on_change (same flag as watchlist)
                    g_old_dec = ""
                    if g_old_row and "decision" in gem_col_map:
                        _di = gem_col_map["decision"] - 1
                        if 0 <= _di < len(g_old_row):
                            g_old_dec = (g_old_row[_di] or "").strip().upper()

                    g_changed = (g_old_dec != (g_decision or "").strip().upper())

                    if update_only_on_change and not g_changed:
                        log(f"{symbol}: output_gem unchanged ({g_decision}); skipped writeback")
                    else:
                        row_dict = {
                            "symbol": symbol,
                            "last_run": now_str_local(),
                            "decision": g_decision,
                            "grade_0_10": g_grade,
                            "pattern": g_pat,
                            "entry": g_entry,
                            "stop": g_stop,
                            "t1": g_t1,
                            "t2": g_t2,
                            "notes": g_notes,
                            "raw_json": json.dumps(gem_result, ensure_ascii=False) if isinstance(gem_result, dict) else "",
                        }
                        upsert_row_by_symbol(
                            ws=ws_gem,
                            col_map=gem_col_map,
                            symbol_to_row=gem_symbol_to_row,
                            symbol=symbol,
                            values_by_col=row_dict,
                        )

                    # Watchlist must reflect FINAL decision (post-vision).
                    # If OpenAI ran, we update from its (possibly vision-adjusted) result; otherwise from Gemini.
                    wl_src = result if isinstance(result, dict) else gem_result
                    wl_decision = normalize_decision(wl_src)
                    wl_grade = grade_val(wl_src)
                    wl_pat = best_pattern(wl_src)

                    wl_wb = build_watchlist_writeback(wl_src)

                    # Merge notes with existing watchlist notes
                    try:
                        wl_old_notes = ""
                        old_row = watch_row_by_symbol.get(symbol, [])
                        if old_row and "notes" in col_map:
                            n_idx = col_map["notes"] - 1
                            if 0 <= n_idx < len(old_row):
                                wl_old_notes = old_row[n_idx] or ""
                        if isinstance(wl_wb, dict) and "notes" in wl_wb:
                            wl_wb["notes"] = merge_notes(wl_old_notes, wl_wb.get("notes") or "")
                    except Exception:
                        pass

                    wl_status_fields = {
                        "last_status": wl_decision,
                        "last_grade": wl_grade,
                        "last_pattern": wl_pat,
                    }

                    wl_changed = status_changed(old_status, wl_decision)
                    if wl_changed:
                        wl_status_fields["last_change_ts"] = now_str_local()
                    if wl_decision == "TRADE":
                        wl_status_fields["last_signal_ts"] = now_str_local()

                    # Mirror watchlist behavior: if update_only_on_change and no change, skip.
                    if update_only_on_change and not wl_changed:
                        log(f"{symbol}: watchlist unchanged ({wl_decision}); skipped writeback (final sync)")
                    else:
                        update_watchlist_row(ws_watch, col_map, r_idx, wl_wb, wl_status_fields, do_update=True)
                        log(f"{symbol}: watchlist updated (final sync). decision={wl_decision} grade={wl_grade} pattern={wl_pat}")

                except Exception as _wb_e:
                    log(f"{symbol}: gem/writeback sync error -> {_wb_e}")

        except Exception as e:
            err = f"{type(e).__name__}: {e}"
            log(f"{symbol}: ERROR -> {err}")

            fail_updates = {
                "last_run": now_str_local(),
                "decision": "ERROR",
                "notes": err,
                "last_status": "ERROR",
                "last_change_ts": now_str_local(),
            }

            update_watchlist_row(ws_watch, col_map, r_idx, fail_updates, {}, do_update=True)

        time.sleep(SLEEP_BETWEEN_SYMBOLS_SEC)

    if last_run_payload:
        ws_watch.batch_update(last_run_payload)

    if last_run_payload_gem:
        ws_gem.batch_update(last_run_payload_gem)

    if history_buffer:
        ws_hist.append_rows(history_buffer, value_input_option="RAW")

    alerts_sorted = sorted(alerts, key=lambda x: (x["decision"] != "TRADE", -int(x["grade"])))

    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"Run summary ({RUN_MODE}) @ {now_str_local()}\n")
        f.write(f"Lookback: {LOOKBACK_PERIOD}  Interval: {INTERVAL}\n")
        f.write(f"Alerts: {len(alerts_sorted)}\n\n")

        for a in alerts_sorted[:25]:
            f.write(
                f"- {a['symbol']} | {a['decision']} | grade={a['grade']} | {a['pattern']} "
                f"| entry={a['entry']} stop={a['stop']} t1={a['t1']} t2={a['t2']}\n"
            )

        f.write("\nStatus changes:\n")
        if not status_changes:
            f.write("- none\n")
        else:
            for sc in status_changes:
                f.write(
                    f"- {sc['symbol']}: {sc['old']} -> {sc['new']} "
                    f"(grade={sc['grade']} pattern={sc['pattern']})\n"
                )

    log(f"Run complete. Summary written to: {summary_path}")



if __name__ == "__main__":
    main()