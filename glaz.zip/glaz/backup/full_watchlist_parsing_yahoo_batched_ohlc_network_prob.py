#!/usr/bin/env python3
"""
full_watchlist_parsing.py (Yahoo Finance + mplfinance version)

Replaces Chart-IMG with:
- yfinance: download 1y daily OHLCV
- mplfinance: render candlestick+volume chart to PNG bytes
Then sends PNG to OpenAI Vision exactly like before.

Dependencies:
  python -m pip install openai gspread google-auth yfinance mplfinance pandas matplotlib httpx

Env vars (recommended):
  OPENAI_API_KEY=...
  SHEET_ID=...
Optional:
  SERVICE_ACCOUNT_JSON=...
  OPENAI_MODEL=...
  RUN_MODE=daily|weekly
"""

from __future__ import annotations

import base64
import datetime as dt
import io
import json
import os
import re
import time
import random
import httpx
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import gspread
import gspread.utils
import pandas as pd
import yfinance as yf
import mplfinance as mpf
from google.oauth2.service_account import Credentials
from openai import OpenAI, APIConnectionError, APITimeoutError, RateLimitError, APIError

import socket
import requests
# =========================
# CONFIG
# =========================

# ---- Google Sheets
SHEET_ID = os.getenv("SHEET_ID", "1SnJXykwwbZL8Okv02D1XGAgrsl7MKyaO05f7c9Z63Fg")
SERVICE_ACCOUNT_JSON = os.getenv("SERVICE_ACCOUNT_JSON", "auto-trading-481921-980bcad6baf5.json")
WATCHLIST_TAB = "Watchlist"
HISTORY_TAB = "DailySignals"

# ---- Chart rendering (local)
LOOKBACK_PERIOD = os.getenv("LOOKBACK_PERIOD", "1y")  # e.g. 6mo, 1y, 2y
INTERVAL = "1d"

# mplfinance render settings (affect readability + OpenAI image tokens)
FIGSIZE = (8, 6)   # inches
DPI = 150          # 120–180 is a good range

# ---- OpenAI
OPENAI_MODEL = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")
OPENAI_TIMEOUT_SEC = 180

# ---- Runtime
OUTPUT_DIR = Path("output")
SAVE_CHARTS = True
SLEEP_BETWEEN_SYMBOLS_SEC = 0.5

# ---- Strategy constraints (hard filters)
MAX_STOP_PCT = 0.02     # 2%
MIN_TARGET1_PCT = 0.05  # 5%
MAX_HOLD_DAYS = 20      # ~1 month trading days

# ---- Run mode
RUN_MODE = os.getenv("RUN_MODE", "daily").strip().lower()
if RUN_MODE not in ("daily", "weekly"):
    RUN_MODE = "daily"

# ---- Watchlist headers (auto-added if missing)
WATCHLIST_HEADERS = [
    # input controls
    "symbol",
    "enabled",
    "min_grade",
    "only_alert_if_trade",
    "update_only_on_change",

    # primary outputs
    "last_run",
    "decision",
    "grade_0_10",
    "pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",

    # status tracking
    "last_status",
    "last_grade",
    "last_pattern",
    "last_signal_ts",
    "last_change_ts",
]

HISTORY_HEADERS = [
    "run_ts",
    "mode",
    "symbol",
    "decision",
    "grade_0_10",
    "best_pattern",
    "entry",
    "stop",
    "t1",
    "t2",
    "notes",
    "raw_json",
]

# =========================
# PROMPTS
# =========================

BASE_PROMPT = f"""
You evaluate daily stock charts using Bulkowski-style chart patterns with highest probability of success.
LONG trades only.

Constraints:
- Timeframe: Daily
- Lookback: last {LOOKBACK_PERIOD} (as shown in the chart image)
- Max holding time: 1 month (about {MAX_HOLD_DAYS} trading days)
- Target: +5% to +10%
- Stop loss: -1% to -2% (flag NO_TRADE if unrealistic given volatility/structure)

Return STRICT JSON only with exactly this schema:
{{
  "symbol": "EXCHANGE:TICKER",
  "pattern_candidates": [
    {{"name": "string", "confidence_0_100": 0, "breakout_level": 0.0, "invalidation_level": 0.0}}
  ],
  "entry_plan": {{
    "decision": "TRADE" or "NO_TRADE",
    "trigger": "string",
    "entry_price": 0.0,
    "stop_price": 0.0,
    "target_price_1": 0.0,
    "target_price_2": 0.0,
    "time_stop_days": {MAX_HOLD_DAYS}
  }},
  "risk_notes": ["string"],
  "grade_0_10": 0,
  "no_trade_if": ["string"]
}}
""".strip()

DAILY_INSTRUCTIONS = """
Mode: DAILY EXECUTION SCAN
- Be strict: Only set decision=TRADE if breakout/trigger is actionable now or next 1–2 sessions.
- Require stop to be structurally valid and within 1–2% (otherwise NO_TRADE).
- Prefer patterns that can plausibly deliver +5% within 1 month before major resistance.
""".strip()

WEEKLY_INSTRUCTIONS = """
Mode: WEEKLY SETUP SCAN
- Identify if a high-quality Bulkowski-style setup is forming or close to a valid trigger.
- It's OK if entry isn't today, but only mark TRADE if trigger is very close (near breakout level).
- Still respect the stop realism: if 1–2% stop is not realistic, prefer NO_TRADE and explain.
""".strip()

PROMPT_BY_MODE = {
    "daily": BASE_PROMPT + "\n\n" + DAILY_INSTRUCTIONS,
    "weekly": BASE_PROMPT + "\n\n" + WEEKLY_INSTRUCTIONS,
}


# =========================
# HELPERS
# =========================

def now_str_local() -> str:
    return dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

def today_iso() -> str:
    return dt.date.today().isoformat()

def safe_filename(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9._-]+", "_", s)
    return s.strip("_") or "item"

def png_bytes_to_data_url(png_bytes: bytes) -> str:
    b64 = base64.b64encode(png_bytes).decode("ascii")
    return f"data:image/png;base64,{b64}"

def to_float(x: Any) -> Optional[float]:
    try:
        if x is None:
            return None
        if isinstance(x, (int, float)):
            return float(x)
        s = str(x).strip()
        if s == "":
            return None
        return float(s)
    except Exception:
        return None

def truthy(x: Any, default: bool = False) -> bool:
    if x is None:
        return default
    s = str(x).strip().upper()
    if s == "":
        return default
    return s in ("TRUE", "YES", "1", "Y")

def to_int(x: Any, default: int) -> int:
    try:
        if x is None:
            return default
        s = str(x).strip()
        if s == "":
            return default
        return int(float(s))
    except Exception:
        return default


# =========================
# GOOGLE SHEETS
# =========================

def connect_sheets() -> Tuple[gspread.Worksheet, gspread.Worksheet]:
    scopes = ["https://www.googleapis.com/auth/spreadsheets"]
    creds = Credentials.from_service_account_file(SERVICE_ACCOUNT_JSON, scopes=scopes)
    gc = gspread.authorize(creds)
    sh = gc.open_by_key(SHEET_ID)

    ws_watch = sh.worksheet(WATCHLIST_TAB)

    try:
        ws_hist = sh.worksheet(HISTORY_TAB)
    except gspread.WorksheetNotFound:
        ws_hist = sh.add_worksheet(title=HISTORY_TAB, rows=2000, cols=30)
        ws_hist.append_row(HISTORY_HEADERS)

    return ws_watch, ws_hist

def ensure_headers(ws: gspread.Worksheet, required_headers: List[str]) -> Dict[str, int]:
    values = ws.get_all_values()
    if not values:
        ws.append_row(required_headers)
        header_row = required_headers
    else:
        header_row = values[0]

    col_map = {h.strip().lower(): i for i, h in enumerate(header_row, start=1)}
    missing = [h for h in required_headers if h.lower() not in col_map]
    if missing:
        new_headers = header_row + missing
        ws.update("1:1", [new_headers])
        col_map = {h.strip().lower(): i for i, h in enumerate(new_headers, start=1)}
    return col_map

def get_cell(row: List[str], col_map: Dict[str, int], name: str) -> str:
    c = col_map[name.lower()]
    return row[c - 1].strip() if c - 1 < len(row) else ""

def set_cell(ws: gspread.Worksheet, row_index: int, col: int, val: Any) -> None:
    """Single-cell write (kept for rare cases). Prefer batch_update_cells()."""
    ws.update_cell(row_index, col, "" if val is None else str(val))

def batch_update_cells(ws: gspread.Worksheet, row_index: int, updates: List[Tuple[int, Any]]) -> None:
    """Batch update many cells in ONE Sheets API write request."""
    if not updates:
        return
    payload = []
    for col, val in updates:
        a1 = gspread.utils.rowcol_to_a1(row_index, col)
        payload.append({"range": a1, "values": [["" if val is None else str(val)]]})
    ws.batch_update(payload)


# =========================
# YFINANCE + MPLFINANCE (replaces Chart-IMG)
# =========================

def symbol_to_yf_ticker(symbol: str) -> str:
    """
    Converts 'NASDAQ:AAPL' -> 'AAPL'
    Keeps already-Yahoo-style tickers as-is.
    """
    s = symbol.strip()
    if ":" in s:
        return s.split(":")[-1].strip()
    return s

def yf_download_ohlcv(yf_ticker: str) -> pd.DataFrame:
    df = yf.download(
        tickers=yf_ticker,
        period=LOOKBACK_PERIOD,
        interval=INTERVAL,
        auto_adjust=False,
        group_by="column",
        progress=False,
        threads=False,
    )
    if df is None or df.empty:
        raise RuntimeError(f"No Yahoo Finance data returned for ticker={yf_ticker}")

    # If MultiIndex columns exist, flatten them (robust handling)
    if isinstance(df.columns, pd.MultiIndex):
        levels0 = set(map(str, df.columns.get_level_values(0)))
        levels1 = set(map(str, df.columns.get_level_values(-1)))
        ohlcv = {"Open", "High", "Low", "Close", "Volume", "Adj Close"}

        if len(levels0 & ohlcv) >= 3:
            df.columns = df.columns.get_level_values(0)
        elif len(levels1 & ohlcv) >= 3:
            df.columns = df.columns.get_level_values(-1)
        else:
            df.columns = ["_".join(map(str, c)) for c in df.columns.to_list()]

    df = df.rename(columns={c: str(c).strip() for c in df.columns})

    required = ["Open", "High", "Low", "Close", "Volume"]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise RuntimeError(f"Missing OHLCV columns {missing}. Got columns: {list(df.columns)}")

    df = df[required].copy()

    # Force numeric
    for col in required:
        s = df[col]
        if not isinstance(s, pd.Series):
            s = s.squeeze()
        df[col] = pd.to_numeric(s, errors="coerce")

    df = df.dropna()
    df.index = pd.to_datetime(df.index)
    return df

def render_chart_png_bytes(ohlcv: pd.DataFrame, title: str = "") -> bytes:
    # Return matplotlib figure so we can save into bytes.
    fig, _axes = mpf.plot(
        ohlcv,
        type="candle",
        style="yahoo",
        volume=True,
        figsize=FIGSIZE,
        title=title or None,
        returnfig=True,
    )

    buf = io.BytesIO()
    fig.savefig(buf, format="png", dpi=DPI, bbox_inches="tight")
    # Avoid memory leak when looping many tickers
    try:
        import matplotlib.pyplot as plt
        plt.close(fig)
    except Exception:
        pass

    return buf.getvalue()

def fetch_chart_png(symbol: str) -> bytes:
    yf_ticker = symbol_to_yf_ticker(symbol)
    df = yf_download_ohlcv(yf_ticker)
    return render_chart_png_bytes(df, title=symbol)



def ohlcv_to_compact_json(df: pd.DataFrame, max_rows: int = 260) -> str:
    """Serialize the last max_rows OHLCV bars into compact JSON to keep payload small."""
    d = df.tail(max_rows).copy()
    # Round prices to reduce token size while keeping precision for pattern logic
    for col in ["Open", "High", "Low", "Close"]:
        d[col] = d[col].round(2)
    # Ensure int volume
    d["Volume"] = d["Volume"].astype("int64")

    rows = []
    for idx, r in d.iterrows():
        rows.append({
            "date": idx.strftime("%Y-%m-%d"),
            "o": float(r["Open"]),
            "h": float(r["High"]),
            "l": float(r["Low"]),
            "c": float(r["Close"]),
            "v": int(r["Volume"]),
        })
    return json.dumps(rows, separators=(",", ":"))


# =========================
# OPENAI
# =========================

def openai_client() -> OpenAI:
    """Create an OpenAI client with HTTP/2 disabled for improved stability on Cloud Run."""
    api_key = os.getenv("OPENAI_API_KEY")
    print("--- API KEY: ---")
    print(api_key)
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY is not set in the environment.")

    # Force HTTP/1.1 (disable HTTP/2). This can reduce intermittent connection errors in some serverless networks.
    http_client = httpx.Client(
        http2=False,
        timeout=httpx.Timeout(OPENAI_TIMEOUT_SEC, connect=30.0),
        headers={"Connection": "close"},
    )

    return OpenAI(
        api_key=api_key,
        http_client=http_client,
        max_retries=5,  # SDK-level retries for transient network errors
    )

def analyze_ohlcv(symbol: str, ohlcv_df: pd.DataFrame, client: OpenAI) -> Dict[str, Any]:
    """Text-only analysis (no image): send compact OHLCV JSON to the model."""
    prompt = PROMPT_BY_MODE[RUN_MODE]
    ohlcv_json = ohlcv_to_compact_json(ohlcv_df, max_rows=260)

    data_prompt = (
        f"Symbol: {symbol}\n\n"
        f"You are given DAILY OHLCV bars as a JSON array of objects with keys: "
        f"date,o,h,l,c,v (open/high/low/close/volume).\n"
        f"Use this OHLCV data (not an image) to detect Bulkowski-style chart patterns "
        f"and propose a LONG trade plan that follows the constraints.\n\n"
        f"OHLCV_JSON:\n{ohlcv_json}"
    )

    max_attempts = 5
    base_sleep = 1.5

    for attempt in range(1, max_attempts + 1):
        try:
            resp = client.responses.create(
                model=OPENAI_MODEL,
                input=[{
                    "role": "user",
                    "content": [
                        {"type": "input_text", "text": data_prompt + "\n\n" + prompt},
                    ],
                }],
                timeout=OPENAI_TIMEOUT_SEC,
            )

            text = (resp.output_text or "").strip()
            if not text:
                raise RuntimeError("OpenAI returned empty output_text.")

            try:
                return json.loads(text)
            except json.JSONDecodeError:
                m = re.search(r"\{.*\}", text, flags=re.DOTALL)
                if not m:
                    raise RuntimeError(f"OpenAI output not JSON:\n{text[:1200]}")
                return json.loads(m.group(0))

        except (APIConnectionError, APITimeoutError, RateLimitError, APIError) as e:
            if attempt == max_attempts:
                raise
            sleep_s = base_sleep * (2 ** (attempt - 1)) + random.uniform(0, 0.5)
            print(
                f"[{now_str_local()}] {symbol}: OpenAI transient error ({type(e).__name__}). "
                f"Retry {attempt}/{max_attempts} in {sleep_s:.1f}s"
            )
            time.sleep(sleep_s)


# =========================
# POST-FILTERS (enforce your plan)
# =========================

def enforce_plan_filters(result: Dict[str, Any]) -> Tuple[Dict[str, Any], List[str]]:
    notes: List[str] = []
    entry_plan = result.get("entry_plan") or {}
    decision = str(entry_plan.get("decision", "")).upper().strip()

    entry = to_float(entry_plan.get("entry_price"))
    stop = to_float(entry_plan.get("stop_price"))
    t1 = to_float(entry_plan.get("target_price_1"))
    t2 = to_float(entry_plan.get("target_price_2"))

    if decision == "TRADE":
        if entry is None or stop is None or t1 is None or t2 is None:
            notes.append("Missing prices in entry_plan; forcing NO_TRADE.")
            decision = "NO_TRADE"

    if decision == "TRADE" and entry and stop:
        stop_pct = (entry - stop) / entry
        if stop_pct <= 0:
            notes.append("Stop is not below entry for LONG; forcing NO_TRADE.")
            decision = "NO_TRADE"
        elif stop_pct > MAX_STOP_PCT:
            notes.append(f"Stop distance {stop_pct*100:.2f}% > {MAX_STOP_PCT*100:.2f}% max; forcing NO_TRADE.")
            decision = "NO_TRADE"

    if decision == "TRADE" and entry and t1:
        t1_pct = (t1 - entry) / entry
        if t1_pct < MIN_TARGET1_PCT:
            notes.append(f"Target1 gain {t1_pct*100:.2f}% < {MIN_TARGET1_PCT*100:.2f}% min; forcing NO_TRADE.")
            decision = "NO_TRADE"

    entry_plan["decision"] = "TRADE" if decision == "TRADE" else "NO_TRADE"
    result["entry_plan"] = entry_plan

    if notes:
        rn = list(result.get("risk_notes") or [])
        rn += [f"[PLAN_FILTER] {n}" for n in notes]
        result["risk_notes"] = rn

        nt = list(result.get("no_trade_if") or [])
        nt += [f"[PLAN_FILTER] {n}" for n in notes]
        result["no_trade_if"] = nt

    return result, notes


# =========================
# EXTRA POLICY: alert threshold + status change logic
# =========================

def best_pattern(result: Dict[str, Any]) -> str:
    pats = result.get("pattern_candidates") or []
    if not pats:
        return ""
    return str((pats[0] or {}).get("name", "")).strip()

def entry_fields(result: Dict[str, Any]) -> Tuple[Any, Any, Any, Any]:
    ep = result.get("entry_plan") or {}
    return ep.get("entry_price", ""), ep.get("stop_price", ""), ep.get("target_price_1", ""), ep.get("target_price_2", "")

def normalize_decision(result: Dict[str, Any]) -> str:
    ep = result.get("entry_plan") or {}
    return str(ep.get("decision", "")).upper().strip() or "NO_TRADE"

def grade_val(result: Dict[str, Any]) -> int:
    g = result.get("grade_0_10", 0)
    try:
        return int(float(g))
    except Exception:
        return 0

def passes_user_thresholds(result: Dict[str, Any], min_grade: int, only_alert_if_trade: bool) -> bool:
    d = normalize_decision(result)
    g = grade_val(result)
    if g < min_grade:
        return False
    if only_alert_if_trade and d != "TRADE":
        return False
    return True

def status_changed(old_status: str, new_status: str) -> bool:
    return (old_status or "").strip().upper() != (new_status or "").strip().upper()


# =========================
# WATCHLIST WRITEBACK + HISTORY
# =========================

def build_watchlist_writeback(result: Dict[str, Any]) -> Dict[str, Any]:
    decision = normalize_decision(result)
    grade = result.get("grade_0_10", "")
    entry, stop, t1, t2 = entry_fields(result)

    rn = result.get("risk_notes") or []
    nt = result.get("no_trade_if") or []
    notes_parts: List[str] = []
    if isinstance(rn, list) and rn:
        notes_parts.append("Risk: " + " | ".join(map(str, rn[:6])))
    if decision == "NO_TRADE" and isinstance(nt, list) and nt:
        notes_parts.append("NoTradeIf: " + " | ".join(map(str, nt[:6])))

    return {
        "last_run": now_str_local(),
        "decision": decision,
        "grade_0_10": grade,
        "pattern": best_pattern(result),
        "entry": entry,
        "stop": stop,
        "t1": t1,
        "t2": t2,
        "notes": " || ".join(notes_parts),
        "raw_json": json.dumps(result, ensure_ascii=False),
    }

def update_watchlist_row(
    ws_watch: gspread.Worksheet,
    col_map: Dict[str, int],
    row_index: int,
    wb: Dict[str, Any],
    status_fields: Dict[str, Any],
    do_update: bool
) -> None:
    if not do_update:
        return

    updates: List[Tuple[int, Any]] = []
    for k, v in {**wb, **status_fields}.items():
        ck = k.lower()
        if ck in col_map:
            updates.append((col_map[ck], v))
    batch_update_cells(ws_watch, row_index, updates)

def build_history_row(result: Dict[str, Any]) -> List[Any]:
    """Build one history row to later append in a single batch."""
    decision = normalize_decision(result)
    grade = result.get("grade_0_10", "")
    pat = best_pattern(result)
    entry, stop, t1, t2 = entry_fields(result)

    rn = result.get("risk_notes") or []
    nt = result.get("no_trade_if") or []
    notes_parts: List[str] = []
    if isinstance(rn, list) and rn:
        notes_parts.append("Risk: " + " | ".join(map(str, rn[:6])))
    if decision == "NO_TRADE" and isinstance(nt, list) and nt:
        notes_parts.append("NoTradeIf: " + " | ".join(map(str, nt[:6])))

    return [
        now_str_local(),
        RUN_MODE,
        result.get("symbol", ""),
        decision,
        grade,
        pat,
        entry,
        stop,
        t1,
        t2,
        " || ".join(notes_parts),
        json.dumps(result, ensure_ascii=False),
    ]


# =========================
# NETWORK PROBE
# =========================



def network_probe():
    print("--- STARTING NETWORK PROBE ---")
    # Test 1: DNS Lookup
    try:
        ip = socket.gethostbyname("api.openai.com")
        print(f"DNS Check: api.openai.com resolved to {ip}")
    except Exception as e:
        print(f"DNS Check FAILED: Could not resolve OpenAI domain. {e}")

    # Test 2: Basic HTTP Reachability
    try:
        r = requests.get("https://api.openai.com/v1/models", timeout=5)
        print(f"HTTP Check: OpenAI reached. Status: {r.status_code}")
    except Exception as e:
        print(f"HTTP Check FAILED: {e}")
    print("--- END NETWORK PROBE ---")



# =========================
# MAIN
# =========================

def main() -> None:

    network_probe()
    
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    logs_dir = OUTPUT_DIR / "logs"
    logs_dir.mkdir(parents=True, exist_ok=True)

    charts_dir = OUTPUT_DIR / "charts" / today_iso()
    if SAVE_CHARTS:
        charts_dir.mkdir(parents=True, exist_ok=True)

    log_path = logs_dir / f"run_{today_iso()}_{RUN_MODE}.log"
    summary_path = OUTPUT_DIR / f"summary_{today_iso()}_{RUN_MODE}.txt"

    def log(msg: str) -> None:
        line = f"[{now_str_local()}] {msg}"
        print(line)
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line + "\n")

    if not SHEET_ID or SHEET_ID.startswith("PUT_YOUR"):
        raise RuntimeError("SHEET_ID not set (env SHEET_ID or edit script).")

    ws_watch, ws_hist = connect_sheets()
    col_map = ensure_headers(ws_watch, WATCHLIST_HEADERS)
    ensure_headers(ws_hist, HISTORY_HEADERS)

    rows = ws_watch.get_all_values()
    if len(rows) < 2:
        log("Watchlist has no rows.")
        return

    client = openai_client()

    alerts: List[Dict[str, Any]] = []
    status_changes: List[Dict[str, Any]] = []
    history_buffer: List[List[Any]] = []  # appended in one batch at end
    last_run_payload: List[Dict[str, Any]] = []  # batch update last_run for unchanged rows

    log(f"Run start: mode={RUN_MODE} symbols_rows={len(rows)-1} model={OPENAI_MODEL}")

    for r_idx in range(2, len(rows) + 1):
        row = rows[r_idx - 1]

        symbol = get_cell(row, col_map, "symbol")
        enabled = get_cell(row, col_map, "enabled")
        if not symbol or not truthy(enabled, default=False):
            continue

        min_grade = to_int(get_cell(row, col_map, "min_grade"), default=7)
        only_alert_if_trade = truthy(get_cell(row, col_map, "only_alert_if_trade"), default=True)
        update_only_on_change = truthy(get_cell(row, col_map, "update_only_on_change"), default=True)

        old_status = get_cell(row, col_map, "last_status")

        safe_sym = safe_filename(symbol)

        try:
            log(f"{symbol}: downloading OHLCV from Yahoo Finance...")
            yf_ticker = symbol_to_yf_ticker(symbol)
            df = yf_download_ohlcv(yf_ticker)

            # Optional: still render and save chart for your own review
            if SAVE_CHARTS:
                png = render_chart_png_bytes(df, title=symbol)
                chart_path = charts_dir / f"{safe_sym}.png"
                chart_path.write_bytes(png)

            log(f"{symbol}: analyzing (text-only OHLCV)...")
            result = analyze_ohlcv(symbol, df, client)

            # Enforce plan constraints
            result, filter_notes = enforce_plan_filters(result)
            if filter_notes:
                log(f"{symbol}: plan filters -> {filter_notes}")

            decision = normalize_decision(result)
            g = grade_val(result)
            pat = best_pattern(result)

            wb = build_watchlist_writeback(result)

            changed = status_changed(old_status, decision)
            status_fields: Dict[str, Any] = {
                "last_status": decision,
                "last_grade": g,
                "last_pattern": pat,
            }
            if changed:
                status_fields["last_change_ts"] = now_str_local()
                status_changes.append({"symbol": symbol, "old": old_status, "new": decision, "grade": g, "pattern": pat})
            if decision == "TRADE":
                status_fields["last_signal_ts"] = now_str_local()

            do_update = True
            if update_only_on_change and not changed:
                do_update = False
                last_run_payload.append({"range": gspread.utils.rowcol_to_a1(r_idx, col_map["last_run"]), "values": [[now_str_local()]]})

            if not do_update:
                log(f"{symbol}: unchanged ({decision}); skipped writeback (except last_run).")
            else:
                update_watchlist_row(ws_watch, col_map, r_idx, wb, status_fields, do_update=True)
                log(f"{symbol}: updated. decision={decision} grade={g} pattern={pat}")

            if passes_user_thresholds(result, min_grade=min_grade, only_alert_if_trade=only_alert_if_trade):
                entry, stop, t1, t2 = entry_fields(result)
                alerts.append({"symbol": symbol, "decision": decision, "grade": g, "pattern": pat, "entry": entry, "stop": stop, "t1": t1, "t2": t2})

            history_buffer.append(build_history_row(result))

        except Exception as e:
            err = f"{type(e).__name__}: {e}"
            log(f"{symbol}: ERROR -> {err}")

            fail_updates = {
                "last_run": now_str_local(),
                "decision": "ERROR",
                "notes": err,
                "last_status": "ERROR",
                "last_change_ts": now_str_local(),
            }
            update_watchlist_row(ws_watch, col_map, r_idx, fail_updates, {}, do_update=True)

        time.sleep(SLEEP_BETWEEN_SYMBOLS_SEC)

    
    # Batch update last_run for unchanged rows (ONE write request)
    if last_run_payload:
        ws_watch.batch_update(last_run_payload)

    # Append history rows in ONE write request (avoids Sheets write quota issues)
    if history_buffer:
        ws_hist.append_rows(history_buffer, value_input_option="RAW")


    alerts_sorted = sorted(alerts, key=lambda x: (x["decision"] != "TRADE", -int(x["grade"])))
    with open(summary_path, "w", encoding="utf-8") as f:
        f.write(f"Run summary ({RUN_MODE}) @ {now_str_local()}\n")
        f.write(f"Lookback: {LOOKBACK_PERIOD}  Interval: {INTERVAL}\n")
        f.write(f"Alerts (after min_grade + only_alert_if_trade filters): {len(alerts_sorted)}\n\n")
        for a in alerts_sorted[:25]:
            f.write(
                f"- {a['symbol']} | {a['decision']} | grade={a['grade']} | {a['pattern']} "
                f"| entry={a['entry']} stop={a['stop']} t1={a['t1']} t2={a['t2']}\n"
            )

        f.write("\nStatus changes:\n")
        if not status_changes:
            f.write("- none\n")
        else:
            for sc in status_changes:
                f.write(f"- {sc['symbol']}: {sc['old']} -> {sc['new']} (grade={sc['grade']} pattern={sc['pattern']})\n")

    log(f"Run complete. Summary written to: {summary_path}")


if __name__ == "__main__":
    main()
